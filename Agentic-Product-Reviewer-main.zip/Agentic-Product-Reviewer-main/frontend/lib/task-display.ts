import type { TaskOut } from "@/lib/api";

const ACTIVE_STATES = new Set([
  "created",
  "planning",
  "executing",
  "recovering",
  "paused",
  "waiting_for_user",
  "waiting_for_approval",
]);

export function isActive(task: TaskOut): boolean {
  return ACTIVE_STATES.has(task.state);
}

export function isHistorical(task: TaskOut): boolean {
  return !ACTIVE_STATES.has(task.state);
}

export function formatElapsed(startIso: string | null, endIso: string | null = null): string {
  if (!startIso) return "—";
  const start = new Date(startIso).getTime();
  const end = endIso ? new Date(endIso).getTime() : Date.now();
  const sec = Math.max(0, Math.floor((end - start) / 1000));
  const mm = String(Math.floor(sec / 60)).padStart(2, "0");
  const ss = String(sec % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

export function formatWhen(iso: string): string {
  const t = new Date(iso).getTime();
  const diff = Date.now() - t;
  const min = Math.floor(diff / 60_000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day === 1) return "Yest.";
  if (day < 7) return `${day}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function siteFromIntent(intent: Record<string, unknown>): string {
  const site = intent?.site;
  if (typeof site === "string" && site) return site;
  const domain = intent?.domain;
  if (typeof domain === "string" && domain) return domain;
  return "—";
}

export function shortId(id: string): string {
  return `T-${id.slice(0, 4).toUpperCase()}`;
}

export const STATE_COLOR: Record<string, string> = {
  completed: "#C4F0C8",
  recovering: "#E8D2B4",
  waiting_for_approval: "#E8D2B4",
  waiting_for_user: "#E8D2B4",
  paused: "#E8D2B4",
  failed: "#E8B4B4",
  cancelled: "#A1A1A6",
};

export function outcomeFromState(state: string): string {
  if (state === "completed") return "COMPLETED";
  if (state === "failed") return "FAILED";
  if (state === "cancelled") return "CANCELLED";
  return state.toUpperCase();
}
