// Local (unverified) JWT payload decode — display-only. The backend is the
// actual verifier; this just reads the `exp` claim so the UI can warn before
// a pasted/paired token goes stale, instead of surfacing a raw 401 later.

export function decodeJwtExpiry(token: string): Date | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  try {
    const payloadJson = atob(parts[1].replace(/-/g, "+").replace(/_/g, "/"));
    const payload = JSON.parse(payloadJson) as { exp?: number };
    if (typeof payload.exp !== "number") return null;
    return new Date(payload.exp * 1000);
  } catch {
    return null;
  }
}

export function formatExpiry(expiry: Date | null): string {
  if (!expiry) return "unknown expiry";
  const ms = expiry.getTime() - Date.now();
  if (ms <= 0) return "expired";
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  if (days >= 1) return `expires in ${days} day${days === 1 ? "" : "s"}`;
  const hours = Math.floor(ms / (1000 * 60 * 60));
  if (hours >= 1) return `expires in ${hours} hour${hours === 1 ? "" : "s"}`;
  return "expires soon";
}
