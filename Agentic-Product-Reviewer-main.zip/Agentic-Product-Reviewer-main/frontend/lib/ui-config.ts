/**
 * Static product configuration — NOT mock data.
 *
 * Lives here because it shapes the product (nav structure, mode descriptions,
 * suggested prompts) rather than representing user state. User state always
 * comes from the backend via lib/api.ts.
 */

export const SUGGESTED_TASKS = [
  {
    icon: "⛁",
    title: "Build a grocery cart",
    hint: "Weekly groceries within your budget",
    goal: "Build a high-protein vegetarian grocery cart for 7 days under ₹1500",
  },
  {
    icon: "✈",
    title: "Plan a trip",
    hint: "Flights and hotels within your rules",
    goal: "Find round-trip flights from Bangalore to Mumbai next weekend, morning departure, under ₹8000",
  },
  {
    icon: "⌘",
    title: "Apply for jobs",
    hint: "Fill applications using your résumé",
    goal: "Find 5 AI engineering internships in Bangalore on LinkedIn and draft application notes",
  },
  {
    icon: "✎",
    title: "Fill a long form",
    hint: "Sign-ups, registrations, applications",
    goal: "Fill the passport renewal application form using my saved identity details",
  },
  {
    icon: "⇌",
    title: "Compare products",
    hint: "Across multiple sites, your criteria",
    goal: "Compare noise-cancelling headphones under ₹15000 across 4 sites and recommend one",
  },
  {
    icon: "✉",
    title: "Triage my email",
    hint: "Read, summarize, draft replies",
    goal: "Open Gmail, summarize the last 10 unread emails and draft reply suggestions",
  },
  {
    icon: "◷",
    title: "Book an appointment",
    hint: "Doctor, salon, restaurant",
    goal: "Find an available dentist appointment in Mumbai next week, morning slot",
  },
  {
    icon: "▶",
    title: "Book event tickets",
    hint: "Movies, concerts, shows",
    goal: "Find two tickets to a movie tonight after 7pm at a PVR cinema near me",
  },
] as const;

export const SIDEBAR_ITEMS = [
  { key: "active", label: "Active Tasks", icon: "◐", href: "/dashboard" },
  { key: "playbooks", label: "Playbooks", icon: "⎘", href: "/playbooks" },
  { key: "memory", label: "Memory", icon: "▢", href: "/settings" },
  { key: "logs", label: "Logs", icon: "☰", href: "/dashboard" },
  { key: "settings", label: "Settings", icon: "⚙", href: "/settings" },
] as const;

export const SETTINGS_NAV = [
  { key: "safety", label: "Safety & approvals", icon: "⚠" },
  { key: "accounts", label: "Connected accounts", icon: "◎" },
  { key: "vault", label: "Vault", icon: "⚿" },
  { key: "memory", label: "Memory", icon: "▢" },
  { key: "model", label: "Model", icon: "◇" },
  { key: "browser", label: "Browser mode", icon: "◰" },
  { key: "connect", label: "Connect your browser", icon: "⇄" },
  { key: "billing", label: "Plan & billing", icon: "⌐" },
] as const;

export const BROWSER_MODE_OPTIONS = [
  {
    key: "browser",
    title: "Agent Browser",
    desc: "Argus drives the shared connected browser with DOM refs + vision. Accurate on real sites, no extra windows.",
    meta: "DEFAULT",
  },
  {
    key: "structured",
    title: "Structured",
    desc: "DOM refs only on the shared browser — fastest, for predictable sites.",
    meta: "FAST PATH",
  },
  {
    key: "vision",
    title: "Vision fallback",
    desc: "Screenshot reasoning first, for layouts where pixels matter most.",
    meta: "PIXEL-FIRST",
  },
  {
    key: "v2",
    title: "Your real browser",
    desc: "Argus acts inside YOUR connected browser (extension or bookmarklet) — your real logged-in sessions, auto-fill from memory.",
    meta: "V2",
  },
] as const;

export const APPROVAL_RULE_DEFINITIONS = [
  {
    key: "payment",
    title: "Payment or checkout",
    desc: "Anything that charges a card or completes a purchase.",
    lock: true,
  },
  {
    key: "identity",
    title: "Submitting forms with identity",
    desc: "Government, financial, or employment forms.",
    lock: true,
  },
  {
    key: "spend_over",
    title: "Spending over a limit",
    desc: "Per task. Adjustable in Plan & billing.",
    lock: false,
  },
  {
    key: "post_on_behalf",
    title: "Posting on my behalf",
    desc: "Reviews, comments, messages, applications.",
    lock: false,
  },
  {
    key: "new_site",
    title: "Connecting a new website",
    desc: "First time Argus uses an unseen site.",
    lock: false,
  },
] as const;
