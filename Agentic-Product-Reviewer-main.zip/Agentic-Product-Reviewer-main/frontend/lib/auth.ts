import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000";

type BackendUser = {
  id: string;
  email: string | null;
  name: string | null;
  avatar_url: string | null;
  email_verified: boolean;
};

type BackendToken = {
  access_token: string;
  token_type: string;
  user: BackendUser;
};

async function backendLogin(email: string, password: string): Promise<BackendToken | null> {
  const res = await fetch(`${BACKEND_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
    cache: "no-store",
  });
  if (!res.ok) return null;
  return (await res.json()) as BackendToken;
}

async function backendGoogle(idToken: string): Promise<BackendToken | null> {
  const res = await fetch(`${BACKEND_URL}/auth/google`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id_token: idToken }),
    cache: "no-store",
  });
  if (!res.ok) return null;
  return (await res.json()) as BackendToken;
}

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Email",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials.password) return null;
        const token = await backendLogin(credentials.email, credentials.password);
        if (!token) return null;
        return {
          id: token.user.id,
          email: token.user.email ?? undefined,
          name: token.user.name ?? undefined,
          image: token.user.avatar_url ?? undefined,
          backendAccessToken: token.access_token,
        };
      },
    }),
    ...(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
      ? [
          GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          }),
        ]
      : []),
  ],
  callbacks: {
    async signIn({ account, user }) {
      if (account?.provider === "google" && account.id_token) {
        const token = await backendGoogle(account.id_token);
        if (!token) return false;
        (user as { backendAccessToken?: string; id: string }).backendAccessToken = token.access_token;
        (user as { id: string }).id = token.user.id;
        return true;
      }
      return true;
    },
    async jwt({ token, user }) {
      if (user) {
        token.userId = (user as { id?: string }).id;
        token.backendAccessToken = (user as { backendAccessToken?: string }).backendAccessToken;
      }
      return token;
    },
    async session({ session, token }) {
      session.user = {
        ...(session.user ?? {}),
        id: token.userId ?? "",
      };
      session.backendAccessToken = token.backendAccessToken;
      return session;
    },
  },
};
