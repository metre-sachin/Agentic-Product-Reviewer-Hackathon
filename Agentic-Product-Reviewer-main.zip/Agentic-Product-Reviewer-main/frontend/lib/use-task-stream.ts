"use client";

import { useEffect, useRef, useState } from "react";
import { getSession } from "next-auth/react";
import type { TaskActionOut, TaskDetailOut, TaskLogOut, TaskStepOut } from "@/lib/api";

export type ApprovalEvent = {
  id: string;
  step_id: string;
  reason: string;
  summary: Record<string, unknown>;
  state: string;
};

export type RecoveryEvent = {
  id: string;
  step_id: string;
  from_layer: string;
  to_layer: string;
  cause: string;
};

export type AssistEvent = {
  step_id: string;
  step_label: string;
  question: string;
};

export type CredentialsEvent = {
  step_id: string;
  domain: string;
};

export type OtpEvent = {
  step_id: string;
  domain: string;
};

export type CaptchaEvent = {
  step_id: string;
  domain: string;
  screenshot: string | null;
};

export type InfoField = {
  id: string;
  label: string;
  kind: string;
};

export type InfoEvent = {
  step_id: string;
  domain: string;
  fields: InfoField[];
};

export type TaskStreamState = {
  task: TaskDetailOut | null;
  steps: TaskStepOut[];
  logs: TaskLogOut[];
  actions: TaskActionOut[];
  state: string;
  approval: ApprovalEvent | null;
  recovery: RecoveryEvent | null;
  recoveryCount: number;
  assist: AssistEvent | null;
  credentials: CredentialsEvent | null;
  otp: OtpEvent | null;
  captcha: CaptchaEvent | null;
  info: InfoEvent | null;
  screenshotUrl: string | null;
  screenshots: string[];
  connected: boolean;
};

const ACTIVE = new Set([
  "created",
  "planning",
  "executing",
  "recovering",
  "paused",
  "waiting_for_user",
  "waiting_for_approval",
]);

/**
 * Subscribes to the backend SSE stream for a task via the same-origin proxy.
 * Hydrates from the initial snapshot, then applies incremental events.
 */
export function useTaskStream(taskId: string | null): TaskStreamState {
  const [task, setTask] = useState<TaskDetailOut | null>(null);
  const [steps, setSteps] = useState<TaskStepOut[]>([]);
  const [logs, setLogs] = useState<TaskLogOut[]>([]);
  const [actions, setActions] = useState<TaskActionOut[]>([]);
  const [state, setState] = useState<string>("created");
  const [approval, setApproval] = useState<ApprovalEvent | null>(null);
  const [recovery, setRecovery] = useState<RecoveryEvent | null>(null);
  const [recoveryCount, setRecoveryCount] = useState(0);
  const [assist, setAssist] = useState<AssistEvent | null>(null);
  const [credentials, setCredentials] = useState<CredentialsEvent | null>(null);
  const [otp, setOtp] = useState<OtpEvent | null>(null);
  const [captcha, setCaptcha] = useState<CaptchaEvent | null>(null);
  const [info, setInfo] = useState<InfoEvent | null>(null);
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);
  const [screenshots, setScreenshots] = useState<string[]>([]);
  const [connected, setConnected] = useState(false);
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!taskId) return;
    let closed = false;

    async function connect() {
      const session = await getSession();
      const token = session?.backendAccessToken ?? "";
      if (closed) return;

      const es = new EventSource(
        `/api/stream/${encodeURIComponent(taskId!)}?token=${encodeURIComponent(token)}`,
      );
      esRef.current = es;

      es.addEventListener("open", () => setConnected(true));
      es.addEventListener("error", () => setConnected(false));

      es.addEventListener("snapshot", (e) => {
        const detail = JSON.parse((e as MessageEvent).data) as TaskDetailOut;
        setTask(detail);
        setSteps(detail.steps ?? []);
        setLogs(detail.logs ?? []);
        setActions(detail.actions ?? []);
        setState(detail.state);
        // Rebuild a pending human prompt after a reload/reconnect — the live
        // event is ephemeral, so without this an OTP/credentials prompt would be
        // lost on refresh and the task would be stuck waiting forever.
        const p = detail.pending_input;
        if (p) {
          if (p.kind === "otp") setOtp({ step_id: p.step_id ?? "", domain: p.domain ?? "" });
          else if (p.kind === "credentials")
            setCredentials({ step_id: p.step_id ?? "", domain: p.domain ?? "" });
          else if (p.kind === "captcha")
            setCaptcha({
              step_id: p.step_id ?? "",
              domain: p.domain ?? "",
              screenshot: p.screenshot ?? null,
            });
          else if (p.kind === "info")
            setInfo({ step_id: p.step_id ?? "", domain: p.domain ?? "", fields: p.fields ?? [] });
          else if (p.kind === "assist")
            setAssist({
              step_id: p.step_id ?? "",
              step_label: p.step_label ?? "",
              question: p.question ?? "",
            });
        }
        // Seed the preview from persisted screenshots (so a completed or
        // already-running task shows what it did, not a blank panel).
        if (detail.screenshots?.length) {
          setScreenshots(detail.screenshots);
          setScreenshotUrl(detail.last_screenshot_url ?? detail.screenshots.at(-1) ?? null);
        }
      });

      es.addEventListener("plan", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as { steps: TaskStepOut[] };
        setSteps(data.steps);
      });

      es.addEventListener("log", (e) => {
        const log = JSON.parse((e as MessageEvent).data) as TaskLogOut;
        setLogs((prev) =>
          prev.some((l) => l.id === log.id) ? prev : [...prev, log],
        );
      });

      es.addEventListener("action", (e) => {
        const action = JSON.parse((e as MessageEvent).data) as TaskActionOut;
        setActions((prev) =>
          prev.some((a) => a.id === action.id) ? prev : [...prev, action],
        );
      });

      es.addEventListener("state", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as { state: string };
        setState(data.state);
        if (data.state !== "waiting_for_approval") setApproval(null);
        if (data.state !== "waiting_for_user") {
          setAssist(null);
          setCredentials(null);
          setOtp(null);
          setCaptcha(null);
          setInfo(null);
        }
        // Close the stream once the task reaches a terminal state.
        if (!ACTIVE.has(data.state)) {
          es.close();
          setConnected(false);
        }
      });

      es.addEventListener("approval", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as ApprovalEvent;
        setApproval(data);
      });

      es.addEventListener("screenshot", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as { url: string };
        // cache-bust so the <img> re-renders on each new capture
        const busted = `${data.url}?t=${Date.now()}`;
        setScreenshotUrl(busted);
        setScreenshots((prev) => [...prev, busted]);
      });

      es.addEventListener("recovery", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as RecoveryEvent;
        setRecovery(data);
        setRecoveryCount((n) => n + 1);
      });

      es.addEventListener("assist", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as AssistEvent;
        setAssist(data);
      });

      es.addEventListener("credentials", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as CredentialsEvent;
        setCredentials(data);
      });

      es.addEventListener("otp", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as OtpEvent;
        setOtp(data);
      });

      es.addEventListener("captcha", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as CaptchaEvent;
        setCaptcha(data);
      });

      es.addEventListener("info_request", (e) => {
        const data = JSON.parse((e as MessageEvent).data) as InfoEvent;
        setInfo(data);
      });
    }

    connect();

    return () => {
      closed = true;
      esRef.current?.close();
      esRef.current = null;
    };
  }, [taskId]);

  return {
    task,
    steps,
    logs,
    actions,
    state,
    approval,
    recovery,
    recoveryCount,
    assist,
    credentials,
    otp,
    captcha,
    info,
    screenshotUrl,
    screenshots,
    connected,
  };
}
