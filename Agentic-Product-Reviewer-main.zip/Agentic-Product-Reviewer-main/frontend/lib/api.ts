"use client";

import { getSession } from "next-auth/react";

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000";

export class ApiError extends Error {
  constructor(public status: number, message: string, public body?: unknown) {
    super(message);
  }
}

async function authHeader(): Promise<HeadersInit> {
  const session = await getSession();
  const token = session?.backendAccessToken;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(await authHeader()),
    ...(init.headers ?? {}),
  };
  const res = await fetch(`${BACKEND_URL}${path}`, { ...init, headers, cache: "no-store" });
  const text = await res.text();
  const body = text ? (JSON.parse(text) as unknown) : null;
  if (!res.ok) {
    let detail = res.statusText;
    if (body && typeof body === "object" && "detail" in body) {
      detail = String((body as { detail: unknown }).detail);
    }
    throw new ApiError(res.status, detail, body);
  }
  return body as T;
}

// ---------------- types ----------------

export type TaskOut = {
  id: string;
  title: string;
  goal: string;
  state: string;
  intent: Record<string, unknown>;
  result: Record<string, unknown> | null;
  error: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
};

export type TaskStepOut = {
  id: string;
  ordinal: number;
  label: string;
  meta: string | null;
  state: string;
  layer_used: string | null;
  attempts: number;
};

export type TaskLogOut = {
  id: number;
  level: string;
  layer: string | null;
  text: string;
  detail: string | null;
  at: string;
};

export type TaskActionOut = {
  id: number;
  ordinal: number;
  kind: string;
  target: string | null;
  value: string | null;
  url: string | null;
  screenshot_url: string | null;
  ok: boolean;
  at: string;
};

export type PendingInput = {
  kind: "otp" | "credentials" | "captcha" | "info" | "assist";
  step_id?: string;
  domain?: string;
  screenshot?: string | null;
  fields?: { id: string; label: string; kind: string }[];
  step_label?: string;
  question?: string;
};

export type TaskDetailOut = TaskOut & {
  steps: TaskStepOut[];
  logs: TaskLogOut[];
  actions: TaskActionOut[];
  screenshots: string[];
  last_screenshot_url: string | null;
  pending_input: PendingInput | null;
};

export type TaskRepeatInput = {
  frequency: "none" | "daily" | "weekly" | "monthly";
  interval?: number;
  end_at?: string | null;
  occurrences?: number | null;
};

export type SettingsOut = {
  approval_rules: Record<string, unknown>;
  browser_mode: string;
  browser_headless: boolean;
  preferred_model: string;
  browser_cdp_url: string | null;
  browser_use_system_chrome: boolean;
  browser_chrome_profile: string | null;
  browser_use_model: string;
  browser_use_captcha_solver: boolean;
  captcha_autosolve: boolean;
  manual_assist_enabled: boolean;
  autofill_enabled: boolean;
  auto_learn_enabled: boolean;
};

export type VaultEntryOut = {
  id: string;
  kind: string;
  label: string;
  fields: string[];
  ask_every_time: boolean;
  last_used_at: string | null;
  created_at: string;
};

export type PlaybookStepOut = {
  id: string;
  ordinal: number;
  label: string;
  kind: string | null;
  enabled: boolean;
};

export type PlaybookOut = {
  id: string;
  title: string;
  goal_template: string;
  intent: Record<string, unknown>;
  source_task_id: string | null;
  step_count: number;
  created_at: string;
};

export type PlaybookDetailOut = PlaybookOut & {
  steps: PlaybookStepOut[];
};

export type MemoryOut = {
  id: string;
  tag: string;
  text: string;
  created_at: string;
  updated_at: string;
};

export type ConnectedSiteOut = {
  id: string;
  domain: string;
  display_name: string | null;
  status: string;
  scopes: string[];
  has_session: boolean;
  last_used_at: string | null;
  created_at: string;
};

export type StatsOut = {
  tasks_week: number;
  success_rate: number;
  recoveries: number;
  avg_time_seconds: number;
  delta_tasks_week: number;
  delta_success_rate: number;
  delta_recoveries: number;
  delta_avg_time_seconds: number;
};

export type PendingApprovalOut = {
  id: string;
  task_id: string;
  task_title: string;
  reason: string;
  summary: Record<string, unknown>;
  state: string;
  created_at: string;
};

// ---------------- endpoints ----------------

export const api = {
  // tasks
  listTasks: () => request<TaskOut[]>("/tasks"),
  createTask: (goal: string, title?: string, repeat?: TaskRepeatInput) =>
    request<TaskOut>("/tasks", {
      method: "POST",
      body: JSON.stringify({ goal, title, repeat }),
    }),
  getTask: (id: string) => request<TaskDetailOut>(`/tasks/${id}`),
  startTask: (id: string) => request<TaskDetailOut>(`/tasks/${id}/start`, { method: "POST" }),
  cancelTask: (id: string) => request<TaskOut>(`/tasks/${id}/cancel`, { method: "POST" }),
  pauseTask: (id: string) => request<TaskOut>(`/tasks/${id}/pause`, { method: "POST" }),
  resumeTask: (id: string) => request<TaskOut>(`/tasks/${id}/resume`, { method: "POST" }),
  approveTask: (id: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/approve`, { method: "POST" }),
  rejectTask: (id: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/reject`, { method: "POST" }),
  sendUserInput: (id: string, text: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/user-input`, {
      method: "POST",
      body: JSON.stringify({ text }),
    }),
  replanTask: (id: string, instruction: string, screenshotUrl?: string | null) =>
    request<Record<string, unknown>>(`/tasks/${id}/replan`, {
      method: "POST",
      body: JSON.stringify({ instruction, screenshot_url: screenshotUrl ?? null }),
    }),
  sendFeedback: (id: string, rating: number | null, text?: string) =>
    request<{ ok: boolean; learned: number }>(`/tasks/${id}/feedback`, {
      method: "POST",
      body: JSON.stringify({ rating, text: text ?? null }),
    }),
  sendCredentials: (id: string, email: string, password: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/credentials`, {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  sendOtp: (id: string, code: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/otp`, {
      method: "POST",
      body: JSON.stringify({ code }),
    }),
  sendCaptcha: (id: string, text: string) =>
    request<Record<string, unknown>>(`/tasks/${id}/captcha`, {
      method: "POST",
      body: JSON.stringify({ text }),
    }),
  sendInfo: (id: string, values: Record<string, string>) =>
    request<Record<string, unknown>>(`/tasks/${id}/info`, {
      method: "POST",
      body: JSON.stringify({ values }),
    }),

  // settings
  getSettings: () => request<SettingsOut>("/settings"),
  updateSettings: (patch: Partial<SettingsOut>) =>
    request<SettingsOut>("/settings", { method: "POST", body: JSON.stringify(patch) }),

  // memories
  listMemories: () => request<MemoryOut[]>("/memories"),
  createMemory: (tag: string, text: string) =>
    request<MemoryOut>("/memories", { method: "POST", body: JSON.stringify({ tag, text }) }),
  deleteMemory: (id: string) => request<null>(`/memories/${id}`, { method: "DELETE" }),

  // playbooks
  listPlaybooks: () => request<PlaybookOut[]>("/playbooks"),
  getPlaybook: (id: string) => request<PlaybookDetailOut>(`/playbooks/${id}`),
  createPlaybook: (taskId: string, title?: string) =>
    request<PlaybookDetailOut>("/playbooks", {
      method: "POST",
      body: JSON.stringify({ task_id: taskId, title }),
    }),
  updatePlaybookStep: (
    playbookId: string,
    stepId: string,
    patch: { enabled?: boolean; label?: string },
  ) =>
    request<PlaybookDetailOut>(`/playbooks/${playbookId}/steps/${stepId}`, {
      method: "PATCH",
      body: JSON.stringify(patch),
    }),
  deletePlaybookStep: (playbookId: string, stepId: string) =>
    request<PlaybookDetailOut>(`/playbooks/${playbookId}/steps/${stepId}`, {
      method: "DELETE",
    }),
  deletePlaybook: (id: string) => request<null>(`/playbooks/${id}`, { method: "DELETE" }),
  runPlaybook: (id: string, goal?: string) =>
    request<TaskOut>(`/playbooks/${id}/run`, {
      method: "POST",
      body: JSON.stringify({ goal }),
    }),

  // vault
  listVault: () => request<VaultEntryOut[]>("/vault"),
  updateVault: (id: string, patch: { ask_every_time?: boolean }) =>
    request<VaultEntryOut>(`/vault/${id}`, { method: "PATCH", body: JSON.stringify(patch) }),
  deleteVault: (id: string) => request<null>(`/vault/${id}`, { method: "DELETE" }),

  // connected sites
  listSites: () => request<ConnectedSiteOut[]>("/connected-sites"),
  createSite: (domain: string, display_name?: string, scopes: string[] = []) =>
    request<ConnectedSiteOut>("/connected-sites", {
      method: "POST",
      body: JSON.stringify({ domain, display_name, scopes }),
    }),
  updateSite: (id: string, patch: { status?: string; display_name?: string; scopes?: string[] }) =>
    request<ConnectedSiteOut>(`/connected-sites/${id}`, {
      method: "PATCH",
      body: JSON.stringify(patch),
    }),
  deleteSite: (id: string) => request<null>(`/connected-sites/${id}`, { method: "DELETE" }),

  // stats
  getStats: () => request<StatsOut>("/stats"),

  // approvals
  listPendingApprovals: () => request<PendingApprovalOut[]>("/approvals/pending"),

  // v2 — real-browser agent (extension / bookmarklet)
  getV2Status: () => request<V2StatusOut>("/v2/status"),
};

export type V2StatusOut = {
  connected: boolean;
  kind: "extension" | "page" | null;
  session_id: string | null;
};

export async function signup(email: string, password: string, name?: string) {
  const res = await fetch(`${BACKEND_URL}/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, name }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiError(res.status, body.detail ?? "signup failed", body);
  }
  return res.json();
}

// SSE helper — returns the EventSource (caller closes).
export async function openTaskStream(taskId: string): Promise<EventSource> {
  const session = await getSession();
  const token = session?.backendAccessToken;
  // EventSource doesn't allow headers; pass token as query string. The server
  // already requires auth via Authorization header. To bridge, the frontend
  // can use fetch + ReadableStream. For now we open a same-origin proxy route.
  const url = `/api/stream/${encodeURIComponent(taskId)}?token=${encodeURIComponent(token ?? "")}`;
  return new EventSource(url);
}
