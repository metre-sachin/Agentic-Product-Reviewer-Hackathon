"use client";
import { createContext, useContext, useState, type ReactNode } from "react";

interface ThemeCtx {
  lightMode: boolean;
  toggleLight: () => void;
}

export const ThemeContext = createContext<ThemeCtx>({ lightMode: false, toggleLight: () => {} });

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [lightMode, setLightMode] = useState(false);
  return (
    <ThemeContext.Provider value={{ lightMode, toggleLight: () => setLightMode(v => !v) }}>
      <div
        className={lightMode ? "al-light-root" : ""}
        style={{ minHeight: "100vh", background: "#08080A", color: "#F4F4F5" }}
      >
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
