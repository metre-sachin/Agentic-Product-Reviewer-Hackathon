import { getSession } from 'next-auth/react';
let pendingSession:ReturnType<typeof getSession>|null=null;
async function sharedSession(){if(!pendingSession)pendingSession=getSession().finally(()=>{setTimeout(()=>{pendingSession=null},1000)});return pendingSession;}
const base = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:8000';
export type Asset = { id:string; name:string; product:string };
export type Finding = {title:string; evidence:string; severity:string; box:number[]|null};
export type Inspection = {id:string; run_id:string; asset_id:string; sequence:number; state:string; assessment:string|null; draft:{cache?:{reused:boolean;analyzed_at:string};product_presence?:'present'|'absent'|'uncertain';presence_evidence?:string;summary:string; findings:Finding[]; uncertainty:string}|null; error:string|null; duration:number|null; created_at:string; decision:{action:string; outcome:string; notes:string; inspector:string; at:string}|null};
export type Report = {id:string; inspection_id:string; body:string; created_at:string};
export type Operation = {id:string;run_id:string;kind:string;title:string;state:string;detail:string;created_at:string};
export type AgentEvent = {id:string;agent:string;action:string;detail:string;created_at:string};
export type BatchReport = {id:string;run_id:string;state:string;body:string;snapshot:{continuous?:boolean;unique_source_images?:number;dispositions?:{accepted:number;rejected:number;rework:number};unresolved?:number;not_inspected?:number;close_blockers?:string[];review_complete?:boolean;release_ready?:boolean;total:number;received:number;analyzed:number;suspected_defects:number;uncertain:number;pending_review:number;failed:number;flagged:boolean;entries:{cache?:{reused:boolean;analyzed_at:string}|null;product:string;product_presence?:string;presence_evidence?:string;sequence:number;inspection_id:string;asset_id:string;state:string;assessment:string|null;summary:string|null;findings:Finding[];uncertainty:string|null;error:string|null;annotation:{box:number[];note:string}|null;source_annotation?:{label:string;source:string;box:number[]|null;has_mask?:boolean}|null;decision:Inspection['decision']}[]};decision:{inspector:string;notes:string;at:string}|null;created_at:string};
export type SourceAnnotation = {asset_id:string;label:string;source:string;box:number[]|null;has_mask:boolean};
export type Workspace = {processing?:{mode:string;group_size:number;max_concurrent:number;review_buffer:number};runtime_version?:string;source_annotations:SourceAnnotation[];criteria:{run_id:string;checks:string[];notes:string}[];attempts:{inspection_id:string;previous:unknown;created_at:string}[];annotations:{inspection_id:string;box:number[];note:string}[];batch_reports:BatchReport[];events:AgentEvent[];operations:Operation[];model_ready:boolean; model:string; assets:Asset[]; runs:{continuous?:boolean;asset_ids?:string[];id:string; state:string; position:number; total:number; interval:number; created_at:string;mode:string}[]; inspections:Inspection[]; reports:Report[]};
export async function qualityRequest(path:string, init:RequestInit = {}) {
  const session = await sharedSession();
  const headers:Record<string,string> = {};
  if(session?.backendAccessToken) headers.Authorization = `Bearer ${session.backendAccessToken}`;
  if(init.body && !(init.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const res = await fetch(`${base}/quality${path}`, {...init, headers:{...headers,...init.headers}, cache:'no-store'});
  if(!res.ok){ const data=await res.json().catch(()=>null); throw new Error(typeof data?.detail === 'string' ? data.detail : `Request failed (${res.status})`); }
  return res;
}
export const getWorkspace = async ():Promise<Workspace> => (await qualityRequest('/workspace')).json();
export const qualityAction = async (path:string, body:unknown) => (await qualityRequest(path,{method:'POST',body:JSON.stringify(body)})).json();

// Share concurrent image downloads between the review grid, report and drawer.
const imageRequests=new Map<string,Promise<Blob>>();
export async function qualityImage(id:string,mask=false):Promise<Blob>{
 const path=`/assets/${id}/${mask?'mask':'image'}`;
 let pending=imageRequests.get(path);
 if(!pending){pending=qualityRequest(path,{signal:AbortSignal.timeout(20000)}).then(r=>r.blob()).catch(error=>{imageRequests.delete(path);throw error});imageRequests.set(path,pending);if(imageRequests.size>80){const key=imageRequests.keys().next().value;if(key)imageRequests.delete(key)}}
 return pending;
}
export function retryQualityImage(id:string){imageRequests.delete(`/assets/${id}/image`);imageRequests.delete(`/assets/${id}/mask`)}
export type ReviewCase = {id:string;run_id:string;inspection_id:string;asset_id:string;group_key:string;issue:string;summary:string;state:string;review:{by:string;notes:string;at:string}|null;created_at:string};
export type ManagerInbox = {groups:{key:string;name:string;role:string;initials:string}[];cases:ReviewCase[]};
