"use client";

import { useState } from "react";
import type { TaskOut } from "@/lib/api";
import { cn } from "@/lib/utils";
import {
  formatElapsed,
  formatWhen,
  isHistorical,
  outcomeFromState,
  shortId,
  siteFromIntent,
  STATE_COLOR,
} from "@/lib/task-display";

const FILTERS = ["ALL", "COMPLETED", "FAILED", "CANCELLED"] as const;
type Filter = (typeof FILTERS)[number];

export function HistoryTable({ tasks }: { tasks?: TaskOut[] }) {
  const [filter, setFilter] = useState<Filter>("ALL");
  const all = (tasks ?? []).filter(isHistorical);
  const rows = filter === "ALL" ? all : all.filter((t) => outcomeFromState(t.state) === filter);

  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="text-[13px] font-medium">Recent history</h3>
        <div className="flex gap-2 font-mono text-[11px]">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "transition-colors",
                filter === f ? "text-fog-50" : "text-fog-400 hover:text-fog-50",
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>
      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        <div className="grid grid-cols-[1fr_140px_110px_90px_90px] border-b border-mist bg-white/[0.015] px-4 py-2.5 font-mono text-[10px] tracking-wider text-fog-400">
          <span>TASK</span>
          <span>SITE</span>
          <span>OUTCOME</span>
          <span>TIME</span>
          <span>WHEN</span>
        </div>
        {rows.length === 0 ? (
          <div className="px-4 py-6 text-center text-[12px] text-fog-400">No finished tasks yet.</div>
        ) : (
          rows.map((t) => (
            <Link key={t.id} task={t} />
          ))
        )}
      </div>
    </section>
  );
}

function Link({ task }: { task: TaskOut }) {
  const color = STATE_COLOR[task.state] ?? "#A1A1A6";
  return (
    <a
      href={`/tasks?id=${task.id}`}
      className="grid grid-cols-[1fr_140px_110px_90px_90px] items-center border-b border-white/[0.03] px-4 py-3 text-[13px] last:border-b-0 hover:bg-white/[0.02]"
    >
      <div className="flex min-w-0 items-center gap-2.5">
        <span className="font-mono text-[11px] text-fog-400">{shortId(task.id)}</span>
        <span className="truncate">{task.title}</span>
      </div>
      <span className="font-mono text-[12px] text-fog-300 truncate">{siteFromIntent(task.intent)}</span>
      <span className="inline-flex items-center gap-1.5 font-mono text-[11px]" style={{ color }}>
        <span className="w-1 h-1 rounded-full bg-current" />
        {outcomeFromState(task.state)}
      </span>
      <span className="font-mono text-[12px] text-fog-300">
        {formatElapsed(task.started_at, task.completed_at)}
      </span>
      <span className="font-mono text-[12px] text-fog-400">{formatWhen(task.created_at)}</span>
    </a>
  );
}
