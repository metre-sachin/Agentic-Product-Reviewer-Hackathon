"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import type { TaskOut } from "@/lib/api";
import { MiniOrb } from "@/components/orb/agent-orb";
import { Badge } from "@/components/ui/badge";
import { formatElapsed, isActive, shortId, siteFromIntent } from "@/lib/task-display";

function stepLabel(t: TaskOut): string {
  if (t.state === "planning") return "Planning…";
  if (t.state === "waiting_for_approval") return "Waiting for your approval";
  if (t.state === "waiting_for_user") return "Waiting for your input";
  return `State · ${t.state.replaceAll("_", " ")}`;
}

export function ActiveTasks({ tasks }: { tasks?: TaskOut[] }) {
  const rows = (tasks ?? []).filter(isActive);

  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="flex items-center gap-2 text-[13px] font-medium text-fog-50">
          Currently running
          <span
            className="w-1.5 h-1.5 rounded-full animate-argus-pulse"
            style={{ background: "#C4F0C8", boxShadow: "0 0 8px rgba(196,240,200,0.7)" }}
          />
        </h3>
        <Link href="/" className="text-[12px] text-fog-300 hover:text-fog-50">
          + New task
        </Link>
      </div>
      <div className="flex flex-col gap-2">
        {rows.length === 0 && (
          <div className="rounded-xl border border-mist bg-ink-800 px-4 py-6 text-center text-[12px] text-fog-400">
            No active tasks. Start one from the home screen.
          </div>
        )}
        {rows.map((t, i) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.06 * i, duration: 0.3 }}
          >
            <Link
              href={`/tasks?id=${t.id}`}
              className="grid grid-cols-[auto_1fr_auto_auto_auto] items-center gap-4 rounded-xl border border-mist bg-ink-800 px-4 py-4 transition-colors hover:bg-ink-700"
            >
              <MiniOrb size={14} />
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{t.title}</div>
                <div className="mt-1 font-mono text-[12px] text-fog-400">{stepLabel(t)}</div>
              </div>
              <div className="font-mono text-[11px] text-fog-300">{siteFromIntent(t.intent)}</div>
              <Badge variant="mono">{t.state.toUpperCase().replaceAll("_", " ")}</Badge>
              <div className="font-mono text-[11px] tabular-nums text-fog-400">
                {shortId(t.id)} · {formatElapsed(t.started_at ?? t.created_at)}
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
