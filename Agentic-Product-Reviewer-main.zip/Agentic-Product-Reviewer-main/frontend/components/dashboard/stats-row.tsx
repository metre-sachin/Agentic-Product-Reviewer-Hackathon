"use client";

import useSWR from "swr";
import { api, type StatsOut } from "@/lib/api";

interface StatCard {
  label: string;
  value: string;
  delta: string;
  deltaColor: string;
}

function fmtDuration(sec: number): string {
  if (sec <= 0) return "—";
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

function signed(n: number, suffix = ""): string {
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}${Math.abs(n)}${suffix}`;
}

function toCards(s: StatsOut | undefined): StatCard[] {
  if (!s) {
    return [
      { label: "TASKS THIS WEEK", value: "—", delta: "", deltaColor: "#A1A1A6" },
      { label: "SUCCESS RATE", value: "—", delta: "", deltaColor: "#A1A1A6" },
      { label: "RECOVERIES", value: "—", delta: "", deltaColor: "#A1A1A6" },
      { label: "AVG TIME / TASK", value: "—", delta: "", deltaColor: "#A1A1A6" },
    ];
  }
  const up = "#C4F0C8";
  const neutral = "#A1A1A6";
  return [
    {
      label: "TASKS THIS WEEK",
      value: String(s.tasks_week),
      delta: signed(s.delta_tasks_week),
      deltaColor: s.delta_tasks_week >= 0 ? up : neutral,
    },
    {
      label: "SUCCESS RATE",
      value: `${Math.round(s.success_rate * 1000) / 10}%`,
      delta: signed(Math.round(s.delta_success_rate * 1000) / 10),
      deltaColor: s.delta_success_rate >= 0 ? up : neutral,
    },
    {
      label: "RECOVERIES",
      value: String(s.recoveries),
      delta: signed(s.delta_recoveries),
      deltaColor: neutral,
    },
    {
      label: "AVG TIME / TASK",
      value: fmtDuration(s.avg_time_seconds),
      delta: s.delta_avg_time_seconds !== 0 ? signed(Math.round(s.delta_avg_time_seconds), "s") : "",
      deltaColor: s.delta_avg_time_seconds <= 0 ? up : neutral,
    },
  ];
}

export function StatsRow() {
  const { data } = useSWR("stats", api.getStats, { refreshInterval: 15_000 });
  const cards = toCards(data);

  return (
    <div className="grid grid-cols-4 gap-3">
      {cards.map((s) => (
        <div key={s.label} className="rounded-xl border border-mist bg-ink-800 p-4">
          <div className="flex items-center justify-between font-mono text-[10px] tracking-wider text-fog-400">
            <span>{s.label}</span>
            {s.delta && <span style={{ color: s.deltaColor }}>{s.delta}</span>}
          </div>
          <div className="mt-2 text-[32px] font-medium tracking-tight tabular-nums">{s.value}</div>
          <div className="mt-3 h-6 flex items-end">
            <div className="h-px w-full bg-white/[0.06]" />
          </div>
        </div>
      ))}
    </div>
  );
}
