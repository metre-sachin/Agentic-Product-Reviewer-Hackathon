"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import type { TaskActionOut, TaskLogOut } from "@/lib/api";

function iconFor(level: string, layer: string | null): { icon: string; color: string } {
  if (level === "error") return { icon: "✕", color: "#E8B4B4" };
  if (level === "warn") return { icon: "⚠", color: "#E8D2B4" };
  if (level === "milestone") return { icon: "✓", color: "#C4F0C8" };
  if (layer === "vision") return { icon: "◉", color: "#E8D2B4" };
  return { icon: "▸", color: "#6B6B72" };
}

// Glyph + colour per action kind, so the real click-by-click trail reads at a glance.
function actionGlyph(kind: string): { icon: string; color: string } {
  switch (kind) {
    case "navigate":
      return { icon: "↪", color: "#9DB4E8" };
    case "click":
      return { icon: "⊙", color: "#C4F0C8" };
    case "type":
      return { icon: "⌶", color: "#E8D2B4" };
    case "select":
      return { icon: "▾", color: "#C9A8E8" };
    case "press":
      return { icon: "⏎", color: "#9DB4E8" };
    case "scroll":
      return { icon: "↕", color: "#6B6B72" };
    case "wait":
      return { icon: "◴", color: "#6B6B72" };
    default:
      return { icon: "•", color: "#6B6B72" };
  }
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString("en-GB", { hour12: false });
  } catch {
    return "--:--:--";
  }
}

type Tab = "log" | "actions";

interface ExecutionLogProps {
  logs: TaskLogOut[];
  actions: TaskActionOut[];
  live: boolean;
}

export function ExecutionLog({ logs, actions, live }: ExecutionLogProps) {
  const [tab, setTab] = useState<Tab>("log");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Follow the tail of whichever view is active as new entries stream in.
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs.length, actions.length, tab]);

  return (
    <div className="flex-1 min-h-0 flex flex-col px-5 pb-3 pt-5">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <TabButton active={tab === "log"} onClick={() => setTab("log")}>
            EXECUTION LOG
          </TabButton>
          <TabButton active={tab === "actions"} onClick={() => setTab("actions")}>
            ACTIONS{actions.length > 0 ? ` · ${actions.length}` : ""}
          </TabButton>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[10px] text-fog-400">{live ? "LIVE" : "IDLE"}</span>
          {live && (
            <span
              className="w-1.5 h-1.5 rounded-full animate-argus-pulse"
              style={{ background: "#C4F0C8", boxShadow: "0 0 6px rgba(196,240,200,0.7)" }}
            />
          )}
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto font-mono text-[12px] leading-7">
        {tab === "log" ? (
          <LogView logs={logs} live={live} />
        ) : (
          <ActionView actions={actions} />
        )}
      </div>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`font-mono text-[10px] tracking-[0.14em] transition-colors ${
        active ? "text-fog-50" : "text-fog-500 hover:text-fog-300"
      }`}
    >
      {children}
      {active && <span className="ml-2 inline-block h-px w-5 align-middle bg-fog-50/60" />}
    </button>
  );
}

function LogView({ logs, live }: { logs: TaskLogOut[]; live: boolean }) {
  return (
    <>
      {logs.length === 0 && <div className="py-2 text-fog-400">No activity yet.</div>}
      {logs.map((l) => {
        const { icon, color } = iconFor(l.level, l.layer);
        return (
          <motion.div
            key={l.id}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="grid grid-cols-[64px_18px_1fr] gap-2.5 py-0.5 text-fog-300"
          >
            <span className="text-fog-500">{formatTime(l.at)}</span>
            <span style={{ color }}>{icon}</span>
            <span>
              {l.text}
              {l.detail && <span className="text-fog-400"> — {l.detail}</span>}
              {l.layer && l.level !== "milestone" && (
                <span className="ml-1.5 text-fog-500">[{l.layer}]</span>
              )}
            </span>
          </motion.div>
        );
      })}

      {live && (
        <div className="grid grid-cols-[64px_18px_1fr] gap-2.5 py-0.5">
          <span className="text-fog-500">{formatTime(new Date().toISOString())}</span>
          <span className="text-fog-300">▸</span>
          <span className="shimmer-text">
            working
            <span className="ml-1 inline-block w-1.5 h-3 align-[-2px] bg-fog-50 animate-argus-caret" />
          </span>
        </div>
      )}
    </>
  );
}

function ActionView({ actions }: { actions: TaskActionOut[] }) {
  if (actions.length === 0) {
    return (
      <div className="py-2 text-fog-400">
        No actions recorded yet. Every click, keystroke, and navigation Argus performs shows up here.
      </div>
    );
  }
  return (
    <>
      {actions.map((a) => {
        const { icon, color } = actionGlyph(a.kind);
        return (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="grid grid-cols-[64px_18px_1fr] gap-2.5 py-0.5 text-fog-300"
            title={a.url ?? undefined}
          >
            <span className="text-fog-500">{formatTime(a.at)}</span>
            <span style={{ color, opacity: a.ok ? 1 : 0.4 }}>{icon}</span>
            <span className={a.ok ? "" : "text-fog-500 line-through decoration-fog-600/60"}>
              <span style={{ color }}>{a.kind}</span>
              {a.target && <span className="text-fog-100"> {a.target}</span>}
              {a.value && <span className="text-fog-400"> · {a.value}</span>}
              {!a.ok && <span className="ml-1.5 text-[#E8B4B4]">✕</span>}
            </span>
          </motion.div>
        );
      })}
    </>
  );
}
