"use client";

import { useState } from "react";
import Link from "next/link";
import { Pause, Play, Square } from "lucide-react";
import { MiniOrb } from "@/components/orb/agent-orb";
import { Button } from "@/components/ui/button";
import type { TaskDetailOut, TaskLogOut } from "@/lib/api";

interface ChatPanelProps {
  task: TaskDetailOut | null;
  logs: TaskLogOut[];
  state: string;
  onSend?: (text: string) => Promise<void> | void;
  onPause?: () => Promise<void> | void;
  onResume?: () => Promise<void> | void;
  onCancel?: () => Promise<void> | void;
  onSavePlaybook?: () => Promise<void> | void;
  onFeedback?: (rating: number | null, text: string) => Promise<void> | void;
}

function shortId(id: string | undefined): string {
  return id ? `T-${id.slice(0, 4).toUpperCase()}` : "—";
}

function timeOf(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
}

export function ChatPanel({
  task,
  logs,
  state,
  onSend,
  onPause,
  onResume,
  onCancel,
  onSavePlaybook,
  onFeedback,
}: ChatPanelProps) {
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [savedPlaybook, setSavedPlaybook] = useState(false);
  const [savingPlaybook, setSavingPlaybook] = useState(false);
  const [rating, setRating] = useState<number | null>(null);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackBusy, setFeedbackBusy] = useState(false);

  async function savePlaybook() {
    if (!onSavePlaybook || savingPlaybook || savedPlaybook) return;
    setSavingPlaybook(true);
    try {
      await onSavePlaybook();
      setSavedPlaybook(true);
    } finally {
      setSavingPlaybook(false);
    }
  }

  async function submitFeedback() {
    if (!onFeedback || feedbackBusy) return;
    if (rating === null && !feedbackText.trim()) return;
    setFeedbackBusy(true);
    try {
      await onFeedback(rating, feedbackText.trim());
      setFeedbackSent(true);
    } finally {
      setFeedbackBusy(false);
    }
  }

  const milestones = logs.filter((l) => l.level === "milestone" || l.level === "warn").slice(-6);
  const thinking = ["created", "planning", "executing", "recovering"].includes(state);
  const terminal = ["completed", "failed", "cancelled"].includes(state);
  const controllable = [
    "created",
    "planning",
    "executing",
    "recovering",
    "paused",
    "waiting_for_user",
    "waiting_for_approval",
  ].includes(state);
  const paused = state === "paused";
  const answer = typeof task?.result?.answer === "string" ? task.result.answer : null;
  const summary = typeof task?.result?.summary === "string" ? task.result.summary : null;

  async function send() {
    const text = draft.trim();
    if (!text || !onSend) return;
    setBusy(true);
    try {
      await onSend(text);
      setDraft("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="row-span-1 flex flex-col min-h-0 bg-ink-950 border-r border-white/[0.05]">
      <header className="flex items-center gap-2.5 border-b border-white/[0.05] px-4 py-3.5">
        <Link href="/dashboard" className="text-fog-400 hover:text-fog-50 transition-colors text-sm">
          ←
        </Link>
        <div className="flex-1 min-w-0">
          <div className="font-mono text-[10px] text-fog-400 tracking-wider">
            TASK · {shortId(task?.id)}
          </div>
          <div className="truncate text-sm font-medium">{task?.title ?? "Loading…"}</div>
        </div>
        <span className="rounded-md border border-mist-strong bg-white/[0.04] px-2 py-1 font-mono text-[10px] text-fog-300 uppercase">
          {state.replaceAll("_", " ")}
        </span>
        {controllable && (
          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              onClick={() => void (paused ? onResume?.() : onPause?.())}
              className="inline-flex h-8 items-center gap-1 rounded-md border border-mist-strong bg-white/[0.05] px-2 text-[11px] text-fog-100 hover:bg-white/[0.09]"
              title={paused ? "Resume task" : "Pause task"}
            >
              {paused ? <Play size={13} /> : <Pause size={13} />}
              {paused ? "Resume" : "Pause"}
            </button>
            <button
              type="button"
              onClick={() => void onCancel?.()}
              className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E8B4B4]/30 bg-[#E8B4B4]/10 px-2 text-[11px] text-[#E8B4B4] hover:bg-[#E8B4B4]/15"
              title="Cancel task"
            >
              <Square size={12} />
              Cancel
            </button>
          </div>
        )}
      </header>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-[18px]">
        {task && (
          <Bubble
            who="YOU"
            time={timeOf(task.created_at)}
            right={
              <div
                className="w-[22px] h-[22px] mt-px shrink-0 grid place-items-center rounded-full border border-mist-strong text-[9px] font-medium"
                style={{ background: "linear-gradient(135deg, #2A2A2E, #16161A)" }}
              >
                ▢
              </div>
            }
          >
            {task.goal}
          </Bubble>
        )}

        {task && Array.isArray(task.intent?.constraints) && (task.intent.constraints as string[]).length > 0 && (
          <div className="flex items-center gap-2.5 rounded-lg border border-mist bg-white/[0.02] px-3 py-2.5 font-mono text-[11px] text-fog-300">
            <span className="text-fog-400">⚐</span>
            <span className="flex-1">
              Constraints:{" "}
              <span className="text-fog-50">
                {(task.intent.constraints as string[]).join(" · ")}
              </span>
            </span>
          </div>
        )}

        {terminal && (answer || summary) && (
          <div className="rounded-lg border border-[#C4F0C8]/25 bg-[#C4F0C8]/[0.055] px-3.5 py-3">
            <div className="mb-2 font-mono text-[10px] tracking-wider text-[#C4F0C8]">
              OUTPUT
            </div>
            <div className="whitespace-pre-wrap text-[13px] leading-relaxed text-fog-50">
              {answer ?? summary}
            </div>
          </div>
        )}

        {state === "completed" && onSavePlaybook && (
          <button
            type="button"
            onClick={() => void savePlaybook()}
            disabled={savingPlaybook || savedPlaybook}
            className={`self-start rounded-md border px-3 py-1.5 text-[12px] transition-colors ${
              savedPlaybook
                ? "border-[#C4F0C8]/30 bg-[#C4F0C8]/10 text-[#C4F0C8]"
                : "border-mist-strong bg-white/[0.04] text-fog-100 hover:bg-white/[0.08]"
            }`}
            title="Save these steps as a reusable playbook you can re-run"
          >
            {savedPlaybook ? "✓ Saved as playbook" : savingPlaybook ? "Saving…" : "＋ Save as playbook"}
          </button>
        )}

        {terminal && onFeedback && (
          feedbackSent ? (
            <div className="self-start rounded-md border border-[#C4F0C8]/30 bg-[#C4F0C8]/10 px-3 py-1.5 text-[12px] text-[#C4F0C8]">
              ✓ Thanks — Argus will use this next time
            </div>
          ) : (
            <div className="rounded-lg border border-mist bg-white/[0.02] px-3.5 py-3">
              <div className="mb-2 font-mono text-[10px] tracking-wider text-fog-400">
                HOW DID ARGUS DO?
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setRating(rating === 5 ? null : 5)}
                  className={`grid h-8 w-8 place-items-center rounded-md border text-[14px] ${
                    rating === 5
                      ? "border-[#C4F0C8]/40 bg-[#C4F0C8]/10"
                      : "border-mist bg-white/[0.03] hover:bg-white/[0.06]"
                  }`}
                  title="Good"
                >
                  👍
                </button>
                <button
                  type="button"
                  onClick={() => setRating(rating === 1 ? null : 1)}
                  className={`grid h-8 w-8 place-items-center rounded-md border text-[14px] ${
                    rating === 1
                      ? "border-[#E8B4B4]/40 bg-[#E8B4B4]/10"
                      : "border-mist bg-white/[0.03] hover:bg-white/[0.06]"
                  }`}
                  title="Not great"
                >
                  👎
                </button>
                <input
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void submitFeedback()}
                  placeholder="Add a note (optional)…"
                  className="h-8 flex-1 rounded-md border border-mist bg-ink-900 px-2.5 text-[12px] text-fog-50 placeholder:text-fog-500 outline-none focus:border-mist-strong"
                />
                <Button
                  size="sm"
                  type="button"
                  className="h-8 px-3"
                  onClick={() => void submitFeedback()}
                  disabled={feedbackBusy || (rating === null && !feedbackText.trim())}
                >
                  Send
                </Button>
              </div>
            </div>
          )
        )}

        {milestones.map((m) => (
          <Bubble
            key={m.id}
            who="ARGUS"
            time={timeOf(m.at)}
            right={
              <div className="mt-px shrink-0">
                <MiniOrb size={14} />
              </div>
            }
          >
            {m.text}
            {m.detail && <span className="text-fog-400"> — {m.detail}</span>}
          </Bubble>
        ))}

        {thinking && (
          <div className="flex items-center gap-2.5">
            <MiniOrb size={14} />
            <div className="shimmer-text font-mono text-[12px]">working…</div>
          </div>
        )}
      </div>

      <div className="border-t border-white/[0.05] px-3.5 py-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send();
          }}
          className="flex items-center gap-2 rounded-xl border border-mist-strong bg-white/[0.03] px-3 py-2.5"
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={
              terminal
                ? "Start another task…"
                : paused
                  ? "Paused — type a new plan and Argus will re-plan…"
                  : "Send a follow-up instruction…"
            }
            disabled={busy}
            className="flex-1 bg-transparent text-[13px] text-fog-50 placeholder:text-fog-400 outline-none"
          />
          <Button size="sm" type="submit" className="h-7 px-2.5" disabled={busy || !draft.trim()}>
            ↵
          </Button>
        </form>
      </div>
    </section>
  );
}

function Bubble({
  who,
  time,
  right,
  children,
}: {
  who: string;
  time: string;
  right: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="flex gap-2.5">
      {right}
      <div className="flex-1">
        <div className="mb-1 font-mono text-[10px] text-fog-400 tracking-wider">
          {who} · {time}
        </div>
        <div className="text-[13px] leading-relaxed text-fog-50">{children}</div>
      </div>
    </div>
  );
}
