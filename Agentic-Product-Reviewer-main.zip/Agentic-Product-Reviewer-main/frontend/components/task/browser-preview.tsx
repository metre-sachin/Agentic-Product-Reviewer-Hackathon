"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Maximize2, Monitor, SkipBack, SkipForward, X } from "lucide-react";
import type { TaskDetailOut } from "@/lib/api";

interface BrowserPreviewProps {
  task: TaskDetailOut | null;
  state: string;
  screenshotUrl?: string | null;
  screenshots?: string[];
  currentUrl?: string | null;
  onReplan?: (instruction: string, screenshotUrl: string | null) => Promise<void> | void;
}

const ACTIVE = new Set([
  "created",
  "planning",
  "executing",
  "recovering",
  "paused",
  "waiting_for_user",
  "waiting_for_approval",
]);

function domainOf(task: TaskDetailOut | null): string {
  const d = task?.intent?.domain;
  if (typeof d === "string" && d) return d;
  return "resolving target...";
}

export function BrowserPreview({
  task,
  state,
  screenshotUrl,
  screenshots = [],
  currentUrl,
  onReplan,
}: BrowserPreviewProps) {
  const live = ACTIVE.has(state);
  const domain = domainOf(task);
  const stepCount = task?.steps?.length ?? 0;
  const doneCount = task?.steps?.filter((s) => s.state === "done").length ?? 0;
  const pct = stepCount > 0 ? Math.round((doneCount / stepCount) * 100) : 0;

  const [picked, setPicked] = useState<string | null>(null);
  const [autoFollow, setAutoFollow] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const [replanText, setReplanText] = useState("");
  const [replanBusy, setReplanBusy] = useState(false);

  const frames = useMemo(() => {
    const all = [...screenshots];
    if (screenshotUrl) all.push(screenshotUrl);
    return Array.from(new Set(all.filter((url): url is string => Boolean(url))));
  }, [screenshotUrl, screenshots]);

  const latest = screenshotUrl ?? frames.at(-1) ?? null;
  const shown = (autoFollow ? latest : picked) ?? picked ?? latest;
  const currentIndex = shown ? Math.max(0, frames.indexOf(shown)) : -1;

  useEffect(() => {
    if (latest && autoFollow) setPicked(latest);
  }, [latest, autoFollow]);

  function pick(url: string) {
    setPicked(url);
    setAutoFollow(false);
  }

  function stepFrame(delta: number) {
    if (!frames.length) return;
    const next = Math.min(frames.length - 1, Math.max(0, currentIndex + delta));
    pick(frames[next]);
  }

  async function submitReplan() {
    const text = replanText.trim();
    if (!text || !onReplan) return;
    setReplanBusy(true);
    try {
      // Anchor the new plan to the frame currently shown (the one the user picked).
      await onReplan(text, shown ?? null);
      setReplanText("");
    } finally {
      setReplanBusy(false);
    }
  }

  const frameCount = frames.length;
  const frameLabel = `${Math.max(currentIndex + 1, 1)} / ${Math.max(frameCount, 1)}`;

  return (
    <div className="argus-live-shell h-full" data-live={live}>
    <section
      className="row-span-1 flex h-full min-h-0 flex-col border-l border-white/[0.09] bg-[#090a0c]"
      style={{ overflow: "hidden", minWidth: 0 }}
    >
      <header className="flex shrink-0 items-center gap-2.5 border-b border-white/[0.05] px-4 py-3">
        <div className="flex gap-1.5">
          <span className="h-2 w-2 rounded-full bg-white/20" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
        </div>
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-md border border-mist bg-white/[0.03] px-2.5 py-1 font-mono text-[11px] text-fog-300">
          <Monitor size={13} className={live ? "argus-silver-pulse text-white" : "text-fog-400"} />
          <span className="truncate text-fog-400">{currentUrl ?? domain}</span>
          <span className="ml-auto shrink-0 text-fog-300">{live ? "LIVE CONTROL" : "IDLE"}</span>
        </div>
        <span
          title="Argus uses screenshot vision for browser decisions"
          className="shrink-0 rounded-md border border-mist-strong bg-white/[0.04] px-2 py-1 font-mono text-[10px] text-fog-300"
        >
          VISION
        </span>
      </header>

      <div className="relative flex min-h-0 flex-1 bg-[#050506]">
        {shown ? (
          <>
            <button
              type="button"
              onClick={() => setFullscreen(true)}
              className="argus-hover-lift absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-md border border-white/10 bg-black/45 text-fog-200 backdrop-blur hover:bg-white/10 hover:text-fog-50"
              title="Open full screen"
            >
              <Maximize2 size={15} />
            </button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={shown}
              alt="Live browser screenshot"
              className="h-full w-full object-contain object-center saturate-[1.08] contrast-[1.02] transition-[filter] duration-700 hover:brightness-105"
            />
          </>
        ) : (
          <div className="absolute inset-0 grid place-items-center px-8">
            <div className="text-center">
              <motion.div
                className="mx-auto mb-5 h-12 w-12 rounded-full"
                style={{
                  background:
                    "radial-gradient(circle at 30% 30%, #fff, #b8b8c0 65%, #46464c)",
                  boxShadow: live ? "0 0 30px rgba(255,255,255,0.25)" : "none",
                }}
                animate={live ? { scale: [1, 1.08, 1], opacity: [0.85, 1, 0.85] } : {}}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              />
              <div className="font-mono text-[11px] tracking-wider text-fog-400">
                {live ? "OPENING BROWSER..." : "NO BROWSER CAPTURE"}
              </div>
              <div className="mt-1.5 max-w-[280px] text-[12px] text-fog-400">
                {live
                  ? "The live page appears here as soon as Argus captures it."
                  : "This task did not need a browser, or no screenshot was captured."}
              </div>
            </div>
          </div>
        )}
      </div>

      {frameCount > 0 && (
        <div className="shrink-0 border-t border-white/[0.05] bg-ink-900/95">
          <div className="flex items-center gap-2 px-3 py-2">
            <button
              type="button"
              onClick={() => stepFrame(-1)}
              disabled={currentIndex <= 0}
              className="grid h-7 w-7 place-items-center rounded-md border border-white/10 bg-white/[0.03] text-fog-300 disabled:opacity-30"
              title="Previous frame"
            >
              <SkipBack size={13} />
            </button>
            <button
              type="button"
              onClick={() => stepFrame(1)}
              disabled={currentIndex >= frameCount - 1}
              className="grid h-7 w-7 place-items-center rounded-md border border-white/10 bg-white/[0.03] text-fog-300 disabled:opacity-30"
              title="Next frame"
            >
              <SkipForward size={13} />
            </button>
            <button
              type="button"
              onClick={() => setAutoFollow(true)}
              className={`argus-hover-lift rounded-md border px-2 py-1 font-mono text-[10px] ${
                autoFollow
                  ? "border-white/35 bg-white/10 text-white shadow-[0_0_18px_rgba(255,255,255,0.12)]"
                  : "border-white/10 bg-white/[0.03] text-fog-400"
              }`}
            >
              LIVE FOLLOW
            </button>
            <span className="ml-auto font-mono text-[10px] text-fog-400">{frameLabel}</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto px-3 pb-2">
            {frames.map((url, i) => {
              const isActive = shown === url;
              return (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={url + i}
                  src={url}
                  alt={`Step ${i + 1}`}
                  onClick={() => pick(url)}
                  className={`h-14 w-24 shrink-0 cursor-pointer rounded border object-cover object-top transition-opacity ${
                    isActive
                      ? "border-white/80 opacity-100 shadow-[0_0_16px_rgba(255,255,255,0.16)]"
                      : "border-mist opacity-55 hover:opacity-100 hover:scale-[1.02]"
                  }`}
                />
              );
            })}
          </div>
        </div>
      )}

      {state === "paused" && onReplan && (
        <div className="shrink-0 border-t border-[#E8D2B4]/20 bg-[#E8D2B4]/[0.04] px-3 py-2.5">
          <div className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] tracking-wider text-[#E8D2B4]">
            <span>⏸ PAUSED · RE-PLAN</span>
            {shown && (
              <span className="text-fog-400">
                · anchored to frame {Math.max(currentIndex + 1, 1)}
              </span>
            )}
          </div>
          <div className="flex items-end gap-2">
            <textarea
              value={replanText}
              onChange={(e) => setReplanText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  void submitReplan();
                }
              }}
              rows={2}
              placeholder="Tell Argus what to do from here — pick a frame above to anchor it…"
              className="min-h-[40px] flex-1 resize-none rounded-md border border-mist bg-ink-900 px-2.5 py-1.5 text-[12px] text-fog-50 placeholder:text-fog-500 outline-none focus:border-mist-strong"
            />
            <button
              type="button"
              onClick={() => void submitReplan()}
              disabled={replanBusy || !replanText.trim()}
              className="shrink-0 rounded-md bg-fog-50 px-3 py-2 text-[12px] font-medium text-ink-900 disabled:opacity-40"
            >
              {replanBusy ? "…" : "Re-plan"}
            </button>
          </div>
        </div>
      )}

      <div className="flex shrink-0 items-center gap-2.5 border-t border-white/[0.05] px-4 py-2.5 font-mono text-[10px] text-fog-400">
        <span>STEP {doneCount}/{stepCount}</span>
        <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/[0.04]">
          <motion.div
            className="h-full"
            style={{
              background: "linear-gradient(90deg, #44484e, #f5f6f7, #7e858d)",
            }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <span className="text-fog-300">{pct}%</span>
      </div>

      {fullscreen && shown && (
        <div className="fixed inset-0 z-[100] flex flex-col bg-black">
          <header className="flex h-12 shrink-0 items-center gap-3 border-b border-white/10 px-4">
            <Monitor size={15} className="text-fog-300" />
            <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-fog-300">
              {currentUrl ?? domain}
            </span>
            <button
              type="button"
              onClick={() => setFullscreen(false)}
              className="grid h-8 w-8 place-items-center rounded-md border border-white/10 bg-white/[0.04] text-fog-200 hover:bg-white/10"
              title="Close full screen"
            >
              <X size={15} />
            </button>
          </header>
          <div className="min-h-0 flex-1">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={shown}
              alt="Full screen browser screenshot"
              className="h-full w-full object-contain object-center"
            />
          </div>
        </div>
      )}
    </section>
    </div>
  );
}
