"use client";

import { cn } from "@/lib/utils";
import type { TaskStepOut } from "@/lib/api";

function markFor(state: string): string {
  if (state === "done") return "✓";
  if (state === "active") return "◐";
  if (state === "failed") return "✕";
  if (state === "skipped") return "⊘";
  return "○";
}

export function PlanList({ steps }: { steps: TaskStepOut[] }) {
  return (
    <div className="px-5 pt-4">
      <SectionHeader
        title="PLAN"
        right={
          <span className="font-mono text-[11px] text-fog-400">
            {steps.length > 0 ? `${steps.length} STEPS` : "—"}
          </span>
        }
      />
      <div className="flex flex-col gap-1">
        {steps.length === 0 && (
          <div className="rounded-lg border border-white/[0.04] px-2.5 py-3 text-[12px] text-fog-400">
            Waiting for the planner…
          </div>
        )}
        {steps.map((p) => {
          const done = p.state === "done";
          const active = p.state === "active";
          const failed = p.state === "failed";
          return (
            <div
              key={p.id}
              className={cn(
                "grid grid-cols-[22px_1fr_auto] items-center gap-3 rounded-lg border px-2.5 py-2",
                active ? "argus-hover-lift border-white/25 bg-white/[0.055] shadow-[inset_2px_0_0_rgba(255,255,255,0.85)]" : "argus-hover-lift border-white/[0.04] bg-transparent",
              )}
            >
              <div
                className={cn(
                  "grid place-items-center w-[18px] h-[18px] rounded-full border font-mono text-[10px]",
                  done && "bg-white/[0.08] border-white/10 text-fog-50",
                  active && "bg-white/[0.10] border-white/50 text-fog-50 argus-silver-pulse",
                  failed && "border-[#E8B4B4]/40 text-[#E8B4B4]",
                  !done && !active && !failed && "border-mist-strong text-fog-400",
                )}
              >
                {markFor(p.state)}
              </div>
              <div
                className={cn(
                  "text-[13px]",
                  done && "text-fog-300",
                  active && "text-fog-50",
                  failed && "text-[#E8B4B4]",
                  !done && !active && !failed && "text-fog-400",
                )}
              >
                {p.label}
              </div>
              <div className="font-mono text-[10px] text-fog-400">
                {active ? "EXECUTING" : p.meta ?? ""}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function SectionHeader({ title, right }: { title: string; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <span className="font-mono text-[10px] tracking-wider text-fog-400">{title}</span>
      <div
        className="flex-1 h-px"
        style={{ background: "linear-gradient(90deg, rgba(255,255,255,0.06), transparent)" }}
      />
      {right}
    </div>
  );
}
