"use client";

import { MiniOrb } from "@/components/orb/agent-orb";
import { Button } from "@/components/ui/button";
import type { ApprovalEvent } from "@/lib/use-task-stream";

interface Props {
  approval: ApprovalEvent | null;
  onReview: () => void;
  onReject: () => void;
}

export function ApprovalBar({ approval, onReview, onReject }: Props) {
  if (!approval) return null;

  const summary = approval.summary ?? {};
  const stepLabel = String(summary.step_label ?? "an irreversible action");
  const total = summary.total != null ? String(summary.total) : null;

  return (
    <footer className="col-span-3 row-start-2 flex items-center gap-4 border-t border-mist-strong bg-ink-950 px-5 py-3.5">
      <div className="flex items-center gap-2.5">
        <MiniOrb size={16} />
        <div>
          <div className="text-[13px] font-medium">Waiting on you</div>
          <div className="font-mono text-[11px] text-fog-400">
            Argus is about to: {stepLabel}
          </div>
        </div>
      </div>
      <div className="flex-1" />
      {total && (
        <div className="flex items-center gap-2 rounded-lg border border-mist bg-white/[0.03] px-2.5 py-1.5 font-mono text-[11px]">
          <span className="text-fog-400">TOTAL</span>
          <span className="text-fog-50">{total}</span>
        </div>
      )}
      <Button variant="secondary" onClick={onReject}>
        Reject
      </Button>
      <Button onClick={onReview}>Review &amp; approve →</Button>
    </footer>
  );
}
