import { cn } from "@/lib/utils";

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "success" | "warn" | "err" | "mono";
}

export function Badge({ className, variant = "default", ...props }: BadgeProps) {
  const styles: Record<string, string> = {
    default: "bg-white/[0.05] border-mist-strong text-fog-300",
    success: "bg-signal-ok/[0.08] border-signal-ok/15 text-signal-ok",
    warn:    "bg-signal-warn/[0.08] border-signal-warn/15 text-signal-warn",
    err:     "bg-signal-err/[0.08] border-signal-err/15 text-signal-err",
    mono:    "bg-white/[0.05] border-mist-strong text-fog-50",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded font-mono text-[10px] tracking-wider border px-1.5 py-0.5",
        styles[variant],
        className,
      )}
      {...props}
    />
  );
}
