import * as React from "react";
import { cn } from "@/lib/utils";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => (
    <input
      ref={ref}
      type={type}
      className={cn(
        "h-9 w-full rounded-lg bg-white/[0.03] border border-mist-strong px-3 text-sm text-fog-50 placeholder:text-fog-400",
        "focus-visible:outline-none focus-visible:border-white/20 focus-visible:bg-white/[0.05]",
        className,
      )}
      {...props}
    />
  )
);
Input.displayName = "Input";
