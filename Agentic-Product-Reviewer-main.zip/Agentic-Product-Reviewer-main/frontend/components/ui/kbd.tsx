import { cn } from "@/lib/utils";

export function Kbd({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border border-mist-strong bg-white/[0.05] px-2 py-0.5 font-mono text-[10px] text-fog-300",
        className,
      )}
      {...props}
    />
  );
}
