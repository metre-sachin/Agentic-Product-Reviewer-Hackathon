import { cn } from "@/lib/utils";

export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("bg-ink-800 border border-mist rounded-xl", className)}
      {...props}
    />
  );
}
