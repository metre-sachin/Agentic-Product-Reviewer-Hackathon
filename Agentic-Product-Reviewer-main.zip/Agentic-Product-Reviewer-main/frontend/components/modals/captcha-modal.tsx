"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface CaptchaModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  domain?: string;
  screenshot?: string | null;
  onSubmit: (text: string) => Promise<void> | void;
}

export function CaptchaModal({ open, onOpenChange, domain, screenshot, onSubmit }: CaptchaModalProps) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const trimmed = text.trim();
    if (!trimmed) return;
    setBusy(true);
    try {
      await onSubmit(trimmed);
      onOpenChange(false);
      setText("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[480px] p-5">
        <div className="flex items-center gap-3">
          <div className="grid h-7 w-7 place-items-center rounded-full border border-mist-strong text-[13px]">
            ⧗
          </div>
          <div className="flex-1">
            <div className="font-mono text-[10px] tracking-wider text-fog-400">CAPTCHA REQUIRED</div>
            <div className="mt-0.5 text-base font-medium">
              Read the characters for {domain ?? "this site"}
            </div>
          </div>
          <DialogClose className="text-fog-400 hover:text-fog-50 text-base">×</DialogClose>
        </div>

        <p className="mt-3 text-[13px] leading-relaxed text-fog-300">
          Argus couldn&apos;t read this CAPTCHA on its own. Here&apos;s what it sees on the page —
          type the characters from the image and Argus will enter them to continue.
        </p>

        {screenshot ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={screenshot}
            alt="CAPTCHA challenge on the page"
            className="mt-3 max-h-[260px] w-full rounded-xl border border-mist object-contain bg-white"
          />
        ) : (
          <div className="mt-3 grid h-24 place-items-center rounded-xl border border-mist bg-white/[0.02] text-[12px] text-fog-400">
            No preview available — check the browser panel.
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
          className="mt-4 space-y-2.5"
        >
          <input
            type="text"
            autoFocus
            autoComplete="off"
            spellCheck={false}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type the characters shown above"
            className="w-full rounded-xl border border-mist bg-ink-800 px-4 py-3 text-center font-mono text-[16px] tracking-[0.25em] text-fog-50 placeholder:tracking-normal placeholder:text-fog-400 outline-none focus:border-mist-strong"
          />

          <div className="grid grid-cols-2 gap-2 pt-1">
            <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy || !text.trim()}>
              {busy ? "Sending…" : "Submit"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
