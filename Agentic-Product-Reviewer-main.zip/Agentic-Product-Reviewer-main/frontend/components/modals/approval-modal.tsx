"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import { MiniOrb } from "@/components/orb/agent-orb";
import { Button } from "@/components/ui/button";
import type { ApprovalEvent } from "@/lib/use-task-stream";

interface ApprovalModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  approval: ApprovalEvent | null;
  onApprove: () => Promise<void> | void;
  onReject: () => Promise<void> | void;
}

type LineItem = { name: string; qty?: string; price?: string };

function extractItems(summary: Record<string, unknown>): LineItem[] {
  const raw = summary.items;
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((i): i is Record<string, unknown> => typeof i === "object" && i !== null)
    .map((i) => ({
      name: String(i.name ?? "Item"),
      qty: i.qty != null ? String(i.qty) : undefined,
      price: i.price != null ? String(i.price) : undefined,
    }));
}

function reasonLabel(reason: string): string {
  const map: Record<string, string> = {
    irreversible: "IRREVERSIBLE ACTION",
    payment: "PAYMENT",
    new_site: "NEW SITE",
    submit: "FORM SUBMISSION",
  };
  return map[reason] ?? reason.toUpperCase();
}

export function ApprovalModal({ open, onOpenChange, approval, onApprove, onReject }: ApprovalModalProps) {
  const [busy, setBusy] = useState<"approve" | "reject" | null>(null);
  if (!approval) return null;

  const summary = approval.summary ?? {};
  const stepLabel = String(summary.step_label ?? "this action");
  const stepOrdinal = summary.step_ordinal != null ? String(summary.step_ordinal) : "—";
  const items = extractItems(summary);
  const total = summary.total != null ? String(summary.total) : null;

  async function run(kind: "approve" | "reject") {
    setBusy(kind);
    try {
      await (kind === "approve" ? onApprove() : onReject());
      onOpenChange(false);
    } finally {
      setBusy(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[520px] p-5">
        <div className="flex items-center gap-3">
          <MiniOrb size={20} />
          <div className="flex-1">
            <div className="font-mono text-[10px] tracking-wider text-fog-400">
              APPROVAL REQUEST · STEP {stepOrdinal}
            </div>
            <div className="mt-0.5 text-base font-medium">{stepLabel}</div>
          </div>
          <DialogClose className="text-fog-400 hover:text-fog-50 text-base">×</DialogClose>
        </div>

        <div className="my-3 flex items-center gap-2 rounded-lg border border-mist bg-white/[0.02] px-3 py-2.5">
          <span className="font-mono text-[10px] tracking-wider text-fog-400">REASON</span>
          <span className="font-mono text-[11px]" style={{ color: "#E8D2B4" }}>
            {reasonLabel(approval.reason)}
          </span>
          <span className="ml-auto font-mono text-[11px] text-fog-300">
            Argus paused before this step.
          </span>
        </div>

        {items.length > 0 && (
          <div className="max-h-[220px] overflow-y-auto rounded-xl border border-mist bg-white/[0.02] px-3.5 py-3">
            {items.map((i, idx) => (
              <div
                key={idx}
                className="grid grid-cols-[24px_1fr_auto] items-center gap-3 border-b border-white/[0.03] py-1.5 text-[13px] last:border-b-0"
              >
                <div className="w-5 h-5 rounded border border-mist bg-white/[0.05]" />
                <div>
                  <div>{i.name}</div>
                  {i.qty && <div className="font-mono text-[10px] text-fog-400">{i.qty}</div>}
                </div>
                {i.price && (
                  <div className="font-mono text-[12px] tabular-nums text-fog-50">{i.price}</div>
                )}
              </div>
            ))}
          </div>
        )}

        {total && (
          <div className="my-3 flex items-center justify-between px-0.5">
            <span className="font-mono text-[11px] text-fog-400">TOTAL</span>
            <span className="text-lg font-medium tabular-nums">{total}</span>
          </div>
        )}

        <div className="mt-4 grid grid-cols-2 gap-2">
          <Button variant="secondary" disabled={busy !== null} onClick={() => run("reject")}>
            {busy === "reject" ? "Rejecting…" : "Reject"}
          </Button>
          <Button disabled={busy !== null} onClick={() => run("approve")}>
            {busy === "approve" ? "Approving…" : "Approve"}
          </Button>
        </div>

        <div className="mt-3 flex items-center gap-2 font-mono text-[10px] text-fog-400">
          <span>Argus will pause again before the next irreversible step.</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
