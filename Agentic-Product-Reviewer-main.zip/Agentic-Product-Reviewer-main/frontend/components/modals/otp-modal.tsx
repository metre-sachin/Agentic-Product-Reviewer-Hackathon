"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface OtpModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  domain?: string;
  onSubmit: (code: string) => Promise<void> | void;
}

export function OtpModal({ open, onOpenChange, domain, onSubmit }: OtpModalProps) {
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const trimmed = code.trim();
    if (!trimmed) return;
    setBusy(true);
    try {
      await onSubmit(trimmed);
      onOpenChange(false);
      setCode("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[440px] p-5">
        <div className="flex items-center gap-3">
          <div className="grid h-7 w-7 place-items-center rounded-full border border-mist-strong text-[13px]">
            ⧉
          </div>
          <div className="flex-1">
            <div className="font-mono text-[10px] tracking-wider text-fog-400">
              VERIFICATION REQUIRED
            </div>
            <div className="mt-0.5 text-base font-medium">
              Enter the one-time passcode for {domain ?? "this site"}
            </div>
          </div>
          <DialogClose className="text-fog-400 hover:text-fog-50 text-base">×</DialogClose>
        </div>

        <p className="mt-3 text-[13px] leading-relaxed text-fog-300">
          {domain ?? "The site"} sent a verification code (SMS, email, or authenticator).
          Type it here and Argus will enter it to continue. It is held in memory only —
          never written to the database or logs.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
          className="mt-4 space-y-2.5"
        >
          <input
            type="text"
            autoFocus
            autoComplete="one-time-code"
            inputMode="numeric"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="123456"
            className="w-full rounded-xl border border-mist bg-ink-800 px-4 py-3 text-center font-mono text-[18px] tracking-[0.4em] text-fog-50 placeholder:tracking-[0.4em] placeholder:text-fog-400 outline-none focus:border-mist-strong"
          />

          <div className="grid grid-cols-2 gap-2 pt-1">
            <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy || !code.trim()}>
              {busy ? "Sending…" : "Submit code"}
            </Button>
          </div>
        </form>

        <div className="mt-3 flex items-center gap-2 font-mono text-[10px] text-fog-400">
          <span>🔒 Held in memory, used once, then discarded.</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
