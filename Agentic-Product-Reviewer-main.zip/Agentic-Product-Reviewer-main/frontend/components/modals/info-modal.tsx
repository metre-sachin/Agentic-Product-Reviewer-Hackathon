"use client";

import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { InfoField } from "@/lib/use-task-stream";

interface InfoModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  domain?: string;
  fields: InfoField[];
  onSubmit: (values: Record<string, string>) => Promise<void> | void;
}

/** Per-kind input attributes so each sensitive field gets the right keyboard,
 * placeholder, and masking — without ever pre-filling a value. */
function inputAttrs(kind: string): {
  type: string;
  inputMode?: "text" | "tel" | "numeric" | "email";
  placeholder: string;
} {
  switch (kind) {
    case "email":
      return { type: "email", inputMode: "email", placeholder: "you@example.com" };
    case "phone":
      return { type: "tel", inputMode: "tel", placeholder: "+1 555 123 4567" };
    case "dob":
      return { type: "text", placeholder: "YYYY-MM-DD" };
    case "card":
      return { type: "text", inputMode: "numeric", placeholder: "Card details" };
    case "address":
      return { type: "text", placeholder: "Street, city, postcode" };
    case "username":
      return { type: "text", placeholder: "Username" };
    case "name":
      return { type: "text", placeholder: "Full name" };
    default:
      return { type: "text", placeholder: "Value" };
  }
}

export function InfoModal({ open, onOpenChange, domain, fields, onSubmit }: InfoModalProps) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  // Reset the form whenever a fresh set of fields arrives.
  useEffect(() => {
    setValues({});
  }, [fields]);

  const allFilled = fields.length > 0 && fields.every((f) => (values[f.id] ?? "").trim());

  async function submit() {
    if (!allFilled) return;
    setBusy(true);
    try {
      const trimmed: Record<string, string> = {};
      for (const f of fields) trimmed[f.id] = (values[f.id] ?? "").trim();
      await onSubmit(trimmed);
      onOpenChange(false);
      setValues({});
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[460px] p-5">
        <div className="flex items-center gap-3">
          <div className="grid h-7 w-7 place-items-center rounded-full border border-mist-strong text-[13px]">
            ✍
          </div>
          <div className="flex-1">
            <div className="font-mono text-[10px] tracking-wider text-fog-400">DETAILS REQUIRED</div>
            <div className="mt-0.5 text-base font-medium">
              Enter the details for {domain ?? "this form"}
            </div>
          </div>
          <DialogClose className="text-fog-400 hover:text-fog-50 text-base">×</DialogClose>
        </div>

        <p className="mt-3 text-[13px] leading-relaxed text-fog-300">
          Argus never fills personal or sensitive details on its own. Type them here and it
          will enter them into the page, then pause for your approval before submitting. They
          are held in memory only — never written to the database or logs.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
          className="mt-4 space-y-2.5"
        >
          {fields.map((f, i) => {
            const attrs = inputAttrs(f.kind);
            return (
              <label key={f.id} className="block">
                <span className="mb-1 block font-mono text-[10px] tracking-wider text-fog-400">
                  {f.label.toUpperCase()}
                </span>
                <input
                  type={attrs.type}
                  inputMode={attrs.inputMode}
                  autoFocus={i === 0}
                  autoComplete="off"
                  value={values[f.id] ?? ""}
                  onChange={(e) =>
                    setValues((prev) => ({ ...prev, [f.id]: e.target.value }))
                  }
                  placeholder={attrs.placeholder}
                  className="w-full rounded-xl border border-mist bg-ink-800 px-4 py-3 text-[14px] text-fog-50 placeholder:text-fog-400 outline-none focus:border-mist-strong"
                />
              </label>
            );
          })}

          <div className="grid grid-cols-2 gap-2 pt-1">
            <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy || !allFilled}>
              {busy ? "Sending…" : "Use these details"}
            </Button>
          </div>
        </form>

        <div className="mt-3 flex items-center gap-2 font-mono text-[10px] text-fog-400">
          <span>🔒 Held in memory, used once, then discarded.</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
