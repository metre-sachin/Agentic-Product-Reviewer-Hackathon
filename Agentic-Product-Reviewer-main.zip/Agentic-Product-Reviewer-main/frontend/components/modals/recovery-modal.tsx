"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export interface RecoveryOption {
  n: string;
  label: string;
  conf: string;
  confTone: "default" | "warn";
  note: string;
  primary: boolean;
}

interface RecoveryModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  question?: string;
  options?: RecoveryOption[];
  stepLabel?: string;
  onSubmit?: (choice: string) => Promise<void> | void;
}

export function RecoveryModal({
  open,
  onOpenChange,
  question = "I couldn't confidently identify the correct action.",
  options = [],
  stepLabel,
  onSubmit,
}: RecoveryModalProps) {
  const [selected, setSelected] = useState<string | null>(null);
  const [freeText, setFreeText] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const choice = selected ?? freeText.trim();
    if (!choice) return;
    setBusy(true);
    try {
      await onSubmit?.(choice);
      onOpenChange(false);
      setSelected(null);
      setFreeText("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[560px] p-5">
        <div className="flex items-center gap-3">
          <motion.div
            className="relative grid place-items-center w-7 h-7"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
          >
            <div
              className="absolute -inset-1 rounded-full"
              style={{ background: "radial-gradient(circle, rgba(232,210,180,0.35), transparent 65%)" }}
            />
            <div
              className="w-[18px] h-[18px] rounded-full"
              style={{ background: "radial-gradient(circle at 35% 30%, #fff, #d8c8b0 70%, #7a6a5a)" }}
            />
          </motion.div>
          <div className="flex-1">
            <div className="font-mono text-[10px] tracking-wider" style={{ color: "#E8D2B4" }}>
              NEEDS YOUR EYES{stepLabel ? ` · ${stepLabel}` : ""}
            </div>
            <div className="mt-0.5 text-base font-medium">{question}</div>
          </div>
          <DialogClose className="text-fog-400 hover:text-fog-50 text-base">×</DialogClose>
        </div>

        {options.length > 0 && (
          <div className="mt-4 grid grid-cols-3 gap-2.5">
            {options.map((o) => (
              <button
                key={o.n}
                onClick={() => setSelected(o.label)}
                className={cn(
                  "flex flex-col gap-2.5 rounded-xl border p-3 text-left transition-colors",
                  selected === o.label
                    ? "border-white/30 bg-white/[0.06]"
                    : o.primary
                      ? "border-white/20 bg-white/[0.04]"
                      : "border-mist bg-white/[0.02]",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] tracking-wider text-fog-400">
                    OPTION {o.n}
                  </span>
                  <span
                    className="font-mono text-[10px]"
                    style={{ color: o.confTone === "warn" ? "#E8D2B4" : "#A1A1A6" }}
                  >
                    {o.conf}
                  </span>
                </div>
                <div
                  className={cn(
                    "rounded-md border border-dashed bg-white/[0.04] px-2.5 py-2 text-center font-mono text-[12px] text-fog-50",
                    o.confTone === "warn" ? "border-[#E8D2B4]/40" : "border-white/30",
                  )}
                >
                  {o.label}
                </div>
                <div className="text-[11px] leading-relaxed text-fog-400">{o.note}</div>
              </button>
            ))}
          </div>
        )}

        <div className="mt-4">
          <label className="font-mono text-[10px] tracking-wider text-fog-400">
            OR TELL ARGUS WHAT TO DO
          </label>
          <input
            value={freeText}
            onChange={(e) => {
              setFreeText(e.target.value);
              setSelected(null);
            }}
            placeholder="e.g. click the green Add button"
            className="mt-1.5 w-full px-3 py-2.5 bg-ink-800 border border-mist rounded-lg text-fog-50 text-[13px] placeholder:text-fog-400 focus:outline-none focus:border-mist-strong"
          />
        </div>

        <div className="mt-4 flex gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <div className="flex-1" />
          <Button disabled={busy || (!selected && !freeText.trim())} onClick={submit}>
            {busy ? "Sending…" : "Continue →"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
