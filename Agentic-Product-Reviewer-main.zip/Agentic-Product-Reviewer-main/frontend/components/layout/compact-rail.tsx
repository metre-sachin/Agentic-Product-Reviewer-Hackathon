"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const ITEMS = [
  { key: "new",  icon: "+", href: "/new" },
  { key: "task", icon: "◐", href: "/tasks" },
  { key: "wf",   icon: "⌥", href: "/dashboard" },
  { key: "mem",  icon: "▢", href: "/settings" },
  { key: "logs", icon: "☰", href: "/dashboard" },
  { key: "set",  icon: "⚙", href: "/settings" },
];

/** 60px rail used on the Task execution screen. */
export function CompactRail() {
  const pathname = usePathname();
  return (
    <aside className="row-span-2 flex flex-col items-center gap-1.5 border-r border-white/[0.05] bg-ink-900 py-4">
      <div className="mb-3.5 grid place-items-center w-[26px] h-[26px] rounded-full border border-white/40">
        <div className="w-2 h-2 rounded-full bg-fog-50 shadow-[0_0_10px_rgba(255,255,255,0.6)]" />
      </div>
      {ITEMS.map((item) => {
        const active = pathname.startsWith(item.href) && item.href !== "/";
        return (
          <Link
            key={item.key}
            href={item.href}
            className={cn(
              "grid place-items-center w-9 h-9 rounded-lg font-mono text-[13px] border transition-colors",
              active
                ? "bg-white/[0.05] border-mist-strong text-fog-50"
                : "bg-transparent border-transparent text-fog-300 hover:bg-white/[0.04]",
            )}
          >
            {item.icon}
          </Link>
        );
      })}
      <div className="mt-auto w-7 h-7 rounded-full grid place-items-center text-[10px] font-medium border border-mist-strong"
           style={{ background: "linear-gradient(135deg, #2A2A2E, #16161A)" }}>
        RM
      </div>
    </aside>
  );
}
