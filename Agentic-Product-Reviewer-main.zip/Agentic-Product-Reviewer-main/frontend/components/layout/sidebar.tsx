"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import useSWR from "swr";
import { SIDEBAR_ITEMS } from "@/lib/ui-config";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";

const STATUS_DOT: Record<string, string> = {
  live: "#C4F0C8",
  ok: "#C4F0C8",
  paused: "#E8D2B4",
  error: "#E8B4B4",
};

function initials(name: string | null | undefined, email: string | null | undefined): string {
  if (name) {
    const parts = name.trim().split(/\s+/);
    return (parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "");
  }
  return (email ?? "U").slice(0, 2).toUpperCase();
}

export function Sidebar() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const { data: sites } = useSWR("connected-sites", api.listSites, { refreshInterval: 30_000 });
  const { data: tasks } = useSWR("tasks", api.listTasks, { refreshInterval: 10_000 });

  const activeCount = (tasks ?? []).filter((t) =>
    [
      "created",
      "planning",
      "executing",
      "recovering",
      "paused",
      "waiting_for_user",
      "waiting_for_approval",
    ].includes(t.state),
  ).length;

  return (
    <aside className="flex flex-col gap-1 border-r border-white/[0.05] bg-ink-900 px-3 py-4">
      <div className="flex items-center gap-2.5 px-2.5 pt-2 pb-4">
        <div className="grid place-items-center w-[22px] h-[22px] rounded-full border border-white/40">
          <div className="w-1.5 h-1.5 rounded-full bg-fog-50 shadow-[0_0_8px_rgba(255,255,255,0.6)]" />
        </div>
        <span className="text-sm font-medium">Argus</span>
        <div className="ml-auto grid place-items-center w-[18px] h-[18px] rounded border border-mist text-fog-400 text-[10px]">
          ⌘
        </div>
      </div>

      <Link
        href="/new"
        className="mb-2 flex items-center gap-2.5 rounded-lg border border-mist-strong bg-white/[0.04] px-3 py-2.5 text-[13px] font-medium hover:bg-white/[0.07]"
      >
        <span className="grid place-items-center w-[14px] h-[14px] rounded bg-fog-50 text-ink-950 text-[11px] font-semibold">
          +
        </span>
        New Task
        <span className="ml-auto font-mono text-[10px] text-fog-400">⌘N</span>
      </Link>

      <SectionLabel>WORKSPACE</SectionLabel>
      {SIDEBAR_ITEMS.map((item) => {
        const active =
          (item.key === "active" && pathname.startsWith("/dashboard")) ||
          (item.key === "playbooks" && pathname.startsWith("/playbooks")) ||
          (item.key === "settings" && pathname.startsWith("/settings"));
        const badge = item.key === "active" && activeCount > 0 ? String(activeCount) : null;
        return (
          <Link
            key={item.key}
            href={item.href}
            className={cn(
              "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-[13px] transition-colors",
              active ? "bg-white/[0.04] text-fog-50" : "text-fog-300 hover:text-fog-50 hover:bg-white/[0.02]",
            )}
          >
            <span
              className={cn(
                "grid place-items-center w-[14px] h-[14px] font-mono text-[11px]",
                active ? "text-fog-50" : "text-fog-400",
              )}
            >
              {item.icon}
            </span>
            {item.label}
            {badge && (
              <span className="ml-auto rounded bg-white/[0.06] px-1.5 py-px font-mono text-[10px] text-fog-300">
                {badge}
              </span>
            )}
          </Link>
        );
      })}

      <SectionLabel className="mt-4">CONNECTIONS</SectionLabel>
      {(sites ?? []).length === 0 && (
        <Link
          href="/settings"
          className="px-2.5 py-1.5 text-[12px] text-fog-400 hover:text-fog-50"
        >
          + Connect a site
        </Link>
      )}
      {(sites ?? []).slice(0, 6).map((c) => (
        <div key={c.id} className="flex items-center gap-2.5 px-2.5 py-1.5 text-[12px] text-fog-300">
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: STATUS_DOT[c.status] ?? "#6B6B72" }} />
          {c.display_name ?? c.domain}
          <span className="ml-auto font-mono text-[10px] text-fog-400">{c.status.toUpperCase()}</span>
        </div>
      ))}

      <div className="mt-auto flex items-center gap-2.5 rounded-lg border border-mist bg-white/[0.02] p-2">
        <div
          className="grid place-items-center w-7 h-7 rounded-full border border-mist-strong text-[11px] font-medium uppercase"
          style={{ background: "linear-gradient(135deg, #2A2A2E, #16161A)" }}
        >
          {initials(session?.user?.name, session?.user?.email)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[12px] font-medium truncate">
            {session?.user?.name ?? session?.user?.email ?? "Account"}
          </div>
          <div className="font-mono text-[10px] text-fog-400">ARGUS</div>
        </div>
        <Link href="/settings" className="text-fog-400 hover:text-fog-50 text-sm">
          ⚙
        </Link>
      </div>
    </aside>
  );
}

function SectionLabel({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("px-2.5 pt-3 pb-1.5 font-mono text-[10px] tracking-widest text-fog-500", className)}>
      {children}
    </div>
  );
}
