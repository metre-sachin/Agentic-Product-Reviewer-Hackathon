"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useTheme } from "@/lib/theme-context";

const SCREENS = [
  { label: "LANDING",   href: "/",          icon: "◯" },
  { label: "DASHBOARD", href: "/dashboard",  icon: "▦" },
  { label: "TASK",      href: "/tasks",      icon: "◐" },
  { label: "SETTINGS",  href: "/settings",   icon: "⚙" },
] as const;

export function ScreenJumper() {
  const pathname = usePathname();
  const { lightMode, toggleLight } = useTheme();

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[80] flex items-stretch border-t border-white/[0.07]"
      style={{
        background:    "rgba(8,8,12,0.94)",
        backdropFilter: "blur(32px)",
        WebkitBackdropFilter: "blur(32px)",
        boxShadow:     "0 -12px 48px rgba(0,0,0,0.4)",
      }}
    >
      {/* Theme toggle */}
      <button
        onClick={toggleLight}
        title={lightMode ? "Switch to dark mode" : "Switch to light mode"}
        className="flex items-center justify-center px-4 border-r border-white/[0.05] text-fog-400 hover:text-fog-50 transition-colors"
      >
        <span className="text-[14px] leading-none">{lightMode ? "◑" : "◐"}</span>
      </button>

      {/* Branding pill */}
      <div className="flex items-center gap-2 px-4 border-r border-white/[0.05]">
        <div className="relative grid place-items-center rounded-full border border-white/[0.35]" style={{ width: 18, height: 18 }}>
          <div className="rounded-full bg-fog-50" style={{ width: 5, height: 5, boxShadow: "0 0 6px rgba(255,255,255,0.9), 0 0 2px white" }} />
        </div>
        <span className="font-mono text-[11px] font-medium text-fog-300 tracking-[0.1em]">ARGUS</span>
      </div>

      {/* Screen tabs */}
      {SCREENS.map((item) => {
        const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-[3px] py-[7px] pb-[9px] border-t-2 font-mono text-[9px] tracking-[0.08em] transition-all min-w-[80px]",
              active
                ? "border-white/65 text-fog-50 bg-white/[0.035]"
                : "border-transparent text-fog-300 hover:text-fog-50",
            )}
          >
            <span className={cn("text-[15px] leading-none", active ? "opacity-100" : "opacity-55")}>
              {item.icon}
            </span>
            <span>{item.label}</span>
          </Link>
        );
      })}
    </div>
  );
}
