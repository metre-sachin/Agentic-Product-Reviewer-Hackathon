import type { ReactNode } from "react";
import { TopNav } from "@/components/landing/top-nav";
import { FooterBand } from "@/components/landing/footer-band";

export function PageShell({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <div className="relative min-h-screen flex flex-col">
      <TopNav />
      <main className="flex-1 px-6 pt-16 pb-24">
        <div className="mx-auto max-w-[920px]">
          <div className="text-center mb-14">
            <div className="font-mono text-[11px] tracking-[0.18em] text-fog-400 uppercase mb-4">
              {eyebrow}
            </div>
            <h1
              className="text-[52px] font-medium tracking-[-0.03em] leading-[1.05] m-0 mb-4"
              style={{
                background: "linear-gradient(180deg, #FFFFFF 0%, #B8B8C0 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              {title}
            </h1>
            <p className="text-[17px] leading-relaxed text-fog-300 max-w-[560px] mx-auto m-0">
              {subtitle}
            </p>
          </div>
          {children}
        </div>
      </main>
      <FooterBand />
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="mb-4 flex items-center gap-2.5">
      <span className="font-mono text-[11px] tracking-wider text-fog-400 uppercase">{children}</span>
      <div
        className="flex-1 h-px"
        style={{ background: "linear-gradient(90deg, rgba(255,255,255,0.08), transparent)" }}
      />
    </div>
  );
}
