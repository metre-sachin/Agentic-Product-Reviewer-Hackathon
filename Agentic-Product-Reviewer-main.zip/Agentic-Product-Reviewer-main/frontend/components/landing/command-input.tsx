"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { useEffect, useRef, useState } from "react";
import useSWR from "swr";
import { Button } from "@/components/ui/button";
import { Kbd } from "@/components/ui/kbd";
import { api, ApiError, type SettingsOut, type TaskRepeatInput } from "@/lib/api";

const MODEL_OPTIONS = [
  { value: "gpt-4o-mini", label: "gpt-4o-mini" },
  { value: "gpt-4o", label: "gpt-4o" },
];

const MODE_OPTIONS = [
  { value: "structured", label: "structured" },
  { value: "browser", label: "browser" },
  { value: "vision", label: "vision" },
];

const REPEAT_OPTIONS = [
  { value: "none", label: "once" },
  { value: "daily", label: "daily" },
  { value: "weekly", label: "weekly" },
  { value: "monthly", label: "monthly" },
];

const REPEAT_END_OPTIONS = [
  { value: "never", label: "no end" },
  { value: "on", label: "end date" },
  { value: "after", label: "after runs" },
];

const APPROVAL_OPTIONS = [
  { value: "payment", label: "before payment" },
  { value: "spend", label: "before any spend" },
  { value: "cautious", label: "ask for everything" },
];

const APPROVAL_PRESETS: Record<string, Record<string, unknown>> = {
  payment: { payment: true, identity: true, new_site: true, spend_over: 500, post_on_behalf: false },
  spend: { payment: true, identity: true, new_site: true, spend_over: 0, post_on_behalf: false },
  cautious: { payment: true, identity: true, new_site: true, spend_over: 0, post_on_behalf: true },
};

function approvalPresetFromRules(rules: Record<string, unknown> | undefined): string {
  if (!rules) return "payment";
  if (rules.post_on_behalf) return "cautious";
  if (Number(rules.spend_over ?? 500) <= 0) return "spend";
  return "payment";
}

export function CommandInput({ placeholder = "What should I accomplish?" }: { placeholder?: string }) {
  const router = useRouter();
  const search = useSearchParams();
  const { status } = useSession();
  const authed = status === "authenticated";

  const { data: settings } = useSWR<SettingsOut>(authed ? "settings" : null, api.getSettings);

  const [value, setValue] = useState("");
  const [model, setModel] = useState("gpt-4o");
  const [mode, setMode] = useState("vision");
  const [approval, setApproval] = useState("payment");
  const [repeat, setRepeat] = useState<TaskRepeatInput["frequency"]>("none");
  const [repeatEnd, setRepeatEnd] = useState("never");
  const [repeatEndDate, setRepeatEndDate] = useState("");
  const [repeatOccurrences, setRepeatOccurrences] = useState("8");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const resumedRef = useRef(false);
  const touchedRef = useRef(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Hydrate selectors from saved settings (until the user changes them).
  useEffect(() => {
    if (settings && !touchedRef.current) {
      setModel(settings.preferred_model || "gpt-4o");
      setMode(settings.browser_mode || "vision");
      setApproval(approvalPresetFromRules(settings.approval_rules));
    }
  }, [settings]);

  // Resume a goal carried through the login redirect (?goal=...).
  useEffect(() => {
    const goal = search.get("goal");
    if (!goal || resumedRef.current) return;
    if (status === "authenticated") {
      resumedRef.current = true;
      submit(goal);
    } else if (status === "unauthenticated") {
      setValue(goal);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, status]);

  async function persistSettings() {
    const patch: Partial<SettingsOut> = {};
    if (settings) {
      if (model !== settings.preferred_model) patch.preferred_model = model;
      if (mode !== settings.browser_mode) patch.browser_mode = mode;
      if (approvalPresetFromRules(settings.approval_rules) !== approval)
        patch.approval_rules = APPROVAL_PRESETS[approval];
    } else {
      patch.preferred_model = model;
      patch.browser_mode = mode;
      patch.approval_rules = APPROVAL_PRESETS[approval];
    }
    if (Object.keys(patch).length > 0) {
      try {
        await api.updateSettings(patch);
      } catch {
        /* non-fatal: task still runs with existing settings */
      }
    }
  }

  function repeatPayload(): TaskRepeatInput | undefined {
    if (repeat === "none") return undefined;
    const payload: TaskRepeatInput = { frequency: repeat, interval: 1 };
    if (repeatEnd === "on" && repeatEndDate) {
      payload.end_at = new Date(repeatEndDate).toISOString();
    }
    if (repeatEnd === "after") {
      const n = Number(repeatOccurrences);
      if (Number.isFinite(n) && n > 0) payload.occurrences = Math.floor(n);
    }
    return payload;
  }

  async function submit(goalArg?: string) {
    const goal = (goalArg ?? value).trim();
    if (!goal) return;
    setError(null);

    if (!authed) {
      router.push(`/login?callbackUrl=${encodeURIComponent(`/?goal=${encodeURIComponent(goal)}`)}`);
      return;
    }

    setBusy(true);
    try {
      await persistSettings();
      const task = await api.createTask(goal, undefined, repeatPayload());
      router.push(`/tasks?id=${task.id}`);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        router.push("/login");
        return;
      }
      setError(err instanceof Error ? err.message : "Could not create task.");
      setBusy(false);
    }
  }

  return (
    <div className="w-full max-w-[680px]">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
        className="relative rounded-2xl border border-mist-strong bg-ink-700/60 px-5 py-5 backdrop-blur-xl shadow-[0_0_0_4px_rgba(255,255,255,0.02),0_30px_60px_-20px_rgba(0,0,0,0.6)]"
      >
        <div className="flex items-center gap-3">
          <span className="font-mono text-fog-400 text-[13px]">›</span>
          <input
            ref={inputRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            disabled={busy}
            autoFocus
            className="flex-1 bg-transparent border-none outline-none text-[17px] font-normal tracking-tight text-fog-50 placeholder:text-fog-400 placeholder:opacity-100"
          />
          <div className="flex items-center gap-2">
            <Kbd>⌘ K</Kbd>
            <Button type="submit" size="sm" disabled={busy}>
              {busy ? "…" : "Run"}
            </Button>
          </div>
        </div>
      </form>

      <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 px-1 font-mono text-[11px] text-fog-400">
        <div className="flex flex-wrap items-center gap-1.5">
          <span>MODEL</span>
          <Select value={model} onChange={(v) => { touchedRef.current = true; setModel(v); }} options={MODEL_OPTIONS} />
          <span className="text-fog-500 mx-1">·</span>
          <span>MODE</span>
          <Select value={mode} onChange={(v) => { touchedRef.current = true; setMode(v); }} options={MODE_OPTIONS} />
          <span className="text-fog-500 mx-1">·</span>
          <span>APPROVAL</span>
          <Select value={approval} onChange={(v) => { touchedRef.current = true; setApproval(v); }} options={APPROVAL_OPTIONS} />
          <span className="text-fog-500 mx-1">·</span>
          <span>REPEAT</span>
          <Select
            value={repeat}
            onChange={(v) => setRepeat(v as TaskRepeatInput["frequency"])}
            options={REPEAT_OPTIONS}
          />
          {repeat !== "none" && (
            <>
              <span className="text-fog-500 mx-1">·</span>
              <span>END</span>
              <Select value={repeatEnd} onChange={setRepeatEnd} options={REPEAT_END_OPTIONS} />
              {repeatEnd === "on" && (
                <input
                  type="date"
                  value={repeatEndDate}
                  onChange={(e) => setRepeatEndDate(e.target.value)}
                  className="h-[22px] rounded-md border border-mist bg-white/[0.03] px-1.5 text-[11px] text-fog-300 outline-none"
                />
              )}
              {repeatEnd === "after" && (
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={repeatOccurrences}
                  onChange={(e) => setRepeatOccurrences(e.target.value)}
                  className="h-[22px] w-12 rounded-md border border-mist bg-white/[0.03] px-1.5 text-[11px] text-fog-300 outline-none"
                />
              )}
            </>
          )}
        </div>
        <span>{error ? <span className="text-signal-err">{error}</span> : "↵  to send"}</span>
      </div>
    </div>
  );
}

interface SelectProps {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}

function Select({ value, onChange, options }: SelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = options.find((o) => o.value === value) ?? options[0];

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  return (
    <div ref={ref} className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1 rounded-md border border-mist bg-white/[0.03] px-1.5 py-0.5 text-fog-300 hover:text-fog-50 hover:border-mist-strong transition-colors"
      >
        {current.label}
        <span className="text-fog-500 text-[9px]">▾</span>
      </button>
      {open && (
        <div className="absolute left-0 top-[120%] z-50 min-w-[150px] rounded-lg border border-mist-strong bg-ink-800 p-1 shadow-[0_12px_32px_rgba(0,0,0,0.5)]">
          {options.map((o) => (
            <button
              key={o.value}
              type="button"
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
              className={`block w-full rounded-md px-2 py-1.5 text-left text-[11px] transition-colors ${
                o.value === value ? "bg-white/[0.06] text-fog-50" : "text-fog-300 hover:bg-white/[0.03] hover:text-fog-50"
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
