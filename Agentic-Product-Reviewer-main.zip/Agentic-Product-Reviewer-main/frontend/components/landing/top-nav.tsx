"use client";

import Link from "next/link";
import { signOut, useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/lib/theme-context";

export function TopNav() {
  const { lightMode, toggleLight } = useTheme();
  const { data: session, status } = useSession();
  const authed = status === "authenticated";

  return (
    <nav className="flex items-center justify-between px-10 py-6 border-b border-white/[0.04]">
      <Link href="/" className="flex items-center gap-2.5">
        <div className="relative grid place-items-center w-[22px] h-[22px] rounded-full border border-white/40">
          <div className="w-1.5 h-1.5 rounded-full bg-fog-50 shadow-[0_0_8px_rgba(255,255,255,0.6)]" />
        </div>
        <span className="text-[15px] font-medium tracking-tight">Argus</span>
        <Badge className="ml-1">v0.4 · BETA</Badge>
      </Link>
      <div className="flex items-center gap-8 text-[13px] text-fog-300">
        <Link href="/product"   className="hover:text-fog-50 transition-colors">Product</Link>
        <Link href="/dashboard" className="hover:text-fog-50 transition-colors">Workflows</Link>
        <Link href="/pricing"   className="hover:text-fog-50 transition-colors">Pricing</Link>
        <Link href="/changelog" className="hover:text-fog-50 transition-colors">Changelog</Link>
        <button
          onClick={toggleLight}
          className="flex items-center gap-1.5 rounded-lg border border-white/[0.1] bg-white/[0.05] px-3 py-[7px] text-[12px] text-fog-300 hover:text-fog-50 hover:bg-white/[0.08] transition-all"
        >
          <span>{lightMode ? "◑" : "◐"}</span>
          <span>{lightMode ? "Dark" : "Light"}</span>
        </button>
        {authed ? (
          <div className="flex items-center gap-3">
            <span className="font-mono text-[11px] text-fog-400 max-w-[180px] truncate">
              {session?.user?.email}
            </span>
            <Link href="/dashboard">
              <Button size="sm">Open app</Button>
            </Link>
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="text-[12px] text-fog-400 hover:text-fog-50 transition-colors"
            >
              Sign out
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-[13px] text-fog-300 hover:text-fog-50 transition-colors">
              Sign in
            </Link>
            <Link href="/signup">
              <Button size="sm">Get started</Button>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
