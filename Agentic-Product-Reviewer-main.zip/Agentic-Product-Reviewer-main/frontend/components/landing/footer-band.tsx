export function FooterBand() {
  return (
    <footer className="flex items-center justify-between px-10 py-4 border-t border-white/[0.04] font-mono text-[11px] text-fog-400">
      <span>© 2026 ARGUS LABS</span>
      <div className="flex gap-5">
        <span>SOC 2 TYPE II</span>
        <span>RUNTIME: SECURE BROWSER</span>
        <span>BUILD 24A91F</span>
      </div>
    </footer>
  );
}
