export function StatusPill({ label = "IDLE · READY FOR INSTRUCTION" }: { label?: string }) {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] border border-mist-strong font-mono text-[11px] text-fog-300 tracking-wider">
      <span
        className="w-1.5 h-1.5 rounded-full animate-argus-pulse"
        style={{ background: "#C4F0C8", boxShadow: "0 0 8px rgba(196,240,200,0.6)" }}
      />
      {label}
    </div>
  );
}
