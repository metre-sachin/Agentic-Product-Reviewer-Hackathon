"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { motion } from "framer-motion";
import { SUGGESTED_TASKS } from "@/lib/ui-config";
import { api, ApiError } from "@/lib/api";

export function SuggestedTasks() {
  const router = useRouter();
  const { status } = useSession();
  const [busy, setBusy] = useState<string | null>(null);

  async function run(goal: string, title: string) {
    if (status !== "authenticated") {
      router.push(`/login?callbackUrl=${encodeURIComponent(`/?goal=${encodeURIComponent(goal)}`)}`);
      return;
    }
    setBusy(title);
    try {
      const task = await api.createTask(goal);
      router.push(`/tasks?id=${task.id}`);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) router.push("/login");
      setBusy(null);
    }
  }

  return (
    <div className="w-full max-w-[760px] mt-6">
      <div className="flex items-center gap-2.5 mb-3.5 px-1">
        <span className="font-mono text-[11px] text-fog-400 tracking-wider">SUGGESTED</span>
        <div
          className="flex-1 h-px"
          style={{ background: "linear-gradient(90deg, rgba(255,255,255,0.06), transparent)" }}
        />
      </div>
      <div className="grid grid-cols-4 gap-2.5">
        {SUGGESTED_TASKS.map((t, i) => (
          <motion.button
            key={t.title}
            onClick={() => run(t.goal, t.title)}
            disabled={busy !== null}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.06 * i + 0.2, duration: 0.4, ease: "easeOut" }}
            whileHover={{ y: -1, borderColor: "rgba(255,255,255,0.12)", backgroundColor: "rgba(28,28,32,0.7)" }}
            className="flex flex-col items-start gap-2.5 rounded-xl border border-mist bg-ink-700/50 px-3.5 py-4 text-left transition-colors disabled:opacity-50"
          >
            <div className="grid place-items-center w-7 h-7 rounded-lg bg-white/[0.04] border border-mist font-mono text-[11px] text-fog-300">
              {busy === t.title ? "…" : t.icon}
            </div>
            <div className="text-[13px] font-medium leading-tight">{t.title}</div>
            <div className="text-[11px] text-fog-400 leading-tight">{t.hint}</div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
