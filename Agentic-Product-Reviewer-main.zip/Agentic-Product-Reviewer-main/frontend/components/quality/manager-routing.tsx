'use client';
import {useEffect,useRef,useState} from 'react';
import type {ManagerInbox,Workspace,ReviewCase} from '@/lib/quality-api';
import {Evidence} from './workspace';
import {InspectionHandoff} from './inspection-handoff';
function ManagerIcon(){return <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><circle cx="12" cy="8" r="3.2"/><path d="M5 21v-3.5C5 14.6 8 13 12 13s7 1.6 7 4.5V21M9 13l3 4 3-4M12 17v4"/></svg>}
export function ManagerRouting({inbox,data,batchId,act,onChanged,onTransferring,error,onRetry}:{inbox?:ManagerInbox;data?:Workspace;batchId?:string;act:(path:string,body:unknown)=>Promise<boolean>;onChanged:()=>void;onTransferring:(active:boolean)=>void;error?:string;onRetry:()=>void}){
 const [group,setGroup]=useState(''),[focused,setFocused]=useState<string|null>(null),[note,setNote]=useState(''),[target,setTarget]=useState('');
 const [queue,setQueue]=useState<ReviewCase[]>([]),[flight,setFlight]=useState<ReviewCase|null>(null),[arrived,setArrived]=useState<ReviewCase|null>(null);
 const known=useRef<Set<string>>(new Set());
 const mountedAt=useRef(Date.now());
 const initialized=useRef(false);
 useEffect(()=>{setQueue([]);setFlight(null);setArrived(null);setGroup('');setFocused(null)},[batchId]);
 useEffect(()=>{
  if(!inbox)return;
  const fresh:ReviewCase[]=[];
  for(const c of [...inbox.cases].reverse()){
   if(known.current.has(c.id))continue;
   known.current.add(c.id);
   // Do not replay historical assignments when opening a batch.
   if(c.run_id===batchId&&c.state!=='withdrawn'&&(initialized.current||Date.parse(c.created_at)>=mountedAt.current))fresh.push(c);
  }
  initialized.current=true;
  if(fresh.length)setQueue(previous=>[...previous,...fresh]);
 },[inbox,batchId]);
 useEffect(()=>{
  if(flight||!queue.length)return;
  const timer=setTimeout(()=>{setFlight(queue[0]);setQueue(previous=>previous.slice(1))},200);
  return()=>clearTimeout(timer);
 },[flight,queue]);
 useEffect(()=>{onTransferring(!!flight||queue.length>0)},[flight,queue.length,onTransferring]);
 useEffect(()=>()=>onTransferring(false),[onTransferring]);
 useEffect(()=>{if(!arrived)return;const timer=setTimeout(()=>setArrived(null),1600);return()=>clearTimeout(timer)},[arrived]);
 const inTransit=new Set([...queue.map(c=>c.id),...(flight?[flight.id]:[])]);
 const cases=(inbox?.cases||[]).filter(c=>(!batchId||c.run_id===batchId)&&c.state!=='withdrawn');
 const shown=group?cases.filter(c=>c.group_key===group):[];const selected=shown.find(c=>c.id===focused);const definition=inbox?.groups.find(g=>g.key===group);
 const latest=arrived||cases[0];
 const latestGroup=inbox?.groups.find(g=>g.key===latest?.group_key);
 function completeTransfer(){if(flight){setArrived(flight);setFlight(null)}}
 async function update(state:string){if(!selected||note.trim().length<3)return;if(await act(`/manager-inboxes/${selected.id}`,{state,group_key:target||selected.group_key,notes:note})){setNote('');setFocused(null);onChanged()}}
 return <section className="manager-routing"><header><div><ManagerIcon/><strong>Manager inboxes</strong></div><span>{cases.filter(c=>['open','awaiting_approval'].includes(c.state)).length} new</span></header><div className="manager-icons">{(inbox?.groups||[]).map(g=>{const count=cases.filter(c=>c.group_key===g.key&&c.state!=='reviewed'&&!inTransit.has(c.id)).length;return <button className={`${group===g.key?'selected':''} ${arrived?.group_key===g.key?'receiving':''}`} key={g.key} data-inbox-group={g.key} onClick={()=>{setGroup(group===g.key?'':g.key);setFocused(null)}}><span className="manager-avatar"><ManagerIcon/></span><span className="manager-count" key={count}>{count}</span><strong>{g.name}</strong><small>{g.role}</small><span className="manager-review-label">awaiting review</span></button>})}</div>{flight&&<InspectionHandoff key={flight.id} item={flight} data={data} destination={inbox?.groups.find(g=>g.key===flight.group_key)?.name||'Manager review'} onArrival={completeTransfer}/>}{error&&<div className="routing-error" role="alert">{error}<button onClick={onRetry}>Retry routing</button></div>}{latest&&<div className={`assignment-receipt ${arrived?'just-arrived':''}`} aria-live="polite"><div className="case-mini-image"><Evidence asset={data?.assets.find(a=>a.id===latest.asset_id)}/></div><div><small>{flight?'Assigning findings…':arrived?'Delivered to inbox':'Latest assignment'}</small><strong>{latestGroup?.name}</strong><span>BAT-{latest.run_id.slice(0,8).toUpperCase()} · {latest.issue}</span></div></div>}{group?<div className="manager-group-view"><div className="manager-inbox-title"><strong>{definition?.name}</strong><button className="manager-back" onClick={()=>{setGroup('');setFocused(null)}}>Back to groups</button></div><div className="manager-case-list">{shown.length?shown.map(c=><button className={`manager-case ${c.id===focused?'selected':''}`} key={c.id} onClick={()=>{setFocused(c.id);setTarget(c.group_key)}}><div className="case-mini-image"><Evidence asset={data?.assets.find(a=>a.id===c.asset_id)}/></div><div><strong>{c.issue}</strong><span>BAT-{c.run_id.slice(0,8).toUpperCase()}</span><p>{c.summary}</p></div><span className={`case-status ${c.state}`}>{c.state==='awaiting_approval'?'Inspector pending':c.state}</span></button>):<div className="routing-empty">No cases in this group.</div>}</div></div>:<div className="manager-total"><span>{cases.filter(c=>c.state!=='reviewed'&&!inTransit.has(c.id)).length} assigned</span><small>Choose a group to review its cases.</small></div>}{selected&&<div className="manager-case-detail"><div><strong>Case {selected.id.slice(0,6).toUpperCase()}</strong><button onClick={()=>setFocused(null)} aria-label="Close case">×</button></div><p>{selected.summary}</p><label>Assign to<select value={target} onChange={e=>setTarget(e.target.value)}>{inbox?.groups.map(g=><option key={g.key} value={g.key}>{g.name} · {g.role}</option>)}</select></label><textarea rows={2} value={note} onChange={e=>setNote(e.target.value)} placeholder="Review or follow-up notes"/><div><button className="q-button" disabled={note.trim().length<3} onClick={()=>update('acknowledged')}>Acknowledge</button><button className="q-button" disabled={note.trim().length<3||selected.state==='awaiting_approval'} onClick={()=>update('reviewed')}>Mark reviewed</button></div></div>}</section>
}
