import type {ManagerInbox, Workspace} from '@/lib/quality-api';

export function ReviewCharts({data, inbox}: {data?: Workspace; inbox?: ManagerInbox}) {
  const rows = data?.inspections || [];
  const outcomes = [
    {name: 'Accepted', value: rows.filter(r => r.decision?.outcome === 'no_defect').length, color: '#238049'},
    {name: 'Rejected', value: rows.filter(r => r.decision?.outcome === 'defect').length, color: '#c3394d'},
    {name: 'Rework', value: rows.filter(r => r.decision?.outcome === 'rework').length, color: '#555555'},
    {name: 'Pending', value: rows.filter(r => !r.decision || r.decision.outcome === 'uncertain').length, color: '#dededb'},
  ];
  const total = outcomes.reduce((n, g) => n + g.value, 0);
  const reviewed = total - outcomes[3].value;
  const completion = total ? Math.round(reviewed / total * 100) : 0;
  const circumference = 2 * Math.PI * 46;
  let offset = 0;
  const days = Array.from({length: 7}, (_, i) => {
    const day = new Date(); day.setDate(day.getDate() - 6 + i);
    return {label: day.toLocaleDateString([], {weekday: 'short'}), date: day.toLocaleDateString([], {day: 'numeric', month: 'short'}), value: rows.filter(r => r.draft && new Date(r.created_at).toDateString() === day.toDateString()).length};
  });
  const max = Math.max(1, ...days.map(d => d.value));
  const volume = days.reduce((n, d) => n + d.value, 0);
  const workload = (inbox?.groups || []).map(g => ({...g, count: inbox?.cases.filter(c => c.group_key === g.key && !['reviewed', 'withdrawn'].includes(c.state)).length || 0}));
  const maxWork = Math.max(1, ...workload.map(g => g.count));
  const open = workload.reduce((n, g) => n + g.count, 0);

  return <div className="review-charts dashboard-charts">
    <section className="chart-card activity-card">
      <header><strong>Inspection activity</strong><span>Past 7 days</span></header>
      <div className="chart-headline"><strong>{volume.toLocaleString()}</strong><span>images analyzed</span></div>
      <div className="activity-plot" role="img" aria-label={days.map(d => `${d.date}: ${d.value} images`).join(', ')}>
        <div className="activity-grid" aria-hidden="true"><span>{max.toLocaleString()}</span><span>{Math.round(max / 2).toLocaleString()}</span><span>0</span></div>
        <div className="activity-bars">{days.map((day, i) => <div key={day.date} className={i === 6 ? 'today' : ''}><div className="activity-bar-track"><span className="activity-bar-value">{day.value ? day.value.toLocaleString() : ''}</span><i style={{height: `${day.value / max * 100}%`}} title={`${day.date}: ${day.value} images`}/></div><small>{day.label}</small></div>)}</div>
      </div>
    </section>

    <section className="chart-card outcomes-card">
      <header><strong>Review outcomes</strong><span>{total.toLocaleString()} images</span></header>
      <div className="outcome-chart"><svg viewBox="0 0 120 120" role="img" aria-label={outcomes.map(g => `${g.name}: ${g.value}`).join(', ')}><circle cx="60" cy="60" r="46" fill="none" stroke="#efefed" strokeWidth="10"/>{outcomes.map(g => {
        const length = total ? g.value / total * circumference : 0;
        const before = offset; offset += length;
        return <circle key={g.name} cx="60" cy="60" r="46" fill="none" stroke={g.color} strokeWidth="10" strokeDasharray={`${length} ${circumference}`} strokeDashoffset={-before} transform="rotate(-90 60 60)"><title>{g.name}: {g.value}</title></circle>;
      })}<text x="60" y="59" textAnchor="middle">{completion}%</text><text className="chart-svg-label" x="60" y="74" textAnchor="middle">reviewed</text></svg><div>{outcomes.map(g => <div key={g.name}><i style={{background: g.color}}/><span>{g.name}</span><b>{g.value.toLocaleString()}</b></div>)}</div></div>
      <footer>{reviewed.toLocaleString()} inspector decisions completed</footer>
    </section>

    <section className="chart-card manager-workload-card">
      <header><strong>Manager workload</strong><span>{open.toLocaleString()} open</span></header>
      <div className="workload-chart">{workload.map(g => <div key={g.key}><div><span>{g.name}</span><b>{g.count.toLocaleString()}</b></div><div><i style={{width: `${g.count / maxWork * 100}%`}}/></div></div>)}{!workload.length && <p>No assignments yet.</p>}</div>
    </section>
  </div>;
}
