'use client';

import {useEffect, useRef} from 'react';
import {createPortal} from 'react-dom';
import {ArrowUpRight, FileText} from 'lucide-react';
import type {ReviewCase, Workspace} from '@/lib/quality-api';
import {Evidence} from './workspace';

// This is a visual receipt for a case already committed by the backend.
// Coordinates are measured from the actual inspection and destination cards.
export function InspectionHandoff({item, data, destination, onArrival}: {
  item: ReviewCase;
  data?: Workspace;
  destination: string;
  onArrival: () => void;
}) {
  const card = useRef<HTMLDivElement>(null);
  const arrival = useRef(onArrival);
  arrival.current = onArrival;

  useEffect(() => {
    const node = card.current;
    const source = document.querySelector<HTMLElement>(`[data-inspection-id="${item.inspection_id}"] .card-image-open`)
      || document.querySelector<HTMLElement>('.four-review .four-cards');
    const target = document.querySelector<HTMLElement>(`[data-inbox-group="${item.group_key}"]`);
    if (!node || !source || !target) {
      arrival.current();
      return;
    }
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let animation: Animation | undefined;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      arrival.current();
    };
    const move = () => {
      animation?.cancel();
      const from = source.getBoundingClientRect();
      const to = target.getBoundingClientRect();
      const width = Math.min(190, from.width * .85);
      const height = 114;
      const x = from.left + (from.width - width) / 2;
      const y = from.top + (from.height - height) / 2;
      const dx = to.left + to.width / 2 - (x + width / 2);
      const dy = to.top + to.height / 2 - (y + height / 2);
      Object.assign(node.style, {left: `${x}px`, top: `${y}px`, width: `${width}px`, visibility: 'visible'});
      if (reduced) {
        animation = node.animate([{opacity: 0}, {opacity: 1}, {opacity: 0}], {duration: 250, fill: 'forwards'});
      } else {
        animation = node.animate([
          {transform: 'translate(0, 0) scale(.94)', opacity: 0, offset: 0},
          {transform: 'translate(0, -8px) scale(1)', opacity: 1, offset: .15},
          {transform: `translate(${dx * .55}px, ${dy * .45 - 34}px) scale(.92) rotate(-3deg)`, opacity: 1, offset: .58},
          {transform: `translate(${dx}px, ${dy}px) scale(.22) rotate(0deg)`, opacity: 0, offset: 1},
        ], {duration: 1600, easing: 'cubic-bezier(.22,.61,.36,1)', fill: 'forwards'});
      }
      animation.onfinish = finish;
    };
    move();
    // Re-measure after scrolling/resizing; the card still lands in the real inbox.
    window.addEventListener('resize', move);
    window.addEventListener('scroll', move, true);
    const fallback = window.setTimeout(finish, 4000);
    return () => {
      done = true;
      animation?.cancel();
      clearTimeout(fallback);
      window.removeEventListener('resize', move);
      window.removeEventListener('scroll', move, true);
    };
  }, [item.id, item.inspection_id, item.group_key]);

  const inspection = data?.inspections.find(i => i.id === item.inspection_id);
  const sequence = inspection?.sequence;
  return createPortal(
    <div className="inspection-transfer-card" ref={card} aria-hidden="true">
      <div className="transfer-thumbnail"><Evidence asset={data?.assets.find(a => a.id === item.asset_id)}/></div>
      <div className="transfer-caption"><FileText size={12}/><span>Image {sequence ? String(sequence).padStart(2, '0') : 'review'}<strong>{item.issue}</strong></span><ArrowUpRight size={14}/></div>
      <div className="transfer-destination">To {destination}</div>
    </div>, document.body,
  );
}
