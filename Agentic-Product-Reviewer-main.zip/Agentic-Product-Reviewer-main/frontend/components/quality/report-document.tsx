'use client';
import Link from 'next/link';
import {ArrowUpRight,ShieldCheck,Image as ImageIcon,AlertTriangle,CheckCircle2} from 'lucide-react';
import type {BatchReport,SourceAnnotation} from '@/lib/quality-api';
import {Evidence} from './workspace';
const human=(s:string)=>s==='loading_saved'?'Preparing result':s.replaceAll('_',' ');
function location(box:number[]|null|undefined){if(!box)return 'No region has been confirmed. Inspect the full image.';const x=(box[0]+box[2])/2,y=(box[1]+box[3])/2;return `${y<.33?'Upper':y>.67?'Lower':'Middle'} ${x<.33?'left':x>.67?'right':'central'} area of the image.`}
export function ReportDocument({report,onEvidence}:{report:BatchReport;onEvidence?:(id:string)=>void}){
 const s=report.snapshot;
 const incomplete=s.failed>0||s.analyzed<s.total;
 const approved=report.state==='approved';
 const headline=incomplete?'Inspection incomplete — do not accept this batch':s.flagged?`${s.suspected_defects} image${s.suspected_defects===1?'':'s'} need defect review`:approved?'Report approved by inspector':'No defect flags recorded — inspector review pending';
 return <div className={`review-document ${report.state}`}>
  <div className="document-kicker"><span>AUTONOMOUS PRODUCT REVIEW</span><span>{report.state==='draft'?'DRAFT · INSPECTOR REVIEW REQUIRED':`${report.state.toUpperCase()} REPORT`}</span></div>
  <h2>Batch quality<br/>review report.</h2>
  <p className="document-subtitle">{s.entries[0]?.product} · BAT-{report.run_id.slice(0,8).toUpperCase()}</p>
  <div className={`report-executive ${incomplete?'inspection-incomplete':s.flagged?'has-issues':approved?'inspector-approved':'review-pending'}`}>
   {approved&&!incomplete?<CheckCircle2 size={19}/>:<AlertTriangle size={19}/>}
   <div><strong>{headline}</strong><p>{s.analyzed} of {s.total} images analyzed. {s.pending_review?`${s.pending_review} image decisions are awaiting the inspector.`:'Image review status is recorded below.'} {s.failed?`${s.failed} image${s.failed===1?'':'s'} could not be analyzed and need rechecking.`:''}</p><small>{report.state==='draft'?'This is a draft. It does not authorize acceptance or release of the batch.':`The inspector ${report.state} this report. See the individual product decisions below.`}</small></div>
  </div>
  <dl className="document-meta"><div><dt>Product</dt><dd>{s.entries[0]?.product}</dd></div><div><dt>Batch reference</dt><dd>BAT-{report.run_id.slice(0,8).toUpperCase()}</dd></div><div><dt>Report status</dt><dd>{report.state}</dd></div><div><dt>Created</dt><dd>{new Date(report.created_at).toLocaleString()}</dd></div></dl>
  <section className="disposition-summary"><h3>Recorded product decisions</h3><div><span><b>{s.dispositions?.accepted||0}</b>Accepted</span><span><b>{s.dispositions?.rework||0}</b>For rework</span><span><b>{s.dispositions?.rejected||0}</b>Rejected</span><span><b>{s.unresolved||0}</b>Unresolved</span></div><p>{s.release_ready?'All scheduled units were accepted by the inspector.': 'No blanket batch release is granted. Keep rejected and rework units segregated and resolve open reviews.'}</p></section><section className="document-evidence"><h3>Inspection findings</h3>{s.entries.map(e=>{
   const input=e.source_annotation;
   const source:SourceAnnotation|undefined=input?{asset_id:e.asset_id,label:input.label,source:input.source,box:input.box,has_mask:!!input.has_mask}:undefined;
   const defective=e.decision?['defect','rework'].includes(e.decision.outcome):!!((input&&input.label!=='good')||e.assessment==='possible_defect');
   const clear=e.decision?.outcome==='no_defect';
   const issue=clear?'Inspector found no defect':defective?(e.findings.map(f=>human(f.title)).join(', ')||human(input?.label||'Suspected defect')):e.state==='failed'?'Image analysis failed':e.assessment==='uncertain'?'The finding needs further review':e.assessment==='no_visible_defect'&&e.product_presence==='present'?'No visible defect reported':'Analysis in progress';
   return <article className={`report-photo-entry ${defective?'possible_defect':''} ${e.state}`} key={e.inspection_id}>
    <div className="document-entry-head"><span>IMAGE {String(e.sequence).padStart(2,'0')} · INS-{e.inspection_id.slice(0,8).toUpperCase()}</span><span className={defective?'entry-flag':clear?'entry-approved':''}>{e.decision?human(e.decision.outcome):defective?'Flagged for review':e.state==='failed'?'Recheck needed':'Awaiting review'}</span></div>
    <div className="report-photo"><Evidence asset={{id:e.asset_id,name:`Image ${e.sequence}`,product:e.product}} source={source} inspectorRegion={e.annotation?.box} inspection={{id:e.inspection_id,asset_id:e.asset_id,run_id:report.run_id,sequence:e.sequence,state:e.state,assessment:e.assessment,draft:e.summary?{summary:e.summary,findings:e.findings,uncertainty:e.uncertainty||''}:null,error:e.error,duration:null,created_at:report.created_at,decision:e.decision}}/></div>
    <p className="report-photo-caption">{e.annotation?'Inspector-selected region':input?(input.box?'Red area: supplied defect annotation':'Supplied annotation: no defect region'):e.findings.some(f=>f.box)?'Red box: unverified AI-suggested region':'Original inspection image · no reliable region supplied'}</p>
    <div className="report-issue-statement"><span>WHAT IS THE ISSUE?</span><strong>{issue}</strong></div>
    <dl className="report-explanation"><div><dt>Product present?</dt><dd>{e.product_presence||'Not verified'} · {e.presence_evidence||'No presence check was recorded.'}</dd></div><div><dt>Visible evidence</dt><dd>{e.findings.length?e.findings.map(f=>f.evidence).join(' '):e.summary||e.error||'Analysis is still in progress.'}</dd></div><div><dt>Where to look</dt><dd>{location(e.annotation?.box||input?.box||e.findings.find(f=>f.box)?.box)}</dd></div><div><dt>Evidence source</dt><dd>{input?`${input.source}. This is supplied input, not independent AI detection.`:e.summary?'AI-generated suggestion from the inspection image.':'No model result is available.'}</dd></div></dl>
    {e.summary&&e.findings.length>0&&<details className="report-extra"><summary>Read the model / inspection observation</summary><p>{e.summary}</p></details>}
    {e.uncertainty&&<div className="report-caution"><strong>What still needs checking</strong><p>{e.uncertainty}</p></div>}
    <div className="report-next-step"><span>NEXT ACTION</span><p>{e.state==='failed'?'Recheck this image before finalizing the report.':e.decision?.outcome==='rework'?'Segregate this unit for rework. Document a separate inspection after physical corrective work.':e.decision?.outcome==='uncertain'?'Reinspection is required. This image has not received a final disposition.':e.decision?'Inspector decision recorded. Use that decision for this image.':defective?'Inspector must verify the highlighted area and confirm, correct, or dismiss the defect.':'Inspector must review the original image and record a decision.'}</p></div>
    {e.annotation&&<p className="document-provenance">Inspector annotation: {e.annotation.note}</p>}
    {e.decision&&<div className={`report-image-decision ${['defect','rework'].includes(e.decision.outcome)?'defect':e.decision.outcome==='no_defect'?'accepted':'pending'}`}><ShieldCheck size={16}/><div><strong>{human(e.decision.outcome)} · {e.decision.inspector}</strong><p>{e.decision.notes}</p><small>{new Date(e.decision.at).toLocaleString()}</small></div></div>}
    {onEvidence?<button className="document-evidence-link" onClick={()=>onEvidence(e.inspection_id)}><ImageIcon size={12}/>Open image for review <ArrowUpRight size={12}/></button>:<Link className="document-evidence-link" href={`/quality?batch=${report.run_id}&inspection=${e.inspection_id}`}><ImageIcon size={12}/>Open image for review <ArrowUpRight size={12}/></Link>}
   </article>})}</section>
  <section className="document-scope"><h3>Inspector sign-off</h3>{report.decision?<div className={`report-signature ${report.state}`}><ShieldCheck size={18}/><div><strong>{report.state} by {report.decision.inspector}</strong><p>{report.decision.notes}</p><small>{new Date(report.decision.at).toLocaleString()}</small></div></div>:<div className="document-awaiting"><ShieldCheck size={16}/>Awaiting inspector approval</div>}<p>This report describes supplied images and annotations. It does not establish hidden defects, measured dimensions, or a manufacturing cause.</p></section>
  <footer>AUTONOMOUS PRODUCT REVIEW · BAT-{report.run_id.slice(0,8).toUpperCase()} · {report.state.toUpperCase()}</footer>
 </div>
}
