'use client';

import {useEffect, useState, type ReactNode} from 'react';
import type {ManagerInbox, Workspace} from '@/lib/quality-api';
import {Evidence} from './workspace';
import {ReviewCharts} from './review-charts';

const code = (id: string) => `BAT-${id.slice(0, 8).toUpperCase()}`;
const number = (value: number) => value.toLocaleString();

export function QualityDashboard({data, inbox, selectedId, onSelect, report}: {
  data?: Workspace;
  inbox?: ManagerInbox;
  selectedId?: string;
  onSelect: (id: string) => void;
  report: ReactNode;
}) {
  const [product, setProduct] = useState('all');
  const [period, setPeriod] = useState('all');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const products = Array.from(new Set(data?.assets.map(a => a.product) || [])).sort();
  const cutoff = period === 'all' ? 0 : Date.now() - Number(period) * 86400000;
  const runs = (data?.runs || []).filter(run => {
    const first = data?.inspections.find(i => i.run_id === run.id);
    const asset = data?.assets.find(a => a.id === (first?.asset_id || run.asset_ids?.[0]));
    return (product === 'all' || asset?.product === product) && Date.parse(run.created_at) >= cutoff;
  });
  const runIds = new Set(runs.map(r => r.id));
  const rows = (data?.inspections || []).filter(i => runIds.has(i.run_id));
  const cases = (inbox?.cases || []).filter(c => runIds.has(c.run_id) && c.state !== 'withdrawn');
  const reports = (data?.batch_reports || []).filter(r => runIds.has(r.run_id));
  const analyzed = rows.filter(i => i.draft).length;
  const accepted = rows.filter(i => i.decision?.outcome === 'no_defect').length;
  const rejected = rows.filter(i => i.decision?.outcome === 'defect').length;
  const rework = rows.filter(i => i.decision?.outcome === 'rework').length;
  const pending = rows.filter(i => !i.decision || i.decision.outcome === 'uncertain').length;
  const failed = rows.filter(i => i.state === 'failed').length;
  const reviewed = accepted + rejected + rework;
  const shown = reports.filter(r => {
    const matches = `${code(r.run_id)} ${r.snapshot.entries[0]?.product || ''}`.toLowerCase().includes(query.toLowerCase());
    return matches && (status === 'all' || (status === 'flagged' ? r.snapshot.flagged : r.state === status));
  });
  const visibleIds = shown.map(r => r.run_id).join('|');
  useEffect(() => {
    if (shown.length && !shown.some(r => r.run_id === selectedId)) onSelect(shown[0].run_id);
  }, [visibleIds, selectedId]);
  const selected = shown.find(r => r.run_id === selectedId);
  const scopedData = data ? {...data, inspections: rows, runs, batch_reports: reports} : undefined;
  const scopedInbox = inbox ? {...inbox, cases} : undefined;
  const metrics = [
    {label: 'Images analyzed', value: analyzed, detail: `${number(runs.length)} inspection batches`, tone: ''},
    {label: 'Awaiting review', value: pending, detail: failed ? `${number(failed)} require rechecking` : `${number(reviewed)} decisions completed`, tone: ''},
    {label: 'Accepted', value: accepted, detail: 'Confirmed by an inspector', tone: 'accepted'},
    {label: 'Rejected', value: rejected, detail: `${number(rework)} sent for rework`, tone: 'rejected'},
  ];

  return <div className="quality-dashboard">
    <div className="dashboard-scope">
      <div><span className="dashboard-live-dot"/>Live overview<span className="scope-divider"/>{number(cases.filter(c => c.state !== 'reviewed').length)} manager reviews open</div>
      <div className="dashboard-filters">
        <label><span>Product</span><select value={product} onChange={e => setProduct(e.target.value)}><option value="all">All products</option>{products.map(p => <option key={p}>{p}</option>)}</select></label>
        <label><span>Period</span><select value={period} onChange={e => setPeriod(e.target.value)}><option value="all">All time</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option></select></label>
      </div>
    </div>

    <div className="dashboard-stat-grid">{metrics.map((m, index) => <section className={`dashboard-stat ${m.tone}`} key={m.label} style={{animationDelay: `${index * 45}ms`}}><div><span>{m.label}</span><span className="stat-index">0{index + 1}</span></div><strong>{number(m.value)}</strong><small>{m.detail}</small></section>)}</div>

    <ReviewCharts data={scopedData} inbox={scopedInbox}/>

    <div className="dashboard-review-layout">
      <section className="batch-ledger">
        <header><div><h2>Batch reviews</h2><span>{number(shown.length)} batches</span></div><label className="batch-search"><svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><circle cx="8" cy="8" r="5"/><path d="m12 12 5 5"/></svg><input aria-label="Search batches" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search batch or product"/></label></header>
        <div className="batch-filter-tabs" role="group" aria-label="Filter batch reports">{[['all', 'All batches'], ['flagged', 'Flagged'], ['draft', 'Pending'], ['approved', 'Approved'], ['rejected', 'Rejected']].map(([value, label]) => <button key={value} aria-pressed={status === value} className={status === value ? 'selected' : ''} onClick={() => setStatus(value)}>{label}</button>)}</div>
        <div className="batch-ledger-scroll"><table><thead><tr><th>Batch / product</th><th>Analyzed</th><th>Flagged</th><th>Review progress</th><th>Report</th></tr></thead><tbody>{shown.map(r => {
          const s = r.snapshot;
          const done = (s.dispositions?.accepted || 0) + (s.dispositions?.rejected || 0) + (s.dispositions?.rework || 0);
          const complete = s.received ? Math.round(done / s.received * 100) : 0;
          const first = s.entries[0];
          return <tr key={r.id} className={selectedId === r.run_id ? 'selected' : ''} onClick={() => onSelect(r.run_id)}><td><div className="ledger-product"><div className="ledger-thumbnail"><Evidence asset={data?.assets.find(a => a.id === first?.asset_id)}/></div><div><button onClick={() => onSelect(r.run_id)} aria-label={`View report for ${code(r.run_id)}`}>{code(r.run_id)}</button><span>{first?.product || 'Inspection'}<i/>{new Date(r.created_at).toLocaleDateString([], {day: 'numeric', month: 'short'})}</span></div></div></td><td className="ledger-number">{number(s.analyzed)}</td><td className={`ledger-number ${s.suspected_defects ? 'has-findings' : ''}`}>{number(s.suspected_defects)}</td><td><div className="ledger-progress"><span>{complete}%<small>{done}/{s.received}</small></span><div><i style={{width: `${complete}%`}}/></div></div></td><td><span className={`ledger-status ${r.state}`}><i/>{r.state === 'draft' ? 'Pending' : r.state}</span></td></tr>;
        })}</tbody></table>{!shown.length && <div className="dashboard-empty"><strong>{reports.length ? 'No matching batches' : 'No inspection batches yet'}</strong><span>{reports.length ? 'Try another product, status, or search.' : 'Start an inspection to see results here.'}</span></div>}</div>
      </section>
      <div className="dashboard-report-preview">{selected ? report : <div className="dashboard-empty"><strong>Select a batch</strong><span>Its findings and review report will appear here.</span></div>}</div>
    </div>
  </div>;
}
