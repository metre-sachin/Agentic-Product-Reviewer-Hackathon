"use client";

import { useEffect, useRef } from "react";
import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

export type AgentState = "idle" | "thinking" | "executing" | "waiting" | "error";

export interface AgentOrbProps {
  size?: number;
  state?: AgentState;
  className?: string;
  style?: CSSProperties;
}

/** Canvas-based particle sphere — fluid, alive, mouse-reactive. */
export function AgentOrb({ size = 280, state = "idle", className, style }: AgentOrbProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.scale(dpr, dpr);

    const st = { mx: 0.5, my: 0.5, tx: 0.5, ty: 0.5, hover: false, ha: 0, time: 0 };

    // Fibonacci sphere particles
    const sphere = Array.from({ length: 600 }, (_, i) => {
      const k = (i + 0.5) / 600;
      return {
        phi:   Math.acos(1 - 2 * k),
        theta: Math.PI * (1 + Math.sqrt(5)) * i,
        r:     76 + (Math.random() - 0.5) * 4,
        phase: Math.random() * Math.PI * 2,
        spd:   0.4 + Math.random() * 0.6,
        sz:    0.4 + Math.random() * 1.3,
        br:    0.35 + Math.random() * 0.55,
      };
    });

    // Inflow particles
    const spawnFree = (initial: boolean) => {
      const ang  = Math.random() * Math.PI * 2;
      const dist = 100 + Math.random() * 30;
      const spd  = 0.3 + Math.random() * 0.3;
      return {
        x: Math.cos(ang) * dist, y: Math.sin(ang) * dist,
        vx: -Math.cos(ang) * spd, vy: -Math.sin(ang) * spd,
        life: initial ? Math.random() * 0.8 : 1.0,
        decay: 0.012 + Math.random() * 0.008,
        sz:    0.5 + Math.random() * 0.7,
        curl:  (Math.random() - 0.5) * 0.025,
      };
    };
    const free = Array.from({ length: 28 }, () => spawnFree(true));

    const C = size / 2;
    let raf: number;
    let last = performance.now();

    const frame = (now: number) => {
      const dt = Math.min(33, now - last); last = now;
      st.time += dt;

      const ease = st.hover ? 0.08 : 0.04;
      st.mx += (st.tx - st.mx) * ease;
      st.my += (st.ty - st.my) * ease;
      st.ha += ((st.hover ? 1 : 0) - st.ha) * 0.045;
      const dx = (st.mx - 0.5) * 2, dy = (st.my - 0.5) * 2, ha = st.ha;

      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = "rgba(0,0,0,0.22)";
      ctx.fillRect(0, 0, size, size);
      ctx.globalCompositeOperation = "lighter";

      const rotY = st.time * 0.00028 + dx * 0.5;
      const rotX = st.time * 0.00011 + dy * 0.3;
      const cY = Math.cos(rotY), sY = Math.sin(rotY);
      const cX = Math.cos(rotX), sX = Math.sin(rotX);

      const drawn = sphere.map(p => {
        const wobble = Math.sin(st.time * 0.0009 * p.spd + p.phase) * 2.5 * (1 + ha * 2.5);
        const rr = p.r + wobble;
        const x0 = rr * Math.sin(p.phi) * Math.cos(p.theta);
        const y0 = rr * Math.sin(p.phi) * Math.sin(p.theta);
        const z0 = rr * Math.cos(p.phi);
        const x1 = x0 * cY - z0 * sY, z1 = x0 * sY + z0 * cY;
        return [x1, y0 * cX - z1 * sX, y0 * sX + z1 * cX, p] as const;
      }).sort((a, b) => a[2] - b[2]);

      for (const [x, y, z, p] of drawn) {
        const depth = Math.max(0, Math.min(1, (z + 80) / 160));
        const alpha = p.br * (0.18 + depth * 0.82) * (0.7 + ha * 0.4);
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${alpha})`;
        ctx.arc(C + x, C + y, p.sz * (0.35 + depth * 0.85), 0, Math.PI * 2);
        ctx.fill();
      }

      for (let i = free.length - 1; i >= 0; i--) {
        const f = free[i];
        const fd = Math.sqrt(f.x * f.x + f.y * f.y);
        if (fd > 0.5) {
          f.vx += (-f.x / fd) * 0.05 + (-f.y / fd) * f.curl * 4;
          f.vy += (-f.y / fd) * 0.05 + ( f.x / fd) * f.curl * 4;
        }
        f.vx *= 0.97; f.vy *= 0.97;
        f.x += f.vx; f.y += f.vy;
        f.life -= f.decay;
        if (fd < 60 || f.life <= 0) { free[i] = spawnFree(false); continue; }
        const la = f.life > 0.65 ? (1 - f.life) / 0.35 : f.life / 0.65;
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${Math.max(0, Math.min(1, la)) * 0.55})`;
        ctx.arc(C + f.x, C + f.y, f.sz, 0, Math.PI * 2);
        ctx.fill();
      }

      // Equatorial rim
      for (let i = 0; i < 80; i++) {
        const t = (i / 80) * Math.PI * 2;
        const rimR = 78 + Math.sin(st.time * 0.0015 + t * 3) * 1.5;
        const x0 = rimR * Math.cos(t), z0 = rimR * Math.sin(t);
        const x1 = x0 * cY - z0 * sY, z1 = x0 * sY + z0 * cY;
        const y2 = -z1 * sX, z2 = z1 * cX;
        const d2 = Math.max(0, Math.min(1, (z2 + 80) / 160));
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${0.18 * Math.pow(d2, 1.5) * (0.6 + ha * 0.5)})`;
        ctx.arc(C + x1, C + y2, 0.9 + d2 * 0.8, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalCompositeOperation = "source-over";
      const halo = ctx.createRadialGradient(C, C, 40, C, C, C);
      halo.addColorStop(0,    `rgba(255,255,255,${0.04 + ha * 0.07})`);
      halo.addColorStop(0.45, `rgba(255,255,255,${0.02 + ha * 0.03})`);
      halo.addColorStop(1,    "rgba(255,255,255,0)");
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, size, size);

      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    const onMove  = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      st.tx = (e.clientX - r.left) / r.width;
      st.ty = (e.clientY - r.top)  / r.height;
    };
    const onEnter = () => { st.hover = true; };
    const onLeave = () => { st.hover = false; st.tx = 0.5; st.ty = 0.5; };

    canvas.addEventListener("mousemove",  onMove);
    canvas.addEventListener("mouseenter", onEnter);
    canvas.addEventListener("mouseleave", onLeave);
    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener("mousemove",  onMove);
      canvas.removeEventListener("mouseenter", onEnter);
      canvas.removeEventListener("mouseleave", onLeave);
    };
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      className={cn(className)}
      style={{
        width: size, height: size, cursor: "default",
        WebkitMaskImage: "radial-gradient(circle, black 60%, transparent 92%)",
        maskImage:        "radial-gradient(circle, black 60%, transparent 92%)",
        ...style,
      }}
    />
  );
}

/** Mini particle orb — used inline in chat, nav marks, approval bar. */
export function MiniOrb({ size = 18, className }: { size?: number; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const orbRef    = useRef({ rotY: Math.random() * Math.PI * 2, hover: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.scale(dpr, dpr);

    const r     = size * 0.3;
    const N     = 18;
    const parts = Array.from({ length: N }, (_, i) => ({
      phi:   Math.acos(1 - 2 * (i + 0.5) / N),
      theta: Math.PI * (1 + Math.sqrt(5)) * i,
      sz:    0.3 + Math.random() * 0.4,
      br:    0.4 + Math.random() * 0.5,
    }));

    const orb = orbRef.current;
    const C   = size / 2;
    let raf: number;
    let last = performance.now();

    const loop = (now: number) => {
      const dt = Math.min(33, now - last); last = now;
      orb.rotY += dt * (orb.hover ? 0.0035 : 0.0012);
      const cY = Math.cos(orb.rotY), sY = Math.sin(orb.rotY);

      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ctx.fillRect(0, 0, size, size);
      ctx.globalCompositeOperation = "lighter";

      const drawn = parts.map(p => {
        const x0 = r * Math.sin(p.phi) * Math.cos(p.theta);
        const y0 = r * Math.sin(p.phi) * Math.sin(p.theta);
        const z0 = r * Math.cos(p.phi);
        return [x0 * cY - z0 * sY, y0, x0 * sY + z0 * cY, p] as const;
      }).sort((a, b) => a[2] - b[2]);

      for (const [x, y, z, p] of drawn) {
        const depth = (z + r) / (2 * r);
        const alpha = p.br * (0.3 + depth * 0.7) * (orb.hover ? 1.4 : 0.9);
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${Math.min(1, alpha)})`;
        ctx.arc(C + x, C + y, p.sz * (0.4 + depth * 0.7), 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalCompositeOperation = "source-over";
      const g = ctx.createRadialGradient(C, C, 0, C, C, r * 1.4);
      g.addColorStop(0, `rgba(255,255,255,${0.22 + (orb.hover ? 0.3 : 0)})`);
      g.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, size, size);

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const parent = canvas.parentElement;
    const onEnter = () => { orb.hover = true; };
    const onLeave = () => { orb.hover = false; };
    parent?.addEventListener("mouseenter", onEnter);
    parent?.addEventListener("mouseleave", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      parent?.removeEventListener("mouseenter", onEnter);
      parent?.removeEventListener("mouseleave", onLeave);
    };
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      className={cn("rounded-full", className)}
      style={{ width: size, height: size }}
    />
  );
}
