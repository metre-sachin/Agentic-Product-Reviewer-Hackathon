"use client";

import { useState } from "react";
import useSWR from "swr";
import { api } from "@/lib/api";

function ageOf(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const day = Math.floor(diff / 86_400_000);
  if (day < 1) return "today";
  if (day < 7) return `${day}d ago`;
  if (day < 30) return `${Math.floor(day / 7)}w ago`;
  return `${Math.floor(day / 30)}mo ago`;
}

export function MemorySection() {
  const { data: memories, mutate } = useSWR("memories", api.listMemories);
  const [adding, setAdding] = useState(false);
  const [tag, setTag] = useState("");
  const [text, setText] = useState("");

  async function add() {
    if (!tag.trim() || !text.trim()) return;
    await api.createMemory(tag.trim(), text.trim());
    setTag("");
    setText("");
    setAdding(false);
    await mutate();
  }

  async function remove(id: string) {
    await api.deleteMemory(id);
    await mutate();
  }

  const list = memories ?? [];

  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="text-[13px] font-medium">Memory</h3>
        <div className="font-mono text-[11px] text-fog-400">
          {list.length} ITEMS · ENCRYPTED
        </div>
      </div>
      <div className="rounded-xl border border-mist bg-ink-800 px-4 py-3.5">
        <div className="flex flex-col gap-2">
          {list.length === 0 && !adding && (
            <div className="py-2 text-[12px] text-fog-400">
              No memories yet. Add preferences Argus should remember across tasks.
            </div>
          )}
          {list.map((m) => (
            <div key={m.id} className="group flex items-center gap-2.5 py-1.5 text-[13px]">
              <span className="min-w-[64px] font-mono text-[10px] text-fog-400">{m.tag}</span>
              <span className="flex-1">{m.text}</span>
              <span className="font-mono text-[10px] text-fog-400">{ageOf(m.created_at)}</span>
              <button
                onClick={() => remove(m.id)}
                className="text-fog-500 opacity-0 transition-opacity group-hover:opacity-100 hover:text-signal-err"
              >
                ×
              </button>
            </div>
          ))}
        </div>

        {adding ? (
          <div className="mt-3 flex items-center gap-2 border-t border-white/[0.04] pt-3">
            <input
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              placeholder="TAG"
              className="w-[90px] bg-ink-900 border border-mist rounded-md px-2 py-1.5 font-mono text-[11px] uppercase text-fog-50 placeholder:text-fog-400 outline-none focus:border-mist-strong"
            />
            <input
              autoFocus
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && add()}
              placeholder="e.g. Vegetarian, high-protein, avoid palm oil"
              className="flex-1 bg-ink-900 border border-mist rounded-md px-2.5 py-1.5 text-[13px] text-fog-50 placeholder:text-fog-400 outline-none focus:border-mist-strong"
            />
            <button onClick={add} className="rounded-md bg-fog-50 px-2.5 py-1.5 text-[12px] text-ink-900">
              Save
            </button>
            <button
              onClick={() => setAdding(false)}
              className="rounded-md border border-mist px-2.5 py-1.5 text-[12px] text-fog-300"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => setAdding(true)}
            className="mt-3 w-full border-t border-white/[0.04] pt-3 text-left text-[12px] text-fog-300 hover:text-fog-50"
          >
            + Add memory
          </button>
        )}
      </div>
    </section>
  );
}
