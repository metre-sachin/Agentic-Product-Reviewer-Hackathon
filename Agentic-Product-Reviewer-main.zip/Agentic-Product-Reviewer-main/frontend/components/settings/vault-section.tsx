"use client";

import useSWR from "swr";
import { api, type VaultEntryOut } from "@/lib/api";

function titleFor(entry: VaultEntryOut): string {
  if (entry.kind === "identity") return "Personal details";
  return entry.label;
}

function codeFor(entry: VaultEntryOut): string {
  if (entry.kind === "identity") return "ID";
  const base = entry.label.replace(/^www\./, "").split(".")[0] ?? entry.label;
  return base.slice(0, 2).toUpperCase();
}

function ageOf(iso: string | null): string {
  if (!iso) return "never used";
  const diff = Date.now() - new Date(iso).getTime();
  const day = Math.floor(diff / 86_400_000);
  if (day < 1) return "used today";
  if (day < 7) return `used ${day}d ago`;
  if (day < 30) return `used ${Math.floor(day / 7)}w ago`;
  return `used ${Math.floor(day / 30)}mo ago`;
}

export function VaultSection() {
  const { data: settings, mutate: mutateSettings } = useSWR("settings", api.getSettings);
  const { data: entries, mutate } = useSWR("vault", api.listVault);

  const autofill = settings?.autofill_enabled ?? true;
  const list = entries ?? [];

  async function toggleAutofill() {
    await api.updateSettings({ autofill_enabled: !autofill });
    await mutateSettings();
  }

  async function toggleAsk(entry: VaultEntryOut) {
    await api.updateVault(entry.id, { ask_every_time: !entry.ask_every_time });
    await mutate();
  }

  async function remove(id: string) {
    await api.deleteVault(id);
    await mutate();
  }

  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="text-[13px] font-medium">Vault</h3>
        <div className="font-mono text-[11px] text-fog-400">
          {list.length} SAVED · ENCRYPTED
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        {/* Autofill master toggle */}
        <div className="flex items-center justify-between gap-3 border-b border-white/[0.04] px-4 py-3.5">
          <div>
            <div className="text-[13px] font-medium">Autofill saved credentials</div>
            <div className="font-mono text-[11px] text-fog-400">
              Sign in and fill your details without asking. OTP codes are always asked.
            </div>
          </div>
          <Toggle on={autofill} onClick={toggleAutofill} />
        </div>

        {list.length === 0 && (
          <div className="px-4 py-5 text-center text-[12px] text-fog-400">
            Nothing saved yet. When Argus signs in or fills your details for a task, it
            stores them here encrypted so it won&apos;t need to ask again.
          </div>
        )}

        {list.map((entry) => (
          <div
            key={entry.id}
            className="grid grid-cols-[32px_1fr_auto_auto] items-center gap-3.5 border-b border-white/[0.04] px-4 py-3.5 last:border-b-0"
          >
            <div className="grid h-7 w-7 place-items-center rounded-lg border border-mist-strong bg-white/[0.05] font-mono text-[11px]">
              {codeFor(entry)}
            </div>
            <div className="min-w-0">
              <div className="truncate text-[13px] font-medium">{titleFor(entry)}</div>
              <div className="font-mono text-[11px] text-fog-400">
                {entry.fields.join(" · ") || "—"} · {ageOf(entry.last_used_at)}
              </div>
            </div>
            <button
              onClick={() => toggleAsk(entry)}
              title={
                entry.ask_every_time
                  ? "Currently asks before using — click to autofill silently"
                  : "Currently autofills — click to ask each time"
              }
              className={`rounded-md border px-2.5 py-1 text-[11px] transition-colors ${
                entry.ask_every_time
                  ? "border-mist text-fog-300 hover:text-fog-50"
                  : "border-[#C4F0C8]/30 bg-[#C4F0C8]/10 text-[#C4F0C8]"
              }`}
            >
              {entry.ask_every_time ? "Ask each time" : "Autofills"}
            </button>
            <button
              onClick={() => remove(entry.id)}
              className="rounded-md border border-mist bg-transparent px-2.5 py-1 text-[11px] text-fog-300 hover:text-signal-err"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${
        on ? "bg-[#C4F0C8]" : "bg-white/[0.12]"
      }`}
    >
      <span
        className={`absolute top-0.5 h-4 w-4 rounded-full bg-ink-900 transition-transform ${
          on ? "translate-x-[18px]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}
