"use client";

import useSWR from "swr";
import { api } from "@/lib/api";
import { BROWSER_MODE_OPTIONS } from "@/lib/ui-config";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";

export function BrowserModes() {
  const { data: settings, mutate } = useSWR("settings", api.getSettings);
  const selected = settings?.browser_mode ?? "browser";
  const headed = settings?.browser_headless === false;

  async function choose(key: string) {
    await mutate(
      async () => api.updateSettings({ browser_mode: key }),
      { optimisticData: settings ? { ...settings, browser_mode: key } : undefined, revalidate: false },
    );
  }

  async function setHeaded(show: boolean) {
    await mutate(
      async () => api.updateSettings({ browser_headless: !show }),
      {
        optimisticData: settings ? { ...settings, browser_headless: !show } : undefined,
        revalidate: false,
      },
    );
  }

  async function patch(patch: Partial<NonNullable<typeof settings>>) {
    await mutate(
      async () => api.updateSettings(patch),
      { optimisticData: settings ? { ...settings, ...patch } : undefined, revalidate: false },
    );
  }

  return (
    <section>
      <h3 className="mb-3 text-[13px] font-medium">Browser mode</h3>
      <div className="grid grid-cols-3 gap-2.5">
        {BROWSER_MODE_OPTIONS.map((m) => {
          const isSelected = m.key === selected;
          return (
            <button
              key={m.key}
              onClick={() => choose(m.key)}
              className={cn(
                "rounded-xl border p-4 text-left transition-colors",
                isSelected
                  ? "border-white/20 bg-white/[0.04]"
                  : "border-mist bg-white/[0.02] hover:bg-white/[0.03]",
              )}
            >
              <div className="flex items-center justify-between">
                <div className="text-[13px] font-medium">{m.title}</div>
                <div
                  className={cn(
                    "grid place-items-center w-3.5 h-3.5 rounded-full border-[1.5px]",
                    isSelected ? "border-fog-50" : "border-fog-400",
                  )}
                >
                  {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-fog-50" />}
                </div>
              </div>
              <div className="mt-2 text-[12px] leading-relaxed text-fog-300">{m.desc}</div>
              <div className="mt-2.5 font-mono text-[10px] tracking-wider text-fog-400">{m.meta}</div>
            </button>
          );
        })}
      </div>
      <p className="mt-2 px-1 text-[11px] text-fog-400">
        Argus drives one shared connected browser. The autonomous Browser Use layer (its own
        separate window) is off by default — enable it via <code>ENABLE_BROWSER_USE</code>, ideally
        with a CDP URL below so it reuses your browser instead of launching another.
      </p>

      <div className="mt-4 flex items-center justify-between rounded-xl border border-mist bg-white/[0.02] p-4">
        <div className="pr-4">
          <div className="text-[13px] font-medium">Show the browser window</div>
          <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
            Run a visible (headed) browser instead of a hidden one. The window opens on the
            machine running Argus, so you can watch it work. The live preview in the task page
            works either way.
          </div>
        </div>
        <Switch
          checked={headed}
          onCheckedChange={setHeaded}
          aria-label="Show the browser window"
        />
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <label className="rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="text-[13px] font-medium">Browser Use model</div>
          <input
            value={settings?.browser_use_model ?? "gpt-4o"}
            onChange={(e) => patch({ browser_use_model: e.target.value })}
            className="mt-2 w-full rounded-md border border-mist bg-ink-900 px-2.5 py-1.5 font-mono text-[12px] text-fog-50 outline-none focus:border-mist-strong"
            placeholder="gpt-4o or bu-2-0"
          />
        </label>

        <label className="rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="text-[13px] font-medium">Connected browser CDP URL</div>
          <input
            value={settings?.browser_cdp_url ?? ""}
            onChange={(e) => patch({ browser_cdp_url: e.target.value })}
            className="mt-2 w-full rounded-md border border-mist bg-ink-900 px-2.5 py-1.5 font-mono text-[12px] text-fog-50 outline-none focus:border-mist-strong"
            placeholder="http://localhost:9222"
          />
        </label>
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <div className="flex items-center justify-between rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="pr-4">
            <div className="text-[13px] font-medium">Use system Chrome profile</div>
            <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
              Let Browser Use launch from a local Chrome profile instead of an isolated session.
            </div>
          </div>
          <Switch
            checked={settings?.browser_use_system_chrome ?? false}
            onCheckedChange={(value) => patch({ browser_use_system_chrome: value })}
            aria-label="Use system Chrome profile"
          />
        </div>

        <label className="rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="text-[13px] font-medium">Chrome profile</div>
          <input
            value={settings?.browser_chrome_profile ?? ""}
            onChange={(e) => patch({ browser_chrome_profile: e.target.value })}
            className="mt-2 w-full rounded-md border border-mist bg-ink-900 px-2.5 py-1.5 font-mono text-[12px] text-fog-50 outline-none focus:border-mist-strong"
            placeholder="Default"
          />
        </label>
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-3">
        <div className="flex items-center justify-between rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="pr-4">
            <div className="text-[13px] font-medium">Browser Use CAPTCHA solver</div>
            <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
              Enables Browser Use's native CAPTCHA handling when available.
            </div>
          </div>
          <Switch
            checked={settings?.browser_use_captcha_solver ?? true}
            onCheckedChange={(value) => patch({ browser_use_captcha_solver: value })}
            aria-label="Browser Use CAPTCHA solver"
          />
        </div>

        <div className="flex items-center justify-between rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="pr-4">
            <div className="text-[13px] font-medium">Read simple CAPTCHA</div>
            <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
              Argus vision tries one text CAPTCHA read before asking you.
            </div>
          </div>
          <Switch
            checked={settings?.captcha_autosolve ?? true}
            onCheckedChange={(value) => patch({ captcha_autosolve: value })}
            aria-label="Read simple CAPTCHA"
          />
        </div>

        <div className="flex items-center justify-between rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="pr-4">
            <div className="text-[13px] font-medium">Manual assist</div>
            <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
              Ask you for credentials, OTP, CAPTCHA, or a recovery instruction when blocked.
            </div>
          </div>
          <Switch
            checked={settings?.manual_assist_enabled ?? true}
            onCheckedChange={(value) => patch({ manual_assist_enabled: value })}
            aria-label="Manual assist"
          />
        </div>
      </div>
    </section>
  );
}
