"use client";

import { useState } from "react";
import useSWR from "swr";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";

function codeFor(domain: string): string {
  const base = domain.replace(/^www\./, "").split(".")[0] ?? domain;
  return base.slice(0, 2).toUpperCase();
}

export function ConnectedAccounts() {
  const { data: sites, mutate } = useSWR("connected-sites", api.listSites);
  const [adding, setAdding] = useState(false);
  const [domain, setDomain] = useState("");

  async function add() {
    const d = domain.trim().toLowerCase();
    if (!d) return;
    await api.createSite(d);
    setDomain("");
    setAdding(false);
    await mutate();
  }

  async function revoke(id: string) {
    await api.deleteSite(id);
    await mutate();
  }

  return (
    <section>
      <h3 className="mb-3 text-[13px] font-medium">Connected accounts</h3>
      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        {(sites ?? []).length === 0 && !adding && (
          <div className="px-4 py-5 text-center text-[12px] text-fog-400">
            No sites connected yet. Argus connects to sites as your tasks need them.
          </div>
        )}
        {(sites ?? []).map((a) => (
          <div
            key={a.id}
            className="grid grid-cols-[32px_1fr_auto_auto] items-center gap-3.5 border-b border-white/[0.04] px-4 py-3.5 last:border-b-0"
          >
            <div className="grid place-items-center w-7 h-7 rounded-lg border border-mist-strong bg-white/[0.05] font-mono text-[11px]">
              {codeFor(a.domain)}
            </div>
            <div>
              <div className="text-[13px] font-medium">{a.display_name ?? a.domain}</div>
              <div className="font-mono text-[11px] text-fog-400">
                {a.has_session
                  ? "Session saved · stays signed in across tasks"
                  : a.scopes.length > 0
                    ? a.scopes.join(" · ")
                    : a.domain}
              </div>
            </div>
            <Badge variant={a.status === "error" ? "mono" : "success"}>{a.status.toUpperCase()}</Badge>
            <button
              onClick={() => revoke(a.id)}
              className="rounded-md border border-mist bg-transparent px-2.5 py-1 text-[11px] text-fog-300 hover:text-fog-50"
            >
              Revoke
            </button>
          </div>
        ))}

        {adding ? (
          <div className="flex items-center gap-2 px-4 py-3">
            <input
              autoFocus
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && add()}
              placeholder="example.com"
              className="flex-1 bg-ink-900 border border-mist rounded-md px-2.5 py-1.5 text-[13px] text-fog-50 placeholder:text-fog-400 outline-none focus:border-mist-strong"
            />
            <button onClick={add} className="rounded-md bg-fog-50 px-2.5 py-1.5 text-[12px] text-ink-900">
              Add
            </button>
            <button
              onClick={() => setAdding(false)}
              className="rounded-md border border-mist px-2.5 py-1.5 text-[12px] text-fog-300"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => setAdding(true)}
            className="w-full bg-transparent py-3 text-[12px] text-fog-300 hover:text-fog-50"
          >
            + Connect account
          </button>
        )}
      </div>
    </section>
  );
}
