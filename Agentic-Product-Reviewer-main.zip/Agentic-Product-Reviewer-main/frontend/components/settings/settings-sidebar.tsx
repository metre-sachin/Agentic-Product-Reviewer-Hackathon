"use client";

import { SETTINGS_NAV } from "@/lib/ui-config";
import { useEffect, useState } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";

const SECTION_IDS: Record<string, string> = {
  safety: "settings-safety",
  browser: "settings-browser",
  connect: "settings-connect",
  accounts: "settings-accounts",
  vault: "settings-vault",
  memory: "settings-memory",
  model: "settings-model",
  billing: "settings-billing",
};

export function SettingsSidebar() {
  const [active, setActive] = useState<string>("safety");

  // Scrollspy: highlight the section currently in view.
  useEffect(() => {
    const entries = Object.entries(SECTION_IDS);
    const observer = new IntersectionObserver(
      (obs) => {
        const visible = obs
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) {
          const key = entries.find(([, id]) => id === visible.target.id)?.[0];
          if (key) setActive(key);
        }
      },
      { rootMargin: "-20% 0px -70% 0px", threshold: [0, 0.5, 1] },
    );
    for (const [, id] of entries) {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  function go(key: string) {
    setActive(key);
    const el = document.getElementById(SECTION_IDS[key]);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <aside className="flex flex-col gap-1 border-r border-white/[0.05] bg-ink-900 px-3 py-4">
      <Link href="/dashboard" className="flex items-center gap-2.5 px-2.5 pt-2 pb-4">
        <div className="grid place-items-center w-[22px] h-[22px] rounded-full border border-white/40">
          <div className="w-1.5 h-1.5 rounded-full bg-fog-50 shadow-[0_0_8px_rgba(255,255,255,0.6)]" />
        </div>
        <span className="text-sm font-medium">Argus</span>
      </Link>
      <div className="px-2.5 pt-1 pb-1.5 font-mono text-[10px] tracking-widest text-fog-500">SETTINGS</div>
      {SETTINGS_NAV.map((n) => {
        const isActive = n.key === active;
        return (
          <button
            key={n.key}
            onClick={() => go(n.key)}
            className={cn(
              "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-[13px] transition-colors",
              isActive
                ? "bg-white/[0.04] text-fog-50"
                : "text-fog-300 hover:text-fog-50 hover:bg-white/[0.02]",
            )}
          >
            <span className="grid place-items-center w-[14px] h-[14px] font-mono text-[11px] text-fog-400">
              {n.icon}
            </span>
            {n.label}
          </button>
        );
      })}
      <Link
        href="/dashboard"
        className="mt-auto rounded-md border border-mist bg-transparent px-2.5 py-1.5 text-center text-[12px] text-fog-300 hover:text-fog-50"
      >
        ← Back to dashboard
      </Link>
    </aside>
  );
}
