"use client";

import useSWR from "swr";
import { api } from "@/lib/api";

const MODELS = [
  { id: "gpt-4o-mini", label: "Cheapest · fast, great for most tasks" },
  { id: "gpt-4o", label: "Most capable · vision + hard reasoning" },
];

export function ModelCard() {
  const { data: settings, mutate } = useSWR("settings", api.getSettings);
  const current = settings?.preferred_model ?? "gpt-4o-mini";

  async function choose(id: string) {
    await mutate(
      async () => api.updateSettings({ preferred_model: id }),
      { optimisticData: settings ? { ...settings, preferred_model: id } : undefined, revalidate: false },
    );
  }

  return (
    <section>
      <h3 className="mb-3 text-[13px] font-medium">Model</h3>
      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        {MODELS.map((m) => {
          const active = m.id === current;
          return (
            <button
              key={m.id}
              onClick={() => choose(m.id)}
              className="grid w-full grid-cols-[1fr_auto] items-center gap-3.5 border-b border-white/[0.04] px-4 py-3.5 text-left last:border-b-0 hover:bg-white/[0.02]"
            >
              <div>
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-sm font-medium">{m.id}</span>
                  {active && (
                    <span className="rounded bg-white/[0.05] px-1.5 py-0.5 font-mono text-[10px] text-fog-300">
                      SELECTED
                    </span>
                  )}
                </div>
                <div className="mt-1.5 text-[12px] text-fog-300">{m.label}</div>
              </div>
              <div
                className="grid place-items-center w-3.5 h-3.5 rounded-full border-[1.5px]"
                style={{ borderColor: active ? "#F4F4F5" : "#6B6B72" }}
              >
                {active && <div className="w-1.5 h-1.5 rounded-full bg-fog-50" />}
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
