"use client";

import useSWR from "swr";
import { api } from "@/lib/api";
import { APPROVAL_RULE_DEFINITIONS } from "@/lib/ui-config";
import { Switch } from "@/components/ui/switch";

export function SafetyRules() {
  const { data: settings, mutate } = useSWR("settings", api.getSettings);
  const rules = (settings?.approval_rules ?? {}) as Record<string, unknown>;

  function isOn(key: string): boolean {
    const v = rules[key];
    if (key === "spend_over") return v != null && Number(v) > 0;
    return Boolean(v);
  }

  async function toggle(key: string, lock: boolean, next: boolean) {
    if (lock) return; // hard-locked rules cannot be turned off
    const updated = { ...rules };
    if (key === "spend_over") {
      updated[key] = next ? 500 : 0;
    } else {
      updated[key] = next;
    }
    await mutate(
      async () => api.updateSettings({ approval_rules: updated }),
      { optimisticData: settings ? { ...settings, approval_rules: updated } : undefined, revalidate: false },
    );
  }

  return (
    <section>
      <h3 className="mb-3 text-[13px] font-medium">Always require approval before</h3>
      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        {APPROVAL_RULE_DEFINITIONS.map((r) => (
          <div
            key={r.key}
            className="grid grid-cols-[1fr_auto] items-center gap-4 border-b border-white/[0.04] px-4 py-3.5 last:border-b-0"
          >
            <div>
              <div className="flex items-center gap-2 text-[13px] font-medium">
                {r.title}
                {r.lock && (
                  <span className="rounded bg-white/[0.05] px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-fog-400">
                    LOCKED
                  </span>
                )}
              </div>
              <div className="mt-0.5 text-[12px] text-fog-400">{r.desc}</div>
            </div>
            <Switch
              checked={r.lock ? true : isOn(r.key)}
              disabled={r.lock}
              onCheckedChange={(v) => toggle(r.key, r.lock, v)}
            />
          </div>
        ))}
      </div>
      <p className="mt-2 px-1 text-[11px] text-fog-400">
        Payment and identity-form submissions are always gated — these cannot be disabled.
      </p>
    </section>
  );
}
