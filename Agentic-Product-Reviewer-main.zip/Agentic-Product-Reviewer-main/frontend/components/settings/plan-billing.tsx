"use client";

import { useEffect, useState } from "react";
import useSWR from "swr";
import { api, type SettingsOut } from "@/lib/api";

export function PlanBilling() {
  const { data: settings, mutate } = useSWR<SettingsOut>("settings", api.getSettings);
  const [limit, setLimit] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (settings) {
      const v = Number(settings.approval_rules?.spend_over ?? 500);
      setLimit(String(v));
    }
  }, [settings]);

  async function save() {
    if (!settings) return;
    const n = Math.max(0, Math.round(Number(limit) || 0));
    setSaving(true);
    setSaved(false);
    try {
      const rules = { ...(settings.approval_rules ?? {}), spend_over: n };
      await mutate(
        async () => api.updateSettings({ approval_rules: rules }),
        { optimisticData: { ...settings, approval_rules: rules }, revalidate: false },
      );
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  }

  return (
    <section>
      <h3 className="mb-3 text-[13px] font-medium">Plan &amp; billing</h3>
      <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
        <div className="flex items-center justify-between border-b border-white/[0.04] px-4 py-3.5">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-medium">Argus MVP</span>
              <span className="rounded bg-white/[0.05] px-1.5 py-0.5 font-mono text-[10px] text-fog-300">
                CURRENT
              </span>
            </div>
            <div className="mt-1.5 text-[12px] text-fog-300">
              Self-hosted. Unlimited tasks — you provide the OpenAI key.
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 px-4 py-3.5">
          <div>
            <div className="text-[13px] font-medium">Approval threshold for spending</div>
            <div className="mt-0.5 text-[12px] text-fog-400">
              Argus pauses for approval before spending more than this on a single task.
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="font-mono text-[13px] text-fog-400">₹</span>
            <input
              type="number"
              min={0}
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && save()}
              className="w-[90px] rounded-md border border-mist bg-ink-900 px-2.5 py-1.5 text-right font-mono text-[13px] text-fog-50 outline-none focus:border-mist-strong"
            />
            <button
              onClick={save}
              disabled={saving}
              className="rounded-md bg-fog-50 px-3 py-1.5 text-[12px] font-medium text-ink-900 hover:bg-white disabled:opacity-50"
            >
              {saving ? "Saving…" : saved ? "Saved ✓" : "Save"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
