"use client";

import { useEffect, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import useSWR from "swr";
import { api } from "@/lib/api";
import { decodeJwtExpiry, formatExpiry } from "@/lib/jwt";
import { cn } from "@/lib/utils";

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000";
// Matches the stable manifest.key pinned in v2/packages/extension/wxt.config.ts.
const EXTENSION_ID =
  process.env.NEXT_PUBLIC_ARGUS_EXTENSION_ID ?? "gijcoaaofgeakofpgblonfaininkiifh";

type PairState = "idle" | "pairing" | "paired" | "not-installed" | "error";

declare global {
  interface Window {
    chrome?: {
      runtime?: {
        sendMessage: (
          extensionId: string,
          message: unknown,
          callback: (response: unknown) => void,
        ) => void;
        lastError?: { message?: string };
      };
    };
  }
}

export function ConnectBrowser() {
  const { data: session } = useSession();
  const token = session?.backendAccessToken;
  const [copied, setCopied] = useState(false);
  const [pairState, setPairState] = useState<PairState>("idle");
  const lastAutoPairToken = useRef<string | null>(null);

  const { data: status } = useSWR("v2-status", () => api.getV2Status(), {
    refreshInterval: 5000,
  });

  const expiry = token ? decodeJwtExpiry(token) : null;

  async function copyToken() {
    if (!token) return;
    await navigator.clipboard.writeText(token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function openBookmarklet() {
    if (!token) return;
    window.open(`${BACKEND_URL}/v2/bookmarklet#token=${encodeURIComponent(token)}`, "_blank");
  }

  function pairExtension(silent = false) {
    if (!token) return;
    const chromeRuntime = window.chrome?.runtime;
    if (!chromeRuntime?.sendMessage) {
      if (!silent) setPairState("not-installed");
      return;
    }
    if (!silent) setPairState("pairing");
    chromeRuntime.sendMessage(
      EXTENSION_ID,
      { type: "argus-pair", backendUrl: BACKEND_URL, token },
      (response) => {
        const err = chromeRuntime.lastError;
        if (err || !response || typeof response !== "object" || !(response as { ok?: boolean }).ok) {
          if (!silent) setPairState(err ? "not-installed" : "error");
          return;
        }
        setPairState("paired");
      },
    );
  }

  // Pair once without prompting whenever the signed-in app sees the extension.
  // The extension persists this config in chrome.storage.local, so subsequent
  // browser launches reconnect even when the Argus web app is not open.
  useEffect(() => {
    if (!token || lastAutoPairToken.current === token) return;
    lastAutoPairToken.current = token;
    pairExtension(true);
  }, [token]);

  // Re-check connection status right after a successful pairing round-trip.
  useEffect(() => {
    if (pairState !== "paired") return;
    const timer = setTimeout(() => void status, 1500);
    return () => clearTimeout(timer);
  }, [pairState, status]);

  const connected = status?.connected ?? false;

  return (
    <section>
      <h3 className="mb-1 text-[13px] font-medium">Connect your browser</h3>
      <p className="mb-3 text-[12px] leading-relaxed text-fog-300">
        Argus v2 acts inside your own browser — your real logged-in sessions, with auto-fill from
        memory. Pick one:
      </p>

      <div className="mb-3 flex items-center gap-2 rounded-xl border border-mist bg-white/[0.02] px-4 py-3">
        <div
          className={cn(
            "h-2 w-2 rounded-full",
            connected ? "bg-signal-ok" : "bg-fog-500",
          )}
        />
        <div className="text-[12px] text-fog-300">
          {connected
            ? `connected via ${status?.kind ?? "browser"}`
            : "no real browser connected — tasks in v2 mode fall back to the server browser"}
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        {/* Extension: zero-paste pairing */}
        <div className="rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="text-[13px] font-medium">Extension</div>
          <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
            Install it once and Argus reconnects whenever the browser opens. Load it unpacked from{" "}
            <code className="rounded bg-white/[0.05] px-1">v2/packages/extension/.output/chrome-mv3</code>,
            then connect once here. When the Argus app has a newer sign-in token, it re-pairs automatically.
          </div>
          <button
            onClick={() => pairExtension()}
            disabled={!token || pairState === "pairing"}
            className="mt-3 w-full rounded-md border border-mist bg-white/[0.04] px-3 py-1.5 text-[12px] font-medium text-fog-50 transition-colors hover:bg-white/[0.07] disabled:opacity-40"
          >
            {pairState === "pairing"
              ? "pairing…"
              : pairState === "paired"
                ? "Connected — auto reconnect on"
                : "Connect once"}
          </button>
          {pairState === "not-installed" && (
            <p className="mt-2 text-[11px] text-signal-warn">
              Extension not detected. Load it unpacked first, then click again.
            </p>
          )}
          {pairState === "error" && (
            <p className="mt-2 text-[11px] text-signal-err">
              Pairing failed — check the extension is up to date and try again.
            </p>
          )}
        </div>

        {/* Bookmarklet: zero-install */}
        <div className="rounded-xl border border-mist bg-white/[0.02] p-4">
          <div className="text-[13px] font-medium">Bookmarklet</div>
          <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
            Zero install, but it only connects the current page after you click the bookmark.
            It cannot reconnect itself after navigation or a browser restart.
          </div>
          <button
            onClick={openBookmarklet}
            disabled={!token}
            className="mt-3 w-full rounded-md border border-mist bg-white/[0.04] px-3 py-1.5 text-[12px] font-medium text-fog-50 transition-colors hover:bg-white/[0.07] disabled:opacity-40"
          >
            Open bookmarklet setup
          </button>
        </div>
      </div>

      <div className="mt-3 rounded-xl border border-mist bg-white/[0.02] p-4">
        <div className="flex items-center justify-between">
          <div className="text-[13px] font-medium">Your Argus token</div>
          <span className="font-mono text-[10px] tracking-wider text-fog-400">
            {formatExpiry(expiry)}
          </span>
        </div>
        <div className="mt-1 text-[12px] leading-relaxed text-fog-300">
          Only needed for manual setup (e.g. the extension side panel if pairing above isn't
          available). Never share it — it grants full access to your Argus account.
        </div>
        <button
          onClick={copyToken}
          disabled={!token}
          className="mt-3 rounded-md border border-mist bg-white/[0.04] px-3 py-1.5 text-[12px] font-medium text-fog-50 transition-colors hover:bg-white/[0.07] disabled:opacity-40"
        >
          {copied ? "✓ copied" : "Copy token"}
        </button>
      </div>
    </section>
  );
}
