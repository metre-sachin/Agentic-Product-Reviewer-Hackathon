import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#08080A",
          900: "#0B0B0E",
          850: "#0E0E12",
          800: "#0F0F11",
          750: "#15151A",
          700: "#16161A",
          600: "#1C1C20",
          500: "#2A2A2E",
        },
        fog: {
          50:  "#F4F4F5",
          300: "#A1A1A6",
          400: "#6B6B72",
          500: "#46464C",
          600: "#2A2A2E",
        },
        signal: {
          ok:   "#C4F0C8",
          warn: "#E8D2B4",
          err:  "#E8B4B4",
        },
        mist: {
          DEFAULT: "rgba(255,255,255,0.06)",
          strong:  "rgba(255,255,255,0.10)",
          soft:    "rgba(255,255,255,0.04)",
        },
      },
      fontFamily: {
        sans: ["var(--font-geist-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-geist-mono)", "ui-monospace", "monospace"],
      },
      borderRadius: {
        "xl": "0.875rem",
        "2xl": "1rem",
      },
      keyframes: {
        "argus-shimmer": {
          "0%":   { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "argus-caret": {
          "0%,49%":   { opacity: "1" },
          "50%,100%": { opacity: "0" },
        },
        "argus-pulse": {
          "0%,100%": { opacity: "1", transform: "scale(1)" },
          "50%":     { opacity: "0.4", transform: "scale(0.7)" },
        },
        "argus-bar": {
          "0%":   { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(400%)" },
        },
      },
      animation: {
        "argus-shimmer": "argus-shimmer 2.4s linear infinite",
        "argus-caret":   "argus-caret 1s steps(1) infinite",
        "argus-pulse":   "argus-pulse 1.8s ease-in-out infinite",
        "argus-bar":     "argus-bar 4s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
