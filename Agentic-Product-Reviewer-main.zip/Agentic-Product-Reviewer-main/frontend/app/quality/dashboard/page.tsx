import {Suspense} from 'react';
import {ReviewStation} from '@/components/quality/review-station';
import '../quality.css';
import '../dashboard.css';
export default function BatchDashboard(){return <Suspense fallback={<p>Loading batch reports…</p>}><ReviewStation dashboard/></Suspense>}
