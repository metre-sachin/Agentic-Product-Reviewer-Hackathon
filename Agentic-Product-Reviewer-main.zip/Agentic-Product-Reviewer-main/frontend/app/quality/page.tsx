import { Suspense } from 'react';
import { ReviewStation } from '@/components/quality/review-station';
import './quality.css';
export default function QualityPage(){return <Suspense fallback={<div className="quality-loading">Opening quality workspace…</div>}><ReviewStation/></Suspense>}
