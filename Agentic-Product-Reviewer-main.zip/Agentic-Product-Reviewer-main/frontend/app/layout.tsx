import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { ThemeProvider } from "@/lib/theme-context";
import { AppSessionProvider } from "@/lib/session-provider";
import "./globals.css";

export const metadata: Metadata = {
  title: "Autonomous Product Review",
  description: "AI-assisted industrial inspection, evidence review, and quality reporting.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="font-sans antialiased">
        <AppSessionProvider>
          <ThemeProvider>
            <div className="relative z-10">{children}</div>
          </ThemeProvider>
        </AppSessionProvider>
      </body>
    </html>
  );
}
