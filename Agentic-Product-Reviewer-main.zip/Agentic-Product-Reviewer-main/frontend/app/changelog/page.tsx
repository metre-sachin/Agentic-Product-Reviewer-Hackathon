import Link from "next/link";
import { PageShell } from "@/components/landing/page-shell";
import { Button } from "@/components/ui/button";

const RELEASES = [
  {
    version: "v0.9",
    date: "Jun 2026",
    title: "Demo polish & one-command run",
    notes: [
      "`./scripts/start.sh` boots the entire stack and prints the link",
      "Live capabilities endpoint shows which layers are active",
      "Seeded demo account with preferences",
    ],
  },
  {
    version: "v0.8",
    date: "Jun 2026",
    title: "Memory-driven planning",
    notes: [
      "Preferences embedded and retrieved at plan time",
      "Plans now reflect diet, budget, address, and travel rules automatically",
    ],
  },
  {
    version: "v0.7",
    date: "Jun 2026",
    title: "Vision fallback + human assist",
    notes: [
      "GPT-4o screenshot reasoning as the final automated layer",
      "Argus asks a clear question when every layer is unsure, then resumes",
    ],
  },
  {
    version: "v0.6",
    date: "Jun 2026",
    title: "Autonomous recovery",
    notes: [
      "Browser Use takes over when structured interaction stalls",
      "Automatic L2→L3 escalation, surfaced live in the timeline",
    ],
  },
  {
    version: "v0.5",
    date: "Jun 2026",
    title: "The acting layer",
    notes: [
      "Real clicks, typing, and form-fills via the accessibility tree",
      "Live browser screenshots stream into the execution screen",
      "Hard approval stop before any checkout",
    ],
  },
  {
    version: "v0.4",
    date: "Jun 2026",
    title: "The reading layer",
    notes: [
      "Scrapling reads the open web with anti-bot stealth",
      "Research and compare tasks complete end-to-end",
    ],
  },
  {
    version: "v0.3",
    date: "Jun 2026",
    title: "Real planner & live execution",
    notes: [
      "OpenAI planner turns goals into approval-gated plans",
      "Server-sent events stream plan, logs, and approvals live",
    ],
  },
];

export default function ChangelogPage() {
  return (
    <PageShell
      eyebrow="Changelog"
      title="What's new in Argus"
      subtitle="The build, shipped in the open. Newest first."
    >
      <div className="mx-auto max-w-[680px]">
        <ol className="relative border-l border-mist pl-7">
          {RELEASES.map((r) => (
            <li key={r.version} className="mb-9 last:mb-0">
              <span className="absolute -left-[6px] mt-1.5 h-[11px] w-[11px] rounded-full border border-mist-strong bg-ink-900" />
              <div className="flex items-baseline gap-3">
                <span className="font-mono text-[13px] text-fog-50">{r.version}</span>
                <span className="font-mono text-[11px] text-fog-400">{r.date}</span>
              </div>
              <div className="mt-1 text-[15px] font-medium">{r.title}</div>
              <ul className="mt-2.5 flex flex-col gap-1.5">
                {r.notes.map((n) => (
                  <li key={n} className="flex items-start gap-2.5 text-[13px] text-fog-300">
                    <span className="mt-0.5 text-fog-500">›</span>
                    <span>{n}</span>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>

        <div className="mt-12 flex justify-center">
          <Link href="/new">
            <Button>Try it now →</Button>
          </Link>
        </div>
      </div>
    </PageShell>
  );
}
