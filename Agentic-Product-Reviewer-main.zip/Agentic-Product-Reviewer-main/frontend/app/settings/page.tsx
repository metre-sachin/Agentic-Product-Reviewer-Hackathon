import { SettingsSidebar } from "@/components/settings/settings-sidebar";
import { SafetyRules } from "@/components/settings/safety-rules";
import { BrowserModes } from "@/components/settings/browser-modes";
import { ConnectBrowser } from "@/components/settings/connect-browser";
import { ConnectedAccounts } from "@/components/settings/connected-accounts";
import { VaultSection } from "@/components/settings/vault-section";
import { MemorySection } from "@/components/settings/memory-section";
import { ModelCard } from "@/components/settings/model-card";
import { PlanBilling } from "@/components/settings/plan-billing";

export default function SettingsPage() {
  return (
    <div className="grid min-h-screen" style={{ gridTemplateColumns: "240px 1fr" }}>
      <SettingsSidebar />
      <section className="overflow-y-auto">
        <header className="border-b border-white/[0.05] px-8 py-5">
          <div className="font-mono text-[10px] tracking-wider text-fog-400">SETTINGS</div>
          <div className="mt-1 text-xl font-medium">Safety &amp; Approvals</div>
          <div className="mt-1 text-[13px] text-fog-300">
            Decide when Argus must stop and ask. Defaults err on the side of caution.
          </div>
        </header>

        <div className="flex max-w-[880px] flex-col gap-9 px-8 py-7">
          <div id="settings-safety" className="scroll-mt-24">
            <SafetyRules />
          </div>
          <div id="settings-browser" className="scroll-mt-24">
            <BrowserModes />
          </div>
          <div id="settings-connect" className="scroll-mt-24">
            <ConnectBrowser />
          </div>
          <div id="settings-accounts" className="scroll-mt-24">
            <ConnectedAccounts />
          </div>
          <div id="settings-vault" className="scroll-mt-24">
            <VaultSection />
          </div>
          <div id="settings-memory" className="scroll-mt-24">
            <MemorySection />
          </div>
          <div id="settings-model" className="scroll-mt-24">
            <ModelCard />
          </div>
          <div id="settings-billing" className="scroll-mt-24">
            <PlanBilling />
          </div>
          <div className="h-10" />
        </div>
      </section>
    </div>
  );
}
