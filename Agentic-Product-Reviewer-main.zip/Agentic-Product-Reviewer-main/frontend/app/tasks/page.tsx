"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import useSWR from "swr";
import { CompactRail } from "@/components/layout/compact-rail";
import { ChatPanel } from "@/components/task/chat-panel";
import { PlanList } from "@/components/task/plan-list";
import { ExecutionLog } from "@/components/task/execution-log";
import { BrowserPreview } from "@/components/task/browser-preview";
import { ApprovalBar } from "@/components/task/approval-bar";
import { ApprovalModal } from "@/components/modals/approval-modal";
import { RecoveryModal } from "@/components/modals/recovery-modal";
import { CredentialsModal } from "@/components/modals/credentials-modal";
import { OtpModal } from "@/components/modals/otp-modal";
import { CaptchaModal } from "@/components/modals/captcha-modal";
import { InfoModal } from "@/components/modals/info-modal";
import { api } from "@/lib/api";
import { useTaskStream } from "@/lib/use-task-stream";

/** Bottom nav (ScreenJumper) is fixed at 56px — grid must not overlap it. */
const JUMPER_H = 56;

const ACTIVE = new Set([
  "created",
  "planning",
  "executing",
  "recovering",
  "paused",
  "waiting_for_user",
  "waiting_for_approval",
]);

const TERMINAL = new Set(["completed", "failed", "cancelled"]);

function TaskExecutionInner() {
  const search = useSearchParams();
  const router = useRouter();
  const taskId = search.get("id");

  const { task, steps, logs, actions, state, approval, screenshotUrl, screenshots, recoveryCount, assist, credentials, otp, captcha, info } =
    useTaskStream(taskId);

  const [approvalOpen, setApprovalOpen] = useState(false);
  const [recoveryOpen, setRecoveryOpen] = useState(false);
  const [credentialsOpen, setCredentialsOpen] = useState(false);
  const [otpOpen, setOtpOpen] = useState(false);
  const [captchaOpen, setCaptchaOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const [browserOpen, setBrowserOpen] = useState(true);

  // Auto-open the approval modal when a new approval arrives.
  useEffect(() => {
    if (approval) setApprovalOpen(true);
  }, [approval]);

  // Auto-open the recovery/assist modal when Argus needs the user's help.
  useEffect(() => {
    if (assist) setRecoveryOpen(true);
  }, [assist]);

  // Auto-open the credentials modal when Argus hits a sign-in form.
  useEffect(() => {
    if (credentials) setCredentialsOpen(true);
  }, [credentials]);

  // Auto-open the OTP modal when Argus hits a 2FA / verification step.
  useEffect(() => {
    if (otp) setOtpOpen(true);
  }, [otp]);

  // Auto-open the CAPTCHA modal when Argus needs a human to read the challenge.
  useEffect(() => {
    if (captcha) setCaptchaOpen(true);
  }, [captcha]);

  // Auto-open the details modal when Argus needs personal/sensitive fields.
  useEffect(() => {
    if (info) setInfoOpen(true);
  }, [info]);

  // If no task id, send the user to pick one.
  useEffect(() => {
    if (!taskId) router.replace("/dashboard");
  }, [taskId, router]);

  if (!taskId) return null;

  const live = ACTIVE.has(state);

  async function handleApprove() {
    if (!taskId) return;
    await api.approveTask(taskId);
  }
  async function handleReject() {
    if (!taskId) return;
    await api.rejectTask(taskId);
  }
  async function handlePause() {
    if (!taskId) return;
    await api.pauseTask(taskId);
  }
  async function handleResume() {
    if (!taskId) return;
    await api.resumeTask(taskId);
  }
  async function handleCancel() {
    if (!taskId) return;
    await api.cancelTask(taskId);
  }
  async function handleUserInput(text: string) {
    if (!taskId) return;
    if (TERMINAL.has(state)) {
      const next = await api.createTask(text);
      router.push(`/tasks?id=${next.id}`);
      return;
    }
    // While paused, a typed instruction becomes a re-plan (no screenshot anchor);
    // the preview composer is the way to anchor it to a specific frame.
    if (state === "paused") {
      await api.replanTask(taskId, text, null);
      return;
    }
    await api.sendUserInput(taskId, text);
  }
  async function handleReplan(instruction: string, screenshotUrl: string | null) {
    if (!taskId) return;
    await api.replanTask(taskId, instruction, screenshotUrl);
  }
  async function handleSavePlaybook() {
    if (!taskId) return;
    await api.createPlaybook(taskId);
  }
  async function handleFeedback(rating: number | null, text: string) {
    if (!taskId) return;
    await api.sendFeedback(taskId, rating, text);
  }

  // Which human prompt is currently awaiting an answer (the data survives a
  // dismissed modal), and whether any of its modals is open right now.
  const pendingPrompt = otp
    ? "otp"
    : credentials
      ? "credentials"
      : captcha
        ? "captcha"
        : info
          ? "info"
          : assist
            ? "assist"
            : null;
  const anyPromptModalOpen =
    otpOpen || credentialsOpen || captchaOpen || infoOpen || recoveryOpen;
  const promptLabel =
    pendingPrompt === "otp"
      ? "the one-time passcode"
      : pendingPrompt === "credentials"
        ? "your sign-in credentials"
        : pendingPrompt === "captcha"
          ? "the CAPTCHA"
          : pendingPrompt === "info"
            ? "your details"
            : pendingPrompt === "assist"
              ? "your guidance"
              : "";
  // Re-open whichever prompt is pending — so an accidental dismissal isn't a
  // dead end: you can always bring the input back and continue the task.
  function reopenPrompt() {
    if (otp) setOtpOpen(true);
    else if (credentials) setCredentialsOpen(true);
    else if (captcha) setCaptchaOpen(true);
    else if (info) setInfoOpen(true);
    else if (assist) setRecoveryOpen(true);
  }
  const showReopenBar =
    state === "waiting_for_user" && pendingPrompt !== null && !anyPromptModalOpen;

  return (
    <>
      <div
        className="argus-control-surface"
        style={{
          display: "grid",
          height: `calc(100vh - ${JUMPER_H}px)`,
          gridTemplateColumns: browserOpen
            ? "60px 300px minmax(240px, 0.8fr) minmax(360px, 1.8fr)"
            : "60px 300px minmax(240px, 1fr) 0px",
          gridTemplateRows: "1fr auto",
          overflow: "hidden",
        }}
      >
        <div style={{ gridColumn: "1", gridRow: "1 / 3" }}>
          <CompactRail />
        </div>

        <div style={{ gridColumn: "2", gridRow: "1", display: "flex", flexDirection: "column", minHeight: 0 }}>
          <ChatPanel
            task={task}
            logs={logs}
            state={state}
            onSend={handleUserInput}
            onPause={handlePause}
            onResume={handleResume}
            onCancel={handleCancel}
            onSavePlaybook={handleSavePlaybook}
            onFeedback={handleFeedback}
          />
        </div>

        <div
          style={{
            gridColumn: "3",
            gridRow: "1",
            display: "flex",
            flexDirection: "column",
            minHeight: 0,
            minWidth: 0,
            background: "rgba(9,10,12,0.88)",
          }}
        >
          <TaskHeader
            state={state}
            steps={steps}
            startedAt={task?.started_at ?? null}
            recoveryCount={recoveryCount}
            browserOpen={browserOpen}
            onToggleBrowser={() => setBrowserOpen((v) => !v)}
            onPause={handlePause}
            onResume={handleResume}
            onCancel={handleCancel}
          />
          <PlanList steps={steps} />
          <ExecutionLog logs={logs} actions={actions} live={live} />
        </div>

        <div style={{ gridColumn: "4", gridRow: "1", overflow: "hidden", minWidth: 0 }}>
          <BrowserPreview
            task={task}
            state={state}
            screenshotUrl={screenshotUrl}
            screenshots={screenshots}
            onReplan={handleReplan}
          />
        </div>

        <div style={{ gridColumn: "2 / 5", gridRow: "2" }}>
          {showReopenBar && (
            <div className="flex items-center gap-3 border-t border-[#E8D2B4]/30 bg-[#E8D2B4]/[0.07] px-5 py-3">
              <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#E8D2B4]/20 text-[11px] text-[#E8D2B4]">
                ⏸
              </span>
              <span className="flex-1 text-[13px] text-fog-100">
                Argus is waiting for {promptLabel}. The prompt was closed — reopen it to continue.
              </span>
              <button
                type="button"
                onClick={reopenPrompt}
                className="shrink-0 rounded-md bg-[#E8D2B4] px-3.5 py-1.5 text-[12px] font-medium text-ink-950 hover:brightness-110"
              >
                Enter now
              </button>
            </div>
          )}
          <ApprovalBar
            approval={approval}
            onReview={() => setApprovalOpen(true)}
            onReject={handleReject}
          />
        </div>
      </div>

      <ApprovalModal
        open={approvalOpen}
        onOpenChange={setApprovalOpen}
        approval={approval}
        onApprove={handleApprove}
        onReject={handleReject}
      />
      <RecoveryModal
        open={recoveryOpen}
        onOpenChange={setRecoveryOpen}
        question={assist?.question}
        stepLabel={assist?.step_label}
        onSubmit={handleUserInput}
      />
      <CredentialsModal
        open={credentialsOpen}
        onOpenChange={setCredentialsOpen}
        domain={credentials?.domain}
        onSubmit={async (email, password) => {
          if (taskId) await api.sendCredentials(taskId, email, password);
        }}
      />
      <OtpModal
        open={otpOpen}
        onOpenChange={setOtpOpen}
        domain={otp?.domain}
        onSubmit={async (code) => {
          if (taskId) await api.sendOtp(taskId, code);
        }}
      />
      <CaptchaModal
        open={captchaOpen}
        onOpenChange={setCaptchaOpen}
        domain={captcha?.domain}
        screenshot={captcha?.screenshot}
        onSubmit={async (text) => {
          if (taskId) await api.sendCaptcha(taskId, text);
        }}
      />
      <InfoModal
        open={infoOpen}
        onOpenChange={setInfoOpen}
        domain={info?.domain}
        fields={info?.fields ?? []}
        onSubmit={async (values) => {
          if (taskId) await api.sendInfo(taskId, values);
        }}
      />
    </>
  );
}

interface TaskHeaderProps {
  state: string;
  steps: { state: string }[];
  startedAt: string | null;
  recoveryCount: number;
  browserOpen: boolean;
  onToggleBrowser: () => void;
  onPause: () => void;
  onResume: () => void;
  onCancel: () => void;
}

function TaskHeader({
  state,
  steps,
  startedAt,
  recoveryCount,
  browserOpen,
  onToggleBrowser,
  onPause,
  onResume,
  onCancel,
}: TaskHeaderProps) {
  const [elapsed, setElapsed] = useState("00:00");
  const done = steps.filter((s) => s.state === "done").length;
  const total = steps.length;
  const active = ACTIVE.has(state);
  const paused = state === "paused";

  useEffect(() => {
    if (!startedAt || !active) return;
    const tick = () => {
      const sec = Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000));
      const mm = String(Math.floor(sec / 60)).padStart(2, "0");
      const ss = String(sec % 60).padStart(2, "0");
      setElapsed(`${mm}:${ss}`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [startedAt, active]);

  const dotColor =
    state === "failed"
      ? "#E8B4B4"
      : state === "paused"
        ? "#E8D2B4"
        : state === "completed"
          ? "#C4F0C8"
          : "#C4F0C8";

  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        padding: "14px 22px",
        flexShrink: 0,
        minWidth: 0,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
        <span
          style={{
            width: 7,
            height: 7,
            borderRadius: "50%",
            background: dotColor,
            boxShadow: `0 0 8px ${dotColor}b0`,
            animation: active ? "argus-pulse 1.8s ease-in-out infinite" : "none",
            display: "inline-block",
          }}
        />
        <span style={{ fontFamily: "var(--font-geist-mono)", fontSize: 11, letterSpacing: "0.06em", color: "#F4F4F5", whiteSpace: "nowrap" }}>
          {state.toUpperCase().replaceAll("_", " ")}
        </span>
      </div>
      <div style={{ width: 1, height: 14, background: "rgba(255,255,255,0.08)", flexShrink: 0 }} />
      <div style={{ fontFamily: "var(--font-geist-mono)", fontSize: 11, color: "#6B6B72", whiteSpace: "nowrap", flexShrink: 0 }}>
        STEP <span style={{ color: "#F4F4F5" }}>{String(done).padStart(2, "0")}/{String(total).padStart(2, "0")}</span>
      </div>
      <div style={{ width: 1, height: 14, background: "rgba(255,255,255,0.08)", flexShrink: 0 }} />
      <div style={{ fontFamily: "var(--font-geist-mono)", fontSize: 11, color: "#6B6B72", whiteSpace: "nowrap", flexShrink: 0 }}>
        ELAPSED <span style={{ color: "#F4F4F5" }}>{elapsed}</span>
      </div>
      {recoveryCount > 0 && (
        <>
          <div style={{ width: 1, height: 14, background: "rgba(255,255,255,0.08)", flexShrink: 0 }} />
          <div
            title="Automatic layer escalations (Agent Browser → Browser Use)"
            style={{ fontFamily: "var(--font-geist-mono)", fontSize: 11, color: "#E8D2B4", whiteSpace: "nowrap", flexShrink: 0 }}
          >
            ⟳ RECOVERED <span style={{ color: "#F4F4F5" }}>{recoveryCount}</span>
          </div>
        </>
      )}
      <div style={{ flex: 1 }} />
      <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
        {active && (
          <>
            <button
              onClick={paused ? onResume : onPause}
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#F4F4F5", padding: "5px 10px", borderRadius: 6, fontSize: 11, cursor: "pointer" }}
            >
              {paused ? "▶ Resume" : "⏸ Pause"}
            </button>
            <button
              onClick={onCancel}
              style={{ background: "rgba(232,180,180,0.10)", border: "1px solid rgba(232,180,180,0.30)", color: "#E8B4B4", padding: "5px 10px", borderRadius: 6, fontSize: 11, cursor: "pointer" }}
            >
              ⏹ Cancel
            </button>
          </>
        )}
        <button
          onClick={onToggleBrowser}
          title={browserOpen ? "Hide browser" : "Show browser"}
          style={{ width: 26, height: 26, borderRadius: 6, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "#A1A1A6", fontSize: 13, display: "grid", placeItems: "center", cursor: "pointer" }}
        >
          {browserOpen ? "⊞" : "⊡"}
        </button>
      </div>
    </header>
  );
}

export default function TaskExecutionPage() {
  return (
    <Suspense fallback={null}>
      <TaskExecutionInner />
    </Suspense>
  );
}
