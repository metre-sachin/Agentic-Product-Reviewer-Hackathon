import Link from "next/link";
import { PageShell } from "@/components/landing/page-shell";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const TIERS = [
  {
    name: "Self-hosted",
    price: "Free",
    note: "Bring your own OpenAI key",
    featured: true,
    cta: "Get started",
    href: "/signup",
    features: [
      "Unlimited tasks",
      "Full five-layer execution ladder",
      "Memory + preferences",
      "Approval gates on everything irreversible",
      "Your data stays on your machine",
    ],
  },
  {
    name: "Cloud",
    price: "₹999",
    note: "per month · coming soon",
    featured: false,
    cta: "Join waitlist",
    href: "/signup",
    features: [
      "Everything in Self-hosted",
      "Managed browsers + proxies",
      "No API key to manage",
      "Hosted task history & screenshots",
      "Email + Slack notifications",
    ],
  },
  {
    name: "Team",
    price: "Custom",
    note: "for organisations",
    featured: false,
    cta: "Contact us",
    href: "/signup",
    features: [
      "Everything in Cloud",
      "Shared connected accounts",
      "Role-based approvals",
      "Audit log + SSO",
      "Priority support",
    ],
  },
];

export default function PricingPage() {
  return (
    <PageShell
      eyebrow="Pricing"
      title="Pay for the work, not the wait"
      subtitle="Run Argus free on your own machine today. Managed cloud and team plans are on the way."
    >
      <div className="grid gap-3 md:grid-cols-3">
        {TIERS.map((t) => (
          <div
            key={t.name}
            className={cn(
              "flex flex-col rounded-2xl border p-6",
              t.featured ? "border-mist-strong bg-ink-750" : "border-mist bg-ink-800",
            )}
          >
            <div className="flex items-center gap-2">
              <span className="text-[14px] font-medium">{t.name}</span>
              {t.featured && (
                <span className="rounded bg-white/[0.06] px-1.5 py-0.5 font-mono text-[9px] tracking-wider text-fog-300">
                  AVAILABLE NOW
                </span>
              )}
            </div>
            <div className="mt-4 flex items-baseline gap-1.5">
              <span className="text-[34px] font-medium tracking-tight">{t.price}</span>
            </div>
            <div className="mt-1 font-mono text-[11px] text-fog-400">{t.note}</div>

            <div className="my-5 h-px bg-mist" />

            <ul className="flex flex-1 flex-col gap-2.5">
              {t.features.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-[13px] text-fog-300">
                  <span className="mt-0.5 text-signal-ok">✓</span>
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <Link href={t.href} className="mt-6">
              <Button variant={t.featured ? "primary" : "secondary"} className="w-full">
                {t.cta}
              </Button>
            </Link>
          </div>
        ))}
      </div>

      <p className="mt-10 text-center text-[13px] text-fog-400">
        Self-hosted is genuinely free — you only pay your own OpenAI usage (gpt-4o-mini is a few
        paise per task).
      </p>
    </PageShell>
  );
}
