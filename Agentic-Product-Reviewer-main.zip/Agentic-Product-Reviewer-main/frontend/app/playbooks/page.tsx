"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import useSWR from "swr";
import { Sidebar } from "@/components/layout/sidebar";
import { api, type PlaybookDetailOut, type PlaybookOut } from "@/lib/api";

export default function PlaybooksPage() {
  const { data: playbooks, mutate } = useSWR("playbooks", api.listPlaybooks);
  const [openId, setOpenId] = useState<string | null>(null);

  const list = playbooks ?? [];

  return (
    <div className="grid min-h-screen" style={{ gridTemplateColumns: "240px 1fr" }}>
      <Sidebar />
      <section className="flex min-w-0 flex-col">
        <header className="border-b border-white/[0.05] px-7 py-3.5">
          <div className="font-mono text-[10px] tracking-wider text-fog-400">PLAYBOOKS</div>
          <div className="mt-0.5 text-lg font-medium">Saved recipes</div>
          <div className="mt-0.5 text-[13px] text-fog-300">
            Re-run a proven task. Toggle off steps you don&apos;t want; credentials come
            from your vault, so only the variables change.
          </div>
        </header>

        <div className="flex max-w-[820px] flex-col gap-3 px-7 py-6">
          {list.length === 0 && (
            <div className="rounded-xl border border-mist bg-ink-800 px-5 py-8 text-center text-[13px] text-fog-400">
              No playbooks yet. Finish a task, then hit{" "}
              <span className="text-fog-200">Save as playbook</span> to keep its steps here.
            </div>
          )}
          {list.map((pb) => (
            <PlaybookCard
              key={pb.id}
              pb={pb}
              open={openId === pb.id}
              onToggle={() => setOpenId(openId === pb.id ? null : pb.id)}
              onChanged={mutate}
            />
          ))}
        </div>
      </section>
    </div>
  );
}

function PlaybookCard({
  pb,
  open,
  onToggle,
  onChanged,
}: {
  pb: PlaybookOut;
  open: boolean;
  onToggle: () => void;
  onChanged: () => void;
}) {
  const router = useRouter();
  const { data: detail, mutate: mutateDetail } = useSWR<PlaybookDetailOut>(
    open ? `playbook-${pb.id}` : null,
    () => api.getPlaybook(pb.id),
  );
  const [running, setRunning] = useState(false);

  const domain = typeof pb.intent?.domain === "string" ? pb.intent.domain : null;
  const enabledCount = detail
    ? detail.steps.filter((s) => s.enabled).length
    : pb.step_count;

  async function run() {
    setRunning(true);
    try {
      const task = await api.runPlaybook(pb.id);
      router.push(`/tasks?id=${task.id}`);
    } finally {
      setRunning(false);
    }
  }

  async function toggleStep(stepId: string, enabled: boolean) {
    await api.updatePlaybookStep(pb.id, stepId, { enabled });
    await mutateDetail();
  }

  async function removeStep(stepId: string) {
    await api.deletePlaybookStep(pb.id, stepId);
    await mutateDetail();
  }

  async function remove() {
    await api.deletePlaybook(pb.id);
    onChanged();
  }

  return (
    <div className="overflow-hidden rounded-xl border border-mist bg-ink-800">
      <div className="flex items-center gap-3 px-4 py-3.5">
        <button onClick={onToggle} className="flex min-w-0 flex-1 items-center gap-3 text-left">
          <span className="font-mono text-[11px] text-fog-500">{open ? "▾" : "▸"}</span>
          <div className="min-w-0">
            <div className="truncate text-[14px] font-medium">{pb.title}</div>
            <div className="font-mono text-[11px] text-fog-400">
              {enabledCount} step{enabledCount === 1 ? "" : "s"}
              {domain ? ` · ${domain}` : ""}
            </div>
          </div>
        </button>
        <button
          onClick={run}
          disabled={running || enabledCount === 0}
          className="shrink-0 rounded-md bg-fog-50 px-3 py-1.5 text-[12px] font-medium text-ink-900 disabled:opacity-40"
        >
          {running ? "Starting…" : "▶ Run"}
        </button>
        <button
          onClick={remove}
          className="shrink-0 rounded-md border border-mist px-2.5 py-1.5 text-[12px] text-fog-300 hover:text-signal-err"
        >
          Delete
        </button>
      </div>

      {open && (
        <div className="border-t border-white/[0.05] bg-ink-900/60 px-4 py-3">
          <div className="mb-2 font-mono text-[10px] tracking-wider text-fog-500">
            GOAL
          </div>
          <div className="mb-3 text-[12px] text-fog-300">{pb.goal_template}</div>
          <div className="mb-2 font-mono text-[10px] tracking-wider text-fog-500">STEPS</div>
          {!detail && <div className="py-2 text-[12px] text-fog-400">Loading…</div>}
          <div className="flex flex-col gap-1">
            {detail?.steps.map((s) => (
              <div
                key={s.id}
                className={`flex items-center gap-3 rounded-md border px-3 py-2 text-[13px] ${
                  s.enabled
                    ? "border-white/[0.05] bg-white/[0.02]"
                    : "border-transparent opacity-45"
                }`}
              >
                <span className="font-mono text-[11px] text-fog-500">
                  {String(s.ordinal).padStart(2, "0")}
                </span>
                <span className={`flex-1 ${s.enabled ? "" : "line-through"}`}>{s.label}</span>
                {s.kind && (
                  <span className="rounded border border-mist px-1.5 py-px font-mono text-[9px] text-fog-400">
                    {s.kind}
                  </span>
                )}
                <button
                  onClick={() => toggleStep(s.id, !s.enabled)}
                  className={`rounded border px-2 py-0.5 font-mono text-[10px] ${
                    s.enabled
                      ? "border-[#C4F0C8]/30 bg-[#C4F0C8]/10 text-[#C4F0C8]"
                      : "border-mist text-fog-400"
                  }`}
                >
                  {s.enabled ? "ON" : "OFF"}
                </button>
                <button
                  onClick={() => removeStep(s.id)}
                  className="text-fog-500 hover:text-signal-err"
                  title="Remove step"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
