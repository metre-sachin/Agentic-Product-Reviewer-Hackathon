"use client";

import { Suspense, useState, type FormEvent } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";

function LoginInner() {
  const router = useRouter();
  const search = useSearchParams();
  const callbackUrl = search.get("callbackUrl") ?? "/dashboard";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const res = await signIn("credentials", { email, password, redirect: false, callbackUrl });
    setBusy(false);
    if (res?.error) {
      setError("Invalid email or password.");
      return;
    }
    router.push(callbackUrl);
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-[400px]"
      >
        <div className="text-center mb-10">
          <div className="font-mono text-[11px] tracking-[0.18em] text-fog-400 uppercase mb-3">
            Autonomous Product Review
          </div>
          <h1
            className="text-[34px] font-medium tracking-[-0.025em] leading-[1.1]"
            style={{
              background: "linear-gradient(180deg, #FFFFFF 0%, #B8B8C0 100%)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
            }}
          >
            Welcome back
          </h1>
          <p className="text-[14px] text-fog-300 mt-2">Sign in to your quality workspace.</p>
        </div>

        <form onSubmit={onSubmit} className="space-y-3">
          <input
            type="email"
            required
            autoFocus
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="w-full px-4 py-3 bg-ink-800 border border-mist rounded-xl text-fog-50 text-[14px] placeholder:text-fog-400 focus:outline-none focus:border-mist-strong transition-colors"
          />
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full px-4 py-3 bg-ink-800 border border-mist rounded-xl text-fog-50 text-[14px] placeholder:text-fog-400 focus:outline-none focus:border-mist-strong transition-colors"
          />

          {error && (
            <div className="text-[13px] text-signal-err font-mono">{error}</div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full px-4 py-3 bg-fog-50 text-ink-900 rounded-xl text-[14px] font-medium hover:bg-white transition-colors disabled:opacity-50"
          >
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-mist" />
          <span className="text-[11px] font-mono uppercase tracking-[0.18em] text-fog-400">or</span>
          <div className="flex-1 h-px bg-mist" />
        </div>

        <button
          onClick={() => signIn("google", { callbackUrl })}
          className="w-full px-4 py-3 bg-ink-800 border border-mist rounded-xl text-fog-50 text-[14px] hover:bg-ink-700 transition-colors"
        >
          Continue with Google
        </button>

        <p className="text-center text-[13px] text-fog-300 mt-8">
          New here?{" "}
          <Link href="/signup" className="text-fog-50 hover:underline underline-offset-4">
            Create an account
          </Link>
        </p>
      </motion.div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen" />}>
      <LoginInner />
    </Suspense>
  );
}
