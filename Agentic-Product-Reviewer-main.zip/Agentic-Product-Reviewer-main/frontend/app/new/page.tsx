import { Suspense } from "react";
import Link from "next/link";
import { AgentOrb } from "@/components/orb/agent-orb";
import { CommandInput } from "@/components/landing/command-input";

export default function NewTaskPage() {
  return (
    <div className="relative min-h-screen flex flex-col">
      <header className="flex items-center justify-between px-10 py-6 border-b border-white/[0.04]">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <span className="text-fog-400 hover:text-fog-50 transition-colors text-sm">←</span>
          <span className="font-mono text-[11px] tracking-[0.18em] text-fog-400 uppercase">
            New task
          </span>
        </Link>
        <Link href="/dashboard" className="text-[13px] text-fog-300 hover:text-fog-50 transition-colors">
          Dashboard
        </Link>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center gap-9 px-6 pb-32 -mt-10">
        <AgentOrb size={220} state="idle" />

        <div className="text-center max-w-[640px]">
          <h1
            className="text-[40px] font-medium tracking-[-0.03em] leading-[1.1] m-0 mb-3"
            style={{
              background: "linear-gradient(180deg, #FFFFFF 0%, #B8B8C0 100%)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
            }}
          >
            What should Argus do?
          </h1>
          <p className="text-[15px] leading-relaxed text-fog-300 m-0 max-w-[460px] mx-auto">
            Describe the goal in plain language. Pick the model, mode, and when Argus
            should pause for approval.
          </p>
        </div>

        <Suspense fallback={<div className="h-[120px] w-full max-w-[680px]" />}>
          <CommandInput />
        </Suspense>
      </main>
    </div>
  );
}
