import Link from "next/link";
import { PageShell, SectionLabel } from "@/components/landing/page-shell";
import { Button } from "@/components/ui/button";

const LADDER = [
  { tag: "L1", name: "Scrapling", desc: "Quiet HTTP reads with anti-bot stealth. Search, listings, prices — cheapest and fastest." },
  { tag: "L2", name: "Agent Browser", desc: "Structured clicks and typing using the page's accessibility tree, not brittle selectors." },
  { tag: "L3", name: "Browser Use", desc: "Autonomous LLM-in-the-loop agent that takes over when structured interaction stalls." },
  { tag: "L4", name: "Vision", desc: "Reads an actual screenshot like a person when nothing else works." },
  { tag: "L5", name: "Human", desc: "Asks you a clear question — and resumes the moment you answer." },
];

const AGENTS = [
  { name: "Planner", desc: "Decomposes your goal into an ordered, approval-gated plan." },
  { name: "Executor", desc: "Picks the cheapest capable layer for each step." },
  { name: "Recovery", desc: "Escalates automatically when a layer can't make progress." },
  { name: "Approval", desc: "Stops before anything irreversible and shows you the details." },
  { name: "Memory", desc: "Remembers your preferences and applies them at plan time." },
  { name: "Vision", desc: "Visual reasoning over screenshots as a last automated resort." },
];

export default function ProductPage() {
  return (
    <PageShell
      eyebrow="Product"
      title={<>A digital operator,<br />not a chatbot</>}
      subtitle="Argus plans, browses, recovers from failures, and asks before anything that matters — across any site on the open web."
    >
      <section className="mb-16">
        <SectionLabel>The execution ladder</SectionLabel>
        <p className="mb-5 text-[14px] text-fog-300 max-w-[640px]">
          Every step tries the cheapest layer that can do the job and escalates only when it must.
          You always see which layer handled what.
        </p>
        <div className="flex flex-col gap-2">
          {LADDER.map((l) => (
            <div
              key={l.tag}
              className="grid grid-cols-[48px_160px_1fr] items-center gap-4 rounded-xl border border-mist bg-ink-800 px-4 py-3.5"
            >
              <span className="font-mono text-[12px] text-fog-400">{l.tag}</span>
              <span className="text-[14px] font-medium">{l.name}</span>
              <span className="text-[13px] text-fog-300">{l.desc}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-16">
        <SectionLabel>Six agents, one operator</SectionLabel>
        <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3">
          {AGENTS.map((a) => (
            <div key={a.name} className="rounded-xl border border-mist bg-ink-800 p-4">
              <div className="text-[14px] font-medium">{a.name}</div>
              <div className="mt-1.5 text-[12px] leading-relaxed text-fog-300">{a.desc}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-12">
        <SectionLabel>Safety is structural</SectionLabel>
        <div className="rounded-xl border border-mist bg-ink-800 p-6">
          <p className="text-[15px] leading-relaxed text-fog-300 m-0">
            Argus <span className="text-fog-50">never</span> auto-submits a payment, purchase,
            application, booking, or message. Every irreversible action pauses for explicit approval
            showing exact details — at every layer, regardless of settings. Payment and identity-form
            gates can&apos;t be disabled.
          </p>
        </div>
      </section>

      <div className="flex justify-center gap-3">
        <Link href="/new">
          <Button>Start a task →</Button>
        </Link>
        <Link href="/pricing">
          <Button variant="secondary">See pricing</Button>
        </Link>
      </div>
    </PageShell>
  );
}
