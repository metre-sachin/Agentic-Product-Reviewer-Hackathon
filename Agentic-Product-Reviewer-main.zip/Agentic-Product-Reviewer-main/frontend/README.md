# Argus

Your Personal Operations Agent — frontend.

## Stack
- Next.js 14 (App Router) · TypeScript
- Tailwind CSS · shadcn/ui · Radix
- Framer Motion (orb + transitions)
- Geist Sans + Geist Mono via `next/font`

## Run
```bash
pnpm install
pnpm dev
```
Then open <http://localhost:3000>.

## Routes
| Path           | Screen                                           |
| -------------- | ------------------------------------------------ |
| `/`            | Landing — hero orb, command input, suggested tasks |
| `/dashboard`   | Active tasks, history, stats, connected sites    |
| `/tasks`       | Live task execution — chat / plan+log / browser  |
| `/settings`    | Safety, browser mode, accounts, memory, model    |

Approval + Recovery modals live on `/tasks` (open via the bar or the floating demo jumper).

## Project layout
```
app/                Next.js routes
components/
  orb/              AgentOrb (the magical orb)
  layout/           Sidebar, compact rail, screen jumper
  landing/          Hero composition pieces
  dashboard/        Stats, active tasks, history
  task/             Chat, plan, log, browser preview, approval bar
  modals/           Approval, recovery
  settings/         Safety rules, browser modes, accounts, memory
  ui/               shadcn primitives
lib/                utils + mock data
```

## Design tokens
All colors live as Tailwind utilities under the `ink` (surfaces) and `fog` (text) scales — see `tailwind.config.ts`. Pure white/silver is the only accent; status uses desaturated neutrals.

The orb is a self-contained component — drop `<AgentOrb size={280} state="executing" />` anywhere.
