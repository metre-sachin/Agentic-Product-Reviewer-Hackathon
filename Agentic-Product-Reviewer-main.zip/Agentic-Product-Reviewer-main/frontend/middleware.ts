import { withAuth } from "next-auth/middleware";

export default withAuth({
  pages: { signIn: "/login" },
});

export const config = {
  matcher: ["/quality/:path*", "/dashboard/:path*", "/tasks/:path*", "/settings/:path*", "/new/:path*"],
};
