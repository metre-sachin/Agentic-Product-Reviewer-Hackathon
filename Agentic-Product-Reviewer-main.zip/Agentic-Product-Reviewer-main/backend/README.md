# Argus Backend

FastAPI + SQLAlchemy (async) + Postgres + Redis.

## First time

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -e .[dev]

# generate secrets and paste into ../.env
python ../scripts/gen_keys.py
```

## Run

```bash
docker compose up -d        # from repo root: starts Postgres + Redis
uvicorn app.main:app --reload
```

Docs: http://localhost:8000/docs

## Layout

- `app/main.py` — FastAPI app factory, CORS, routers
- `app/core/` — config, JWT, password hashing, auth dependency
- `app/db/session.py` — async engine + session
- `app/models/orm.py` — SQLAlchemy ORM models (mirror migrations/001_init.sql)
- `app/schemas/` — Pydantic request/response models
- `app/api/` — route modules: health, auth, tasks, settings
- `app/services/` — business logic (auth, task, settings)

## What works in Phase 2

- `POST /auth/signup`, `POST /auth/login`, `POST /auth/google`, `GET /auth/me`
- `GET/POST /tasks`, `GET /tasks/{id}`, `POST /tasks/{id}/cancel`, `GET /tasks/{id}/logs`
- `GET/POST /settings`
- Hard-coded approval triggers in `agents/approval/approval.py`

Endpoints returning 501 are intentional stubs reserved for later phases.
