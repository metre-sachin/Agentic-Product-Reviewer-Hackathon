"""Unit tests for the experiential site-lessons helpers.

Covers the pure logic that decides which site a goal refers to, de-duplicates
lessons, and formats them for prompt injection. No DB or LLM.

    cd backend && PYTHONPATH=. .venv/bin/python -m unittest tests.test_lessons
"""

from __future__ import annotations

import unittest
from types import SimpleNamespace

from app.services.lessons_service import (
    _distinctive_labels,
    _is_duplicate,
    format_lessons,
)


def _lesson(kind: str, text: str) -> SimpleNamespace:
    return SimpleNamespace(kind=kind, lesson=text)


class DistinctiveLabelsTests(unittest.TestCase):
    def test_drops_generic_subdomains_and_suffixes(self) -> None:
        self.assertEqual(_distinctive_labels("student.alliance.edu.in"), ["alliance"])
        self.assertEqual(_distinctive_labels("www.blinkit.com"), ["blinkit"])

    def test_keeps_multiple_distinctive_labels(self) -> None:
        self.assertEqual(_distinctive_labels("careers.acme-corp.org"), ["careers", "acme-corp"])

    def test_short_or_all_generic_yields_nothing(self) -> None:
        self.assertEqual(_distinctive_labels("my.app.co"), [])


class IsDuplicateTests(unittest.TestCase):
    def test_exact_and_substring(self) -> None:
        self.assertTrue(_is_duplicate("Login needs OTP", {"login needs otp"}))
        self.assertTrue(_is_duplicate("otp", {"login needs otp after password"}))

    def test_distinct_is_not_duplicate(self) -> None:
        self.assertFalse(_is_duplicate("feedback is star-rating", {"login needs otp"}))

    def test_blank_is_duplicate(self) -> None:
        self.assertTrue(_is_duplicate("  ", set()))


class FormatLessonsTests(unittest.TestCase):
    def test_groups_avoid_then_prefer_then_fact(self) -> None:
        out = format_lessons([
            _lesson("fact", "login needs otp"),
            _lesson("prefer", "open the link directly"),
            _lesson("avoid", "clicking Continue stalls"),
        ])
        self.assertEqual(
            out,
            "- AVOID: clicking Continue stalls\n"
            "- PREFER: open the link directly\n"
            "- NOTE: login needs otp",
        )

    def test_empty(self) -> None:
        self.assertEqual(format_lessons([]), "")


if __name__ == "__main__":
    unittest.main()
