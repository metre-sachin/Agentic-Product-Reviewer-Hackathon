"""Unit tests for the credential vault crypto + merge rules.

Guards the core invariants: secrets round-trip through Fernet, a corrupt/garbage
token degrades to {} rather than crashing, and merging never clobbers a saved
value with an empty update. Pure logic — no DB or network. Run with:

    cd backend && PYTHONPATH=. .venv/bin/python -m unittest tests.test_vault
"""

from __future__ import annotations

import unittest

from app.core import crypto
from app.services.vault_service import merge_blob


class CryptoRoundTripTests(unittest.TestCase):
    def test_encrypt_then_decrypt_recovers_the_blob(self) -> None:
        data = {"email": "a@b.com", "username": "ab", "password": "s3cr3t!"}
        token = crypto.encrypt_json(data)
        self.assertIsInstance(token, bytes)
        self.assertEqual(crypto.decrypt_json(token), data)

    def test_ciphertext_does_not_contain_plaintext(self) -> None:
        token = crypto.encrypt_json({"password": "hunter2"})
        self.assertNotIn(b"hunter2", token)

    def test_garbage_token_decrypts_to_empty(self) -> None:
        self.assertEqual(crypto.decrypt_json(b"not-a-valid-token"), {})
        self.assertEqual(crypto.decrypt_json(None), {})
        self.assertEqual(crypto.decrypt_json(b""), {})


class MergeBlobTests(unittest.TestCase):
    def test_overlays_new_values(self) -> None:
        merged = merge_blob({"email": "a@b.com"}, {"password": "pw"})
        self.assertEqual(merged, {"email": "a@b.com", "password": "pw"})

    def test_empty_update_never_clobbers(self) -> None:
        merged = merge_blob({"password": "pw"}, {"email": "x@y.com", "password": ""})
        self.assertEqual(merged, {"password": "pw", "email": "x@y.com"})

    def test_none_update_is_ignored(self) -> None:
        merged = merge_blob({"password": "pw"}, {"password": None, "phone": "123"})
        self.assertEqual(merged, {"password": "pw", "phone": "123"})

    def test_values_are_trimmed(self) -> None:
        self.assertEqual(merge_blob({}, {"email": "  a@b.com  "}), {"email": "a@b.com"})

    def test_does_not_mutate_inputs(self) -> None:
        existing = {"password": "pw"}
        merge_blob(existing, {"email": "a@b.com"})
        self.assertEqual(existing, {"password": "pw"})


if __name__ == "__main__":
    unittest.main()
