"""API integration checks against an isolated SQLite store; no live model charges."""
import asyncio
import io
import uuid
from contextlib import asynccontextmanager
from unittest.mock import AsyncMock
import httpx
import pytest
from PIL import Image
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.dialects.postgresql import JSONB
from app.main import app
from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.models.quality import QualityAsset, QualityRun, QualityInspection, QualityReport, QualityOperation, QualityEvent, QualityBatchReport, QualityAnnotation, QualityRunContext, QualityAttempt, QualitySourceAnnotation, QualityAnalysisCache, QualityReviewCase, QualityStream
from app.services import quality_service

@compiles(JSONB, 'sqlite')
def jsonb_sqlite(type_, compiler, **kw):
    return 'JSON'

class AsyncStore:
    def __init__(self, session): self.session = session
    async def execute(self, *a, **kw): return self.session.execute(*a, **kw)
    async def scalars(self, *a, **kw): return self.session.scalars(*a, **kw)
    async def scalar(self, *a, **kw): return self.session.scalar(*a, **kw)
    async def get(self, *a, **kw): return self.session.get(*a, **kw)
    def add(self, row): self.session.add(row)
    async def flush(self): self.session.flush()
    async def commit(self): self.session.commit()
    async def rollback(self): self.session.rollback()

@pytest.mark.asyncio
async def test_inspection_to_hold_ticket_and_approved_report(tmp_path, monkeypatch):
    engine = create_engine('sqlite://')
    tables = [User.__table__,QualityAsset.__table__,QualityRun.__table__,QualityInspection.__table__,QualityReport.__table__,QualityOperation.__table__, QualityEvent.__table__, QualityBatchReport.__table__, QualityAnnotation.__table__, QualityRunContext.__table__, QualityAttempt.__table__, QualitySourceAnnotation.__table__, QualityAnalysisCache.__table__, QualityReviewCase.__table__, QualityStream.__table__]
    User.metadata.create_all(engine, tables=tables)
    session = Session(engine, expire_on_commit=False)
    user = User(id=uuid.uuid4(),email='inspector@example.test',name='Test Inspector')
    session.add(user); session.commit()
    store = AsyncStore(session)
    async def db(): yield store
    app.dependency_overrides[get_db] = db
    app.dependency_overrides[get_current_user] = lambda:user
    @asynccontextmanager
    async def worker_db(): yield store
    monkeypatch.setattr(quality_service,'SessionLocal',worker_db)
    monkeypatch.setattr(quality_service.settings,'media_dir',str(tmp_path/'media'))
    monkeypatch.setattr(quality_service.settings,'openai_api_key','test-not-a-real-key')
    monkeypatch.setattr(quality_service,'analyze',AsyncMock(return_value={'product_presence':'present','presence_evidence':'Component body visible','assessment':'possible_defect','summary':'Suspected surface damage','findings':[],'uncertainty':'Requires inspector review'}))
    image = io.BytesIO(); Image.new('RGB',(32,32),'gray').save(image,format='PNG')
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
            bad=await client.post('/quality/assets',files={'files':('bad.png',b'not-image','image/png')})
            assert bad.status_code==400
            for n in range(3):
                image=io.BytesIO();Image.new('RGB',(32,32),(100+n,100,100)).save(image,format='PNG')
                response=await client.post('/quality/assets',files={'files':(f'{n}.png',image.getvalue(),'image/png')},data={'product':'Transistor'})
                assert response.status_code==201,response.text
            response=await client.post('/quality/runs',json={'product':'Transistor','interval':1,'limit':3,'checks':['bent_lead'],'context_notes':'Inspect lead geometry against reference.'})
            assert response.status_code==201,response.text
            await asyncio.sleep(3.3)
            state=(await client.get('/quality/workspace')).json()
            assert state['runtime_version']=='quality-manager-inboxes-v7'
            assert len(state['inspections'])==3
            assert {o['kind'] for o in state['operations']}=={'maintenance','quarantine'}
            assert any(e['action'] == 'Apply precautionary hold' for e in state['events'])
            operations = asyncio.create_task(quality_service.operations_loop())
            await asyncio.sleep(0.1)
            operations.cancel()
            await asyncio.gather(operations, return_exceptions=True)
            state=(await client.get('/quality/workspace')).json()
            ticket=next(o for o in state['operations'] if o['kind']=='maintenance')
            assert ticket['state']=='in_progress'
            assert 'Evidence attached' in ticket['detail']
            assert any(e['action']=='Attach evidence & start investigation' for e in state['events'])
            inbox=(await client.get('/quality/manager-inboxes')).json()
            assert len(inbox['cases'])==3
            assert all(c['state']=='awaiting_approval' for c in inbox['cases'])
            # Repair a previously missed handoff without duplicating other cases.
            lost_case=session.get(QualityReviewCase,uuid.UUID(inbox['cases'][0]['id']))
            session.delete(lost_case);session.commit()
            repaired=await client.post(f"/quality/runs/{state['runs'][0]['id']}/route",json={})
            assert repaired.status_code==200,repaired.text
            assert repaired.json()['assigned']==3
            assert (await client.post(f"/quality/runs/{state['runs'][0]['id']}/route",json={})).json()['assigned']==3
            inbox=(await client.get('/quality/manager-inboxes')).json()

            premature=await client.post(f"/quality/manager-inboxes/{inbox['cases'][0]['id']}",json={'state':'reviewed','notes':'Attempt before inspector confirmation'})
            assert premature.status_code==409
            batch_report=state['batch_reports'][0]
            assert batch_report['snapshot']['flagged'] is True
            assert batch_report['snapshot']['suspected_defects']==3
            assert batch_report['state']=='draft'
            assert all(item['inspection_id'] in batch_report['body'] or item['inspection_id'][:8].upper() in batch_report['body'] for item in batch_report['snapshot']['entries'])
            assert (await client.post(f"/quality/batch-reports/{batch_report['id']}/decision",json={'action':'approve','notes':'Attempt premature approval'})).status_code==409
            hold=next(o for o in state['operations'] if o['kind']=='quarantine')
            assert (await client.post(f"/quality/operations/{hold['id']}",json={'state':'resolved'})).status_code==409
            target=state['inspections'][0]['id']
            assert state['criteria'][0]['checks']==['bent_lead']
            assert 'bent lead' in quality_service.analyze.call_args.args[2]
            retry=await client.post(f'/quality/inspections/{target}/recheck')
            assert retry.status_code==202,retry.text
            await asyncio.sleep(0.15)
            refreshed=(await client.get('/quality/workspace')).json()
            assert len(refreshed['inspections'])==3
            assert len(refreshed['attempts'])==1
            assert refreshed['attempts'][0]['inspection_id']==target
            assert next(i for i in refreshed['inspections'] if i['id']==target)['state']=='awaiting_review'
            invalid_region=await client.post(f'/quality/inspections/{target}/region',json={'box':[0.8,0.1,0.2,0.5],'note':'Invalid corners'})
            assert invalid_region.status_code==422
            annotation=await client.post(f'/quality/inspections/{target}/region',json={'box':[0.1,0.2,0.5,0.7],'note':'Inspector marked the damaged surface'})
            assert annotation.status_code==200,annotation.text
            for row in state['inspections']:
                response=await client.post(f"/quality/inspections/{row['id']}/decision",json={'action':'approve','outcome':'defect','notes':'Damage confirmed by inspector'})
                assert response.status_code==200,response.text
            assert (await client.post(f"/quality/inspections/{state['inspections'][0]['id']}/decision",json={'action':'approve','outcome':'defect','notes':'Duplicate'})).status_code==409
            state=(await client.get('/quality/workspace')).json()
            assert len(state['reports'])==3
            routed=(await client.get('/quality/manager-inboxes')).json()
            assert len(routed['cases'])==3
            assert all(c['state']=='open' for c in routed['cases'])
            reviewed_case=await client.post(f"/quality/manager-inboxes/{routed['cases'][0]['id']}",json={'state':'reviewed','notes':'Manager reviewed image evidence and assigned follow-up.'})
            assert reviewed_case.status_code==200,reviewed_case.text
            batch_report=state['batch_reports'][0]
            assert batch_report['snapshot']['pending_review']==0
            assert 'Inspector marked the damaged surface' in batch_report['body']
            approved=await client.post(f"/quality/batch-reports/{batch_report['id']}/decision",json={'action':'approve','notes':'Reviewed all source images and confirmed findings.'})
            assert approved.status_code==200,approved.text
            exported=await client.get(f"/quality/batch-reports/{batch_report['id']}/download")
            assert 'STATUS: APPROVED' in exported.text
            assert (await client.post(f'/quality/inspections/{target}/recheck')).status_code==409
            assert (await client.post(f'/quality/inspections/{target}/region',json={'box':[0.1,0.2,0.5,0.7],'note':'Try editing finalized evidence'})).status_code==409
            assert 'Test Inspector' in exported.text
            assert (await client.post(f"/quality/operations/{hold['id']}",json={'state':'resolved'})).status_code==409
            response=await client.get(f"/quality/reports/{state['reports'][0]['id']}/download")
            assert 'Test Inspector' in response.text
            # Manual mode works without a model key and waits for a decision.
            monkeypatch.setattr(quality_service.settings,'openai_api_key','')
            response=await client.post('/quality/runs',json={'product':'Transistor','mode':'manual','interval':1,'limit':2})
            assert response.status_code==201,response.text
            await asyncio.sleep(1.2)
            manual=(await client.get('/quality/workspace')).json()
            manual_rows=[r for r in manual['inspections'] if r['run_id']==response.json()['id']]
            assert len(manual_rows)==2
            assert 'Manual inspection' in manual_rows[0]['draft']['summary']
            await asyncio.sleep(1.2)
            later=(await client.get('/quality/workspace')).json()
            assert len([r for r in later['inspections'] if r['run_id']==response.json()['id']])==2
            # Other users cannot retrieve evidence.
            app.dependency_overrides[get_current_user]=lambda:User(id=uuid.uuid4())
            assert (await client.get(f"/quality/assets/{state['assets'][0]['id']}/image")).status_code==404
    finally:
        app.dependency_overrides.clear()
        await quality_service.shutdown()
        session.close()


def test_invalid_model_regions_do_not_destroy_findings():
    from app.services.quality_service import Analysis
    payload={'product_presence':'present','presence_evidence':'Expected test product present','assessment':'possible_defect','summary':'Possible surface scratch','uncertainty':'Location needs review','findings':[{'title':'scratch','evidence':'A visible line crosses the surface','severity':'low','box':[200,150,400,300]}]}
    result=Analysis.model_validate(payload)
    assert result.findings[0].box is None
    assert result.findings[0].title=='scratch'
    payload['findings'][0]['box']=[0.1,0.2,0.4,0.5]
    assert Analysis.model_validate(payload).findings[0].box==[0.1,0.2,0.4,0.5]

@pytest.mark.asyncio
async def test_annotation_assisted_import_provenance_and_no_fake_accuracy(tmp_path, monkeypatch):
    from pathlib import Path
    from app.models.base import Base
    engine=create_engine('sqlite://')
    # Include only quality tables and their user dependency.
    tables=[User.__table__]+[t for n,t in Base.metadata.tables.items() if n.startswith('quality_')]
    Base.metadata.create_all(engine,tables=tables)
    session=Session(engine,expire_on_commit=False)
    user=User(id=uuid.uuid4(),email='annotation@example.test',name='Annotation Inspector')
    session.add(user);session.commit()
    store=AsyncStore(session)
    async def db():yield store
    @asynccontextmanager
    async def worker_db():yield store
    app.dependency_overrides[get_db]=db
    app.dependency_overrides[get_current_user]=lambda:user
    monkeypatch.setattr(quality_service,'SessionLocal',worker_db)
    monkeypatch.setattr(quality_service.settings,'media_dir',str(tmp_path/'media'))
    monkeypatch.setattr(quality_service.settings,'openai_api_key','')
    monkeypatch.setattr(Path,'home',classmethod(lambda cls:tmp_path))
    root=tmp_path/'Downloads'/'tile'
    for label,color in [('good',(130,130,130)),('crack',(80,80,80))]:
        directory=root/'test'/label;directory.mkdir(parents=True)
        Image.new('RGB',(64,64),color).save(directory/'001.png')
    mask_dir=root/'ground_truth'/'crack';mask_dir.mkdir(parents=True)
    mask=Image.new('L',(64,64),0)
    from PIL import ImageDraw
    ImageDraw.Draw(mask).rectangle((16,8,31,47),fill=255)
    mask.save(mask_dir/'001_mask.png')
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
            imported=await client.post('/quality/import-local',json={'product':'Tile','count':20})
            assert imported.status_code==201,imported.text
            assert imported.json()['imported']==2
            duplicate=await client.post('/quality/import-local',json={'product':'Tile','count':20})
            assert duplicate.json()['imported']==0
            workspace=(await client.get('/quality/workspace')).json()
            assert len(workspace['assets'])==2
            assert len(workspace['source_annotations'])==2
            source=next(a for a in workspace['source_annotations'] if a['label']=='crack')
            assert source['box']==[0.25,0.125,0.5,0.75]
            overlay=await client.get(f"/quality/assets/{source['asset_id']}/mask")
            assert overlay.status_code==200
            with Image.open(io.BytesIO(overlay.content)) as rendered:
                red,green,blue,alpha=rendered.convert('RGBA').getpixel((20,20))
                assert red>green and red>blue and alpha>0
            run=await client.post('/quality/runs',json={'product':'Tile','mode':'assisted','interval':1,'limit':2})
            assert run.status_code==201,run.text
            await asyncio.sleep(2.3)
            workspace=(await client.get('/quality/workspace')).json()
            assert len(workspace['inspections'])==2
            assert all(i['state']=='awaiting_review' for i in workspace['inspections'])
            report=workspace['batch_reports'][0]
            assert report['snapshot']['flagged']
            assert report['snapshot']['suspected_defects']==1
            inbox=(await client.get('/quality/manager-inboxes')).json()
            assert len(inbox['cases'])==1
            assert inbox['cases'][0]['group_key']=='cracks'
            assert inbox['cases'][0]['asset_id']==source['asset_id']
            assert 'MVTec supplied test annotation' in report['body']
            assert 'not a model detection result' in report['body']
            flagged=next(i for i in workspace['inspections'] if i['assessment']=='possible_defect')
            assert flagged['draft']['findings'][0]['box']==source['box']
            assert 'No model call was made' in flagged['draft']['uncertainty']
            evaluation=(await client.get('/quality/evaluation')).json()
            assert evaluation['scored']==0 and evaluation['accuracy'] is None
    finally:
        app.dependency_overrides.clear()
        await quality_service.shutdown()
        session.close()

@pytest.mark.asyncio
async def test_four_parallel_groups_continue_without_review_and_atomic_bulk_review(tmp_path,monkeypatch):
    from app.models.base import Base
    engine=create_engine('sqlite://')
    Base.metadata.create_all(engine,tables=[User.__table__]+[t for n,t in Base.metadata.tables.items() if n.startswith('quality_')])
    session=Session(engine,expire_on_commit=False)
    user=User(id=uuid.uuid4(),email='parallel@example.test',name='Parallel Inspector')
    session.add(user);session.commit()
    store=AsyncStore(session)
    async def db():yield store
    @asynccontextmanager
    async def worker_db():yield store
    app.dependency_overrides[get_db]=db
    app.dependency_overrides[get_current_user]=lambda:user
    monkeypatch.setattr(quality_service,'SessionLocal',worker_db)
    monkeypatch.setattr(quality_service.settings,'media_dir',str(tmp_path/'media'))
    monkeypatch.setattr(quality_service.settings,'openai_api_key','test-not-a-real-key')
    active=peak=calls=0
    starts=[];finishes=[]
    async def inspect(*args):
        nonlocal active,peak,calls
        active+=1;calls+=1;index=calls;peak=max(peak,active)
        import time
        starts.append((index,time.monotonic()))
        try:
            await asyncio.sleep(.05 if index%4==1 else .2)
            if index==9:
                raise RuntimeError('Controlled image-level failure')
            return {'product_presence':'present','presence_evidence':'Component body visible','assessment':'possible_defect','summary':'Test evidence','findings':[],'uncertainty':'Inspector must review'}
        finally:
            finishes.append((index,time.monotonic()))
            active-=1
    monkeypatch.setattr(quality_service,'inspect_asset',inspect)
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
            for n in range(12):
                image=io.BytesIO();Image.new('RGB',(20,20),(n,50,70)).save(image,format='PNG')
                assert (await client.post('/quality/assets',files={'files':(f'{n}.png',image.getvalue(),'image/png')})).status_code==201
            started=await client.post('/quality/runs',json={'interval':1,'limit':12})
            assert started.status_code==201,started.text
            await asyncio.sleep(2.4)
            state=(await client.get('/quality/workspace')).json()
            assert peak==4
            assert len(starts)==12
            assert max(t for i,t in starts if i<=4)-min(t for i,t in starts if i<=4)<.05
            assert min(t for i,t in starts if 5<=i<=8)>=max(t for i,t in finishes if i<=4)
            assert state['processing']['mode']=='parallel_groups'
            assert len(state['inspections'])==12, 'All groups must process without waiting for review decisions'
            first=sorted(state['inspections'],key=lambda r:r['sequence'])[:4]
            ids=[r['id'] for r in first]
            missing=await store.get(QualityInspection,uuid.UUID(ids[0]))
            original=dict(missing.draft)
            missing.draft={**original,'product_presence':'absent'}
            await store.commit()
            blocked=await client.post('/quality/review-selection',json={'ids':ids,'action':'approve','notes':'Should be blocked by missing product gate'})
            assert blocked.status_code==409
            assert missing.decision is None
            missing.draft=original
            await store.commit()
            approved=await client.post('/quality/review-selection',json={'ids':ids,'action':'approve','notes':'Inspector checked each selected source image; no defect found.'})
            assert approved.status_code==200,approved.text
            assert approved.json()['reviewed']==4
            remaining=next(r['id'] for r in state['inspections'] if r['id'] not in ids and r['state']=='awaiting_review')
            mixed=await client.post('/quality/review-selection',json={'ids':[ids[0],remaining],'action':'reject','notes':'Cannot alter a completed image decision'})
            assert mixed.status_code==409
            await asyncio.sleep(1.6)
            state=(await client.get('/quality/workspace')).json()
            assert len(state['inspections'])==12
            assert sum(i['state']=='failed' for i in state['inspections'])==1
            assert sum(i['state']=='approved' for i in state['inspections'])==4
            assert next(i for i in state['inspections'] if i['id']==remaining)['state']=='awaiting_review'
            assert state['runs'][0]['state']=='completed'
    finally:
        app.dependency_overrides.clear()
        await quality_service.shutdown()
        session.close()

@pytest.mark.asyncio
async def test_missing_product_cannot_pass_defect_analysis(tmp_path,monkeypatch):
    from pathlib import Path
    monkeypatch.setattr(Path,'home',classmethod(lambda cls:tmp_path))
    call=AsyncMock(return_value={'presence':'absent','evidence':'Only the striped carrier board and holes are visible; no transistor body or leads are present.'})
    monkeypatch.setattr(quality_service,'complete_json_vision',call)
    result=await quality_service.analyze(b'image-bytes','Transistor')
    assert result['product_presence']=='absent'
    assert result['assessment']=='possible_defect'
    assert result['findings'][0]['title']=='Missing expected product'
    assert result['findings'][0]['box'] is None
    assert call.await_count==1, 'Do not proceed to a defect-pass decision after presence failure'
    call.return_value={'presence':'uncertain','evidence':'The object is too obscured to establish its identity.'}
    result=await quality_service.analyze(b'image-bytes','Transistor')
    assert result['assessment']=='uncertain'

@pytest.mark.asyncio
async def test_product_dispositions_and_batch_closure(tmp_path,monkeypatch):
    from app.models.base import Base
    engine=create_engine('sqlite://')
    Base.metadata.create_all(engine,tables=[User.__table__]+[t for n,t in Base.metadata.tables.items() if n.startswith('quality_')])
    session=Session(engine,expire_on_commit=False)
    user=User(id=uuid.uuid4(),email='dispositions@example.test',name='Quality Inspector')
    session.add(user);session.commit();store=AsyncStore(session)
    async def db():yield store
    @asynccontextmanager
    async def worker_db():yield store
    app.dependency_overrides[get_db]=db
    app.dependency_overrides[get_current_user]=lambda:user
    monkeypatch.setattr(quality_service,'SessionLocal',worker_db)
    monkeypatch.setattr(quality_service.settings,'media_dir',str(tmp_path/'media'))
    monkeypatch.setattr(quality_service.settings,'openai_api_key','')
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
            for n in range(4):
                image=io.BytesIO();Image.new('RGB',(20,20),(n,70,90)).save(image,format='PNG')
                await client.post('/quality/assets',files={'files':(f'{n}.png',image.getvalue(),'image/png')})
            run=await client.post('/quality/runs',json={'mode':'manual','interval':1,'limit':4})
            assert run.status_code==201
            await asyncio.sleep(1.3)
            state=(await client.get('/quality/workspace')).json()
            assert len(state['runs'][0]['asset_ids'])==4
            rows=sorted(state['inspections'],key=lambda r:r['sequence'])
            assert len(rows)==4
            result=await client.post('/quality/review-selection',json={'ids':[r['id'] for r in rows[:2]],'action':'rework','notes':'Surface finish requires corrective work; segregate these units.'})
            assert result.status_code==200,result.text
            await client.post('/quality/review-selection',json={'ids':[rows[2]['id']],'action':'reject','notes':'Crack confirmed; this unit is rejected.'})
            await client.post('/quality/review-selection',json={'ids':[rows[3]['id']],'action':'reinspect','notes':'Evidence unclear; another review is required.'})
            state=(await client.get('/quality/workspace')).json();report=state['batch_reports'][0]
            assert report['snapshot']['dispositions']=={'accepted':0,'rejected':1,'rework':2}
            assert report['snapshot']['unresolved']==1
            assert not report['snapshot']['review_complete']
            blocked=await client.post(f"/quality/batch-reports/{report['id']}/decision",json={'action':'approve','notes':'Cannot close an unresolved image'})
            assert blocked.status_code==409
            recheck=await client.post(f"/quality/inspections/{rows[3]['id']}/recheck")
            assert recheck.status_code==202,recheck.text
            await asyncio.sleep(.15)
            accepted=await client.post('/quality/review-selection',json={'ids':[rows[3]['id']],'action':'approve','notes':'Inspector re-examined the source and verified the unit.'})
            assert accepted.status_code==200,accepted.text
            state=(await client.get('/quality/workspace')).json();report=state['batch_reports'][0]
            assert report['snapshot']['review_complete']
            assert report['snapshot']['dispositions']['accepted']==1
            assert not report['snapshot']['release_ready']
            final=await client.post(f"/quality/batch-reports/{report['id']}/decision",json={'action':'approve','notes':'Review completed; rejected and rework units remain segregated.'})
            assert final.status_code==200,final.text
            hold=next(o for o in state['operations'] if o['kind']=='quarantine')
            assert (await client.post(f"/quality/operations/{hold['id']}",json={'state':'resolved'})).status_code==409
    finally:
        app.dependency_overrides.clear()
        await quality_service.shutdown();session.close()

@pytest.mark.asyncio
async def test_analysis_cache_is_scoped_and_force_recheck_bypasses(tmp_path,monkeypatch):
    from app.models.base import Base
    from pathlib import Path
    engine=create_engine('sqlite://')
    Base.metadata.create_all(engine,tables=[User.__table__]+[t for n,t in Base.metadata.tables.items() if n.startswith('quality_')])
    session=Session(engine,expire_on_commit=False)
    first=User(id=uuid.uuid4(),email='cache1@example.test');second=User(id=uuid.uuid4(),email='cache2@example.test')
    session.add_all([first,second]);session.flush()
    assets=[QualityAsset(id=uuid.uuid4(),user_id=u.id,name='Image',path=str(tmp_path/'image.png'),product='Tile') for u in (first,second)]
    session.add_all(assets);session.commit();store=AsyncStore(session)
    @asynccontextmanager
    async def db():yield store
    monkeypatch.setattr(quality_service,'SessionLocal',db)
    monkeypatch.setattr(Path,'home',classmethod(lambda cls:tmp_path))
    inspect=AsyncMock(return_value={'product_presence':'present','presence_evidence':'Tile surface visible','assessment':'no_visible_defect','summary':'No visible defect','findings':[],'uncertainty':'Inspector verification required'})
    monkeypatch.setattr(quality_service,'inspect_asset',inspect)
    try:
        initial=await quality_service.resolve_analysis(assets[0].id,b'same-image','Tile','check cracks','agentic')
        import time
        before_reuse=time.monotonic()
        again=await quality_service.resolve_analysis(assets[0].id,b'same-image','Tile','check cracks','agentic')
        assert time.monotonic()-before_reuse>=.95
        assert inspect.await_count==1
        assert not initial['cache']['reused'] and again['cache']['reused']
        assert 'decision' not in again
        changed=await quality_service.resolve_analysis(assets[0].id,b'same-image','Tile','check contamination','agentic')
        assert inspect.await_count==2 and not changed['cache']['reused']
        forced=await quality_service.resolve_analysis(assets[0].id,b'same-image','Tile','check contamination','agentic',force=True)
        assert inspect.await_count==3 and not forced['cache']['reused']
        other=await quality_service.resolve_analysis(assets[1].id,b'same-image','Tile','check cracks','agentic')
        assert inspect.await_count==4 and not other['cache']['reused']
        altered=await quality_service.resolve_analysis(assets[0].id,b'different-image','Tile','check cracks','agentic')
        assert inspect.await_count==5 and not altered['cache']['reused']
    finally:
        session.close()


def test_issue_routing_is_explicit_and_has_general_fallback():
    from app.services.quality_routing import choose_group
    assert choose_group('Oil spill')=='contamination'
    assert choose_group('Cracked tile')=='cracks'
    assert choose_group('rough surface')=='surface'
    assert choose_group('bent transistor lead')=='components'
    assert choose_group('Unclassified quality issue')=='general'


@pytest.mark.asyncio
async def test_continuous_inspection_passes_150_and_stops_without_repeating_decisions(tmp_path,monkeypatch):
    from app.models.base import Base
    import time
    engine=create_engine('sqlite://')
    Base.metadata.create_all(engine,tables=[User.__table__]+[t for n,t in Base.metadata.tables.items() if n.startswith('quality_')])
    session=Session(engine,expire_on_commit=False)
    user=User(id=uuid.uuid4(),email='stream@example.test',name='Stream Inspector')
    session.add(user);session.commit()
    store=AsyncStore(session)
    async def db():yield store
    @asynccontextmanager
    async def worker_db():yield store
    app.dependency_overrides[get_db]=db
    app.dependency_overrides[get_current_user]=lambda:user
    monkeypatch.setattr(quality_service,'SessionLocal',worker_db)
    monkeypatch.setattr(quality_service,'STREAM_GROUP_INTERVAL',0)
    monkeypatch.setattr(quality_service,'CACHE_PRESENTATION_DELAY',0)
    monkeypatch.setattr(quality_service.settings,'media_dir',str(tmp_path/'media'))
    monkeypatch.setattr(quality_service.settings,'openai_api_key','test-not-a-real-key')
    model=AsyncMock(return_value={'product_presence':'present','presence_evidence':'Component visible','assessment':'possible_defect','summary':'Crack visible in supplied image','findings':[{'title':'Crack','evidence':'Visible crack','severity':'medium','box':None}],'uncertainty':'Requires inspector approval'})
    monkeypatch.setattr(quality_service,'analyze',model)
    resolve=quality_service.resolve_analysis
    async def fast_resolve(asset_id,image,product,context,mode,**kwargs):
        # Keep real persistent cache behavior; omit presentation delay in this test.
        return await resolve(asset_id,image,product,context,mode)
    monkeypatch.setattr(quality_service,'resolve_analysis',fast_resolve)
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
            for n in range(4):
                image=io.BytesIO();Image.new('RGB',(16,16),(n+20,50,60)).save(image,format='PNG')
                assert (await client.post('/quality/assets',files={'files':(f'{n}.png',image.getvalue(),'image/png')})).status_code==201
            started=await client.post('/quality/runs',json={'limit':4,'continuous':True})
            assert started.status_code==201,started.text
            ident=started.json()['id']
            deadline=time.monotonic()+20
            while time.monotonic()<deadline:
                count=len(session.query(QualityInspection).all())
                if count>=156:break
                await asyncio.sleep(.05)
            assert count>=156,'Continuous source cycle must keep processing beyond 150'
            paused=await client.post(f'/quality/runs/{ident}/control',json={'action':'pause'})
            assert paused.status_code==200
            task=quality_service.workers.get(uuid.UUID(ident))
            if task:await asyncio.wait_for(asyncio.shield(task),5)
            state=(await client.get('/quality/workspace')).json()
            assert state['runs'][0]['continuous'] is True
            assert state['runs'][0]['state']=='paused'
            count=len(state['inspections'])
            await asyncio.sleep(.15)
            assert len(session.query(QualityInspection).all())==count
            assert model.await_count==4,'Repeated source images must use their actual previous analysis'
            assert len({i['asset_id'] for i in state['inspections']})==4
            assert all(i['decision'] is None for i in state['inspections'])
            assert sorted(i['sequence'] for i in state['inspections'])==list(range(1,count+1))
            assert sum(bool(i['draft'].get('cache',{}).get('reused')) for i in state['inspections'])==count-4
            cases=(await client.get('/quality/manager-inboxes')).json()['cases']
            assert len(cases)==count
            assert all(c['state']=='awaiting_approval' and c['group_key']=='cracks' for c in cases)
            assert (await client.post(f'/quality/runs/{ident}/control',json={'action':'stop'})).status_code==200
            await asyncio.sleep(.15)
            state=(await client.get('/quality/workspace')).json()
            assert state['runs'][0]['state']=='stopped'
            assert state['runs'][0]['total']==count
            assert len(state['inspections'])==count
    finally:
        app.dependency_overrides.clear()
        await quality_service.shutdown()
        session.close()
