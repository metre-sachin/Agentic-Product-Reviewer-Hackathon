"""Unit tests for the replan-aware execution queue.

`_next_step` is what lets a mid-run replan take effect: it re-reads task.steps on
every call and returns the lowest-ordinal not-yet-started step, so steps inserted
by a replan are picked up without re-running completed ones. Pure logic — no DB.

    cd backend && PYTHONPATH=. .venv/bin/python -m unittest tests.test_replan
"""

from __future__ import annotations

import unittest
import uuid
from types import SimpleNamespace

from app.services.runtime import _next_step, _screenshot_b64_from_url


def _step(ordinal: int, state: str, sid: uuid.UUID | None = None) -> SimpleNamespace:
    return SimpleNamespace(id=sid or uuid.uuid4(), ordinal=ordinal, state=state)


def _task(steps: list[SimpleNamespace]) -> SimpleNamespace:
    return SimpleNamespace(steps=steps)


class NextStepTests(unittest.TestCase):
    def test_picks_lowest_ordinal_pending(self) -> None:
        s1, s2 = _step(1, "pending"), _step(2, "pending")
        step = _next_step(_task([s2, s1]), set())
        self.assertIs(step, s1)

    def test_skips_processed_and_completed(self) -> None:
        done = _step(1, "done")
        active = _step(2, "active")
        nxt = _step(3, "pending")
        processed = {done.id, active.id}
        self.assertIs(_next_step(_task([done, active, nxt]), processed), nxt)

    def test_returns_none_when_nothing_pending(self) -> None:
        steps = [_step(1, "done"), _step(2, "skipped"), _step(3, "failed")]
        self.assertIsNone(_next_step(_task(steps), set()))

    def test_picks_up_replan_inserted_step(self) -> None:
        # First two steps already started/done; a replan appends a new pending step.
        done = _step(1, "done")
        old = _step(2, "pending")
        processed = {done.id, old.id}  # both already started
        # nothing left to do...
        self.assertIsNone(_next_step(_task([done, old]), processed))
        # ...until replan inserts a fresh pending step with a new id.
        inserted = _step(3, "pending")
        self.assertIs(_next_step(_task([done, old, inserted]), processed), inserted)


class ScreenshotUrlGuardTests(unittest.TestCase):
    def test_rejects_non_png_and_traversal_and_empty(self) -> None:
        tid = uuid.uuid4()
        self.assertIsNone(_screenshot_b64_from_url(tid, None))
        self.assertIsNone(_screenshot_b64_from_url(tid, ""))
        self.assertIsNone(_screenshot_b64_from_url(tid, "https://x/media/a/notes.txt"))
        # traversal collapses to a basename that doesn't exist -> None, never escapes
        self.assertIsNone(_screenshot_b64_from_url(tid, "../../../../etc/passwd"))

    def test_missing_png_returns_none(self) -> None:
        tid = uuid.uuid4()
        self.assertIsNone(
            _screenshot_b64_from_url(tid, f"http://x/media/{tid}/does-not-exist.png?t=123")
        )


if __name__ == "__main__":
    unittest.main()
