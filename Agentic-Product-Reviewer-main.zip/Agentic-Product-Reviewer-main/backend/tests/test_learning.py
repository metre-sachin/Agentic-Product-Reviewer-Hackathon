"""Unit tests for auto-memory de-duplication.

`_is_duplicate` keeps the memory store from filling with near-identical learned
preferences. Pure logic — no DB or LLM.

    cd backend && PYTHONPATH=. .venv/bin/python -m unittest tests.test_learning
"""

from __future__ import annotations

import unittest

from app.services.learning_service import _is_duplicate


class IsDuplicateTests(unittest.TestCase):
    def test_exact_match_case_insensitive(self) -> None:
        self.assertTrue(_is_duplicate("Vegetarian", {"vegetarian"}))

    def test_substring_either_direction(self) -> None:
        # candidate contained in an existing memory
        self.assertTrue(_is_duplicate("veg", {"vegetarian, high protein"}))
        # existing memory contained in the candidate
        self.assertTrue(_is_duplicate("budget 500 inr per order", {"budget 500 inr"}))

    def test_distinct_preferences_are_not_duplicates(self) -> None:
        self.assertFalse(_is_duplicate("Budget 500 INR", {"vegetarian"}))
        self.assertFalse(_is_duplicate("Prefers window seat", {"prefers aisle seat? no"}))

    def test_blank_is_duplicate(self) -> None:
        # nothing meaningful to store
        self.assertTrue(_is_duplicate("   ", {"vegetarian"}))
        self.assertTrue(_is_duplicate("", set()))


if __name__ == "__main__":
    unittest.main()
