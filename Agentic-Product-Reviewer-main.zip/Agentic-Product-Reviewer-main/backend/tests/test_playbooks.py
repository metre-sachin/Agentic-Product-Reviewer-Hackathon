"""Unit tests for playbook distillation selection.

`_replayable_steps` decides which of a finished task's steps become the saved
playbook: the ones that actually ran, in order, falling back to all steps. Pure
logic — no DB.

    cd backend && PYTHONPATH=. .venv/bin/python -m unittest tests.test_playbooks
"""

from __future__ import annotations

import unittest
from types import SimpleNamespace

from app.services.playbook_service import _replayable_steps


def _step(ordinal: int, state: str, label: str = "") -> SimpleNamespace:
    return SimpleNamespace(ordinal=ordinal, state=state, label=label or f"step {ordinal}")


class ReplayableStepsTests(unittest.TestCase):
    def test_keeps_only_steps_that_ran_in_order(self) -> None:
        steps = [
            _step(2, "done"),
            _step(1, "done"),
            _step(3, "pending"),   # never reached -> dropped
            _step(4, "skipped"),
        ]
        out = _replayable_steps(steps)
        self.assertEqual([s.ordinal for s in out], [1, 2, 4])

    def test_includes_failed_and_active(self) -> None:
        steps = [_step(1, "failed"), _step(2, "active")]
        self.assertEqual(len(_replayable_steps(steps)), 2)

    def test_falls_back_to_all_when_none_ran(self) -> None:
        steps = [_step(1, "pending"), _step(2, "pending")]
        self.assertEqual([s.ordinal for s in _replayable_steps(steps)], [1, 2])

    def test_empty_in_empty_out(self) -> None:
        self.assertEqual(_replayable_steps([]), [])


if __name__ == "__main__":
    unittest.main()
