"""Argus v2 backend tests — hub correlation, adapter mapping, profile shaping."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from app.services.v2_hub import V2Connection, V2Hub
from integrations.base import StepInput
from integrations.page_agent.adapter import V2BrowserAdapter


class FakeWs:
    """Captures outbound frames and lets tests inject replies."""

    def __init__(self) -> None:
        self.sent: list[dict[str, Any]] = []

    async def send_json(self, data: dict[str, Any]) -> None:
        self.sent.append(data)


def make_conn(kind: str = "extension") -> tuple[V2Connection, FakeWs]:
    ws = FakeWs()
    conn = V2Connection(ws, user_id="u1", session_id="s1", info={"kind": kind})
    return conn, ws


# ---------------------- hub ----------------------


@pytest.mark.asyncio
async def test_action_roundtrip_resolves_matching_future():
    conn, ws = make_conn()

    async def respond() -> None:
        while not ws.sent:
            await asyncio.sleep(0)
        frame = ws.sent[0]
        assert frame["type"] == "action"
        assert frame["action"]["kind"] == "click"
        conn.resolve(frame["id"], {"ok": True, "message": "clicked"})

    responder = asyncio.create_task(respond())
    result = await conn.send_action({"kind": "click", "ref": "e3"}, timeout=2.0)
    await responder
    assert result == {"ok": True, "message": "clicked"}


@pytest.mark.asyncio
async def test_disconnect_fails_pending_actions():
    conn, ws = make_conn()

    async def kill() -> None:
        while not ws.sent:
            await asyncio.sleep(0)
        conn.fail_all("disconnected")

    killer = asyncio.create_task(kill())
    with pytest.raises(ConnectionError):
        await conn.send_action({"kind": "snapshot"}, timeout=2.0)
    await killer
    # And new sends are refused outright.
    with pytest.raises(ConnectionError):
        await conn.send_action({"kind": "snapshot"}, timeout=2.0)


@pytest.mark.asyncio
async def test_hub_newest_connection_wins():
    hub = V2Hub()
    old, old_ws = make_conn()
    new, _ = make_conn()
    hub.register(old)

    async def pending_on_old() -> None:
        await old.send_action({"kind": "wait"}, timeout=2.0)

    task = asyncio.create_task(pending_on_old())
    while not old_ws.sent:
        await asyncio.sleep(0)

    hub.register(new)  # replaces old, failing its in-flight action
    with pytest.raises(ConnectionError):
        await task
    assert hub.get("u1") is new

    hub.unregister(new)
    assert hub.get("u1") is None


# ---------------------- adapter ----------------------


@pytest.mark.asyncio
async def test_adapter_snapshot_maps_to_v1_shape():
    conn, ws = make_conn()
    adapter = V2BrowserAdapter(conn)

    async def respond() -> None:
        while not ws.sent:
            await asyncio.sleep(0)
        frame = ws.sent[0]
        conn.resolve(
            frame["id"],
            {
                "ok": True,
                "snapshot": {
                    "url": "https://example.com",
                    "title": "Example",
                    "elements": [{"ref": "e0", "tag": "button", "text": "Add to cart"}],
                },
            },
        )

    responder = asyncio.create_task(respond())
    snap = await adapter.snapshot()
    await responder
    assert snap.url == "https://example.com"
    assert snap.title == "Example"
    assert snap.elements[0]["ref"] == "e0"
    # The digest used by browser_loop renders without error.
    assert "e0" in snap.digest()


@pytest.mark.asyncio
async def test_adapter_click_failure_is_false_not_raise():
    conn, _ = make_conn()
    conn.fail_all("gone")
    adapter = V2BrowserAdapter(conn)
    assert await adapter.click("e1") is False
    assert await adapter.type_text("e1", "hi") is False


@pytest.mark.asyncio
async def test_run_goal_maps_success_and_failure():
    conn, ws = make_conn()
    adapter = V2BrowserAdapter(conn)

    async def respond(success: bool) -> None:
        while not ws.sent:
            await asyncio.sleep(0)
        frame = ws.sent.pop(0)
        assert frame["type"] == "execute"
        conn.resolve(frame["id"], {"success": success, "data": "summary"})

    responder = asyncio.create_task(respond(True))
    ok = await adapter.run_goal(StepInput(goal="add milk to cart"))
    await responder
    assert ok.ok is True
    assert ok.confidence > 0.5
    assert ok.observed["summary"] == "summary"

    responder = asyncio.create_task(respond(False))
    bad = await adapter.run_goal(StepInput(goal="impossible"))
    await responder
    assert bad.ok is False
    assert bad.error == "summary"


# ---------------------- profile shaping ----------------------


def test_profile_autofill_kind_filter():
    """The /v2/profile endpoint only exposes allow-listed identity kinds."""
    from app.api.v2 import AUTOFILL_KINDS

    raw = {
        "name": "Gaurav",
        "email": "g@example.com",
        "otp_secret": "should-never-leak",
        "password": "should-never-leak",
        "card": "4111",
    }
    filtered = {k: v for k, v in raw.items() if k in AUTOFILL_KINDS and v}
    assert set(filtered) == {"name", "email", "card"}
    assert "otp_secret" not in filtered
    assert "password" not in filtered
