"""Argus v2 browser transport endpoint.

A connected browser (Argus extension or bookmarklet page) authenticates with the
user's Argus JWT, then becomes the user's live browser: the runtime sends
`action` (primitive) or `execute` (goal) frames and the browser replies with
`result` frames. This is the bridge that lets the Python brain drive the user's
real, logged-in browser through the page-agent engine.

Wire protocol (mirrors v2/packages/extension/lib/protocol.ts):
  client -> server: {"type":"hello","token":"…","info":{"kind":"extension",…}}
                    {"type":"result","id":"…","result":{…}}
                    {"type":"event","event":"…","data":{…}}
                    {"type":"pong"}
  server -> client: {"type":"welcome","sessionId":"…"}
                    {"type":"action","id":"…","action":{"kind":"click",…}}
                    {"type":"execute","id":"…","task":"…","config":{…}}
                    {"type":"stop"}
                    {"type":"ping"}
"""

from __future__ import annotations

import asyncio
import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from jose import JWTError

from app.core.deps import get_current_user
from app.core.security import decode_token
from app.models import User
from app.services.v2_hub import V2Connection, hub

log = logging.getLogger(__name__)

router = APIRouter()

PING_INTERVAL_S = 20.0


async def _ping_loop(ws: WebSocket) -> None:
    try:
        while True:
            await asyncio.sleep(PING_INTERVAL_S)
            await ws.send_json({"type": "ping"})
    except (WebSocketDisconnect, RuntimeError):
        return


@router.websocket("/ws/v2")
async def v2_ws(ws: WebSocket) -> None:
    await ws.accept()

    # First frame must authenticate.
    try:
        hello = await asyncio.wait_for(ws.receive_json(), timeout=10.0)
    except (asyncio.TimeoutError, WebSocketDisconnect):
        await ws.close(code=4001)
        return

    if hello.get("type") != "hello" or not hello.get("token"):
        await ws.close(code=4001)
        return
    try:
        payload = decode_token(hello["token"])
        user_id = str(payload["sub"])
        uuid.UUID(user_id)  # validate shape
    except (JWTError, KeyError, ValueError):
        await ws.close(code=4001)
        return

    session_id = str(uuid.uuid4())
    conn = V2Connection(ws, user_id, session_id, hello.get("info") or {})
    hub.register(conn)
    await ws.send_json({"type": "welcome", "sessionId": session_id})

    ping_task = asyncio.create_task(_ping_loop(ws))
    try:
        while True:
            msg = await ws.receive_json()
            kind = msg.get("type")
            if kind == "result":
                conn.resolve(str(msg.get("id")), msg.get("result") or {})
            elif kind == "event":
                conn.push_event(str(msg.get("event") or ""), msg.get("data") or {})
            elif kind == "pong":
                continue
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # noqa: BLE001
        log.warning("v2 ws error: %s", exc)
    finally:
        ping_task.cancel()
        conn.fail_all("disconnected")
        hub.unregister(conn)


@router.get("/v2/status")
async def v2_status(user: User = Depends(get_current_user)) -> dict:
    """Is this user's real browser connected right now (and how)?"""
    conn = hub.get(str(user.id))
    return {
        "connected": conn is not None,
        "kind": conn.kind if conn is not None else None,
        "session_id": conn.session_id if conn is not None else None,
    }


@router.post("/v2/ping")
async def v2_ping(user: User = Depends(get_current_user)) -> dict:
    """Round-trip check: snapshot the active tab through the connected browser.

    Proves the full brain -> browser -> page-agent engine -> brain loop.
    """
    conn = hub.get(str(user.id))
    if conn is None:
        raise HTTPException(status_code=409, detail="no v2 browser connected")
    try:
        result = await conn.send_action({"kind": "snapshot"}, timeout=15.0)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=504, detail=f"browser did not respond: {exc}") from exc
    snap = result.get("snapshot") or {}
    return {
        "ok": bool(result.get("ok")),
        "url": snap.get("url"),
        "title": snap.get("title"),
        "elements": len(snap.get("elements") or []),
    }
