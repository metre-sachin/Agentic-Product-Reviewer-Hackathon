from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.schemas.connected_sites import (
    ConnectedSiteCreate,
    ConnectedSiteOut,
    ConnectedSiteUpdate,
)
from app.services import connected_sites_service

router = APIRouter()


@router.get("", response_model=list[ConnectedSiteOut])
async def list_sites(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[ConnectedSiteOut]:
    return await connected_sites_service.list_for_user(db, user)


@router.post("", response_model=ConnectedSiteOut, status_code=201)
async def create_site(
    payload: ConnectedSiteCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ConnectedSiteOut:
    return await connected_sites_service.create(db, user, payload)


@router.patch("/{site_id}", response_model=ConnectedSiteOut)
async def update_site(
    site_id: str,
    payload: ConnectedSiteUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ConnectedSiteOut:
    return await connected_sites_service.update(db, user, site_id, payload)


@router.delete("/{site_id}", status_code=204)
async def delete_site(
    site_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    await connected_sites_service.delete(db, user, site_id)
