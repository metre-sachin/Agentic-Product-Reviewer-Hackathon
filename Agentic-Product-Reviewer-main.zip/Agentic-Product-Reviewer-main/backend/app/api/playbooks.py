import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.schemas.playbooks import (
    PlaybookCreateRequest,
    PlaybookDetailOut,
    PlaybookOut,
    PlaybookRunRequest,
    PlaybookStepUpdate,
)
from app.schemas.tasks import TaskOut
from app.services import playbook_service, runtime, task_service

router = APIRouter()


@router.get("", response_model=list[PlaybookOut])
async def list_playbooks(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[PlaybookOut]:
    return await playbook_service.list_for_user(db, user)


@router.post("", response_model=PlaybookDetailOut, status_code=201)
async def create_playbook(
    payload: PlaybookCreateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PlaybookDetailOut:
    return await playbook_service.create_from_task(db, user, payload.task_id, payload.title)


@router.get("/{playbook_id}", response_model=PlaybookDetailOut)
async def get_playbook(
    playbook_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PlaybookDetailOut:
    return await playbook_service.get_detail(db, user, playbook_id)


@router.patch("/{playbook_id}/steps/{step_id}", response_model=PlaybookDetailOut)
async def update_step(
    playbook_id: str,
    step_id: str,
    payload: PlaybookStepUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PlaybookDetailOut:
    return await playbook_service.update_step(db, user, playbook_id, step_id, payload)


@router.delete("/{playbook_id}/steps/{step_id}", response_model=PlaybookDetailOut)
async def delete_step(
    playbook_id: str,
    step_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PlaybookDetailOut:
    return await playbook_service.delete_step(db, user, playbook_id, step_id)


@router.delete("/{playbook_id}", status_code=204)
async def delete_playbook(
    playbook_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    await playbook_service.delete(db, user, playbook_id)


@router.post("/{playbook_id}/run", response_model=TaskOut, status_code=201)
async def run_playbook(
    playbook_id: str,
    payload: PlaybookRunRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    task = await playbook_service.create_run_task(db, user, playbook_id, payload.goal)
    runtime.start_task(uuid.UUID(str(task.id)))
    return await task_service.get_detail(db, user, str(task.id))
