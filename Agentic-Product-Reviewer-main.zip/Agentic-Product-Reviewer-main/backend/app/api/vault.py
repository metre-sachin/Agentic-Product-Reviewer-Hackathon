from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.schemas.vault import VaultEntryOut, VaultEntryUpdate
from app.services import vault_service

router = APIRouter()


@router.get("", response_model=list[VaultEntryOut])
async def list_entries(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[VaultEntryOut]:
    """Vault entry metadata only — encrypted values are never returned."""
    return await vault_service.list_for_user(db, user)


@router.patch("/{entry_id}", response_model=VaultEntryOut)
async def update_entry(
    entry_id: str,
    payload: VaultEntryUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> VaultEntryOut:
    return await vault_service.update(db, user, entry_id, payload)


@router.delete("/{entry_id}", status_code=204)
async def delete_entry(
    entry_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    await vault_service.delete(db, user, entry_id)
