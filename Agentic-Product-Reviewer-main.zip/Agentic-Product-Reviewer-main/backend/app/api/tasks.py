from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime
from typing import AsyncIterator

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sse_starlette.sse import EventSourceResponse

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import Task, User
from app.schemas.tasks import (
    CaptchaRequest,
    CredentialsRequest,
    FeedbackRequest,
    InfoRequest,
    OtpRequest,
    ReplanRequest,
    TaskCreateRequest,
    TaskDetailOut,
    TaskLogOut,
    TaskOut,
    UserInputRequest,
)
from app.services import approval_service, feedback_service, runtime, task_service
from app.services.event_bus import bus

router = APIRouter()


@router.get("", response_model=list[TaskOut])
async def list_tasks(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[TaskOut]:
    return await task_service.list_for_user(db, user)


@router.post("", response_model=TaskOut, status_code=201)
async def create_task(
    payload: TaskCreateRequest,
    autostart: bool = Query(default=True),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    task = await task_service.create_for_user(db, user, payload)
    if autostart:
        runtime.start_task(uuid.UUID(task.id))
    return task


@router.get("/{task_id}", response_model=TaskDetailOut)
async def get_task(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskDetailOut:
    return await task_service.get_detail(db, user, task_id)


@router.post("/{task_id}/start", response_model=TaskOut)
async def start_task(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    # Verify ownership before launching.
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.start_task(tid)
    return await task_service.get_detail(db, user, task_id)


@router.post("/{task_id}/cancel", response_model=TaskOut)
async def cancel_task(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    return await task_service.cancel(db, user, task_id)


@router.post("/{task_id}/pause", response_model=TaskOut)
async def pause_task(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    return await task_service.pause(db, user, task_id)


@router.post("/{task_id}/resume", response_model=TaskOut)
async def resume_task(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    return await task_service.resume(db, user, task_id)


@router.post("/{task_id}/replan")
async def replan_task(
    task_id: str,
    payload: ReplanRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Hand a paused (or running) task a brand-new plan, optionally anchored to a
    screenshot the user picked. The runtime rebuilds the remaining steps and
    continues; completed steps are preserved."""
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_replan(tid, payload.instruction, payload.screenshot_url)
    return {"ok": True}


@router.post("/{task_id}/feedback")
async def feedback(
    task_id: str,
    payload: FeedbackRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Leave a rating and/or note on a finished task. When auto-learn is on, durable
    preferences are distilled into memory for future tasks."""
    return await feedback_service.create(db, user, task_id, payload)


@router.get("/{task_id}/logs", response_model=list[TaskLogOut])
async def get_task_logs(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[TaskLogOut]:
    return await task_service.list_logs(db, user, task_id)


@router.post("/{task_id}/approve")
async def approve(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    return await approval_service.respond(db, user, task_id, "approved")


@router.post("/{task_id}/reject")
async def reject(
    task_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    return await approval_service.respond(db, user, task_id, "rejected")


@router.post("/{task_id}/user-input")
async def user_input(
    task_id: str,
    payload: UserInputRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_user_input(tid, payload.text)
    return {"ok": True}


@router.post("/{task_id}/credentials")
async def credentials(
    task_id: str,
    payload: CredentialsRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Hand sign-in credentials to a paused task. Held in memory only, never
    written to the database or logs; used once to fill the login form."""
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_credentials(tid, payload.email, payload.password)
    return {"ok": True}


@router.post("/{task_id}/otp")
async def otp(
    task_id: str,
    payload: OtpRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Hand a one-time passcode to a paused task. Held in memory only, never
    written to the database or logs; typed once into the verification field."""
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_otp(tid, payload.code)
    return {"ok": True}


@router.post("/{task_id}/info")
async def info(
    task_id: str,
    payload: InfoRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Hand personal/sensitive form values (name, email, phone, address, card, …)
    to a paused task. Held in memory only, typed once into the matching fields;
    never written to the database or logs."""
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_info(tid, payload.values)
    return {"ok": True}


@router.post("/{task_id}/captcha")
async def captcha(
    task_id: str,
    payload: CaptchaRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Hand a CAPTCHA answer to a paused task. Held in memory only, typed once
    into the challenge field; never written to the database or logs."""
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")
    runtime.submit_captcha(tid, payload.text)
    return {"ok": True}


@router.get("/{task_id}/stream")
async def stream_task(
    task_id: str,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> EventSourceResponse:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc

    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")

    queue = bus.subscribe(task_id)

    async def event_gen() -> AsyncIterator[dict]:
        try:
            # Initial snapshot so the UI hydrates immediately.
            detail = await task_service.get_detail(db, user, task_id)
            yield {"event": "snapshot", "data": json.dumps(detail.model_dump(mode="json"))}
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15.0)
                    yield {"event": event["kind"], "data": json.dumps(event["payload"], default=_default)}
                except asyncio.TimeoutError:
                    # Heartbeat so proxies don't kill the connection.
                    yield {"event": "ping", "data": json.dumps({"t": datetime.utcnow().isoformat()})}
        finally:
            bus.unsubscribe(task_id, queue)

    return EventSourceResponse(event_gen())


def _default(o):  # noqa: ANN001
    if isinstance(o, (datetime,)):
        return o.isoformat()
    if isinstance(o, uuid.UUID):
        return str(o)
    raise TypeError(f"unserialisable: {type(o)}")
