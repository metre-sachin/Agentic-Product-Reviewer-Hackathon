"""Authenticated APIs for the quality workspace; labels never enter model prompts."""
import asyncio
import io
import random
import uuid
import zipfile
import hashlib
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field, field_validator
from PIL import Image, UnidentifiedImageError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.deps import get_current_user
from app.core.config import settings
from app.db.session import get_db
from app.models import User
from app.models.quality import QualityAsset, QualityRun, QualityInspection, QualityReport, QualityOperation, QualityEvent, QualityBatchReport, QualityAnnotation, QualityRunContext, QualityAttempt, QualitySourceAnnotation
from app.services import quality_service as service
from app.models.quality import QualityReviewCase, QualityStream
from app.services.quality_guides import GUIDES
from app.services.quality_routing import GROUPS, route_decision, route_completed_group

router = APIRouter(prefix='/quality', tags=['quality'])

async def owned(db, cls, ident, user, lock=False):
    stmt = select(cls).where(cls.id == ident, cls.user_id == user.id)
    if lock:
        stmt = stmt.with_for_update()
    row = (await db.execute(stmt)).scalar_one_or_none()
    if row is None:
        raise HTTPException(404, 'Record not found')
    return row

@router.get('/workspace')
async def workspace(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    async def rows(cls):
        return list((await db.scalars(select(cls).where(cls.user_id == user.id).order_by(cls.created_at.desc()))).all())
    assets, runs, inspections, reports = await rows(QualityAsset), await rows(QualityRun), await rows(QualityInspection), await rows(QualityReport)
    streaming=set((await db.scalars(select(QualityStream.run_id).join(QualityRun,QualityRun.id==QualityStream.run_id).where(QualityRun.user_id==user.id))).all())
    return {
        'processing': {'mode':'parallel_groups','group_size':4,'max_concurrent':4,'review_backlog':'persisted','automatic_groups':True},
        'runtime_version':'quality-manager-inboxes-v7',
        'source_annotations': [{'asset_id':str(a.asset_id),'label':a.label,'source':a.source,'box':a.box,'has_mask':bool(a.mask_path)} for a in await rows(QualitySourceAnnotation)],
        'attempts': [{'inspection_id':str(a.inspection_id),'previous':a.previous,'created_at':a.created_at} for a in await rows(QualityAttempt)],
        'criteria': [{'run_id':str(c.run_id),'checks':c.checks,'notes':c.notes} for c in (await db.scalars(select(QualityRunContext).join(QualityRun,QualityRun.id==QualityRunContext.run_id).where(QualityRun.user_id==user.id))).all()],
        'annotations': [{'inspection_id':str(a.inspection_id),'box':a.box,'note':a.note} for a in await rows(QualityAnnotation)],
        'batch_reports': [{'id':str(r.id),'run_id':str(r.run_id),'state':r.state,'body':r.body,'snapshot':r.snapshot,'decision':r.decision,'created_at':r.created_at} for r in await rows(QualityBatchReport)],
        'events': [{'id':str(e.id),'agent':e.agent,'action':e.action,'detail':e.detail,'created_at':e.created_at} for e in (await db.scalars(select(QualityEvent).where(QualityEvent.user_id == user.id).order_by(QualityEvent.created_at.desc()).limit(80))).all()],
        'operations': [{'id':str(o.id),'run_id':str(o.run_id),'kind':o.kind,'title':o.title,'state':o.state,'detail':o.detail,'created_at':o.created_at} for o in await rows(QualityOperation)],
        'model_ready': bool(settings.openai_api_key), 'model': settings.openai_model_vision,
        'assets': [{'id':str(a.id), 'name':a.name, 'product':a.product} for a in assets],
        'runs': [{'continuous':r.id in streaming,'asset_ids':r.assets,'id':str(r.id), 'state':r.state, 'position':r.position, 'total':len(r.assets), 'mode':r.mode, 'interval':r.interval, 'created_at':r.created_at} for r in runs],
        'inspections': [{'id':str(i.id), 'run_id':str(i.run_id), 'asset_id':str(i.asset_id), 'sequence':i.sequence, 'state':i.state, 'assessment':i.assessment, 'draft':i.draft, 'error':i.error, 'decision':i.decision, 'duration':i.duration, 'created_at':i.created_at} for i in inspections],
        'reports': [{'id':str(r.id), 'inspection_id':str(r.inspection_id), 'body':r.body, 'created_at':r.created_at} for r in reports],
    }

@router.post('/assets', status_code=201)
async def upload(files: list[UploadFile] = File(...), product: str = Form('Transistor', max_length=80), user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    entries = []
    total = 0
    for upload in files:
        raw = await upload.read(100 * 1024 * 1024 + 1)
        total += len(raw)
        if total > 100 * 1024 * 1024:
            raise HTTPException(413, 'Upload up to 100 MB at a time')
        name = upload.filename or 'image.png'
        if name.lower().endswith('.zip'):
            try:
                with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                    selected = [m for m in archive.infolist() if not m.is_dir() and PurePosixPath(m.filename).suffix.lower() in {'.png','.jpg','.jpeg','.webp'} and not any(x in PurePosixPath(m.filename).parts for x in ('ground_truth','train','__MACOSX'))]
                    if len(selected) + len(entries) > 300 or sum(m.file_size for m in selected) > 100 * 1024 * 1024:
                        raise HTTPException(413, 'Select up to 300 test images, with at most 100 MB uncompressed')
                    for m in selected:
                        entries.append((m.filename, archive.read(m)))
            except (zipfile.BadZipFile, RuntimeError, NotImplementedError):
                raise HTTPException(400, 'Could not read ZIP archive')
        else:
            entries.append((name, raw))
    if not entries or len(entries) > 300 or sum(len(r) for _, r in entries) > 100 * 1024 * 1024:
        raise HTTPException(400, 'Choose 1–300 images, up to 100 MB total. PNG, JPEG and WebP are supported.')
    directory = settings.media_path.parent / '.quality-assets' / str(user.id)
    directory.mkdir(parents=True, exist_ok=True)
    written = []
    imported_ids = []
    try:
        for name, raw in entries:
            try:
                with Image.open(io.BytesIO(raw)) as im:
                    if im.width * im.height > 25_000_000:
                        raise ValueError('Image too large')
                    im.load()
                    im = im.convert('RGB')
                    im.thumbnail((1600,1600))
                    data = io.BytesIO()
                    im.save(data, format='PNG')
            except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
                raise HTTPException(400, 'An image is invalid or exceeds the image size limit')
            ident = uuid.uuid5(uuid.NAMESPACE_URL,str(user.id)+'/'+product+'/'+hashlib.sha256(data.getvalue()).hexdigest())
            if await db.get(QualityAsset,ident):
                imported_ids.append(str(ident))
                continue
            path = directory / f'{ident}.png'
            path.write_bytes(data.getvalue())
            written.append(path)
            imported_ids.append(str(ident))
            parts = PurePosixPath(name.replace('\\','/')).parts
            truth = parts[-2] if 'test' in parts and len(parts) >= 2 else None
            # Canonical names avoid leaking defect directory names to the model or reviewer.
            db.add(QualityAsset(id=ident, user_id=user.id, path=str(path), name=f'Frame {ident.hex[:6].upper()}', product=product.strip() or 'Transistor', truth=truth))
        await db.commit()
    except Exception:
        await db.rollback()
        for path in written:
            path.unlink(missing_ok=True)
        raise
    return {'imported':len(written),'asset_ids':imported_ids}

@router.get('/assets/{ident}/image')
async def image(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    asset = await owned(db, QualityAsset, ident, user)
    return FileResponse(asset.path, media_type='image/png', headers={'Cache-Control':'private, max-age=3600'})

class Start(BaseModel):
    checks: list[str] = Field(default_factory=list, max_length=20)
    context_notes: str = Field(default="", max_length=2000)
    product: str = Field(default="Transistor", max_length=80)
    mode: str = Field(default="agentic", pattern="^(agentic|manual|assisted)$")
    interval: int = Field(default=5, ge=1, le=60)
    limit: int = Field(default=20, ge=1, le=500)
    continuous: bool = False

@router.post('/runs', status_code=201)
async def start(payload: Start, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if any(c not in GUIDES.get(payload.product,{}) for c in payload.checks):
        raise HTTPException(422, 'Unknown defect check for this product')
    if payload.mode == 'agentic' and not settings.openai_api_key:
        raise HTTPException(409, 'Add OPENAI_API_KEY to the backend environment and restart to enable image analysis.')
    await db.execute(select(User).where(User.id == user.id).with_for_update())
    active = await db.scalar(select(QualityRun).where(QualityRun.user_id == user.id, QualityRun.state.in_(['running','paused'])))
    if active:
        raise HTTPException(409, 'Resume or stop your existing run first')
    asset_query = select(QualityAsset.id).where(QualityAsset.user_id == user.id, QualityAsset.product == payload.product)
    if payload.mode == 'assisted':
        asset_query = asset_query.join(QualitySourceAnnotation,QualitySourceAnnotation.asset_id==QualityAsset.id)
    assets = list((await db.scalars(asset_query)).all())
    if not assets:
        raise HTTPException(409, 'Import inspection images first')
    random.shuffle(assets)
    run = QualityRun(user_id=user.id, assets=[str(x) for x in assets[:payload.limit]], interval=payload.interval, mode=payload.mode)
    db.add(run)
    await db.flush()
    if payload.continuous:
        db.add(QualityStream(run_id=run.id,source_assets=list(run.assets)))
    db.add(QualityRunContext(run_id=run.id,checks=payload.checks or list(GUIDES.get(payload.product,{})),notes=payload.context_notes))
    await db.commit()
    service.launch(run.id)
    return {'id':str(run.id)}

@router.post('/runs/{ident}/route')
async def repair_routing(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    run=await owned(db,QualityRun,ident,user,lock=True)
    sequences=(await db.scalars(select(QualityInspection.sequence).where(QualityInspection.run_id==run.id))).all()
    for first in sorted({((sequence-1)//4)*4+1 for sequence in sequences}):
        await route_completed_group(db,run.id,first)
    await db.commit()
    count=len((await db.scalars(select(QualityReviewCase.id).where(QualityReviewCase.run_id==run.id))).all())
    return {'assigned':count}

class Control(BaseModel):
    action: str = Field(pattern='^(pause|resume|stop)$')

@router.post('/runs/{ident}/control')
async def control(ident: uuid.UUID, payload: Control, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    run = await owned(db, QualityRun, ident, user, lock=True)
    if run.state not in ('running','paused'):
        raise HTTPException(409, 'This run has ended')
    if payload.action == 'resume' and run.state != 'paused':
        raise HTTPException(409, 'Run is already running')
    run.state = {'pause':'paused','resume':'running','stop':'stopped'}[payload.action]
    if payload.action=='stop' and await db.get(QualityStream,run.id):
        run.assets=list(run.assets[:run.position])
    await db.commit()
    await service.refresh_batch_report(db, run.id)
    if payload.action == 'resume':
        task = service.workers.get(run.id)
        if not task or task.done():
            service.launch(run.id)
        else:
            task.add_done_callback(lambda _: service.launch(ident))
    return {'state':run.state}

class Decision(BaseModel):
    action: str = Field(pattern='^(approve|reject|rework|reinspect)$')
    outcome: str = Field(pattern='^(defect|no_defect|uncertain|rework)$')
    notes: str = Field(min_length=3, max_length=3000)

    @field_validator('notes', mode='before')
    @classmethod
    def trim_notes(cls, value):
        return value.strip() if isinstance(value, str) else value

@router.post('/inspections/{ident}/decision')
async def decide(ident: uuid.UUID, payload: Decision, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    row = await owned(db, QualityInspection, ident, user, lock=True)
    if row.state != 'awaiting_review':
        raise HTTPException(409, 'This inspection is not awaiting review')
    await apply_image_decision(db,row,payload,user)
    await db.commit()
    await service.refresh_batch_report(db, row.run_id)
    return {'state':row.state}

async def apply_image_decision(db, row, payload, user):
    now = datetime.now(timezone.utc)
    row.decision = {'action':payload.action, 'outcome':payload.outcome, 'notes':payload.notes, 'inspector':user.name or user.email or str(user.id), 'inspector_id':str(user.id), 'at':now.isoformat()}
    row.state = 'awaiting_reinspection' if payload.action=='reinspect' or payload.outcome=='uncertain' else 'rework_required' if payload.action=='rework' or payload.outcome=='rework' else 'approved' if payload.outcome=='no_defect' else 'rejected'
    await db.flush()
    siblings = list((await db.scalars(select(QualityInspection).where(QualityInspection.run_id == row.run_id))).all())
    defect_count = sum(1 for item in siblings if (item.decision and item.decision['outcome'] in ('defect','rework')) or (not item.decision and item.assessment == 'possible_defect'))
    existing_hold = await db.scalar(select(QualityOperation.id).where(QualityOperation.run_id == row.run_id, QualityOperation.kind == 'quarantine'))
    if defect_count >= 3 and not existing_hold:
        db.add(QualityOperation(user_id=user.id,run_id=row.run_id,kind='quarantine',title='Batch precautionary hold',detail='Three or more defective or suspected defective units in this simulated batch. Review every inspection before release.'))
        db.add(QualityOperation(user_id=user.id,run_id=row.run_id,kind='maintenance',title='Investigate recurring batch defects',detail='Review the linked batch inspections and record the corrective action.'))

    await route_decision(db,row)
    if row.decision['outcome'] in ('defect','rework'):
        service.record_event(db,user.id,row.run_id,'inbox','Route to manager group','Internal review case created with source image, batch reference and inspector notes')
    service.record_event(db, user.id, row.run_id, 'inbox', 'Record inspector decision', f'{payload.action}: {payload.outcome}')
    if payload.action == 'approve' and payload.outcome!='uncertain':
        service.record_event(db, user.id, row.run_id, 'inbox', 'Generate approved report', f'Inspection {str(row.id)[:8]} signed by inspector')
        asset = await db.get(QualityAsset, row.asset_id)
        draft = row.draft or {}
        body = f"# Quality inspection report\n\nInspection: {row.id}\nProduct: {asset.product}\nEvidence image: {asset.id}\nReviewed: {now.isoformat()}\nInspector: {row.decision['inspector']}\n\n## Inspector decision\n{payload.outcome.replace('_',' ')}\n\n{payload.notes}\n\n## Original AI draft\n{draft.get('summary','')}\n\n"
        for finding in draft.get('findings',[]):
            body += f"- {finding['title']}: {finding['evidence']}\n"
        body += f"\nLimitations: {draft.get('uncertainty','')}\n"
        db.add(QualityReport(user_id=user.id, inspection_id=row.id, body=body))

@router.get('/reports/{ident}/download')
async def download(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    report = await owned(db, QualityReport, ident, user)
    return Response(report.body, media_type='text/markdown', headers={'Content-Disposition':f'attachment; filename="inspection-{str(ident)[:8]}.md"'})

class OperationUpdate(BaseModel):
    notes: str | None = Field(default=None, max_length=3000)
    state: str = Field(pattern='^(open|in_progress|resolved)$')

@router.post('/operations/{ident}')
async def operation_update(ident: uuid.UUID, payload: OperationUpdate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    operation = await owned(db, QualityOperation, ident, user, lock=True)
    if operation.kind == 'quarantine' and payload.state == 'resolved':
        pending = await db.scalar(select(QualityInspection.id).where(QualityInspection.run_id == operation.run_id, QualityInspection.state.in_(['analyzing','loading_saved','awaiting_review','awaiting_reinspection'])))
        run = await db.get(QualityRun, operation.run_id)
        if pending or run.state in ('running','paused'):
            raise HTTPException(409, 'End the run and review every inspection before releasing the hold.')
        decisions=(await db.scalars(select(QualityInspection).where(QualityInspection.run_id==operation.run_id))).all()
        if any(not r.decision or r.decision['outcome']!='no_defect' for r in decisions):
            raise HTTPException(409,'Batch contains rejected, rework, or unverified units. Inspector acceptance is required before releasing this hold.')
    if payload.notes and payload.notes.strip():
        operation.detail += "\n\nOperator note: " + payload.notes.strip()
    operation.state = payload.state
    await db.commit()
    return {'state':operation.state}

class LocalImport(BaseModel):
    product: str = Field(pattern='^(Transistor|Wood|Tile)$')
    count: int = Field(default=20, ge=1, le=50)

@router.get('/local-datasets')
async def local_datasets(user: User = Depends(get_current_user)):
    root = Path.home() / 'Downloads'
    return [{'product':p, 'images':len(list((root / p.lower() / 'test').rglob('*.png')))} for p in ('Transistor','Wood','Tile') if (root / p.lower() / 'test').is_dir()]

@router.post('/import-local', status_code=201)
async def import_local(payload: LocalImport, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    root = Path.home() / 'Downloads' / payload.product.lower() / 'test'
    if not root.is_dir():
        raise HTTPException(404, 'Dataset test folder not found. Upload images or a ZIP instead.')
    # Round-robin over classes gives an initial mix; labels are not sent to the model.
    groups = [sorted(d.glob('*.png')) for d in sorted(root.iterdir()) if d.is_dir()]
    selected = []
    while groups and len(selected) < payload.count:
        for group in groups:
            if group and len(selected) < payload.count:
                selected.append(group.pop(0))
        groups = [g for g in groups if g]
    files = [UploadFile(filename=f"test/{f.parent.name}/{f.name}", file=io.BytesIO(f.read_bytes())) for f in selected if f.resolve().is_relative_to(root.resolve())]
    result = await upload(files=files, product=payload.product, user=user, db=db)
    for file, ident in zip(selected,result['asset_ids']):
        label = file.parent.name
        mask = root.parent / 'ground_truth' / label / (file.stem + '_mask.png')
        box, mask_path = None, None
        if label != 'good' and mask.is_file():
            with Image.open(mask) as raw_mask:
                binary = raw_mask.convert('L').point(lambda p:255 if p>0 else 0)
                bounds = binary.getbbox()
                if bounds:
                    box = [bounds[0]/binary.width,bounds[1]/binary.height,bounds[2]/binary.width,bounds[3]/binary.height]
                    overlay = Image.new('RGBA',binary.size,(220,45,55,0))
                    overlay.putalpha(binary.point(lambda p:110 if p else 0))
                    path = settings.media_path.parent / '.quality-assets' / str(user.id) / (ident+'-mask.png')
                    overlay.save(path)
                    mask_path = str(path)
        if (label == 'good' or box) and not await db.scalar(select(QualitySourceAnnotation.id).where(QualitySourceAnnotation.asset_id==uuid.UUID(ident))):
            db.add(QualitySourceAnnotation(user_id=user.id,asset_id=uuid.UUID(ident),label=label,source='MVTec supplied test annotation (explicit input)',box=box,mask_path=mask_path))
    await db.commit()
    return result


@router.get('/evaluation')
async def evaluation(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(QualityInspection, QualityAsset).join(QualityAsset, QualityAsset.id == QualityInspection.asset_id).join(QualityRun, QualityRun.id==QualityInspection.run_id).where(QualityRun.mode=='agentic').where(QualityInspection.user_id == user.id, QualityAsset.truth.is_not(None)))).all()
    scored = [(i,a) for i,a in rows if i.assessment in ('possible_defect','no_visible_defect')]
    correct = sum((i.assessment == 'no_visible_defect') == (a.truth == 'good') for i,a in scored)
    return {'scored':len(scored),'correct':correct,'uncertain':sum(i.assessment == 'uncertain' for i,a in rows), 'accuracy':correct/len(scored) if scored else None, 'note':'Evaluation labels are used only after prediction. These results are not input to the model.'}


class BatchDecision(BaseModel):
    action: str = Field(pattern='^(approve|reject)$')
    notes: str = Field(min_length=3, max_length=3000)

@router.post('/batch-reports/{ident}/decision')
async def batch_decision(ident: uuid.UUID, payload: BatchDecision, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    report = await owned(db, QualityBatchReport, ident, user, lock=True)
    if report.state != 'draft':
        raise HTTPException(409, 'This report has already been reviewed')
    run = await db.get(QualityRun, report.run_id)
    if run.state in ('running','paused'):
        raise HTTPException(409, 'Complete or end the inspection run before finalizing its report')
    rows = (await db.scalars(select(QualityInspection).where(QualityInspection.run_id==run.id))).all()
    if payload.action == 'approve' and run.position<len(run.assets):
        raise HTTPException(409,'Scheduled images remain uninspected. Complete the batch before approval.')
    if payload.action == 'approve' and any(r.state in ('analyzing','loading_saved','awaiting_review','awaiting_reinspection','failed') or (r.decision and r.decision['outcome']=='uncertain') for r in rows):
        raise HTTPException(409, 'Review every image and resolve processing errors before approving the batch report')
    if not payload.notes.strip():
        raise HTTPException(422, 'Inspector notes are required')
    report.state = 'approved' if payload.action=='approve' else 'rejected'
    report.decision = {'inspector':user.name or user.email, 'inspector_id':str(user.id), 'notes':payload.notes.strip(),'at':datetime.now(timezone.utc).isoformat()}
    service.record_event(db,user.id,run.id,'inbox','Finalize batch report',report.state)
    await db.commit()
    return {'state':report.state}

@router.get('/batch-reports/{ident}/download')
async def batch_download(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    report = await owned(db, QualityBatchReport, ident, user)
    decision = report.decision or {}
    content = f"STATUS: {report.state.upper()}\n\n" + report.body
    if decision:
        content += f"\n## Report sign-off\nInspector: {decision['inspector']}\n{decision['at']}\n{decision['notes']}\n"
    return Response(content, media_type='text/markdown', headers={'Content-Disposition':f'attachment; filename="batch-{str(report.run_id)[:8]}-{report.state}.md"'})


class RegionInput(BaseModel):
    box: list[float] = Field(min_length=4, max_length=4)
    note: str = Field(min_length=3, max_length=1500)

    @field_validator('box')
    @classmethod
    def validate_region(cls, value):
        if not all(0<=v<=1 for v in value) or value[0]>=value[2] or value[1]>=value[3]:
            raise ValueError('Expected normalized [left, top, right, bottom] coordinates')
        return value

@router.post('/inspections/{ident}/region')
async def save_region(ident: uuid.UUID, payload: RegionInput, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    row = await owned(db, QualityInspection, ident, user, lock=True)
    report = await db.scalar(select(QualityBatchReport).where(QualityBatchReport.run_id == row.run_id))
    if report and report.state != 'draft':
        raise HTTPException(409, 'The batch report has been finalized; its evidence is locked')
    annotation = await db.scalar(select(QualityAnnotation).where(QualityAnnotation.inspection_id == ident))
    if annotation:
        annotation.box, annotation.note = payload.box, payload.note
    else:
        db.add(QualityAnnotation(user_id=user.id,inspection_id=ident,box=payload.box,note=payload.note))
    service.record_event(db,user.id,row.run_id,'inspection','Record inspector-selected region',payload.note)
    await db.commit()
    await service.refresh_batch_report(db,row.run_id)
    return {'saved':True}


@router.get('/defect-guides')
async def defect_guides(user: User = Depends(get_current_user)):
    return GUIDES

@router.post('/inspections/{ident}/recheck', status_code=202)
async def recheck(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    row = await owned(db, QualityInspection, ident, user, lock=True)
    run = await db.get(QualityRun,row.run_id)
    if not settings.openai_api_key and run.mode not in ('assisted','manual'):
        raise HTTPException(409, 'Configure the vision API before rechecking')
    report = await db.scalar(select(QualityBatchReport).where(QualityBatchReport.run_id==row.run_id))
    if (row.decision and row.state!='awaiting_reinspection') or (report and report.state != 'draft'):
        raise HTTPException(409, 'Reviewed or finalized evidence is locked. Create a new inspection batch.')
    if row.state in ('analyzing','loading_saved'):
        raise HTTPException(409, 'This image is already being analyzed')
    db.add(QualityAttempt(user_id=user.id,inspection_id=row.id,previous={'state':row.state,'assessment':row.assessment,'draft':row.draft,'error':row.error,'duration':row.duration,'decision':row.decision}))
    row.state,row.draft,row.assessment,row.error,row.decision = 'analyzing',None,None,None,None
    service.record_event(db,user.id,row.run_id,'inspection','Recheck image','Repeat analysis using the saved product defect guide; prior attempt retained')
    await db.commit()
    await service.refresh_batch_report(db,row.run_id)
    task = asyncio.create_task(service.recheck_inspection(row.id))
    service.workers[row.id]=task
    task.add_done_callback(lambda _: service.workers.pop(ident,None))
    return {'state':'analyzing'}


@router.get('/assets/{ident}/mask')
async def source_mask(ident: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    await owned(db,QualityAsset,ident,user)
    source = await db.scalar(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id==ident,QualitySourceAnnotation.user_id==user.id))
    if not source or not source.mask_path:
        raise HTTPException(404,'No supplied mask')
    with Image.open(source.mask_path) as mask:
        red=Image.new('RGBA',mask.size,(220,45,55,0))
        red.putalpha(mask.convert('RGBA').getchannel('A'))
        buffer=io.BytesIO();red.save(buffer,format='PNG')
    return Response(buffer.getvalue(),media_type='image/png',headers={'Cache-Control':'private, max-age=3600'})


class BulkImageDecision(BaseModel):
    ids: list[uuid.UUID] = Field(min_length=1,max_length=4)
    action: str = Field(pattern='^(approve|reject|rework|reinspect)$')
    notes: str = Field(min_length=3,max_length=3000)

@router.post('/review-selection')
async def review_selection(payload: BulkImageDecision, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if len(set(payload.ids)) != len(payload.ids) or len(payload.notes.strip())<3:
        raise HTTPException(422,'Select distinct images and supply inspector notes')
    rows = list((await db.scalars(select(QualityInspection).where(QualityInspection.id.in_(payload.ids),QualityInspection.user_id==user.id).order_by(QualityInspection.id).with_for_update())).all())
    if len(rows)!=len(payload.ids):
        raise HTTPException(404,'One or more selected images were not found')
    if len({row.run_id for row in rows})!=1:
        raise HTTPException(422,'Select images from the same batch')
    run = await db.get(QualityRun,rows[0].run_id)
    if payload.action == 'approve' and run.mode != 'manual' and any((row.draft or {}).get('product_presence') != 'present' for row in rows):
        raise HTTPException(409,'Cannot bulk-accept images without verified product presence. Recheck or inspect and decide each image individually.')
    if any(row.state!='awaiting_review' for row in rows):
        raise HTTPException(409,'All selected images must be awaiting review; no decisions were changed')
    report=await db.scalar(select(QualityBatchReport).where(QualityBatchReport.run_id==rows[0].run_id))
    if report and report.state!='draft':
        raise HTTPException(409,'This batch report is finalized')
    decision=Decision(action=payload.action,outcome={'approve':'no_defect','reject':'defect','rework':'rework','reinspect':'uncertain'}[payload.action],notes=payload.notes.strip())
    for row in rows:
        await apply_image_decision(db,row,decision,user)
    await db.commit()
    await service.refresh_batch_report(db,rows[0].run_id)
    return {'reviewed':len(rows),'state':rows[0].state}


@router.get('/manager-inboxes')
async def manager_inboxes(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    cases=(await db.scalars(select(QualityReviewCase).where(QualityReviewCase.user_id==user.id).order_by(QualityReviewCase.created_at.desc()))).all()
    return {'groups':GROUPS,'cases':[{'id':str(c.id),'run_id':str(c.run_id),'inspection_id':str(c.inspection_id),'asset_id':str(c.asset_id),'group_key':c.group_key,'issue':c.issue,'summary':c.summary,'state':c.state,'review':c.review,'created_at':c.created_at} for c in cases]}

class CaseUpdate(BaseModel):
    state: str = Field(pattern='^(open|acknowledged|reviewed)$')
    group_key: str | None = None
    notes: str = Field(min_length=3,max_length=1500)

@router.post('/manager-inboxes/{ident}')
async def update_manager_case(ident: uuid.UUID, payload: CaseUpdate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    case=await owned(db,QualityReviewCase,ident,user,lock=True)
    inspection=await db.get(QualityInspection,case.inspection_id)
    if payload.state=='reviewed' and (not inspection.decision or inspection.decision['outcome'] not in ('defect','rework')):
        raise HTTPException(409,'Inspector confirmation is required before completing manager review.')
    if payload.group_key and payload.group_key not in {g['key'] for g in GROUPS}:
        raise HTTPException(422,'Unknown review group')
    if not payload.notes.strip():raise HTTPException(422,'Review notes are required')
    override=bool(payload.group_key and payload.group_key!=case.group_key)
    if payload.group_key:case.group_key=payload.group_key
    case.state=payload.state
    case.review={'group_override':override,'by':user.name or user.email,'user_id':str(user.id),'notes':payload.notes.strip(),'at':datetime.now(timezone.utc).isoformat()}
    service.record_event(db,user.id,case.run_id,'inbox','Update manager review case',payload.state)
    await db.commit()
    return {'state':case.state}
