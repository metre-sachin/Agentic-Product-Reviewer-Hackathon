"""Argus v2 REST surface — config, autofill profile, LLM proxy, bookmarklet.

Everything here reuses the existing env (.env) and auth (Argus JWT). Nothing new
to configure:

- GET  /v2/config                  → model + limits the in-browser agent should use
- GET  /v2/profile?domain=…        → autofill values from the vault ("memory")
- POST /v2/llm/chat/completions    → OpenAI-compatible proxy; the OPENAI_API_KEY
                                     never leaves the server — the in-browser
                                     agent authenticates with the Argus JWT as
                                     its "api key"
- GET  /v2/argus.js                → the built Argus in-page agent bundle
- GET  /v2/bookmarklet             → install page for the Argus bookmarklet
"""

from __future__ import annotations

import logging
import pathlib

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.services import vault_service

log = logging.getLogger(__name__)

router = APIRouter()

OPENAI_BASE = "https://api.openai.com/v1"
# Largest request body the proxy will forward (a full page snapshot + history).
MAX_LLM_BODY_BYTES = 4 * 1024 * 1024
LLM_TIMEOUT_S = 120.0

# Identity kinds the in-browser agent may autofill without asking. OTP and
# CAPTCHA values are deliberately absent — those are always asked for live.
AUTOFILL_KINDS = ("name", "username", "email", "phone", "address", "dob", "card")

_V2_DIST = (
    pathlib.Path(__file__).resolve().parents[3]
    / "v2"
    / "packages"
    / "bookmarklet"
    / "dist"
)


@router.get("/v2/config")
async def v2_config(user: User = Depends(get_current_user)) -> dict:
    """Runtime config for the in-browser agent. Same env as the backend."""
    return {
        "model": settings.openai_model_executor,
        "max_steps": settings.browser_use_max_steps,
        "llm_mocked": settings.llm_mocked,
        "backend_public_url": settings.backend_public_url,
    }


@router.get("/v2/profile")
async def v2_profile(
    domain: str = "",
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Everything Argus may auto-fill from memory for this user.

    Returns the saved identity profile (vault) plus the saved login for the
    given domain. Values are returned to the AUTHENTICATED OWNER's own browser
    over HTTPS — this endpoint is what makes "auto-fill from memory" work.
    """
    identity = await vault_service.identity_for_autofill(db, user.id) or {}
    # Sensible fallbacks so a fresh account can still autofill the basics.
    identity.setdefault("email", user.email or "")
    if getattr(user, "name", None):
        identity.setdefault("name", user.name)
    identity = {k: v for k, v in identity.items() if k in AUTOFILL_KINDS and v}

    login = None
    if domain:
        login = await vault_service.login_for_autofill(db, user.id, domain)

    return {
        "identity": identity,
        "identity_fields": sorted(identity.keys()),
        "login": login,
        "login_available": bool(login),
    }


@router.post("/v2/llm/chat/completions")
async def v2_llm_proxy(
    request: Request,
    user: User = Depends(get_current_user),
) -> JSONResponse:
    """OpenAI-compatible chat-completions proxy for the in-browser agent.

    The page-agent LLM client posts here with `Authorization: Bearer <ArgusJWT>`;
    we swap in the server's OPENAI_API_KEY. Model defaults to the executor model
    from the env when the client doesn't pin one.
    """
    if settings.llm_mocked:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is not configured")

    body_bytes = await request.body()
    if len(body_bytes) > MAX_LLM_BODY_BYTES:
        raise HTTPException(status_code=413, detail="request too large")

    import json

    try:
        body = json.loads(body_bytes)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid JSON body") from exc

    if not isinstance(body, dict) or not body.get("messages"):
        raise HTTPException(status_code=400, detail="messages required")

    body.setdefault("model", settings.openai_model_executor)
    body["stream"] = False  # the in-browser agent uses blocking invocations
    body["user"] = str(user.id)  # per-user attribution in the OpenAI dashboard

    async with httpx.AsyncClient(timeout=LLM_TIMEOUT_S) as client:
        try:
            upstream = await client.post(
                f"{OPENAI_BASE}/chat/completions",
                json=body,
                headers={"Authorization": f"Bearer {settings.openai_api_key}"},
            )
        except httpx.HTTPError as exc:
            log.warning("v2 llm proxy upstream error: %s", exc)
            raise HTTPException(status_code=502, detail="LLM upstream error") from exc

    return JSONResponse(status_code=upstream.status_code, content=upstream.json())


@router.get("/v2/argus.js")
async def v2_agent_bundle() -> FileResponse:
    """Serve the built Argus in-page agent (IIFE bundle) for the bookmarklet."""
    bundle = _V2_DIST / "argus.js"
    if not bundle.exists():
        raise HTTPException(
            status_code=404,
            detail="argus.js not built — run `pnpm build` inside v2/",
        )
    return FileResponse(bundle, media_type="text/javascript")


_BOOKMARKLET_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Argus — bookmarklet</title>
<style>
  body{background:#0B0B0E;color:#F4F4F5;font:16px/1.6 system-ui,sans-serif;
       display:grid;place-items:center;min-height:100vh;margin:0}
  main{max-width:34rem;padding:2rem}
  h1{font-size:1.4rem;letter-spacing:-.02em}
  a.bm{display:inline-block;background:#15151A;border:1px solid rgba(255,255,255,.1);
       padding:.7rem 1.2rem;border-radius:.875rem;color:#F4F4F5;text-decoration:none;
       font-weight:600;cursor:grab}
  input{width:100%;box-sizing:border-box;background:#0E0E12;color:#F4F4F5;
       border:1px solid rgba(255,255,255,.1);border-radius:.5rem;padding:.6rem .8rem;
       margin:.6rem 0;font:inherit}
  p.dim{color:#A1A1A6;font-size:.9rem}
  code{background:#15151A;padding:.1rem .35rem;border-radius:.3rem}
</style></head><body><main>
<h1>👁️ Argus — add to your browser</h1>
<p>Paste your Argus token (Settings → API token, or it auto-fills when you open
this page from the Argus app), then drag the button to your bookmarks bar.
Click it on any page to summon Argus there.</p>
<input id="tok" placeholder="Argus token (JWT)" autocomplete="off">
<p><a class="bm" id="bm" href="#">👁️ Argus</a></p>
<p class="dim">For multi-tab tasks and always-on connection, install the Argus
extension from <code>v2/packages/extension</code> instead.</p>
<script>
  const base = location.origin;
  const tok = document.getElementById('tok');
  const bm = document.getElementById('bm');
  const fromHash = new URLSearchParams(location.hash.slice(1)).get('token');
  if (fromHash) tok.value = fromHash;
  function render() {
    const t = tok.value.trim();
    const code = "(function(){if(window.__ARGUS_V2__){window.__ARGUS_V2__.toggle();return}" +
      "window.__ARGUS_CFG__={backendUrl:" + JSON.stringify(base) + ",token:" + JSON.stringify(t) + "};" +
      "var s=document.createElement('script');s.src=" + JSON.stringify(base + '/v2/argus.js') + ";" +
      "document.documentElement.appendChild(s);})();";
    bm.href = "javascript:" + encodeURIComponent(code);
  }
  tok.addEventListener('input', render); render();
</script>
</main></body></html>"""


@router.get("/v2/bookmarklet")
async def v2_bookmarklet_page() -> HTMLResponse:
    """Self-contained install page for the Argus bookmarklet."""
    return HTMLResponse(_BOOKMARKLET_HTML)
