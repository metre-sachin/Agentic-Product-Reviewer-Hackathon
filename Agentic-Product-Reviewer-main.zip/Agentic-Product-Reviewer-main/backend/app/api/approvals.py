from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import User
from app.schemas.approvals import PendingApprovalOut
from app.services import approval_service

router = APIRouter()


@router.get("/pending", response_model=list[PendingApprovalOut])
async def list_pending(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[PendingApprovalOut]:
    rows = await approval_service.list_for_user(db, user)
    return [PendingApprovalOut(**r) for r in rows]
