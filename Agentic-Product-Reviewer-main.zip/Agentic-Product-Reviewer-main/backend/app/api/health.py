from fastapi import APIRouter

from app.core.config import settings

router = APIRouter()


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


def _module_available(name: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(name) is not None
    except Exception:  # noqa: BLE001
        return False


def _chromium_installed() -> bool:
    """True only when both the playwright package AND a chromium binary exist."""
    if not _module_available("playwright"):
        return False
    import pathlib

    for base in (
        pathlib.Path.home() / "Library/Caches/ms-playwright",  # macOS
        pathlib.Path.home() / ".cache/ms-playwright",  # Linux
    ):
        if base.exists() and any(base.glob("chromium-*")):
            return True
    return False


@router.get("/health/capabilities")
async def capabilities() -> dict[str, object]:
    """Report which execution layers can actually run right now.

    Handy for the demo + debugging: shows whether the LLM key is set and which
    browser/scraping libraries are importable.
    """
    llm = bool(settings.openai_api_key)
    chromium = _chromium_installed()
    return {
        "llm": llm,
        "layers": {
            "scrapling": settings.enable_scrapling and _module_available("scrapling"),
            "agent_browser": settings.enable_agent_browser and chromium,
            "browser_use": settings.enable_browser_use and llm and _module_available("browser_use"),
            "vision": settings.enable_vision and llm and chromium,
            "human": True,
        },
        "models": {
            "planner": settings.openai_model_planner,
            "executor": settings.openai_model_executor,
            "vision": settings.openai_model_vision,
            "embedding": settings.openai_model_embedding,
        },
    }
