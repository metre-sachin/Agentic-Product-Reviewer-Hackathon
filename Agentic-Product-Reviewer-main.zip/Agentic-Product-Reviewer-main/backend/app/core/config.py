from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file="../.env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    database_url: str = Field(default="postgresql+asyncpg://argus:argus_dev@localhost:5432/argus")
    redis_url: str = Field(default="redis://localhost:6379/0")

    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    backend_public_url: str = "http://localhost:8000"
    frontend_origin: str = "http://localhost:3000"

    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_expires_minutes: int = 10080

    vault_encryption_key: str = "change-me-32-bytes-base64-fernet-key"

    openai_api_key: str = ""
    openai_model_planner: str = "gpt-4o-mini"
    openai_model_vision: str = "gpt-4o-mini"
    openai_model_executor: str = "gpt-4o-mini"
    openai_model_embedding: str = "text-embedding-3-small"
    browser_use_api_key: str = ""
    browser_use_model: str = "gpt-4o"

    enable_scrapling: bool = True
    enable_agent_browser: bool = True
    # Browser Use launches its own separate browser and is less accurate on
    # structured portals than the Agent Browser driving our shared connected
    # browser. Off by default — opt in (ideally with a CDP URL to your own
    # browser) when you want the autonomous layer.
    enable_browser_use: bool = False
    enable_vision: bool = True

    # Browser automation
    browser_headless: bool = True
    # Real Chrome evades bot-detection (Cloudflare etc.) far better than bundled
    # chromium. Falls back to chromium automatically if the channel is missing.
    # Set to "" to force bundled chromium.
    browser_channel: str = "chrome"
    browser_locale: str = "en-US"
    browser_timezone: str = "Asia/Kolkata"
    # Optional proxy for sites that block by IP reputation (datacenter/VPN IPs).
    # e.g. "http://user:pass@host:port" or "socks5://host:port". Empty = direct.
    browser_proxy: str = ""
    # Optional connection to an already-running Chrome/Browser Use browser:
    # e.g. http://localhost:9222. Empty means Argus/Browser Use launches one.
    browser_use_cdp_url: str = ""
    browser_use_system_chrome: bool = False
    browser_chrome_profile: str = ""
    browser_use_captcha_solver: bool = True
    browser_use_max_steps: int = 40
    captcha_autosolve: bool = True
    manual_assist_enabled: bool = True
    media_dir: str = ".media"

    @property
    def llm_mocked(self) -> bool:
        return not self.openai_api_key

    @property
    def media_path(self):
        import pathlib

        p = pathlib.Path(self.media_dir)
        if not p.is_absolute():
            p = pathlib.Path(__file__).resolve().parents[2] / self.media_dir
        p.mkdir(parents=True, exist_ok=True)
        return p

    def screenshot_url(self, task_id: str, filename: str) -> str:
        return f"{self.backend_public_url}/media/{task_id}/{filename}"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
