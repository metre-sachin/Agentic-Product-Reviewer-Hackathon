"""Symmetric encryption for the credential vault.

Vault entries (logins, personal identity, cards) are stored as Fernet-encrypted
JSON blobs — the database only ever holds ciphertext. The key comes from
`settings.vault_encryption_key`. A real url-safe base64 32-byte Fernet key is used
as-is; any other string is deterministically stretched into one so the app works
out of the box in dev. Rotating the key invalidates everything already stored.
"""

from __future__ import annotations

import base64
import hashlib
import json
from functools import lru_cache
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import settings


@lru_cache(maxsize=1)
def _fernet() -> Fernet:
    raw = (settings.vault_encryption_key or "argus-dev-vault-key").encode("utf-8")
    try:
        # Accept a properly-formatted Fernet key verbatim.
        return Fernet(raw)
    except (ValueError, TypeError):
        # Otherwise derive a stable 32-byte key from whatever was configured.
        digest = hashlib.sha256(raw).digest()
        return Fernet(base64.urlsafe_b64encode(digest))


def encrypt_json(data: dict[str, Any]) -> bytes:
    """Encrypt a JSON-serialisable dict to a Fernet token (bytes)."""
    payload = json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return _fernet().encrypt(payload)


def decrypt_json(blob: bytes | memoryview | None) -> dict[str, Any]:
    """Decrypt a Fernet token back to a dict. Returns {} on tamper/garbage so a
    corrupt or key-rotated entry degrades gracefully instead of crashing a task."""
    if not blob:
        return {}
    try:
        plain = _fernet().decrypt(bytes(blob))
        data = json.loads(plain.decode("utf-8"))
        return data if isinstance(data, dict) else {}
    except (InvalidToken, ValueError, TypeError):
        return {}
