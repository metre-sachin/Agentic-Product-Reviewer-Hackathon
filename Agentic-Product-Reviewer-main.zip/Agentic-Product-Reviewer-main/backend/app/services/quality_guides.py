"""Product knowledge supplied before inspection, never per-image answer labels."""
GUIDES = {
    'Tile': {
        'crack':'A narrow fracture or split that interrupts the tile surface. Distinguish it from normal printed veins and lighting.',
        'oil_contamination':'A possible localized oily-looking stain, pooled patch, or changed sheen. Describe visual contamination; a photograph cannot confirm oil chemistry.',
        'rough_surface':'A localized change in surface texture relative to good references. Uniform speckling, pores, and designed texture can be normal.',
        'scratch':'A thin abrasion or scraped line distinct from the normal surface pattern.',
        'foreign_material':'An extra object or residue visibly lying on the surface.'
    },
    'Wood': {
        'crack':'A split or fissure distinct from continuous normal grain.',
        'hole':'An opening or missing material inconsistent with normal knots and reference samples.',
        'scratch':'An abrasion that disrupts the grain or finish.',
        'rough_surface':'Localized torn fibers, splinters, or disrupted finish; natural grain alone is not a defect.',
        'liquid_contamination':'A localized stain or wet-looking area. Do not infer the liquid or its cause from appearance alone.'
    },
    'Transistor': {
        'bent_lead':'A lead that deviates substantially from the known-good geometry.',
        'broken_lead':'A visibly missing, severed, or shortened lead.',
        'damaged_case':'A cracked or chipped housing, distinguished from normal printed markings.',
        'misplaced_part':'An observable assembly position inconsistent with the reference.',
        'surface_contamination':'Unexpected residue or material on the component.'
    }
}

def guide_for(product, selected=None, notes=''):
    guide = GUIDES.get(product, {})
    checks = selected or list(guide)
    lines = [f'{name.replace("_"," ")}: {guide[name]}' for name in checks if name in guide]
    return 'INSPECTION KNOWLEDGE — these are possibilities, NOT labels for this image. Do not force a match.\n' + '\n'.join(lines) + '\nInspector context: ' + (notes or 'None supplied')
