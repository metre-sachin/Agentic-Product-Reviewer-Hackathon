"""Task business logic. Phase 3 adds queue dispatch + planner trigger."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import Task, TaskAction, TaskLog, TaskStep, User
from app.schemas.tasks import (
    TaskActionOut,
    TaskCreateRequest,
    TaskDetailOut,
    TaskLogOut,
    TaskOut,
    TaskStepOut,
)
from app.services import recurring_service
from app.services.event_bus import bus


ACTIVE_STATES = {
    "created",
    "planning",
    "executing",
    "recovering",
    "waiting_for_user",
    "waiting_for_approval",
}


def _title_from_goal(goal: str) -> str:
    s = goal.strip().rstrip(".")
    return s[:80] + ("…" if len(s) > 80 else "")


def _to_out(task: Task) -> TaskOut:
    return TaskOut(
        id=str(task.id),
        title=task.title,
        goal=task.goal,
        state=task.state,
        intent=task.intent or {},
        result=task.result,
        error=task.error,
        started_at=task.started_at,
        completed_at=task.completed_at,
        created_at=task.created_at,
        updated_at=task.updated_at,
    )


def _step_out(step: TaskStep) -> TaskStepOut:
    return TaskStepOut(
        id=str(step.id),
        ordinal=step.ordinal,
        label=step.label,
        meta=step.meta,
        state=step.state,
        layer_used=step.layer_used,
        attempts=step.attempts,
    )


def _log_out(log: TaskLog) -> TaskLogOut:
    return TaskLogOut(
        id=log.id,
        level=log.level,
        layer=log.layer,
        text=log.text,
        detail=log.detail,
        at=log.at,
    )


def _action_out(action: TaskAction) -> TaskActionOut:
    return TaskActionOut(
        id=action.id,
        ordinal=action.ordinal,
        kind=action.kind,
        target=action.target,
        value=action.value,
        url=action.url,
        screenshot_url=action.screenshot_url,
        ok=action.ok,
        at=action.at,
    )


async def list_for_user(db: AsyncSession, user: User, limit: int = 50) -> list[TaskOut]:
    result = await db.execute(
        select(Task)
        .where(Task.user_id == user.id)
        .order_by(Task.created_at.desc())
        .limit(limit)
    )
    return [_to_out(t) for t in result.scalars().all()]


async def create_for_user(
    db: AsyncSession, user: User, payload: TaskCreateRequest
) -> TaskOut:
    task = Task(
        user_id=user.id,
        title=payload.title or _title_from_goal(payload.goal),
        goal=payload.goal.strip(),
        state="created",
        intent={},
    )
    db.add(task)
    await db.flush()
    db.add(
        TaskLog(
            task_id=task.id,
            level="milestone",
            text="Task created",
            detail=payload.goal.strip()[:200],
        )
    )
    await recurring_service.create_schedule_for_task(db, user, task, payload.repeat)
    await db.commit()
    await db.refresh(task)
    return _to_out(task)


async def _get_owned(db: AsyncSession, user: User, task_id: str) -> Task:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc

    result = await db.execute(
        select(Task)
        .where(Task.id == tid, Task.user_id == user.id)
        .options(
            selectinload(Task.steps),
            selectinload(Task.logs),
            selectinload(Task.actions),
        )
    )
    task = result.scalar_one_or_none()
    if task is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="task not found")
    return task


def _screenshots_for(task_id) -> list[str]:
    from app.core.config import settings

    d = settings.media_path / str(task_id)
    if not d.exists():
        return []
    files = sorted(d.glob("*.png"))
    return [settings.screenshot_url(str(task_id), f.name) for f in files]


async def get_detail(db: AsyncSession, user: User, task_id: str) -> TaskDetailOut:
    task = await _get_owned(db, user, task_id)
    shots = _screenshots_for(task.id)
    from app.services import runtime

    return TaskDetailOut(
        **_to_out(task).model_dump(),
        steps=[_step_out(s) for s in task.steps],
        logs=[_log_out(log) for log in task.logs],
        actions=[_action_out(a) for a in task.actions],
        screenshots=shots,
        last_screenshot_url=shots[-1] if shots else None,
        pending_input=runtime.pending_prompt(task.id),
    )


async def cancel(db: AsyncSession, user: User, task_id: str) -> TaskOut:
    task = await _get_owned(db, user, task_id)
    if task.state in ("completed", "failed", "cancelled"):
        return _to_out(task)
    task.state = "cancelled"
    task.completed_at = datetime.now(timezone.utc)
    db.add(TaskLog(task_id=task.id, level="warn", text="Task cancelled by user"))
    await db.commit()
    await db.refresh(task)
    # Unblock the runtime if it's parked waiting for approval or human input.
    from app.services import runtime

    runtime.cancel_task(task.id)
    return _to_out(task)


async def pause(db: AsyncSession, user: User, task_id: str) -> TaskOut:
    task = await _get_owned(db, user, task_id)
    if task.state not in ACTIVE_STATES:
        return _to_out(task)
    task.state = "paused"
    db.add(TaskLog(task_id=task.id, level="warn", layer="human", text="Task paused"))
    await db.commit()
    await db.refresh(task)

    from app.services import runtime

    runtime.pause_task(task.id)
    await bus.publish(
        str(task.id),
        {
            "kind": "state",
            "payload": {"state": "paused"},
            "at": datetime.now(timezone.utc).isoformat(),
        },
    )
    return _to_out(task)


async def resume(db: AsyncSession, user: User, task_id: str) -> TaskOut:
    task = await _get_owned(db, user, task_id)
    if task.state != "paused":
        return _to_out(task)
    task.state = "executing"
    db.add(TaskLog(task_id=task.id, level="info", layer="human", text="Task resumed"))
    await db.commit()
    await db.refresh(task)

    from app.services import runtime

    runtime.resume_task(task.id)
    await bus.publish(
        str(task.id),
        {
            "kind": "state",
            "payload": {"state": "executing"},
            "at": datetime.now(timezone.utc).isoformat(),
        },
    )
    return _to_out(task)


async def list_logs(db: AsyncSession, user: User, task_id: str) -> list[TaskLogOut]:
    task = await _get_owned(db, user, task_id)
    return [_log_out(log) for log in task.logs]
