"""Internal, role-based group inboxes. Routing does not email or impersonate a manager."""
from sqlalchemy import select
from app.models.quality import QualityReviewCase, QualitySourceAnnotation, QualityRun

GROUPS = [
 {'key':'contamination','name':'Oil & contamination','role':'Contamination lead','initials':'OC'},
 {'key':'cracks','name':'Cracks & fractures','role':'Structural quality lead','initials':'CR'},
 {'key':'surface','name':'Surface finish','role':'Surface quality lead','initials':'SF'},
 {'key':'components','name':'Components','role':'Electronics quality lead','initials':'EC'},
 {'key':'general','name':'General review','role':'Batch manager','initials':'BM'},
]

def choose_group(text):
    import re
    words=set(re.findall(r'[a-z]+',text.lower()))
    if words & {'oil','oily','liquid','contamination','contaminated','stain','stains','residue'}:return 'contamination'
    if words & {'crack','cracks','cracked','fracture','fractures','split'}:return 'cracks'
    if words & {'rough','scratch','scratches','scratched','abrasion','finish'}:return 'surface'
    if words & {'lead','leads','pin','pins','transistor','component','housing','case','missing'}:return 'components'
    return 'general'

async def route_decision(db,row):
    existing=await db.scalar(select(QualityReviewCase).where(QualityReviewCase.inspection_id==row.id))
    if not row.decision or row.decision['outcome'] not in ('defect','rework'):
        if existing:existing.state='withdrawn'
        return
    run=await db.get(QualityRun,row.run_id)
    source=await db.scalar(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id==row.asset_id)) if run.mode=='assisted' else None
    findings=(row.draft or {}).get('findings',[])
    issue=', '.join(f['title'] for f in findings) or (source.label.replace('_',' ') if source else 'Defect confirmed by inspector')
    # Use explicit issue titles and provided labels, not free-form negative disclaimers.
    key=choose_group(issue+' '+(source.label.replace('_',' ') if source else ''))
    summary=row.decision['notes'][:1500]
    if existing:
        if existing.review and existing.review.get('group_override'):key=existing.group_key
        existing.group_key,existing.issue,existing.summary,existing.state=key,issue,summary,'open'
    else:
        db.add(QualityReviewCase(user_id=row.user_id,run_id=row.run_id,inspection_id=row.id,asset_id=row.asset_id,group_key=key,issue=issue,summary=summary))

async def route_completed_group(db,run_id,sequence):
    from app.models.quality import QualityInspection
    # Serialize group repair and the worker's handoff so a case is inserted once.
    run=await db.scalar(select(QualityRun).where(QualityRun.id==run_id).with_for_update())
    first=((sequence-1)//4)*4+1
    expected=min(4,len(run.assets)-first+1)
    rows=list((await db.scalars(select(QualityInspection).where(QualityInspection.run_id==run_id,QualityInspection.sequence>=first,QualityInspection.sequence<first+4))).all())
    if len(rows)!=expected or any(r.state in ('analyzing','loading_saved') for r in rows):return
    for row in rows:
        if await db.scalar(select(QualityReviewCase.id).where(QualityReviewCase.inspection_id==row.id)):continue
        source=await db.scalar(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id==row.asset_id)) if run.mode=='assisted' else None
        if row.assessment!='possible_defect' and not (source and source.label!='good'):continue
        if row.decision:
            await route_decision(db,row)
            continue
        findings=(row.draft or {}).get('findings',[])
        issue=', '.join(f['title'] for f in findings) or (source.label.replace('_',' ') if source else 'Suspected defect')
        summary=(row.draft or {}).get('summary') or 'Source annotation requires review.'
        db.add(QualityReviewCase(user_id=row.user_id,run_id=run_id,inspection_id=row.id,asset_id=row.asset_id,group_key=choose_group(issue+' '+(source.label if source else '')),issue=issue,summary=summary[:1500],state='awaiting_approval'))
