"""Embedding helpers for memory retrieval.

Vectors are stored as packed float32 bytes in `memories.embedding`. Cosine
similarity is computed in pure Python (vectors are small, retrieval sets tiny),
so there's no numpy/pgvector dependency for the MVP.
"""

from __future__ import annotations

import array
import logging
import math

from app.core.config import settings

log = logging.getLogger(__name__)


def serialize(vec: list[float]) -> bytes:
    return array.array("f", vec).tobytes()


def deserialize(blob: bytes | None) -> list[float]:
    if not blob:
        return []
    a = array.array("f")
    a.frombytes(blob)
    return list(a)


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


async def embed_text(text: str) -> list[float] | None:
    """Return an embedding for `text`, or None if embeddings aren't configured."""
    if not settings.openai_api_key:
        return None
    try:
        from app.services.llm import get_client

        client = get_client()
        resp = await client.embeddings.create(
            model=settings.openai_model_embedding, input=text[:8000]
        )
        return list(resp.data[0].embedding)
    except Exception as exc:  # noqa: BLE001
        log.warning("embedding failed: %s", exc)
        return None
