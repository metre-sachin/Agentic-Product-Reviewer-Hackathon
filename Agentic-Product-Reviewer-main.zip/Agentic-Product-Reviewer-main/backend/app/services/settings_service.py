from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import User, UserSettings
from app.schemas.settings import SettingsOut, SettingsUpdate
from app.services.auth_service import DEFAULT_APPROVAL_RULES


def _to_out(s: UserSettings) -> SettingsOut:
    return SettingsOut(
        approval_rules=s.approval_rules or {},
        browser_mode=s.browser_mode,
        browser_headless=s.browser_headless,
        preferred_model=s.preferred_model,
        browser_cdp_url=s.browser_cdp_url,
        browser_use_system_chrome=s.browser_use_system_chrome,
        browser_chrome_profile=s.browser_chrome_profile,
        browser_use_model=s.browser_use_model,
        browser_use_captcha_solver=s.browser_use_captcha_solver,
        captcha_autosolve=s.captcha_autosolve,
        manual_assist_enabled=s.manual_assist_enabled,
        autofill_enabled=s.autofill_enabled,
        auto_learn_enabled=s.auto_learn_enabled,
    )


async def _get_or_create(db: AsyncSession, user: User) -> UserSettings:
    result = await db.execute(select(UserSettings).where(UserSettings.user_id == user.id))
    settings = result.scalar_one_or_none()
    if settings is None:
        settings = UserSettings(
            user_id=user.id,
            approval_rules=DEFAULT_APPROVAL_RULES,
            browser_mode="browser",
            preferred_model="gpt-4o",
            browser_use_model="gpt-4o",
            browser_use_captcha_solver=True,
            captcha_autosolve=True,
            manual_assist_enabled=True,
        )
        db.add(settings)
        await db.commit()
        await db.refresh(settings)
    return settings


async def get_for_user(db: AsyncSession, user: User) -> SettingsOut:
    return _to_out(await _get_or_create(db, user))


async def update_for_user(
    db: AsyncSession, user: User, payload: SettingsUpdate
) -> SettingsOut:
    settings = await _get_or_create(db, user)
    if payload.approval_rules is not None:
        settings.approval_rules = payload.approval_rules
    if payload.browser_mode is not None:
        settings.browser_mode = payload.browser_mode
    if payload.browser_headless is not None:
        settings.browser_headless = payload.browser_headless
    if payload.preferred_model is not None:
        settings.preferred_model = payload.preferred_model
    if payload.browser_cdp_url is not None:
        settings.browser_cdp_url = payload.browser_cdp_url.strip() or None
    if payload.browser_use_system_chrome is not None:
        settings.browser_use_system_chrome = payload.browser_use_system_chrome
    if payload.browser_chrome_profile is not None:
        settings.browser_chrome_profile = payload.browser_chrome_profile.strip() or None
    if payload.browser_use_model is not None:
        settings.browser_use_model = payload.browser_use_model.strip() or "gpt-4o"
    if payload.browser_use_captcha_solver is not None:
        settings.browser_use_captcha_solver = payload.browser_use_captcha_solver
    if payload.captcha_autosolve is not None:
        settings.captcha_autosolve = payload.captcha_autosolve
    if payload.manual_assist_enabled is not None:
        settings.manual_assist_enabled = payload.manual_assist_enabled
    if payload.autofill_enabled is not None:
        settings.autofill_enabled = payload.autofill_enabled
    if payload.auto_learn_enabled is not None:
        settings.auto_learn_enabled = payload.auto_learn_enabled
    await db.commit()
    await db.refresh(settings)
    return _to_out(settings)
