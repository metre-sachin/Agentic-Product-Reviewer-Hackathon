"""Auth business logic."""

from __future__ import annotations

import httpx
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import create_access_token, hash_password, verify_password
from app.models import User, UserSettings
from app.schemas.auth import (
    GoogleAuthRequest,
    LoginRequest,
    SignupRequest,
    TokenResponse,
    UserPublic,
)

GOOGLE_TOKENINFO_URL = "https://oauth2.googleapis.com/tokeninfo"

DEFAULT_APPROVAL_RULES = {
    "payment": True,
    "identity": True,
    "spend_over": 500,
    "post_on_behalf": False,
    "new_site": True,
}


def _to_public(user: User) -> UserPublic:
    return UserPublic(
        id=str(user.id),
        email=user.email,
        name=user.name,
        avatar_url=user.avatar_url,
        email_verified=user.email_verified,
    )


def _issue(user: User) -> TokenResponse:
    token = create_access_token(subject=str(user.id), extra={"email": user.email})
    return TokenResponse(access_token=token, user=_to_public(user))


async def _ensure_default_settings(db: AsyncSession, user: User) -> None:
    result = await db.execute(select(UserSettings).where(UserSettings.user_id == user.id))
    if result.scalar_one_or_none() is None:
        db.add(
            UserSettings(
                user_id=user.id,
                approval_rules=DEFAULT_APPROVAL_RULES,
                browser_mode="browser",
                preferred_model="gpt-4o",
                browser_use_model="gpt-4o",
                browser_use_captcha_solver=True,
                captcha_autosolve=True,
                manual_assist_enabled=True,
            )
        )


async def signup(db: AsyncSession, payload: SignupRequest) -> TokenResponse:
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="email already registered")

    user = User(
        email=payload.email,
        name=payload.name,
        password_hash=hash_password(payload.password),
        email_verified=False,
    )
    db.add(user)
    await db.flush()
    await _ensure_default_settings(db, user)
    await db.commit()
    await db.refresh(user)
    return _issue(user)


async def login(db: AsyncSession, payload: LoginRequest) -> TokenResponse:
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()
    if user is None or not user.password_hash:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid credentials"
        )
    if not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid credentials"
        )
    return _issue(user)


async def google_auth(db: AsyncSession, payload: GoogleAuthRequest) -> TokenResponse:
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(GOOGLE_TOKENINFO_URL, params={"id_token": payload.id_token})

    if resp.status_code != 200:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid google id_token"
        )
    info = resp.json()
    google_id = info.get("sub")
    email = info.get("email")
    if not google_id or not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="google token missing claims"
        )

    result = await db.execute(select(User).where(User.google_id == google_id))
    user = result.scalar_one_or_none()
    if user is None:
        # Link to existing email-based account if present.
        result = await db.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()
        if user is None:
            user = User(
                email=email,
                name=info.get("name"),
                avatar_url=info.get("picture"),
                google_id=google_id,
                email_verified=info.get("email_verified") in ("true", True),
            )
            db.add(user)
            await db.flush()
            await _ensure_default_settings(db, user)
        else:
            user.google_id = google_id
            if not user.avatar_url:
                user.avatar_url = info.get("picture")
            user.email_verified = True

    await db.commit()
    await db.refresh(user)
    return _issue(user)
