from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import ConnectedSite, User
from app.schemas.connected_sites import (
    ConnectedSiteCreate,
    ConnectedSiteOut,
    ConnectedSiteUpdate,
)


def _to_out(s: ConnectedSite) -> ConnectedSiteOut:
    return ConnectedSiteOut(
        id=str(s.id),
        domain=s.domain,
        display_name=s.display_name,
        status=s.status,
        scopes=s.scopes or [],
        has_session=s.storage_state is not None,
        last_used_at=s.last_used_at,
        created_at=s.created_at,
    )


async def list_for_user(db: AsyncSession, user: User) -> list[ConnectedSiteOut]:
    result = await db.execute(
        select(ConnectedSite)
        .where(ConnectedSite.user_id == user.id)
        .order_by(ConnectedSite.created_at.desc())
    )
    return [_to_out(s) for s in result.scalars().all()]


async def create(
    db: AsyncSession, user: User, payload: ConnectedSiteCreate
) -> ConnectedSiteOut:
    domain = payload.domain.strip().lower()
    exists = await db.execute(
        select(ConnectedSite).where(
            ConnectedSite.user_id == user.id, ConnectedSite.domain == domain
        )
    )
    if exists.scalar_one_or_none() is not None:
        raise HTTPException(status_code=409, detail="site already connected")
    site = ConnectedSite(
        user_id=user.id,
        domain=domain,
        display_name=payload.display_name,
        scopes=payload.scopes,
        status="live",
    )
    db.add(site)
    await db.commit()
    await db.refresh(site)
    return _to_out(site)


async def update(
    db: AsyncSession, user: User, site_id: str, payload: ConnectedSiteUpdate
) -> ConnectedSiteOut:
    site = await _get_owned(db, user, site_id)
    if payload.status is not None:
        site.status = payload.status
    if payload.display_name is not None:
        site.display_name = payload.display_name
    if payload.scopes is not None:
        site.scopes = payload.scopes
    await db.commit()
    await db.refresh(site)
    return _to_out(site)


async def delete(db: AsyncSession, user: User, site_id: str) -> None:
    site = await _get_owned(db, user, site_id)
    await db.delete(site)
    await db.commit()


async def get_storage_state(
    db: AsyncSession, user_id: uuid.UUID, domain: str
) -> dict | None:
    """Return the saved Playwright storage state for a user's domain, if any."""
    result = await db.execute(
        select(ConnectedSite).where(
            ConnectedSite.user_id == user_id,
            ConnectedSite.domain == domain.strip().lower(),
        )
    )
    site = result.scalar_one_or_none()
    return site.storage_state if site is not None else None


async def save_session(
    db: AsyncSession, user_id: uuid.UUID, domain: str, storage_state: dict
) -> None:
    """Persist a login session against a connected site, creating the row if the
    site hasn't been connected before. Storage state is cookies + localStorage —
    it is the user's live session, so treat it like a credential.
    """
    domain = domain.strip().lower()
    result = await db.execute(
        select(ConnectedSite).where(
            ConnectedSite.user_id == user_id, ConnectedSite.domain == domain
        )
    )
    site = result.scalar_one_or_none()
    now = datetime.now(timezone.utc)
    if site is None:
        site = ConnectedSite(
            user_id=user_id,
            domain=domain,
            display_name=domain,
            status="live",
            scopes=[],
            storage_state=storage_state,
            last_used_at=now,
        )
        db.add(site)
    else:
        site.storage_state = storage_state
        site.status = "live"
        site.last_used_at = now
    await db.commit()


async def _get_owned(db: AsyncSession, user: User, site_id: str) -> ConnectedSite:
    try:
        sid = uuid.UUID(site_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid site id") from exc
    site = await db.get(ConnectedSite, sid)
    if site is None or site.user_id != user.id:
        raise HTTPException(status_code=404, detail="site not found")
    return site
