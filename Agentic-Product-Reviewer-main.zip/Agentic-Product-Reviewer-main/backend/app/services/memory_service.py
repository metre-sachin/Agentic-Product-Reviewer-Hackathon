from __future__ import annotations

import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Memory, User
from app.schemas.memories import MemoryCreate, MemoryOut
from app.services.embeddings import embed_text, serialize


def _to_out(m: Memory) -> MemoryOut:
    return MemoryOut(
        id=str(m.id),
        tag=m.tag,
        text=m.text,
        created_at=m.created_at,
        updated_at=m.updated_at,
    )


async def list_for_user(db: AsyncSession, user: User) -> list[MemoryOut]:
    result = await db.execute(
        select(Memory).where(Memory.user_id == user.id).order_by(Memory.created_at.desc())
    )
    return [_to_out(m) for m in result.scalars().all()]


async def create(db: AsyncSession, user: User, payload: MemoryCreate) -> MemoryOut:
    tag = payload.tag.upper().strip()
    text = payload.text.strip()
    vec = await embed_text(f"{tag}: {text}")
    memory = Memory(
        user_id=user.id,
        tag=tag,
        text=text,
        embedding=serialize(vec) if vec else None,
    )
    db.add(memory)
    await db.commit()
    await db.refresh(memory)
    return _to_out(memory)


async def delete(db: AsyncSession, user: User, memory_id: str) -> None:
    try:
        mid = uuid.UUID(memory_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid memory id") from exc
    memory = await db.get(Memory, mid)
    if memory is None or memory.user_id != user.id:
        raise HTTPException(status_code=404, detail="memory not found")
    await db.delete(memory)
    await db.commit()
