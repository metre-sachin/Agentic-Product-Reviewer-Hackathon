"""Post-task feedback + opt-in learning into memory."""

from __future__ import annotations

import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Task, TaskFeedback, TaskLog, User, UserSettings
from app.schemas.tasks import FeedbackRequest
from app.services import learning_service


async def create(
    db: AsyncSession, user: User, task_id: str, payload: FeedbackRequest
) -> dict:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    task = await db.get(Task, tid)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=404, detail="task not found")

    text = payload.text.strip() if payload.text else None
    db.add(TaskFeedback(task_id=task.id, user_id=user.id, rating=payload.rating, text=text))
    note = " · ".join(
        p for p in [
            f"{payload.rating}/5" if payload.rating is not None else "",
            text or "",
        ] if p
    )
    db.add(
        TaskLog(
            task_id=task.id,
            level="info",
            layer="feedback",
            text="Thanks — feedback received",
            detail=note[:200] or None,
        )
    )
    await db.commit()

    learned = 0
    if await _auto_learn_enabled(db, user.id):
        observations = list((task.result or {}).get("observations") or [])
        learned = await learning_service.learn_from_task(
            db, user.id, task.goal, observations, feedback=text
        )
    return {"ok": True, "learned": learned}


async def _auto_learn_enabled(db: AsyncSession, user_id: uuid.UUID) -> bool:
    result = await db.execute(
        select(UserSettings.auto_learn_enabled).where(UserSettings.user_id == user_id)
    )
    value = result.scalar_one_or_none()
    return True if value is None else bool(value)
