"""OpenAI client + structured prompts shared across agents."""

from __future__ import annotations

import json
from typing import Any

from openai import AsyncOpenAI

from app.core.config import settings


class LLMNotConfigured(RuntimeError):
    pass


_client: AsyncOpenAI | None = None


def get_client() -> AsyncOpenAI:
    global _client
    if not settings.openai_api_key:
        raise LLMNotConfigured(
            "OPENAI_API_KEY is not set. Add it to .env to enable the planner."
        )
    if _client is None:
        _client = AsyncOpenAI(api_key=settings.openai_api_key)
    return _client


async def complete_json(
    *,
    system: str,
    user: str,
    model: str | None = None,
    temperature: float = 0.2,
    max_tokens: int = 2000,
) -> dict[str, Any]:
    """Call chat.completions with JSON mode and return the parsed dict."""
    client = get_client()
    response = await client.chat.completions.create(
        model=model or settings.openai_model_planner,
        temperature=temperature,
        max_tokens=max_tokens,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"model returned invalid JSON: {content[:200]}") from exc


async def complete_json_vision(
    *,
    system: str,
    user: str,
    image_b64: str,
    reference_images: list[str] | None = None,
    model: str | None = None,
    temperature: float = 0.1,
    max_tokens: int = 500,
) -> dict[str, Any]:
    """Vision call: text + a base64 PNG, returns parsed JSON."""
    client = get_client()
    content_blocks = []
    for reference in reference_images or []:
        content_blocks.extend([{"type":"text","text":"Known-good reference image for comparison only. Inspect the separate target image below."}, {"type":"image_url","image_url":{"url":f"data:image/png;base64,{reference}","detail":"high"}}])
    content_blocks.extend([{"type":"text","text":user + "\nTARGET IMAGE TO INSPECT:"}, {"type":"image_url","image_url":{"url":f"data:image/png;base64,{image_b64}","detail":"high"}}])
    response = await client.chat.completions.create(
        model=model or settings.openai_model_vision,
        temperature=temperature,
        max_tokens=max_tokens,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": content_blocks,
            },
        ],
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"vision model returned invalid JSON: {content[:200]}") from exc
