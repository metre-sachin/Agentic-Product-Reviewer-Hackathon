"""Database-backed inspection runner. A single backend owns execution for the prototype."""
import asyncio
import base64
import logging
import time
import uuid
from datetime import datetime, timezone, timedelta
from typing import Literal
from pydantic import BaseModel, Field, model_validator, field_validator
from app.services.quality_guides import guide_for
from app.services.quality_routing import route_completed_group
from sqlalchemy import select, update, func
from app.db.session import SessionLocal, engine
from app.models.quality import QualityAsset, QualityRun, QualityInspection, QualityReport, QualityOperation, QualityEvent, QualityBatchReport, QualityAnnotation, QualityRunContext, QualityAttempt, QualitySourceAnnotation, QualityAnalysisCache, QualityReviewCase, QualityStream
from app.core.config import settings
from app.services.llm import complete_json_vision

log = logging.getLogger(__name__)
workers: dict[uuid.UUID, asyncio.Task] = {}
STREAM_GROUP_INTERVAL = 10.0
CACHE_PRESENTATION_DELAY = 1.0

class Finding(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    evidence: str = Field(min_length=1, max_length=1500)
    severity: Literal['low', 'medium', 'high']
    box: list[float] | None = None

    @field_validator('box', mode='before')
    @classmethod
    def parse_optional_box(cls, value):
        if value is None:
            return None
        if not isinstance(value,list) or len(value)!=4 or any(not isinstance(n,(int,float)) or isinstance(n,bool) for n in value):
            return None
        return value

    @model_validator(mode='after')
    def valid_box(self):
        if self.box is not None:
            if len(self.box) != 4 or not all(0 <= n <= 1 for n in self.box):
                self.box = None
                return self
            x1, y1, x2, y2 = self.box
            if x1 >= x2 or y1 >= y2:
                self.box = None
        return self

class Analysis(BaseModel):
    assessment: Literal['possible_defect', 'no_visible_defect', 'uncertain']
    summary: str = Field(min_length=1, max_length=2000)
    findings: list[Finding] = Field(default_factory=list, max_length=12)
    uncertainty: str = Field(max_length=1000)

class ProductPresence(BaseModel):
    presence: Literal['present','absent','uncertain']
    evidence: str = Field(min_length=3,max_length=1500)

PRESENCE_SYSTEM = """Check the LAST/TARGET image for the expected product BEFORE inspecting defects. Earlier images are references only, never the target.
Return JSON {"presence":"present|absent|uncertain", "evidence":"specific visible evidence in the TARGET"}.
For a transistor, a dark component body and its leads must be visible. A carrier board with holes/stripes but no transistor body is ABSENT, not a good transistor. Background alone is never a passing product.
For tile/wood, verify the expected material surface is actually visible. Use uncertain if the view is insufficient or the product type cannot be established. Do not infer presence from file names, annotation labels, or reference images."""

SYSTEM = '''You assist industrial inspectors reviewing product images. All results are DRAFTS requiring human review.
Inspect only visible image evidence; never infer hidden measurements or guarantee quality.
Return JSON: {"assessment":"possible_defect|no_visible_defect|uncertain", "summary":"concise visual assessment", "findings":[{"title":"suspected defect", "evidence":"specific visible evidence", "severity":"low|medium|high", "box":null}], "uncertainty":"limitations"}.
A box is optional, normalized [left,top,right,bottom] relative to the FULL image. Only supply it when you can locate the evidence reliably. Otherwise use null. Never return pixel coordinates; all four coordinates must be between 0 and 1.
Compare with known-good references when provided. For transistors inspect lead count, obvious bending or breakage, damaged housing and misplaced parts. For tile inspect cracks and surface damage; for wood inspect holes, scratches and disrupted surfaces. Normal texture variation and lighting changes alone are not defects. Do not use a generic disclaimer as your assessment: describe the visible target. No visible defect is not an industrial safety certification. Use uncertain when image quality or context is inadequate. Do not invent confidence scores.'''

async def initialize():
    tables = [QualityAsset.__table__, QualityRun.__table__, QualityInspection.__table__, QualityReport.__table__, QualityOperation.__table__, QualityEvent.__table__, QualityBatchReport.__table__, QualityAnnotation.__table__, QualityRunContext.__table__, QualityAttempt.__table__, QualitySourceAnnotation.__table__, QualityAnalysisCache.__table__, QualityReviewCase.__table__, QualityStream.__table__]
    async with engine.begin() as conn:
        await conn.run_sync(lambda sync: QualityAsset.metadata.create_all(sync, tables=tables))
    # Processes cannot resume their in-memory tasks after a restart. Make this explicit.
    async with SessionLocal() as db:
        await db.execute(update(QualityRun).where(QualityRun.state == 'running').values(state='paused'))
        await db.execute(update(QualityInspection).where(QualityInspection.state.in_(['analyzing','loading_saved'])).values(state='failed', error='Backend restarted during analysis. Start a new run to retry.'))
        await db.commit()
        for run_id in (await db.scalars(select(QualityRun.id))).all():
            await refresh_batch_report(db, run_id)

async def shutdown():
    tasks = list(workers.values())
    for task in tasks:
        task.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    workers.clear()

async def analyze(image: bytes, product: str, context: str | None = None):
    from pathlib import Path
    from PIL import Image
    import io
    references = []
    if product.lower() in ('transistor','wood','tile'):
        folder = Path.home() / 'Downloads' / product.lower() / 'train' / 'good'
        for path in sorted(folder.glob('*.png'))[:2]:
            with Image.open(path) as ref:
                ref = ref.convert('RGB')
                ref.thumbnail((1200,1200))
                output = io.BytesIO()
                ref.save(output,format='PNG')
                references.append(base64.b64encode(output.getvalue()).decode())
    presence_payload = await asyncio.wait_for(complete_json_vision(system=PRESENCE_SYSTEM,user=f'Expected product: {product}. Is that product actually present in the target image? An empty fixture/carrier is not an intact product.',image_b64=base64.b64encode(image).decode(),reference_images=references,max_tokens=500),timeout=45)
    presence = ProductPresence.model_validate(presence_payload)
    if presence.presence != 'present':
        missing = presence.presence == 'absent'
        return {'product_presence':presence.presence,'presence_evidence':presence.evidence,'assessment':'possible_defect' if missing else 'uncertain','summary':f"Expected {product.lower()} is missing from the inspection image." if missing else f"Cannot verify that the expected {product.lower()} is present.",'findings':[{'title':'Missing expected product','evidence':presence.evidence,'severity':'unrated','box':None}] if missing else [],'uncertainty':'Defect acceptance is blocked. Inspector must verify product presence; no location is invented for a missing object.'}
    payload = await asyncio.wait_for(complete_json_vision(system=SYSTEM, user=f"{context or guide_for(product)}\nInspect this {product} target image independently. Describe evidence and avoid guessing a defect from the checklist. Return the draft JSON.", image_b64=base64.b64encode(image).decode(), reference_images=references, max_tokens=1800), timeout=90)
    result = Analysis.model_validate(payload).model_dump()
    result.update(product_presence='present',presence_evidence=presence.evidence)
    return result

def launch(run_id):
    if run_id in workers and not workers[run_id].done():
        return
    task = asyncio.create_task(execute(run_id))
    workers[run_id] = task
    task.add_done_callback(lambda _: workers.pop(run_id, None))

def record_event(db, user_id, run_id, agent, action, detail):
    db.add(QualityEvent(user_id=user_id, run_id=run_id, agent=agent, action=action, detail=detail, created_at=datetime.now(timezone.utc)))

async def execute(run_id):
    """Start each group together: four simultaneous analyses, then the next group."""
    from pathlib import Path
    inflight = set()
    persistence_lock = asyncio.Lock()
    next_dispatch_at = 0.0

    async def process(iid, asset_id, path, product, context, mode):
        started = time.monotonic()
        try:
            draft = ({'assessment':'uncertain','summary':'Manual inspection requested. Review this image and record a decision.', 'findings':[], 'uncertainty':'No AI analysis performed in Manual mode.'} if mode == 'manual' else await resolve_analysis(asset_id,Path(path).read_bytes(),product,context,mode,inspection_id=iid))
            async with persistence_lock:
                async with SessionLocal() as db:
                    row = await db.get(QualityInspection,iid)
                    row.draft,row.assessment,row.state,row.error = draft,draft['assessment'],'awaiting_review',None
                    row.duration = round(time.monotonic()-started,2)
                    record_event(db,row.user_id,row.run_id,'inspection','Save draft assessment',draft['summary'])
                    record_event(db,row.user_id,row.run_id,'inbox','Route inspection to review queue',f"Image {row.sequence}: {draft['assessment']}")
                    await db.commit()
                    prior = list((await db.scalars(select(QualityInspection).where(QualityInspection.run_id==run_id,QualityInspection.assessment=='possible_defect'))).all())
                    existing = await db.scalar(select(QualityOperation.id).where(QualityOperation.run_id==run_id,QualityOperation.kind=='quarantine'))
                    if len(prior)>=3 and not existing:
                        db.add(QualityOperation(user_id=row.user_id,run_id=run_id,kind='quarantine',title='Batch precautionary hold',detail='Three or more suspected defects; inspector review required before release.'))
                        db.add(QualityOperation(user_id=row.user_id,run_id=run_id,kind='maintenance',title='Investigate recurring batch defects',detail='Review source image evidence before determining any production cause.'))
                        record_event(db,row.user_id,run_id,'batch','Apply precautionary hold','Three suspected defects recorded')
                    await db.commit()
                    await route_completed_group(db,run_id,row.sequence)
                    await db.commit()
                    await refresh_batch_report(db,run_id)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('Quality analysis failed for %s',iid)
            async with persistence_lock:
                async with SessionLocal() as db:
                    row = await db.get(QualityInspection,iid)
                    row.state,row.error='failed','This image could not be analyzed. Use Recheck; other images continue independently.'
                    await db.commit()
                    await route_completed_group(db,run_id,row.sequence)
                    await db.commit()
                    await refresh_batch_report(db,run_id)

    try:
        while True:
            inflight = {task for task in inflight if not task.done()}
            async with persistence_lock:
                async with SessionLocal() as db:
                    run = await db.get(QualityRun,run_id)
                    if not run or run.state!='running':
                        break
                    stream=await db.get(QualityStream,run_id)
                    if stream and run.position>=len(run.assets) and not inflight:
                        run.assets=list(run.assets)+list(stream.source_assets)
                        await db.commit()
                    if run.position>=len(run.assets) and not inflight:
                        run.state='completed'
                        await db.commit()
                        await refresh_batch_report(db,run_id)
                        break
                    group_size = min(4,len(run.assets)-run.position)
                    # Launch a complete group in one turn, never one replacement at a time.
                    slots = group_size if not inflight and time.monotonic()>=next_dispatch_at else 0
                    work=[]
                    criteria = await db.scalar(select(QualityRunContext).where(QualityRunContext.run_id==run_id))
                    for _ in range(max(0,slots)):
                        asset = await db.get(QualityAsset,uuid.UUID(run.assets[run.position]))
                        row = QualityInspection(user_id=run.user_id,run_id=run.id,asset_id=asset.id,sequence=run.position+1)
                        db.add(row)
                        await db.flush()
                        context=guide_for(asset.product,criteria.checks if criteria else None,criteria.notes if criteria else '')
                        work.append((row.id,asset.id,asset.path,asset.product,context,run.mode))
                        record_event(db,run.user_id,run.id,'inspection','Dispatch image to review pipeline',f'Image {row.sequence}; launched with simultaneous group {(row.sequence-1)//4+1}')
                        run.position+=1
                    await db.commit()
            for args in work:
                inflight.add(asyncio.create_task(process(*args)))
            if work:
                if stream:
                    next_dispatch_at=time.monotonic()+STREAM_GROUP_INTERVAL
                await asyncio.sleep(0)
            else:
                await asyncio.sleep(.1)
    except asyncio.CancelledError:
        for task in inflight:
            task.cancel()
        await asyncio.gather(*inflight,return_exceptions=True)
        raise
    except Exception:
        log.exception('Inspection scheduler failed for %s',run_id)
        async with SessionLocal() as db:
            run=await db.get(QualityRun,run_id)
            if run:
                run.state='paused'
                await db.commit()
    finally:
        # A pause or stop prevents new dispatches; already-started images finish.
        await asyncio.gather(*inflight,return_exceptions=True)


async def followup_loop():
    """Durable, idempotent follow-up records for overdue maintenance investigations."""
    while True:
        try:
            async with SessionLocal() as db:
                cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
                tickets = (await db.scalars(select(QualityOperation).where(QualityOperation.kind == 'maintenance', QualityOperation.state != 'resolved', QualityOperation.created_at < cutoff))).all()
                for ticket in tickets:
                    exists = await db.scalar(select(QualityOperation.id).where(QualityOperation.run_id == ticket.run_id, QualityOperation.kind == 'followup'))
                    if not exists:
                        record_event(db, ticket.user_id, ticket.run_id, 'maintenance', 'Escalate overdue investigation', 'Follow-up record created after one hour')
                        db.add(QualityOperation(user_id=ticket.user_id,run_id=ticket.run_id,kind='followup', title='Maintenance follow-up due',detail='The batch investigation has been unresolved for over one hour. Check progress and record the next action.'))
                await db.commit()
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('Follow-up check failed')
        await asyncio.sleep(30)


async def operations_loop():
    """Prepare maintenance investigations while image analysis continues independently."""
    while True:
        try:
            async with SessionLocal() as db:
                tickets = list((await db.scalars(select(QualityOperation).where(QualityOperation.kind == 'maintenance', QualityOperation.state == 'open'))).all())
                for ticket in tickets:
                    rows = list((await db.scalars(select(QualityInspection).where(QualityInspection.run_id == ticket.run_id))).all())
                    evidence = [f"INS-{str(r.id)[:8]}: {(r.draft or {}).get('summary', 'Awaiting analysis')}" for r in rows if r.assessment == 'possible_defect']
                    ticket.detail += '\n\nEvidence attached:\n' + '\n'.join(evidence) + '\n\nNext steps: inspect the flagged units; check production records; document the cause before corrective action.'
                    ticket.state = 'in_progress'
                    record_event(db,ticket.user_id,ticket.run_id,'maintenance','Attach evidence & start investigation',f'{len(evidence)} suspected defect inspections linked; awaiting technician investigation')
                    record_event(db,ticket.user_id,ticket.run_id,'inbox','Publish investigation notification',ticket.title)
                await db.commit()
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('Operations worker failed')
        await asyncio.sleep(2)


async def refresh_batch_report(db, run_id):
    """Build a factual report from saved evidence. Never infer manufacturing causes."""
    from app.models.quality import QualityBatchReport
    run = await db.get(QualityRun, run_id)
    rows = list((await db.scalars(select(QualityInspection).where(QualityInspection.run_id == run_id).order_by(QualityInspection.sequence))).all())
    if not run or not rows:
        return
    report = await db.scalar(select(QualityBatchReport).where(QualityBatchReport.run_id == run_id))
    if report and report.state != 'draft':
        return
    # Load report evidence in batches; long-running sessions should not issue
    # four extra SQL requests for every previously inspected image on each update.
    asset_ids={row.asset_id for row in rows}
    inspection_ids=[row.id for row in rows]
    assets={asset.id:asset for asset in (await db.scalars(select(QualityAsset).where(QualityAsset.id.in_(asset_ids)))).all()}
    annotations={item.inspection_id:item for item in (await db.scalars(select(QualityAnnotation).where(QualityAnnotation.inspection_id.in_(inspection_ids)))).all()}
    sources={item.asset_id:item for item in (await db.scalars(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id.in_(asset_ids)))).all()}
    attempts=dict((await db.execute(select(QualityAttempt.inspection_id,func.count()).where(QualityAttempt.inspection_id.in_(inspection_ids)).group_by(QualityAttempt.inspection_id))).all())
    entries = []
    for row in rows:
        asset=assets[row.asset_id]
        annotation=annotations.get(row.id)
        source=sources.get(row.asset_id)
        entries.append({'cache':(row.draft or {}).get('cache'), 'source_annotation':{'label':source.label,'source':source.source,'box':source.box,'has_mask':bool(source.mask_path)} if source and run.mode=='assisted' else None, 'previous_attempts':attempts.get(row.id,0),'annotation':{'box':annotation.box,'note':annotation.note} if annotation else None, 'inspection_id':str(row.id),'asset_id':str(row.asset_id),'product':asset.product,'sequence':row.sequence,'state':row.state,'product_presence':(row.draft or {}).get('product_presence','uncertain'),'presence_evidence':(row.draft or {}).get('presence_evidence','Presence check not recorded'),'assessment':row.assessment,'summary':(row.draft or {}).get('summary'), 'findings':(row.draft or {}).get('findings',[]),'uncertainty':(row.draft or {}).get('uncertainty'), 'decision':row.decision, 'error':row.error})
    def needs_defect_review(entry):
        if entry['decision']:
            return entry['decision']['outcome'] in ('defect','rework')
        supplied = entry.get('source_annotation')
        return bool((supplied and supplied['label'] != 'good') or entry['assessment'] == 'possible_defect')
    suspected = sum(needs_defect_review(e) for e in entries)
    stream=await db.get(QualityStream,run_id)
    snapshot = {'continuous':bool(stream),'unique_source_images':len(set(run.assets)),'batch_id':str(run.id),'run_state':run.state,'total':len(run.assets),'received':len(rows),'analyzed':sum(r.draft is not None for r in rows),'suspected_defects':suspected,'uncertain':sum(r.assessment=='uncertain' for r in rows),'pending_review':sum(r.state=='awaiting_review' for r in rows),'failed':sum(r.state=='failed' for r in rows),'flagged':suspected>0,'entries':entries}
    dispositions = {name:sum(bool(r.decision) and r.decision['outcome']==outcome for r in rows) for name,outcome in [('accepted','no_defect'),('rejected','defect'),('rework','rework')]}
    unresolved=sum(r.state in ('analyzing','loading_saved','awaiting_review','awaiting_reinspection','failed') or not r.decision for r in rows)
    remaining=max(0,len(run.assets)-len(rows))
    blockers=[]
    if run.state in ('running','paused'):blockers.append('Inspection run is still active; complete or end it.')
    if remaining:blockers.append(f'{remaining} scheduled images have not been inspected.')
    if unresolved:blockers.append(f'{unresolved} image reviews or processing errors remain unresolved.')
    snapshot.update(dispositions=dispositions,unresolved=unresolved,not_inspected=remaining,close_blockers=blockers,review_complete=not blockers,release_ready=not blockers and dispositions['accepted']==len(rows))
    criteria = await db.scalar(select(QualityRunContext).where(QualityRunContext.run_id == run_id))
    context = guide_for(entries[0]['product'],criteria.checks if criteria else None,criteria.notes if criteria else '')
    body = f"# Batch quality review\n\nBatch: BAT-{str(run.id)[:8].upper()}\nProduct: {entries[0]['product']}\nSource: dataset simulation\nProcessing state: {run.state}\n\n## Review summary\nImages received: {len(rows)} / {len(run.assets)}\nImages analyzed: {snapshot['analyzed']}\nSuspected or confirmed defective units: {suspected}\nUncertain assessments: {snapshot['uncertain']}\nAwaiting inspector review: {snapshot['pending_review']}\nProcessing errors: {snapshot['failed']}\n\nBatch flag: {'REVIEW REQUIRED — defect evidence recorded' if suspected else 'No defect flag recorded; inspector review still required'}\n\n## Evidence-linked findings\n"
    for e in entries:
        body += f"\n### Image {e['sequence']} · INS-{e['inspection_id'][:8].upper()}\nEvidence asset: {e['asset_id']}\nDraft assessment: {e['assessment'] or 'Not available'}\n{e['summary'] or e['error'] or 'Analysis in progress'}\n"
        for finding in e['findings']:
            body += f"- {finding['title']}: {finding['evidence']}\n  Reported severity: {finding['severity']}\n  Suggested image region: {finding.get('box') or 'Not localized'}\n"
        body += f"Expected product presence: {e['product_presence']}\nPresence evidence: {e['presence_evidence']}\n"
        if e['source_annotation']:
            body += f"Supplied annotation: {e['source_annotation']['label']}\nAnnotation provenance: {e['source_annotation']['source']}\nThis annotation is an input, not a model detection result.\n"
        if e['cache'] and e['cache']['reused']:
            body += f"Analysis recorded at {e['cache']['analyzed_at']}; this image still requires its own inspector decision.\n"
        if e['previous_attempts']:
            body += f"Previous attempts retained for audit: {e['previous_attempts']}\n"
        if e['annotation']:
            body += f"Inspector-selected region (normalized): {e['annotation']['box']}\nRegion note: {e['annotation']['note']}\n"
        if e['uncertainty']:
            body += f"Limitations: {e['uncertainty']}\n"
        if e['decision']:
            body += f"Inspector: {e['decision']['inspector']}\nDecision: {e['decision']['outcome']}\nNotes: {e['decision']['notes']}\n"
    body += '\n## Product dispositions\n' + '\n'.join(f'{name}: {count}' for name,count in dispositions.items()) + '\nBatch review closure: ' + ('Ready for inspector sign-off' if not blockers else '; '.join(blockers)) + '\nRelease status: ' + ('All reviewed units accepted' if snapshot['release_ready'] else 'Not cleared for release; segregate rejected/rework units and resolve pending work') + '\n'
    body += '\n## Inspection criteria supplied before analysis\n' + context + '\n'
    body += '\n## Scope\nFindings describe supplied images. No claim is made about hidden defects, physical measurements, manufacturing cause, or actual factory conditions. AI regions and assessments require inspector verification.\n'
    if not report:
        report = QualityBatchReport(user_id=run.user_id,run_id=run.id,body=body,snapshot=snapshot)
        db.add(report)
        record_event(db,run.user_id,run.id,'inbox','Create batch review report','Draft assembled from saved inspection evidence')
    else:
        report.body, report.snapshot = body, snapshot
    await db.commit()


async def recheck_inspection(inspection_id):
    from pathlib import Path
    started = time.monotonic()
    try:
        async with SessionLocal() as db:
            row = await db.get(QualityInspection, inspection_id)
            asset = await db.get(QualityAsset, row.asset_id)
            criteria = await db.scalar(select(QualityRunContext).where(QualityRunContext.run_id == row.run_id))
            context = guide_for(asset.product,criteria.checks if criteria else None,criteria.notes if criteria else '')
            run_id, path, product = row.run_id,asset.path,asset.product
        async with SessionLocal() as db:
            run = await db.get(QualityRun,run_id)
        draft = ({'assessment':'uncertain','summary':'Inspector requested another review of this source image. No new physical evidence has been added.','findings':[],'uncertainty':'Manual reinspection requires the inspector to examine the evidence and record a new decision.'} if run.mode=='manual' else await resolve_analysis(asset.id,Path(path).read_bytes(),product,context,run.mode,force=True))
        async with SessionLocal() as db:
            row = await db.get(QualityInspection, inspection_id)
            row.draft,row.assessment,row.state,row.error = draft,draft['assessment'],'awaiting_review',None
            row.duration = round(time.monotonic()-started,2)
            record_event(db,row.user_id,row.run_id,'inspection','Complete image recheck',draft['summary'])
            await route_completed_group(db,row.run_id,row.sequence)
            await db.commit()
            await refresh_batch_report(db,row.run_id)
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception('Image recheck failed: %s',inspection_id)
        async with SessionLocal() as db:
            row = await db.get(QualityInspection, inspection_id)
            row.state,row.error = 'failed','Recheck failed. Verify model configuration or retry later; previous attempts remain saved.'
            await db.commit()
            await refresh_batch_report(db,row.run_id)


async def inspect_asset(asset_id, image, product, context, mode):
    if mode != 'assisted':
        return await analyze(image,product,context)
    async with SessionLocal() as db:
        source = await db.scalar(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id==asset_id))
    if source is None:
        return {'assessment':'uncertain','summary':'No supplied annotation is available for this image. Inspector annotation is required.', 'findings':[], 'uncertainty':'Annotation-assisted mode does not invent an independent detection result.'}
    product_presence,presence_evidence = 'uncertain','No visual product-presence check has completed.'
    normal = source.label == 'good'
    assessment = 'no_visible_defect' if normal else 'possible_defect'
    evidence = f"Supplied annotation identifies {source.label.replace('_',' ')}. " + ('The source mask defines the highlighted region.' if source.box else 'No defect region is supplied.')
    summary = 'Source annotation marks this image as good; inspector verification is required.' if normal else evidence
    uncertainty = 'Source: '+source.source+'. This is supplied inspection evidence, not an independent AI detection.'
    if settings.openai_api_key:
        try:
            commentary = await analyze(image,product,context+'\nSUPPLIED ANNOTATION INPUT: '+source.label+'; region '+str(source.box)+'. Explain whether the visible image supports this annotation. Do not invent additional defects or a manufacturing cause.')
            product_presence = commentary.get('product_presence','uncertain')
            presence_evidence = commentary.get('presence_evidence','Presence has not been verified.')
            if product_presence == 'absent':
                commentary['summary'] += ' Supplied annotation: '+source.label+'. Product presence contradicts any acceptance.'
                return commentary
            if product_presence == 'absent':
                commentary['uncertainty'] += ' Supplied annotation: '+source.label+'. Missing product takes priority over a good label.'
                return commentary
            summary += ' Model observation: '+commentary['summary']
            uncertainty += ' '+commentary['uncertainty']
            if commentary['assessment'] not in (assessment,):
                uncertainty += ' Model and source annotation do not fully agree. Inspector reconciliation required.'
                assessment = 'uncertain'
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception('Annotation commentary unavailable for %s',asset_id)
            uncertainty += ' Model commentary could not be obtained; source annotation retained for human review.'
    else:
        uncertainty += ' No model call was made because the vision API is not configured.'
    if product_presence != 'present' and assessment == 'no_visible_defect':
        assessment = 'uncertain'
    return {'product_presence':product_presence,'presence_evidence':presence_evidence,'assessment':assessment,'summary':summary[:2000],'findings':[] if normal else [{'title':source.label.replace('_',' '),'evidence':evidence,'severity':'unrated','box':source.box}], 'uncertainty':uncertainty[:1000]}


_cache_locks = {}

async def resolve_analysis(asset_id, image, product, context, mode, force=False, inspection_id=None):
    """Reuse only analysis, never inspector decisions. Recheck always bypasses reuse."""
    import hashlib
    import json
    import copy
    from pathlib import Path
    async with SessionLocal() as db:
        asset = await db.get(QualityAsset,asset_id)
        owner = asset.user_id
        source = await db.scalar(select(QualitySourceAnnotation).where(QualitySourceAnnotation.asset_id==asset_id)) if mode=='assisted' else None
        provenance = {'label':source.label,'source':source.source,'box':source.box,'mask':hashlib.sha256(Path(source.mask_path).read_bytes()).hexdigest() if source.mask_path else None} if source else None
    references=[]
    if product.lower() in ('tile','wood','transistor'):
        for path in sorted((Path.home()/'Downloads'/product.lower()/'train'/'good').glob('*.png'))[:2]:
            references.append(hashlib.sha256(path.read_bytes()).hexdigest())
    key=hashlib.sha256(json.dumps({'policy':'quality-presence-guides-v2','image':hashlib.sha256(image).hexdigest(),'product':product,'context':context,'mode':mode,'model':settings.openai_model_vision,'model_enabled':bool(settings.openai_api_key),'annotation':provenance,'references':references},sort_keys=True).encode()).hexdigest()
    lock=_cache_locks.setdefault((str(owner),key),asyncio.Lock())
    async with lock:
        async with SessionLocal() as db:
            cached=await db.scalar(select(QualityAnalysisCache).where(QualityAnalysisCache.user_id==owner,QualityAnalysisCache.fingerprint==key))
            if cached:
                created=cached.created_at
                if created.tzinfo is None:created=created.replace(tzinfo=timezone.utc)
                if not force and datetime.now(timezone.utc)-created<timedelta(hours=24):
                    result=copy.deepcopy(cached.result)
                    result['cache']={'reused':True,'analyzed_at':created.isoformat()}
                    if inspection_id:
                        row=await db.get(QualityInspection,inspection_id)
                        row.state='loading_saved'
                        record_event(db,owner,row.run_id,'inspection','Prepare inspection result','Result preparation; no new model inference.')
                        await db.commit()
                    await asyncio.sleep(CACHE_PRESENTATION_DELAY)
                    return result
        result=await inspect_asset(asset_id,image,product,context,mode)
        now=datetime.now(timezone.utc)
        async with SessionLocal() as db:
            cached=await db.scalar(select(QualityAnalysisCache).where(QualityAnalysisCache.user_id==owner,QualityAnalysisCache.fingerprint==key))
            if cached:
                cached.result=copy.deepcopy(result);cached.created_at=now
            else:
                db.add(QualityAnalysisCache(user_id=owner,fingerprint=key,result=copy.deepcopy(result),created_at=now))
            await db.commit()
        result=copy.deepcopy(result)
        result['cache']={'reused':False,'analyzed_at':now.isoformat()}
        return result
