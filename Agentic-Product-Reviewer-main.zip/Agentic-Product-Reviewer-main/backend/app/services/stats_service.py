from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Task, User
from app.schemas.stats import StatsOut


async def for_user(db: AsyncSession, user: User) -> StatsOut:
    now = datetime.now(timezone.utc)
    week_ago = now - timedelta(days=7)
    prev_week_start = now - timedelta(days=14)

    async def _bucket(start: datetime, end: datetime) -> tuple[int, int, int, float]:
        result = await db.execute(
            select(Task).where(
                Task.user_id == user.id,
                Task.created_at >= start,
                Task.created_at < end,
            )
        )
        tasks = list(result.scalars().all())
        total = len(tasks)
        completed = sum(1 for t in tasks if t.state == "completed")
        recoveries = sum(1 for t in tasks if t.state in ("recovering", "completed") and t.error)
        durations = [
            (t.completed_at - t.started_at).total_seconds()
            for t in tasks
            if t.started_at and t.completed_at
        ]
        avg = sum(durations) / len(durations) if durations else 0.0
        return total, completed, recoveries, avg

    this_total, this_done, this_rec, this_avg = await _bucket(week_ago, now)
    prev_total, prev_done, prev_rec, prev_avg = await _bucket(prev_week_start, week_ago)

    success_rate = (this_done / this_total) if this_total else 0.0
    prev_success_rate = (prev_done / prev_total) if prev_total else 0.0

    return StatsOut(
        tasks_week=this_total,
        success_rate=success_rate,
        recoveries=this_rec,
        avg_time_seconds=this_avg,
        delta_tasks_week=this_total - prev_total,
        delta_success_rate=success_rate - prev_success_rate,
        delta_recoveries=this_rec - prev_rec,
        delta_avg_time_seconds=this_avg - prev_avg,
    )


async def _global_count(db: AsyncSession) -> int:
    result = await db.execute(select(func.count()).select_from(Task))
    return int(result.scalar_one())
