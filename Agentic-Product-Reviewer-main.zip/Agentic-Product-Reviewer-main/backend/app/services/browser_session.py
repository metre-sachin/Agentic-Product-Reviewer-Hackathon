"""Per-task browser session lifecycle.

Lazily boots a PlaywrightController + AgentBrowserAdapter the first time a task
needs to act on a page. Import-safe: if Playwright or the browser binary is
unavailable, `ensure()` returns None and the runtime degrades gracefully.

v2 mode: when the user's settings say `browser_mode="v2"` and their real
browser is connected (Argus extension / bookmarklet on the v2 hub), `ensure()`
returns a V2BrowserAdapter that drives THAT browser through the page-agent
engine instead of booting Playwright. Falls back to Playwright when no browser
is connected, so tasks never dead-end.
"""

from __future__ import annotations

import logging

from app.core.config import settings

log = logging.getLogger(__name__)


class TaskBrowser:
    def __init__(
        self,
        task_id: str,
        *,
        headless: bool | None = None,
        storage_state: dict | None = None,
        user_id: str | None = None,
        mode: str = "browser",
    ) -> None:
        self._task_id = task_id
        self._headless = settings.browser_headless if headless is None else headless
        self._initial_state = storage_state
        self._user_id = user_id
        self._mode = mode
        self._controller = None
        self._adapter = None
        self._v2_adapter = None
        self._v2_shot_seq = 0
        self._failed = False

    @property
    def started(self) -> bool:
        return self._adapter is not None or self._v2_adapter is not None

    @property
    def headless(self) -> bool:
        return self._headless

    def use_storage_state(self, state: dict | None) -> None:
        """Seed a saved login session before the browser is first opened."""
        self._initial_state = state or None

    def _try_v2(self):
        """Return a live V2BrowserAdapter for this user, or None."""
        if self._mode != "v2" or not self._user_id:
            return None
        if self._v2_adapter is not None:
            return self._v2_adapter
        try:
            from app.services.v2_hub import hub
            from integrations.page_agent.adapter import V2BrowserAdapter

            conn = hub.get(self._user_id)
            if conn is None:
                log.info(
                    "v2 mode requested but no browser connected for user %s; "
                    "falling back to Playwright",
                    self._user_id,
                )
                return None
            self._v2_adapter = V2BrowserAdapter(conn)
            return self._v2_adapter
        except Exception as exc:  # noqa: BLE001
            log.warning("v2 browser unavailable for task %s: %s", self._task_id, exc)
            return None

    async def ensure(self):
        """Return the acting adapter, or None if the browser layer can't run."""
        v2 = self._try_v2()
        if v2 is not None:
            return v2
        if self._adapter is not None:
            return self._adapter
        if self._failed:
            return None
        try:
            from integrations.agent_browser.adapter import AgentBrowserAdapter
            from integrations.playwright.controller import PlaywrightController

            controller = PlaywrightController(
                settings.media_path,
                headless=self._headless,
                channel=settings.browser_channel,
                locale=settings.browser_locale,
                timezone=settings.browser_timezone,
                proxy=settings.browser_proxy,
            )
            await controller.start(storage_state=self._initial_state)
            self._controller = controller
            self._adapter = AgentBrowserAdapter(controller)
            return self._adapter
        except Exception as exc:  # noqa: BLE001
            log.warning("browser layer unavailable for task %s: %s", self._task_id, exc)
            self._failed = True
            return None

    async def screenshot(self) -> str | None:
        """Capture a screenshot, return its public URL (or None)."""
        if self._v2_adapter is not None:
            data = await self._v2_adapter.screenshot_bytes()
            if not data:
                return None
            shot_dir = settings.media_path / self._task_id
            shot_dir.mkdir(parents=True, exist_ok=True)
            self._v2_shot_seq += 1
            name = f"v2_{self._v2_shot_seq:04d}.png"
            (shot_dir / name).write_bytes(data)
            return settings.screenshot_url(self._task_id, name)
        if self._controller is None:
            return None
        path = await self._controller.screenshot(self._task_id)
        if path is None:
            return None
        return settings.screenshot_url(self._task_id, path.name)

    async def screenshot_bytes(self) -> bytes | None:
        """Capture the viewport as PNG bytes for vision reasoning."""
        if self._v2_adapter is not None:
            return await self._v2_adapter.screenshot_bytes()
        if self._controller is None:
            return None
        return await self._controller.screenshot_bytes()

    @property
    def controller(self):
        return self._controller

    @property
    def cdp_url(self) -> str | None:
        """CDP endpoint of the shared browser, so Browser Use can recover on the
        same page. None until the browser has started."""
        return self._controller.cdp_url if self._controller is not None else None

    async def current_url(self) -> str:
        if self._v2_adapter is not None:
            return await self._v2_adapter.current_url()
        if self._controller is None:
            return ""
        return await self._controller.current_url()

    async def storage_state(self) -> dict:
        if self._controller is None:
            return {}
        return await self._controller.storage_state()

    async def close(self) -> None:
        if self._controller is not None:
            await self._controller.stop()
        self._controller = None
        self._adapter = None
