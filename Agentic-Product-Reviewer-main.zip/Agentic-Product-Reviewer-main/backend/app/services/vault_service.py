"""Credential vault — encrypted storage for logins, personal identity, and cards.

Values live only as Fernet ciphertext (see app.core.crypto). The runtime saves a
login automatically the first time the user signs in to a domain, and autofills it
on the next task for that domain (unless the entry is marked ask_every_time). The
HTTP layer only ever exposes metadata — which fields exist, never their values.

Scoping:
- login    → one entry per domain (label = domain), blob {email, username, password}
- identity → one per user (label = IDENTITY_LABEL), blob keyed by field kind
             (name, email, phone, address, dob, card, …) — the user's own details
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.crypto import decrypt_json, encrypt_json
from app.models import User, VaultEntry
from app.schemas.vault import VaultEntryOut, VaultEntryUpdate

LOGIN_KIND = "login"
IDENTITY_KIND = "identity"
IDENTITY_LABEL = "__identity__"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def merge_blob(existing: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    """Overlay non-empty updates onto an existing secret blob. Pure (no DB) so the
    merge rules are unit-testable. Empty/None updates never clobber a saved value."""
    merged = dict(existing or {})
    for key, value in (updates or {}).items():
        if value is None:
            continue
        text = str(value).strip()
        if text:
            merged[key] = text
    return merged


def _domain(label: str) -> str:
    return (label or "").strip().lower()


def _to_out(entry: VaultEntry) -> VaultEntryOut:
    blob = decrypt_json(entry.ciphertext)
    return VaultEntryOut(
        id=str(entry.id),
        kind=entry.kind,
        label=entry.label,
        fields=sorted(blob.keys()),
        ask_every_time=entry.ask_every_time,
        last_used_at=entry.last_used_at,
        created_at=entry.created_at,
    )


async def _get_entry(
    db: AsyncSession, user_id: uuid.UUID, kind: str, label: str
) -> VaultEntry | None:
    result = await db.execute(
        select(VaultEntry).where(
            VaultEntry.user_id == user_id,
            VaultEntry.kind == kind,
            VaultEntry.label == label,
        )
    )
    return result.scalar_one_or_none()


async def _upsert(
    db: AsyncSession, user_id: uuid.UUID, kind: str, label: str, updates: dict[str, Any]
) -> None:
    entry = await _get_entry(db, user_id, kind, label)
    if entry is None:
        blob = merge_blob({}, updates)
        if not blob:
            return
        db.add(
            VaultEntry(
                user_id=user_id,
                kind=kind,
                label=label,
                ciphertext=encrypt_json(blob),
                last_used_at=_now(),
            )
        )
    else:
        blob = merge_blob(decrypt_json(entry.ciphertext), updates)
        entry.ciphertext = encrypt_json(blob)
        entry.last_used_at = _now()
    await db.commit()


# ---------------------- logins ----------------------

async def save_login(
    db: AsyncSession, user_id: uuid.UUID, domain: str, creds: dict[str, Any]
) -> None:
    domain = _domain(domain)
    if not domain:
        return
    await _upsert(
        db,
        user_id,
        LOGIN_KIND,
        domain,
        {
            "email": creds.get("email"),
            "username": creds.get("username"),
            "password": creds.get("password"),
        },
    )


async def login_for_autofill(
    db: AsyncSession, user_id: uuid.UUID, domain: str
) -> dict[str, str] | None:
    """Return saved {email, password} for a domain when autofill is allowed, i.e.
    the entry exists, has a password, and is not flagged ask_every_time."""
    entry = await _get_entry(db, user_id, LOGIN_KIND, _domain(domain))
    if entry is None or entry.ask_every_time:
        return None
    blob = decrypt_json(entry.ciphertext)
    if not blob.get("password"):
        return None
    entry.last_used_at = _now()
    await db.commit()
    return {
        "email": blob.get("email") or blob.get("username") or "",
        "password": blob["password"],
    }


# ---------------------- identity (personal details) ----------------------

async def save_identity(
    db: AsyncSession, user_id: uuid.UUID, values_by_kind: dict[str, Any]
) -> None:
    if not values_by_kind:
        return
    await _upsert(db, user_id, IDENTITY_KIND, IDENTITY_LABEL, values_by_kind)


async def identity_for_autofill(
    db: AsyncSession, user_id: uuid.UUID
) -> dict[str, str] | None:
    """Return the saved identity profile (values keyed by field kind) when autofill
    is allowed for it."""
    entry = await _get_entry(db, user_id, IDENTITY_KIND, IDENTITY_LABEL)
    if entry is None or entry.ask_every_time:
        return None
    blob = decrypt_json(entry.ciphertext)
    return {k: str(v) for k, v in blob.items() if v} or None


# ---------------------- HTTP surface (metadata only) ----------------------

async def list_for_user(db: AsyncSession, user: User) -> list[VaultEntryOut]:
    result = await db.execute(
        select(VaultEntry)
        .where(VaultEntry.user_id == user.id)
        .order_by(VaultEntry.created_at.desc())
    )
    return [_to_out(e) for e in result.scalars().all()]


async def _get_owned(db: AsyncSession, user: User, entry_id: str) -> VaultEntry:
    try:
        eid = uuid.UUID(entry_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid vault entry id") from exc
    entry = await db.get(VaultEntry, eid)
    if entry is None or entry.user_id != user.id:
        raise HTTPException(status_code=404, detail="vault entry not found")
    return entry


async def update(
    db: AsyncSession, user: User, entry_id: str, payload: VaultEntryUpdate
) -> VaultEntryOut:
    entry = await _get_owned(db, user, entry_id)
    if payload.ask_every_time is not None:
        entry.ask_every_time = payload.ask_every_time
    await db.commit()
    await db.refresh(entry)
    return _to_out(entry)


async def delete(db: AsyncSession, user: User, entry_id: str) -> None:
    entry = await _get_owned(db, user, entry_id)
    await db.delete(entry)
    await db.commit()
