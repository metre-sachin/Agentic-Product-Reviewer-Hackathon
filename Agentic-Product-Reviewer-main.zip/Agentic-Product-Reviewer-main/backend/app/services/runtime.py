"""Task runtime — orchestrates planner and (eventually) executor adapters.

State machine: created -> planning -> executing -> (waiting_for_approval)* -> completed | failed.

In Phase 3 the executor is a placeholder that logs per-step work so the UI
pipeline (plan/log/SSE/approval gate) is end-to-end verifiable. Phase 5+ wires
the real adapter ladder (Scrapling -> Agent Browser -> Browser Use -> Vision).
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from agents.approval.approval import needs_approval
from agents.executor.browser_loop import MAX_ACTIONS, REDACTED, run_interaction
from agents.executor.executor import execute_step
from agents.executor.vision_loop import run_vision
from agents.memory.memory import relevant_memories
from agents.planner.planner import plan as run_planner
from agents.planner.planner import replan as run_replan
from agents.state import AgentState
from integrations.base import StepInput
from integrations.browser_use.adapter import BrowserUseAdapter
from app.core.config import settings
from app.db.session import SessionLocal
from app.models import (
    Approval,
    BrowserSession,
    RecoveryEvent,
    Task,
    TaskAction,
    TaskLog,
    TaskStep,
    UserSettings,
)
from app.services import (
    connected_sites_service,
    learning_service,
    lessons_service,
    playbook_service,
    vault_service,
)
from app.services.browser_session import TaskBrowser
from app.services.event_bus import bus

log = logging.getLogger(__name__)


# ---------------------- helpers ----------------------

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _coerce_budget(raw: Any) -> float | None:
    """The numeric task budget, or None when the goal had no spend cap."""
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def _merge_cart(
    cart: list[dict[str, Any]],
    added: list[dict[str, Any]],
    budget: float | None,
) -> list[dict[str, Any]]:
    """Fold a step's added items into the running cart ledger — deduping by product
    name and never crossing the budget. Mutates `cart`, returns the items actually
    added so the caller can log them. This is the deterministic backstop that keeps
    the ledger honest even if the browser loop over-adds."""
    from agents.executor.browser_loop import _ledger_total, _name_in_ledger

    newly: list[dict[str, Any]] = []
    for item in added:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        if not name or _name_in_ledger(name, cart):
            continue
        try:
            price = float(item["price"]) if item.get("price") is not None else None
        except (TypeError, ValueError):
            price = None
        if (
            budget is not None
            and price is not None
            and _ledger_total(cart) + price > budget + 1e-6
        ):
            continue
        entry = {"name": name[:80], "price": price}
        cart.append(entry)
        newly.append(entry)
    return newly


async def _publish(task_id: uuid.UUID, kind: str, payload: dict[str, Any]) -> None:
    await bus.publish(str(task_id), {"kind": kind, "payload": payload, "at": _now().isoformat()})


async def _log(
    db: AsyncSession,
    task_id: uuid.UUID,
    text: str,
    *,
    level: str = "info",
    detail: str | None = None,
    layer: str | None = None,
    step_id: uuid.UUID | None = None,
    data: dict[str, Any] | None = None,
) -> None:
    row = TaskLog(
        task_id=task_id,
        step_id=step_id,
        level=level,
        layer=layer,
        text=text,
        detail=detail,
        data=data,
    )
    db.add(row)
    await db.flush()
    await db.commit()
    await _publish(
        task_id,
        "log",
        {
            "id": row.id,
            "level": level,
            "layer": layer,
            "text": text,
            "detail": detail,
            "at": row.at.isoformat() if row.at else _now().isoformat(),
        },
    )


async def _set_state(db: AsyncSession, task: Task, new_state: str) -> None:
    # A user cancel wins over any in-flight transition.
    if is_cancelled(task.id) and new_state not in {"cancelled", "failed", "completed"}:
        new_state = "cancelled"
    if (
        is_paused(task.id)
        and new_state not in {
            "paused",
            "cancelled",
            "failed",
            "completed",
            "waiting_for_user",
            "waiting_for_approval",
        }
    ):
        new_state = "paused"
    task.state = new_state
    if new_state == "executing" and task.started_at is None:
        task.started_at = _now()
    if new_state in {"completed", "failed", "cancelled"} and task.completed_at is None:
        task.completed_at = _now()
    await db.commit()
    await _publish(
        task.id,
        "state",
        {"state": new_state, "started_at": task.started_at and task.started_at.isoformat(),
         "completed_at": task.completed_at and task.completed_at.isoformat()},
    )


async def _wait_if_paused(db: AsyncSession, task: Task) -> None:
    if not is_paused(task.id):
        return
    await _set_state(db, task, "paused")
    event = _pause_events.setdefault(task.id, asyncio.Event())
    await event.wait()
    _pause_events.pop(task.id, None)
    if not is_cancelled(task.id):
        await _set_state(db, task, "executing")


async def _publish_plan(task: Task) -> None:
    await _publish(
        task.id,
        "plan",
        {
            "steps": [
                {
                    "id": str(s.id),
                    "ordinal": s.ordinal,
                    "label": s.label,
                    "meta": s.meta,
                    "state": s.state,
                    "layer_used": s.layer_used,
                    "attempts": s.attempts,
                }
                for s in sorted(task.steps, key=lambda x: x.ordinal)
            ]
        },
    )


# ---------------------- recovery ladder (L2 -> L3 -> L4 -> L5 human) ----------------------

async def _record_recovery(
    db: AsyncSession, task: Task, step: TaskStep, from_layer: str, to_layer: str, cause: str
) -> RecoveryEvent:
    rec = RecoveryEvent(
        task_id=task.id, step_id=step.id,
        from_layer=from_layer, to_layer=to_layer, cause=cause,
        evidence={"step": step.label},
    )
    db.add(rec)
    await db.commit()
    await _set_state(db, task, "recovering")
    await _publish(
        task.id, "recovery",
        {"id": str(rec.id), "step_id": str(step.id),
         "from_layer": from_layer, "to_layer": to_layer, "cause": cause},
    )
    return rec


async def _recover(
    db: AsyncSession,
    task: Task,
    step: TaskStep,
    cause: str,
    observations: list[str],
    task_browser: "TaskBrowser",
    model: str | None = None,
    browser_use_options: dict[str, Any] | None = None,
    manual_assist_enabled: bool = True,
    record: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    lessons: str = "",
    notes: list[str] | None = None,
) -> tuple[bool, str]:
    """Escalate a stalled step down the ladder: L3 Browser Use -> L4 Vision ->
    L5 human assist. Records a recovery_events row per hop and streams events."""

    async def _emit(text: str, detail: str | None = None) -> None:
        await _log(db, task.id, text, level="info", step_id=step.id)
        shot = await task_browser.screenshot()
        if shot:
            await _publish(task.id, "screenshot", {"url": shot})
        await _wait_if_paused(db, task)

    # ---- L3: hand the stuck page to Browser Use ----
    # When the shared browser is running we attach Browser Use to it over CDP, so
    # it finishes the click/form on the SAME page and session the structured loop
    # got stuck on — ideal for JS portals like ERP "Continue" buttons. Only when
    # there is no shared browser do we fall back to Browser Use launching its own
    # (opt-in via enable_browser_use), which loses the session.
    shared_cdp = task_browser.cdp_url
    on_same_page = bool(shared_cdp)
    bu_attempted = False
    if shared_cdp or settings.enable_browser_use:
        bu_attempted = True
        rec = await _record_recovery(db, task, step, "agent_browser", "browser_use", cause)
        await _log(
            db, task.id,
            (
                "Structured interaction stalled — handing this page to Browser Use"
                if on_same_page
                else f"Structured interaction stalled — escalating to autonomous Browser Use ({cause})"
            ),
            level="warn", layer="browser_use", step_id=step.id,
        )
        bu = BrowserUseAdapter(
            model=(browser_use_options or {}).get("model") or model or settings.openai_model_executor,
            api_key=settings.openai_api_key,
            browser_use_api_key=settings.browser_use_api_key,
            headless=task_browser.headless,
            cdp_url=shared_cdp or (browser_use_options or {}).get("cdp_url"),
            use_system_chrome=False if on_same_page else bool((browser_use_options or {}).get("use_system_chrome")),
            chrome_profile=None if on_same_page else (browser_use_options or {}).get("chrome_profile"),
            storage_state=None if on_same_page else (browser_use_options or {}).get("storage_state"),
            channel=settings.browser_channel,
            proxy=settings.browser_proxy,
            captcha_solver=bool((browser_use_options or {}).get("captcha_solver", True)),
            # Recovery often means a long form (multi-question/multi-course survey),
            # so give it a generous step budget rather than the default.
            max_steps=max(
                int((browser_use_options or {}).get("max_steps") or settings.browser_use_max_steps),
                80,
            ),
            task_id=str(task.id),
            on_screenshot=lambda url: _publish(task.id, "screenshot", {"url": url}),
            should_stop=lambda: asyncio.sleep(0, result=is_cancelled(task.id) or is_paused(task.id)),
        )
        if bu.available:
            result = await bu.run(
                StepInput(
                    goal=_browser_use_goal(
                        task.goal, step.label, observations,
                        lessons=lessons, notes=notes,
                    ),
                    # On the shared page we're already where we need to be.
                    url=None if on_same_page else _start_url_from_intent(task.intent),
                    data={"observations": observations, "allow_irreversible": False},
                )
            )
            rec.recovered = bool(result.ok)
            await db.commit()
            if result.ok:
                obs = str(result.observed.get("result") or f"Recovered: {step.label}")
                await _set_state(db, task, "executing")
                await _log(db, task.id, f"Recovered via Browser Use: {obs}",
                           level="milestone", layer="browser_use", step_id=step.id)
                await bu.close()
                return True, obs
            await _log(db, task.id,
                       f"Browser Use could not complete the step: {result.error or 'unknown'}",
                       level="warn", layer="browser_use", step_id=step.id)
            await bu.close()
        else:
            rec.recovered = False
            await db.commit()
            await _log(db, task.id, "Browser Use unavailable — skipping to vision",
                       level="warn", layer="browser_use", step_id=step.id)

    # ---- L4: vision over a live screenshot ----
    adapter = await task_browser.ensure()
    controller = task_browser.controller
    if adapter is not None and controller is not None and settings.openai_api_key:
        rec2 = await _record_recovery(
            db, task, step,
            "browser_use" if bu_attempted else "agent_browser",
            "vision",
            "l3_failed" if bu_attempted else "structured_stalled",
        )
        await _log(db, task.id, "Escalating to vision fallback (screenshot reasoning)",
                   level="warn", layer="vision", step_id=step.id)
        vis = await run_vision(
            adapter=adapter, controller=controller, goal=task.goal, step_label=step.label,
            intent=task.intent or {}, emit=_emit,
            model=model or settings.openai_model_vision, api_key=settings.openai_api_key,
            record=record,
        )
        rec2.recovered = bool(vis.ok)
        await db.commit()
        if vis.ok:
            await _set_state(db, task, "executing")
            await _log(db, task.id, f"Recovered via vision: {vis.observation}",
                       level="milestone", layer="vision", step_id=step.id)
            return True, vis.observation
        await _log(db, task.id, "Vision fallback could not complete the step",
                   level="warn", layer="vision", step_id=step.id)

    # ---- L5: ask the human ----
    if not manual_assist_enabled:
        await _log(
            db, task.id,
            "Manual assist is disabled, so Argus stopped instead of asking for help",
            level="warn", layer="human", step_id=step.id,
        )
        return False, ""

    # Only ask if Argus actually has a browser to act on the answer. With no
    # browser at all, the user can't help Argus do the click/type — asking per
    # step would just be noise. Fail cleanly with an actionable message instead.
    if adapter is None:
        await _log(
            db, task.id,
            "No browser available for this step. Install it once with "
            "`python -m playwright install chromium`, then re-run the task.",
            level="warn", layer="human", step_id=step.id,
        )
        return False, ""

    rec3 = await _record_recovery(db, task, step, "vision", "human", "all_layers_failed")
    await _set_state(db, task, "waiting_for_user")
    question = f"I couldn't complete this step on my own: {step.label}. How should I proceed?"
    _pending_prompt[task.id] = {
        "kind": "assist", "step_id": str(step.id),
        "step_label": step.label, "question": question,
    }
    await _publish(task.id, "assist", {
        "step_id": str(step.id), "step_label": step.label, "question": question,
    })
    await _log(db, task.id, f"Asking for help: {step.label}",
               level="milestone", layer="human", step_id=step.id)

    user_text = await wait_for_user_input(task.id)
    if user_text == CANCEL_SENTINEL or is_cancelled(task.id):
        return False, ""
    await _set_state(db, task, "executing")
    # Never echo raw user input verbatim — it may contain a password/OTP.
    await _log(db, task.id, "Received your guidance", level="info", layer="human", step_id=step.id)

    if adapter is not None and user_text.strip():
        guided = await run_interaction(
            adapter=adapter, goal=task.goal,
            step_label=f"{step.label} — user guidance: {user_text}",
            intent=task.intent or {}, prior_observations=observations,
            emit=_emit, start_url=None, allow_irreversible=False,
            controller=task_browser.controller,
            use_vision=True,
            model=model or settings.openai_model_executor,
            record=record,
        )
        rec3.recovered = bool(guided.ok)
        await db.commit()
        if guided.ok:
            await _log(db, task.id, f"Completed with your guidance: {guided.observation}",
                       level="milestone", layer="human", step_id=step.id)
            return True, guided.observation

    rec3.recovered = False
    await db.commit()
    return False, ""


# ---------------------- runtime ----------------------

def _start_url_from_intent(intent: dict) -> str | None:
    domain = str((intent or {}).get("domain") or "").strip().lower()
    if not domain or domain in {"multiple", "various", "n/a"}:
        return None
    if domain.startswith("http"):
        return domain
    if "." in domain and " " not in domain:
        return f"https://{domain}"
    return None


def _session_domain(intent: dict) -> str | None:
    """Registrable host used to key a reusable login session (storage_state)."""
    domain = str((intent or {}).get("domain") or "").strip().lower()
    if not domain or domain in {"multiple", "various", "n/a"}:
        return None
    if domain.startswith("http"):
        from urllib.parse import urlparse

        domain = urlparse(domain).netloc or domain
    domain = domain.split("/")[0]
    if "." not in domain or " " in domain:
        return None
    return domain


# Standing, site-agnostic guidance handed to Browser Use so it can complete the
# kinds of widgets the structured loop can't drive — star ratings, score scales,
# multi-question surveys, registrations, reviews — on ANY site. The rating VALUE
# is driven by the user's goal, not hardcoded.
_FORM_FILL_GUIDANCE = (
    "Some pages are forms — surveys, feedback, ratings/reviews, registrations. "
    "When a form has required fields or star/score ratings, complete EVERY required "
    "item before submitting; a partial submit is rejected. "
    "For each rating question, use the rating the USER ASKED FOR in the goal above: "
    "if they gave a value or range (e.g. '5 stars', '2 stars', '3 to 4', 'mixed', "
    "'be honest/critical'), follow it; if they did NOT specify, pick a realistic, "
    "natural rating — generally 3 to 5 of 5, varied rather than identical, as a real "
    "respondent would. To set N stars, click the N-th star/option in that question's "
    "row. There may be many questions, pages, or sections (e.g. 'Question 3 of 10', "
    "'Page 1 of 4') — do them ALL, advancing through each. Fill any free-text comment "
    "briefly and naturally in line with the rating. Do NOT click submit/finish until "
    "every required rating and field is set."
)


def _build_run_summary(
    task: Task, run_notes: list[str], answered: bool, error: str | None
) -> str:
    """Compact account of how a run went — outcome, per-step layer/state, and the
    issues hit — used as the raw material for distilling site lessons."""
    if answered:
        outcome = "succeeded"
    elif error:
        outcome = f"failed ({error})"
    else:
        outcome = "incomplete"
    lines = [f"Outcome: {outcome}"]
    for s in sorted(task.steps, key=lambda x: x.ordinal):
        layer = f" via {s.layer_used}" if s.layer_used else ""
        lines.append(f"- {s.label}: {s.state}{layer}")
    if run_notes:
        lines.append("Issues hit: " + " | ".join(run_notes[-8:]))
    return "\n".join(lines)


def _browser_use_goal(
    goal: str,
    step_label: str,
    observations: list[str],
    *,
    lessons: str = "",
    notes: list[str] | None = None,
) -> str:
    """Build the Browser Use task prompt: the user's goal + current sub-task +
    form-filling guidance + what Argus learned about this site + what already
    failed this run, so it skips known dead-ends and handles forms/ratings."""
    parts = [goal.strip(), f"Current sub-task: {step_label}.", _FORM_FILL_GUIDANCE]
    if lessons:
        parts.append("What Argus learned about this site (use it):\n" + lessons)
    if notes:
        parts.append(
            "Already failed this run — do NOT repeat these approaches:\n"
            + "\n".join(f"- {n}" for n in notes[-6:])
        )
    if observations:
        parts.append("Known so far: " + " | ".join(observations[-3:]))
    return "\n\n".join(parts)


_SYNTH_SYSTEM = """You are Argus. You have finished working a user's web task. Using
ONLY the notes Argus actually gathered, write the final answer that directly
addresses the user's goal.

- Be specific and useful: include the concrete facts, lists, comparisons, dates,
  or results the user asked for, and cite sources where the notes provide them.
- If the notes do NOT actually contain enough to answer the goal, do not invent
  anything. Set answered=false and briefly explain what was missing or what
  blocked progress (e.g. the site required sign-in or blocked automated access).

Output strict JSON: {"answer": "the answer, or the explanation", "answered": true|false}.
"""


async def _synthesize_answer(
    goal: str, observations: list[str], *, model: str | None = None
) -> dict[str, Any]:
    """Turn the gathered notes into a direct answer, and judge whether the goal
    was actually met. Returns {answer, answered}."""
    from app.services.llm import complete_json

    notes = "\n".join(f"- {o}" for o in observations if o)[:7000]
    if not notes.strip():
        return {"answer": "", "answered": False}
    try:
        return await complete_json(
            system=_SYNTH_SYSTEM,
            user=f"User goal:\n{goal}\n\nNotes Argus gathered:\n{notes}\n\nReturn JSON.",
            model=model,
            temperature=0.2,
            max_tokens=700,
        )
    except Exception:  # noqa: BLE001
        return {"answer": "", "answered": False}


_CAPTCHA_SYSTEM = """You are reading a CAPTCHA image so the user can sign in to their
OWN account. Find the distorted-text CAPTCHA box in the screenshot and return the
exact characters it shows, preserving case when legible. If you cannot read it
confidently, set confident=false and leave text empty.
Output strict JSON: {"text": "the characters", "confident": true|false}.
"""


async def _autosolve_captcha(task_browser: TaskBrowser, *, model: str | None = None) -> str | None:
    """Best-effort: read a simple image CAPTCHA with the vision model. Returns the
    text only when the model is confident, else None so the human is asked."""
    if not settings.openai_api_key:
        return None
    img = await task_browser.screenshot_bytes()
    if not img:
        return None
    import base64

    from app.services.llm import complete_json_vision

    try:
        out = await complete_json_vision(
            system=_CAPTCHA_SYSTEM,
            user="Read the CAPTCHA characters shown in this screenshot.",
            image_b64=base64.b64encode(img).decode(),
            model=model or settings.openai_model_vision,
            temperature=0.0,
            max_tokens=50,
        )
    except Exception:  # noqa: BLE001
        return None
    text = str(out.get("text") or "").strip()
    if out.get("confident") and 2 <= len(text) <= 12:
        return text
    return None


def _next_step(task: Task, processed: set[uuid.UUID]) -> TaskStep | None:
    """Lowest-ordinal not-yet-started step. Re-reads task.steps on each call so
    steps inserted by a mid-run replan are picked up by the execution loop."""
    pending = [
        s for s in sorted(task.steps, key=lambda x: x.ordinal)
        if s.id not in processed and s.state == "pending"
    ]
    return pending[0] if pending else None


def _screenshot_b64_from_url(task_id: uuid.UUID, url: str | None) -> str | None:
    """Map a /media screenshot URL back to its file and base64-encode it, so the
    re-planner can 'see' the frame the user selected. Basename + .png guard blocks
    path traversal; the cache-bust query is stripped."""
    if not url:
        return None
    import base64
    import os

    name = os.path.basename(url.split("?")[0].rstrip("/"))
    if not name.endswith(".png"):
        return None
    path = settings.media_path / str(task_id) / name
    if not path.exists():
        return None
    try:
        return base64.b64encode(path.read_bytes()).decode()
    except OSError:
        return None


async def _apply_replan(
    db: AsyncSession,
    task: Task,
    request: dict[str, Any],
    observations: list[str],
    task_browser: "TaskBrowser",
    *,
    model: str | None,
    notes: list[str] | None = None,
    lessons: str = "",
) -> None:
    """Replace the not-yet-started steps with a fresh plan built from the user's new
    instruction (and an optional selected screenshot). Completed steps are kept."""
    instruction = str(request.get("instruction") or "").strip()
    screenshot_url = request.get("screenshot_url")

    kept = [s for s in sorted(task.steps, key=lambda x: x.ordinal) if s.state != "pending"]
    max_ord = max((s.ordinal for s in kept), default=0)
    done_payload = [{"label": s.label, "state": s.state} for s in kept]

    try:
        current_url = await task_browser.current_url()
    except Exception:  # noqa: BLE001
        current_url = None
    image_b64 = _screenshot_b64_from_url(task.id, screenshot_url)

    await _log(db, task.id, "Re-planning from your guidance", level="info", layer="planner")
    try:
        state = AgentState(
            task_id=str(task.id), user_id=str(task.user_id),
            goal=task.goal, intent=task.intent or {}, lessons=lessons,
        )
        state = await run_replan(
            state,
            done_steps=done_payload,
            observations=observations,
            current_url=current_url,
            user_instruction=instruction,
            screenshot_b64=image_b64,
            notes=notes,
            model=model,
        )
    except Exception as exc:  # noqa: BLE001
        await _log(db, task.id, "Could not re-plan from that instruction",
                   level="warn", layer="planner", detail=str(exc)[:200])
        return

    # Drop the not-yet-started steps and append the new ones after the kept set.
    for s in [s for s in task.steps if s.state == "pending"]:
        await db.delete(s)
    await db.flush()
    for i, p in enumerate(state.plan, start=1):
        db.add(TaskStep(
            task_id=task.id, ordinal=max_ord + i,
            label=p.label, meta=p.meta, state="pending",
        ))
    await db.commit()
    await db.refresh(task, attribute_names=["steps"])
    await _publish_plan(task)
    await _log(
        db, task.id,
        f"New plan: {len(state.plan)} step(s) from your guidance",
        level="milestone", layer="planner",
        detail=instruction[:200] or None,
    )


async def _seed_steps_from_playbook(db: AsyncSession, task: Task, playbook_id_raw) -> bool:
    """Seed task_steps from a saved playbook's enabled steps (skipping the planner).
    Returns False if the playbook is missing or has no enabled steps."""
    try:
        pid = uuid.UUID(str(playbook_id_raw))
    except (ValueError, TypeError):
        return False
    loaded = await playbook_service.get_for_run(db, pid)
    if loaded is None:
        return False
    _pb, enabled = loaded
    if not enabled:
        return False
    task.steps.clear()
    await db.flush()
    for i, s in enumerate(enabled, start=1):
        db.add(TaskStep(task_id=task.id, ordinal=i, label=s.label, meta=s.kind, state="pending"))
    await db.commit()
    await db.refresh(task, attribute_names=["steps"])
    return True


async def _run(task_id: uuid.UUID) -> None:
    async with SessionLocal() as db:
        result = await db.execute(
            select(Task).where(Task.id == task_id).options(selectinload(Task.steps))
        )
        task = result.scalar_one_or_none()
        if task is None:
            log.warning("runtime: task %s vanished", task_id)
            return

        # Load user settings up-front: they drive the headless preference (and
        # later the approval rules), and the browser is built from them.
        settings_row = await db.execute(
            select(UserSettings).where(UserSettings.user_id == task.user_id)
        )
        user_settings = settings_row.scalar_one_or_none()
        headless = (
            user_settings.browser_headless
            if user_settings is not None
            else settings.browser_headless
        )
        preferred_model = (
            user_settings.preferred_model
            if user_settings is not None and user_settings.preferred_model
            else settings.openai_model_executor
        )
        if preferred_model == "gpt-4o-mini":
            preferred_model = "gpt-4o"
        browser_mode = (
            user_settings.browser_mode
            if user_settings is not None and user_settings.browser_mode
            else "browser"
        )
        browser_use_model = (
            user_settings.browser_use_model
            if user_settings is not None and user_settings.browser_use_model
            else settings.browser_use_model
        )
        if browser_use_model == "gpt-4o-mini":
            browser_use_model = "gpt-4o"
        browser_cdp_url = (
            user_settings.browser_cdp_url
            if user_settings is not None and user_settings.browser_cdp_url
            else settings.browser_use_cdp_url
        )
        browser_use_system_chrome = (
            user_settings.browser_use_system_chrome
            if user_settings is not None
            else settings.browser_use_system_chrome
        )
        browser_chrome_profile = (
            user_settings.browser_chrome_profile
            if user_settings is not None and user_settings.browser_chrome_profile
            else settings.browser_chrome_profile
        )
        browser_use_captcha_solver = (
            user_settings.browser_use_captcha_solver
            if user_settings is not None
            else settings.browser_use_captcha_solver
        )
        captcha_autosolve = (
            user_settings.captcha_autosolve
            if user_settings is not None
            else settings.captcha_autosolve
        )
        manual_assist_enabled = (
            user_settings.manual_assist_enabled
            if user_settings is not None
            else settings.manual_assist_enabled
        )
        autofill_enabled = (
            user_settings.autofill_enabled if user_settings is not None else True
        )
        auto_learn_enabled = (
            user_settings.auto_learn_enabled if user_settings is not None else True
        )
        use_vision_in_browser = browser_mode != "structured"

        task_browser = TaskBrowser(
            str(task.id),
            headless=headless,
            user_id=str(task.user_id),
            mode=browser_mode,
        )
        browser_use_adapter: BrowserUseAdapter | None = None
        browser_use_session_persisted = False
        browser_use_started = False
        browser_use_active_step_id: uuid.UUID | None = None
        browser_use_storage_state: dict | None = None
        browser_session_persisted = False
        browser_started = False

        # ---- structured action trace ----
        # Every concrete browser action (click/type/navigate/…) is recorded as a
        # task_actions row + streamed as an "action" event. `current_step_id` binds
        # each recorded action to the step in flight; the loops pass `record` and
        # the runtime fills the rest. Sensitive values are already redacted to
        # '•••' by the loops before they reach here.
        action_seq = 0
        current_step_id: uuid.UUID | None = None

        async def _record_action_cb(payload: dict[str, Any]) -> None:
            nonlocal action_seq
            action_seq += 1
            kind = str(payload.get("kind") or "action")[:40]
            target = str(payload["target"])[:300] if payload.get("target") else None
            value = str(payload["value"])[:500] if payload.get("value") else None
            url = str(payload["url"])[:1000] if payload.get("url") else None
            screenshot_url = payload.get("screenshot_url")
            ok = bool(payload.get("ok", True))
            row = TaskAction(
                task_id=task.id,
                step_id=current_step_id,
                ordinal=action_seq,
                kind=kind,
                target=target,
                value=value,
                url=url,
                screenshot_url=screenshot_url,
                ok=ok,
            )
            db.add(row)
            await db.flush()
            row_id = row.id
            await db.commit()
            await _publish(
                task.id,
                "action",
                {
                    "id": row_id,
                    "ordinal": action_seq,
                    "kind": kind,
                    "target": target,
                    "value": value,
                    "url": url,
                    "screenshot_url": screenshot_url,
                    "ok": ok,
                    "at": _now().isoformat(),
                },
            )

        # Browser-backed search/read for the reading layer: real Chrome passes the
        # bot-checks that block plain HTTP search engines, so research steps can
        # actually reach live sites. A screenshot is streamed after each so the
        # live preview follows along during research, not just interaction.
        async def _browser_search(query: str):
            adapter = await task_browser.ensure()
            ctrl = task_browser.controller
            if adapter is None or ctrl is None:
                return None
            page = await ctrl.search_serp(query)
            shot = await task_browser.screenshot()
            if shot:
                await _publish(task.id, "screenshot", {"url": shot})
            return page

        async def _browser_read(url: str):
            adapter = await task_browser.ensure()
            ctrl = task_browser.controller
            if adapter is None or ctrl is None:
                return None
            page = await ctrl.read(url)
            shot = await task_browser.screenshot()
            if shot:
                await _publish(task.id, "screenshot", {"url": shot})
            return page

        def _browser_use_options() -> dict[str, Any]:
            return {
                "model": browser_use_model,
                "cdp_url": browser_cdp_url,
                "use_system_chrome": browser_use_system_chrome,
                "chrome_profile": browser_chrome_profile,
                "storage_state": browser_use_storage_state,
                "captcha_solver": browser_use_captcha_solver,
                "max_steps": settings.browser_use_max_steps,
            }

        async def _browser_use_emit(text: str, detail: str | None = None) -> None:
            await _log(
                db,
                task.id,
                text,
                level="info",
                layer="browser_use",
                step_id=browser_use_active_step_id,
                detail=detail,
            )
            await _wait_if_paused(db, task)

        async def _browser_use_screenshot(url: str) -> None:
            await _publish(task.id, "screenshot", {"url": url})
            await _wait_if_paused(db, task)

        async def _browser_use_should_stop() -> bool:
            return is_cancelled(task.id) or is_paused(task.id)

        async def _ensure_browser_use_adapter() -> BrowserUseAdapter:
            nonlocal browser_use_adapter, browser_use_session_persisted
            if browser_use_adapter is None:
                browser_use_adapter = BrowserUseAdapter(
                    model=browser_use_model,
                    api_key=settings.openai_api_key,
                    browser_use_api_key=settings.browser_use_api_key,
                    headless=headless,
                    cdp_url=browser_cdp_url,
                    use_system_chrome=browser_use_system_chrome,
                    chrome_profile=browser_chrome_profile,
                    storage_state=browser_use_storage_state,
                    channel=settings.browser_channel,
                    proxy=settings.browser_proxy,
                    captcha_solver=browser_use_captcha_solver,
                    max_steps=settings.browser_use_max_steps,
                    task_id=str(task.id),
                    emit=_browser_use_emit,
                    on_screenshot=_browser_use_screenshot,
                    should_stop=_browser_use_should_stop,
                )
            if browser_use_adapter.available and not browser_use_session_persisted:
                db.add(
                    BrowserSession(
                        task_id=task.id,
                        user_id=task.user_id,
                        layer="browser_use",
                    )
                )
                await db.commit()
                browser_use_session_persisted = True
            return browser_use_adapter

        async def _run_browser_use_step(
            step: TaskStep,
            *,
            start_url: str | None,
            allow_irreversible: bool,
            observations: list[str],
        ):
            nonlocal browser_use_active_step_id, browser_use_started
            browser_use_active_step_id = step.id
            bu = await _ensure_browser_use_adapter()
            if not bu.available:
                return None
            browser_use_started = True
            result = await bu.run(
                StepInput(
                    goal=_browser_use_goal(
                        task.goal, step.label, observations,
                        lessons=site_lessons_text, notes=run_notes,
                    ),
                    url=start_url,
                    data={
                        "intent": task.intent or {},
                        "observations": observations,
                        "allow_irreversible": allow_irreversible,
                    },
                )
            )
            return result

        try:
            await _set_state(db, task, "planning")

            # A task created from a playbook replays its saved steps verbatim and
            # skips the planner — the proven sequence, just re-run.
            seeded_from_playbook = False
            playbook_id_raw = (task.intent or {}).get("playbook_id")
            if playbook_id_raw:
                seeded_from_playbook = await _seed_steps_from_playbook(
                    db, task, playbook_id_raw
                )

            if seeded_from_playbook:
                await _publish_plan(task)
                await _log(
                    db, task.id,
                    f"Loaded playbook · {len(task.steps)} step(s)",
                    level="milestone", layer="playbook",
                    detail=(task.intent.get("domain") or "") or None,
                )
            else:
                await _log(db, task.id, "Planner started", layer="planner")

                # Retrieve relevant user preferences to shape the plan.
                memories = await relevant_memories(db, task.user_id, task.goal)
                if memories:
                    await _log(
                        db, task.id,
                        f"Loaded {len(memories)} relevant preference(s) from memory",
                        layer="memory",
                        detail=" · ".join(m["tag"] for m in memories),
                    )

                # Recall what Argus learned about this site on past runs, so the
                # plan reuses what worked and avoids what failed.
                goal_lessons = await lessons_service.lessons_for_goal(
                    db, task.user_id, task.goal
                )
                if goal_lessons:
                    await _log(
                        db, task.id,
                        f"Recalled {len(goal_lessons)} lesson(s) from past runs here",
                        layer="memory",
                    )

                state = AgentState(
                    task_id=str(task.id), user_id=str(task.user_id), goal=task.goal,
                    memories=memories,
                    lessons=lessons_service.format_lessons(goal_lessons),
                )
                state = await run_planner(state, model=preferred_model)

                # Persist plan + intent
                task.intent = state.intent
                if state.intent.get("title"):
                    task.title = str(state.intent["title"])[:120]
                # Clear any previous steps (replanning safe)
                task.steps.clear()
                await db.flush()
                for p in state.plan:
                    db.add(
                        TaskStep(
                            task_id=task.id,
                            ordinal=p.ordinal,
                            label=p.label,
                            meta=p.meta,
                            state="pending",
                        )
                    )
                await db.commit()
                await db.refresh(task, attribute_names=["steps"])
                await _publish_plan(task)
                await _log(
                    db,
                    task.id,
                    f"Planned {len(state.plan)} steps",
                    level="milestone",
                    layer="planner",
                    detail=(state.intent.get("domain") or "") or None,
                )

            # Reuse a saved login session for this site, if Argus has one. This
            # is what keeps a connected account signed in across tasks.
            session_domain = _session_domain(task.intent)
            if session_domain:
                saved_state = await connected_sites_service.get_storage_state(
                    db, task.user_id, session_domain
                )
                if saved_state:
                    task_browser.use_storage_state(saved_state)
                    browser_use_storage_state = saved_state
                    await _log(
                        db, task.id,
                        f"Reusing your saved session for {session_domain}",
                        level="info", layer="agent_browser",
                    )

            # Recall what Argus learned about this site (Reflexion memory) and start
            # a within-run reflection log, so the executor skips known dead-ends and
            # never repeats the same failed approach within this run.
            site_lessons_text = ""
            if session_domain:
                domain_lessons = await lessons_service.lessons_for_domain(
                    db, task.user_id, session_domain
                )
                site_lessons_text = lessons_service.format_lessons(domain_lessons)
                if domain_lessons:
                    await _log(
                        db, task.id,
                        f"Recalled {len(domain_lessons)} lesson(s) about {session_domain}",
                        level="info", layer="memory",
                    )
            run_notes: list[str] = []

            await _set_state(db, task, "executing")

            approval_rules = (user_settings.approval_rules if user_settings else {}) or {}

            observations: list[str] = []
            deferred = 0
            browser_unavailable = False

            # Cart ledger: structured record of what's been added so add-to-cart
            # steps never duplicate an item or exceed the budget. Rehydrated from a
            # prior run so it survives a reload mid-task.
            cart_items: list[dict[str, Any]] = list((task.result or {}).get("cart") or [])
            cart_budget = _coerce_budget((task.intent or {}).get("budget"))
            cart_currency = (task.intent or {}).get("currency")

            processed_steps: set[uuid.UUID] = set()
            while True:
                # The in-memory cancel set is always current (the runtime's own
                # session would otherwise serve a stale, cached task row).
                if is_cancelled(task.id):
                    await _log(db, task.id, "Task cancelled; runtime stopping", level="warn")
                    return
                await _wait_if_paused(db, task)
                if is_cancelled(task.id):
                    await _log(db, task.id, "Task cancelled; runtime stopping", level="warn")
                    return

                # A paused user can hand Argus a new plan (optionally anchored to a
                # screenshot they picked). Apply it before choosing the next step so
                # the new steps run; already-completed steps are preserved.
                replan_req = _replan_requests.pop(task.id, None)
                if replan_req is not None:
                    await _apply_replan(
                        db, task, replan_req, observations, task_browser,
                        model=preferred_model, notes=run_notes, lessons=site_lessons_text,
                    )

                step = _next_step(task, processed_steps)
                if step is None:
                    break
                processed_steps.add(step.id)
                current_step_id = step.id

                # Approval gate (planner-tagged irreversible steps).
                pre_approved = False
                gate = needs_approval(step.label, step.meta or "", approval_rules)
                if gate is not None:
                    await _request_approval(db, task, step, gate.reason, gate.summary)
                    decision = await _wait_for_approval(task.id)
                    if is_cancelled(task.id):
                        await _log(db, task.id, "Task cancelled by user", level="warn")
                        return
                    if decision != "approved":
                        await _set_state(db, task, "failed")
                        task.error = f"approval {decision} for step {step.ordinal}"
                        await db.commit()
                        await _log(
                            db, task.id, f"Step {step.ordinal} {decision}; task aborted",
                            level="warn", step_id=step.id,
                        )
                        return
                    pre_approved = True
                    # Re-enter executing after approval.
                    await _set_state(db, task, "executing")

                step.state = "active"
                step.started_at = _now()
                step.attempts += 1
                await db.commit()
                await _publish_plan(task)
                await _log(db, task.id, step.label, level="info", step_id=step.id)

                result = await execute_step(
                    goal=task.goal,
                    step_label=step.label,
                    step_meta=step.meta or "",
                    intent=task.intent or {},
                    prior_observations=observations,
                    scrapling_enabled=getattr(settings, "enable_scrapling", True),
                    searcher=_browser_search,
                    reader=_browser_read,
                    model=preferred_model,
                )

                if result.needs_interaction:
                    # ----- Browser Use autonomous mode: run the browser-use
                    # agent first, like the upstream groceries/forms examples.
                    if browser_mode == "browser" and getattr(settings, "enable_browser_use", True):
                        bu_start_url = None if browser_use_started else _start_url_from_intent(task.intent)
                        await _log(
                            db,
                            task.id,
                            "Running autonomous Browser Use agent",
                            level="info",
                            layer="browser_use",
                            step_id=step.id,
                        )
                        bu_result = await _run_browser_use_step(
                            step,
                            start_url=bu_start_url,
                            allow_irreversible=pre_approved,
                            observations=observations,
                        )
                        if bu_result is not None and bu_result.error == "approval_needed":
                            await _request_approval(
                                db,
                                task,
                                step,
                                "irreversible",
                                {
                                    "step_label": step.label,
                                    "detail": bu_result.observed.get("result"),
                                },
                            )
                            decision = await _wait_for_approval(task.id)
                            if is_cancelled(task.id):
                                await _log(db, task.id, "Task cancelled by user", level="warn")
                                return
                            if decision != "approved":
                                await _set_state(db, task, "failed")
                                task.error = f"approval {decision} for step {step.ordinal}"
                                await db.commit()
                                await _log(
                                    db,
                                    task.id,
                                    f"Step {step.ordinal} {decision}; task aborted",
                                    level="warn",
                                    step_id=step.id,
                                )
                                return
                            await _set_state(db, task, "executing")
                            bu_result = await _run_browser_use_step(
                                step,
                                start_url=None,
                                allow_irreversible=True,
                                observations=observations,
                            )

                        if bu_result is not None and bu_result.ok:
                            obs = str(
                                bu_result.observed.get("result")
                                or f"Completed via Browser Use: {step.label}"
                            )
                            observations.append(obs)
                            step.state = "done"
                            step.layer_used = "browser_use"
                            step.ended_at = _now()
                            await db.commit()
                            await _publish_plan(task)
                            await _log(
                                db,
                                task.id,
                                obs,
                                level="milestone",
                                step_id=step.id,
                                layer="browser_use",
                            )
                            continue

                        if bu_result is None:
                            await _log(
                                db,
                                task.id,
                                "Browser Use unavailable — falling back to Argus browser loop",
                                level="warn",
                                layer="browser_use",
                                step_id=step.id,
                            )
                        else:
                            await _log(
                                db,
                                task.id,
                                f"Browser Use did not finish this step: {bu_result.error or 'unknown'}",
                                level="warn",
                                layer="browser_use",
                                step_id=step.id,
                                detail=str(bu_result.observed.get("result") or "")[:400] or None,
                            )

                    # ----- L2 Agent Browser: real structured interaction -----
                    # If we already know the browser can't start, defer immediately
                    # rather than re-running the recovery dance for every step.
                    adapter = None if browser_unavailable else await task_browser.ensure()
                    if adapter is None:
                        recovered, rec_obs = (False, "")
                        if not browser_unavailable:
                            # First interaction step: try the autonomous fallback once.
                            recovered, rec_obs = await _recover(
                                db,
                                task,
                                step,
                                "browser_unavailable",
                                observations,
                                task_browser,
                                model=preferred_model,
                                browser_use_options=_browser_use_options(),
                                manual_assist_enabled=manual_assist_enabled,
                                record=_record_action_cb,
                                lessons=site_lessons_text,
                                notes=run_notes,
                            )
                            if not recovered:
                                browser_unavailable = True
                        if recovered:
                            observations.append(rec_obs)
                            step.state = "done"
                            step.layer_used = "browser_use"
                        else:
                            deferred += 1
                            step.state = "skipped"
                            step.layer_used = "agent_browser"
                        step.ended_at = _now()
                        await db.commit()
                        await _publish_plan(task)
                        if step.state == "skipped":
                            await _log(
                                db, task.id,
                                f"Step {step.ordinal} needs a browser — deferred. "
                                "Install it once with "
                                "`python -m playwright install chromium`, then re-run.",
                                level="warn", step_id=step.id, layer="agent_browser",
                            )
                        continue

                    if not browser_session_persisted:
                        db.add(BrowserSession(
                            task_id=task.id, user_id=task.user_id, layer="agent_browser",
                        ))
                        await db.commit()
                        browser_session_persisted = True

                    start_url = None if browser_started else _start_url_from_intent(task.intent)
                    browser_started = True

                    async def _emit(text: str, detail: str | None = None, _sid=step.id) -> None:
                        await _log(
                            db, task.id, text, level="info",
                            layer="agent_browser", step_id=_sid, detail=detail,
                        )
                        shot = await task_browser.screenshot()
                        if shot:
                            await _publish(task.id, "screenshot", {"url": shot})
                        await _wait_if_paused(db, task)

                    # One entry point for this step's interaction calls so every
                    # invocation (initial + each gate resume) carries the same cart
                    # ledger / budget context without repeating the kwargs.
                    async def _interact(**overrides):
                        base = dict(
                            adapter=adapter, goal=task.goal, step_label=step.label,
                            intent=task.intent or {}, prior_observations=observations,
                            emit=_emit, controller=task_browser.controller,
                            use_vision=use_vision_in_browser, model=preferred_model,
                            record=_record_action_cb,
                            cart_ledger=cart_items, budget=cart_budget,
                            currency=cart_currency,
                        )
                        base.update(overrides)
                        return await run_interaction(**base)

                    inter = await _interact(
                        adapter=adapter, goal=task.goal, step_label=step.label,
                        intent=task.intent or {}, prior_observations=observations,
                        emit=_emit, start_url=start_url, allow_irreversible=pre_approved,
                        controller=task_browser.controller,
                        use_vision=use_vision_in_browser,
                        model=preferred_model,
                        record=_record_action_cb,
                    )

                    # Resolve interactive gates the loop can raise mid-step —
                    # sign-in, one-time passcode, CAPTCHA, or an irreversible
                    # action — in whatever order the site presents them, then
                    # resume. Bounded so a misbehaving page can never park forever.
                    captcha_tries = 0
                    for _gate in range(6):
                        domain = (
                            _start_url_from_intent(task.intent)
                            or (task.intent or {}).get("domain")
                            or "this site"
                        )

                        # ----- sign-in form: fill credentials (ask once), resume -----
                        if inter.needs_credentials:
                            if not manual_assist_enabled:
                                await _log(
                                    db,
                                    task.id,
                                    "Sign-in is required but manual assist is disabled",
                                    level="warn",
                                    layer="human",
                                    step_id=step.id,
                                )
                                break
                            vault_domain = _session_domain(task.intent)
                            creds = _task_credentials.get(task.id)
                            just_obtained = False
                            # 1) Try the vault first — sign in without asking.
                            if creds is None and autofill_enabled and vault_domain:
                                saved = await vault_service.login_for_autofill(
                                    db, task.user_id, vault_domain
                                )
                                if saved and saved.get("password"):
                                    creds = saved
                                    _task_credentials[task.id] = creds
                                    just_obtained = True
                                    await _log(
                                        db, task.id,
                                        f"Autofilled your saved sign-in for {vault_domain} "
                                        "from your vault",
                                        level="info", layer="vault", step_id=step.id,
                                    )
                            # 2) Otherwise ask, then auto-save for next time.
                            if creds is None:
                                await _set_state(db, task, "waiting_for_user")
                                _pending_prompt[task.id] = {
                                    "kind": "credentials",
                                    "step_id": str(step.id), "domain": str(domain),
                                }
                                await _publish(task.id, "credentials", {
                                    "step_id": str(step.id), "domain": str(domain),
                                })
                                await _log(
                                    db, task.id,
                                    "Sign-in required — requesting your credentials securely",
                                    level="milestone", layer="human", step_id=step.id,
                                )
                                creds = await wait_for_credentials(task.id)
                                if creds is None or is_cancelled(task.id):
                                    await _log(db, task.id, "Task cancelled by user", level="warn")
                                    return
                                _task_credentials[task.id] = creds
                                just_obtained = True
                                await _set_state(db, task, "executing")
                                if autofill_enabled and vault_domain:
                                    await vault_service.save_login(
                                        db, task.user_id, vault_domain, creds
                                    )
                                    await _log(
                                        db, task.id,
                                        f"Saved this sign-in for {vault_domain} to your "
                                        "vault (encrypted)",
                                        level="info", layer="vault", step_id=step.id,
                                    )
                            elif not just_obtained:
                                # Already have them — refill silently (the form likely
                                # reloaded), don't pester the user again.
                                await _log(
                                    db, task.id,
                                    "Re-entering the credentials you already provided",
                                    level="info", layer="agent_browser", step_id=step.id,
                                )
                            if inter.email_ref and creds.get("email"):
                                await adapter.type_text(inter.email_ref, creds["email"])
                            if inter.password_ref and creds.get("password"):
                                await adapter.type_text(inter.password_ref, creds["password"])
                            await _log(db, task.id, "Entered your credentials",
                                       level="info", layer="agent_browser", step_id=step.id)
                            await _record_action_cb(
                                {"kind": "type", "target": f"Sign-in ({domain})",
                                 "value": REDACTED, "ok": True}
                            )
                            shot = await task_browser.screenshot()
                            if shot:
                                await _publish(task.id, "screenshot", {"url": shot})
                            inter = await _interact(
                                adapter=adapter, goal=task.goal, step_label=step.label,
                                intent=task.intent or {}, prior_observations=observations,
                                emit=_emit, start_url=None, allow_irreversible=False,
                                controller=task_browser.controller,
                                use_vision=use_vision_in_browser,
                                model=preferred_model,
                                record=_record_action_cb,
                            )
                            continue

                        # ----- personal/sensitive fields: ask the user, fill, resume -----
                        if inter.needs_info:
                            if not manual_assist_enabled:
                                await _log(
                                    db,
                                    task.id,
                                    "Personal details are required but manual assist is disabled",
                                    level="warn",
                                    layer="human",
                                    step_id=step.id,
                                )
                                break
                            fields = inter.info_fields or []
                            values = None
                            # Fill from the saved identity profile without asking, but
                            # only when every requested field is covered.
                            if autofill_enabled and fields:
                                identity = await vault_service.identity_for_autofill(
                                    db, task.user_id
                                )
                                if identity:
                                    auto = {
                                        f["ref"]: identity[f["kind"]]
                                        for f in fields
                                        if identity.get(f["kind"])
                                    }
                                    if len(auto) == len(fields):
                                        values = auto
                                        await _log(
                                            db, task.id,
                                            "Autofilled your saved details from your vault",
                                            level="info", layer="vault", step_id=step.id,
                                        )
                            if values is None:
                                await _set_state(db, task, "waiting_for_user")
                                _info_fields_payload = [
                                    {"id": f["ref"], "label": f["label"], "kind": f["kind"]}
                                    for f in fields
                                ]
                                _pending_prompt[task.id] = {
                                    "kind": "info",
                                    "step_id": str(step.id),
                                    "domain": str(domain),
                                    "fields": _info_fields_payload,
                                }
                                await _publish(task.id, "info_request", {
                                    "step_id": str(step.id),
                                    "domain": str(domain),
                                    "fields": _info_fields_payload,
                                })
                                labels = ", ".join(f["label"] for f in fields) or "some details"
                                await _log(
                                    db, task.id,
                                    f"Personal details needed — asking you to provide: {labels}",
                                    level="milestone", layer="human", step_id=step.id,
                                )
                                values = await wait_for_info(task.id)
                                if values is None or is_cancelled(task.id):
                                    await _log(db, task.id, "Task cancelled by user", level="warn")
                                    return
                                await _set_state(db, task, "executing")
                                # Auto-save the user's details (keyed by kind) for reuse.
                                if autofill_enabled:
                                    by_kind = {
                                        f["kind"]: values.get(f["ref"])
                                        for f in fields
                                        if values.get(f["ref"])
                                    }
                                    if by_kind:
                                        await vault_service.save_identity(
                                            db, task.user_id, by_kind
                                        )
                                        await _log(
                                            db, task.id,
                                            "Saved these details to your vault (encrypted)",
                                            level="info", layer="vault", step_id=step.id,
                                        )
                            for f in fields:
                                val = values.get(f["ref"])
                                if val:
                                    await adapter.type_text(f["ref"], val)
                            await _log(db, task.id, "Entered the details you provided",
                                       level="info", layer="agent_browser", step_id=step.id)
                            await _record_action_cb(
                                {"kind": "type", "target": f"Personal details ({domain})",
                                 "value": REDACTED, "ok": True}
                            )
                            shot = await task_browser.screenshot()
                            if shot:
                                await _publish(task.id, "screenshot", {"url": shot})
                            inter = await _interact(
                                adapter=adapter, goal=task.goal, step_label=step.label,
                                intent=task.intent or {}, prior_observations=observations,
                                emit=_emit, start_url=None, allow_irreversible=False,
                                controller=task_browser.controller,
                                use_vision=use_vision_in_browser,
                                model=preferred_model,
                                record=_record_action_cb,
                            )
                            continue

                        # ----- 2FA / OTP page: ask for the code, fill, resume -----
                        if inter.needs_otp:
                            if not manual_assist_enabled:
                                await _log(
                                    db,
                                    task.id,
                                    "One-time passcode is required but manual assist is disabled",
                                    level="warn",
                                    layer="human",
                                    step_id=step.id,
                                )
                                break
                            await _set_state(db, task, "waiting_for_user")
                            _pending_prompt[task.id] = {
                                "kind": "otp",
                                "step_id": str(step.id), "domain": str(domain),
                            }
                            await _publish(task.id, "otp", {
                                "step_id": str(step.id), "domain": str(domain),
                            })
                            await _log(
                                db, task.id,
                                "One-time passcode required — waiting for your code",
                                level="milestone", layer="human", step_id=step.id,
                            )
                            code = await wait_for_otp(task.id)
                            if code is None or is_cancelled(task.id):
                                await _log(db, task.id, "Task cancelled by user", level="warn")
                                return
                            await _set_state(db, task, "executing")
                            if inter.otp_ref and code:
                                await adapter.type_text(inter.otp_ref, code)
                            await _log(db, task.id, "Entered your one-time passcode (not stored)",
                                       level="info", layer="agent_browser", step_id=step.id)
                            await _record_action_cb(
                                {"kind": "type", "target": f"One-time passcode ({domain})",
                                 "value": REDACTED, "ok": True}
                            )
                            shot = await task_browser.screenshot()
                            if shot:
                                await _publish(task.id, "screenshot", {"url": shot})
                            inter = await _interact(
                                adapter=adapter, goal=task.goal, step_label=step.label,
                                intent=task.intent or {}, prior_observations=observations,
                                emit=_emit, start_url=None, allow_irreversible=False,
                                controller=task_browser.controller,
                                use_vision=use_vision_in_browser,
                                model=preferred_model,
                                record=_record_action_cb,
                            )
                            continue

                        # ----- CAPTCHA image: try once automatically, else show the user -----
                        if inter.needs_captcha:
                            # One automatic attempt; if it didn't read (or it read
                            # wrong and the CAPTCHA came back), hand it to the user.
                            if captcha_autosolve and captcha_tries == 0:
                                captcha_tries += 1
                                solved = await _autosolve_captcha(
                                    task_browser, model=preferred_model
                                )
                                if solved and inter.captcha_ref:
                                    await adapter.type_text(inter.captcha_ref, solved)
                                    await _log(
                                        db, task.id,
                                        "Read the CAPTCHA automatically and entered it",
                                        level="info", layer="vision", step_id=step.id,
                                    )
                                    await _record_action_cb(
                                        {"kind": "type", "target": f"CAPTCHA auto-read ({domain})",
                                         "value": solved, "ok": True}
                                    )
                                    shot = await task_browser.screenshot()
                                    if shot:
                                        await _publish(task.id, "screenshot", {"url": shot})
                                    inter = await _interact(
                                        adapter=adapter, goal=task.goal, step_label=step.label,
                                        intent=task.intent or {}, prior_observations=observations,
                                        emit=_emit, start_url=None, allow_irreversible=False,
                                        controller=task_browser.controller,
                                        use_vision=use_vision_in_browser,
                                        model=preferred_model,
                                    )
                                    continue
                            # Auto-solve unavailable or already tried — show the user the CAPTCHA.
                            if not manual_assist_enabled:
                                await _log(
                                    db,
                                    task.id,
                                    "CAPTCHA is required but manual assist is disabled",
                                    level="warn",
                                    layer="human",
                                    step_id=step.id,
                                )
                                break
                            await _set_state(db, task, "waiting_for_user")
                            shot = await task_browser.screenshot()
                            _pending_prompt[task.id] = {
                                "kind": "captcha",
                                "step_id": str(step.id), "domain": str(domain), "screenshot": shot,
                            }
                            await _publish(task.id, "captcha", {
                                "step_id": str(step.id), "domain": str(domain), "screenshot": shot,
                            })
                            await _log(db, task.id, "CAPTCHA needs solving — showing it to you",
                                       level="milestone", layer="human", step_id=step.id)
                            answer = await wait_for_captcha(task.id)
                            if answer is None or is_cancelled(task.id):
                                await _log(db, task.id, "Task cancelled by user", level="warn")
                                return
                            await _set_state(db, task, "executing")
                            if inter.captcha_ref and answer:
                                await adapter.type_text(inter.captcha_ref, answer)
                            await _log(db, task.id, "Entered the CAPTCHA you provided",
                                       level="info", layer="agent_browser", step_id=step.id)
                            await _record_action_cb(
                                {"kind": "type", "target": f"CAPTCHA ({domain})",
                                 "value": answer or "", "ok": True}
                            )
                            shot = await task_browser.screenshot()
                            if shot:
                                await _publish(task.id, "screenshot", {"url": shot})
                            inter = await _interact(
                                adapter=adapter, goal=task.goal, step_label=step.label,
                                intent=task.intent or {}, prior_observations=observations,
                                emit=_emit, start_url=None, allow_irreversible=False,
                                controller=task_browser.controller,
                                use_vision=use_vision_in_browser,
                                model=preferred_model,
                                record=_record_action_cb,
                            )
                            continue

                        # ----- irreversible action discovered: ask, then resume -----
                        if inter.needs_approval:
                            await _request_approval(
                                db, task, step, "irreversible",
                                {"step_label": step.label, "detail": inter.approval_reason},
                            )
                            decision = await _wait_for_approval(task.id)
                            if is_cancelled(task.id):
                                await _log(db, task.id, "Task cancelled by user", level="warn")
                                return
                            if decision != "approved":
                                await _set_state(db, task, "failed")
                                task.error = f"approval {decision} for step {step.ordinal}"
                                await db.commit()
                                await _log(
                                    db, task.id, f"Step {step.ordinal} {decision}; task aborted",
                                    level="warn", step_id=step.id,
                                )
                                return
                            await _set_state(db, task, "executing")
                            inter = await _interact(
                                adapter=adapter, goal=task.goal, step_label=step.label,
                                intent=task.intent or {}, prior_observations=observations,
                                emit=_emit, start_url=None, allow_irreversible=True,
                                controller=task_browser.controller,
                                use_vision=use_vision_in_browser,
                                model=preferred_model,
                                record=_record_action_cb,
                            )
                            continue

                        break

                    # Fold whatever this step added into the cart ledger (deduped +
                    # budget-checked) so later add-to-cart steps see the true cart
                    # state. Persisted to the task so it survives a reload.
                    added = (inter.data or {}).get("added_items") or []
                    if added:
                        newly = _merge_cart(cart_items, added, cart_budget)
                        if newly:
                            task.result = {**(task.result or {}), "cart": cart_items}
                            await db.commit()
                            names = ", ".join(c["name"] for c in newly)
                            subtotal = int(sum(c.get("price") or 0 for c in cart_items))
                            await _log(
                                db, task.id,
                                f"Cart now holds {len(cart_items)} item(s) "
                                f"(₹{subtotal}): added {names}",
                                level="info", layer="agent_browser", step_id=step.id,
                            )

                    # L2 stalled -> Recovery agent escalates to L3 (Browser Use).
                    used_layer = "agent_browser"
                    final_obs = inter.observation
                    if not inter.ok:
                        cause = str(
                            (inter.data or {}).get("cause")
                            or ("action_limit" if inter.actions_taken >= MAX_ACTIONS else "no_progress")
                        )
                        # Within-run reflection: remember this approach didn't work,
                        # so later steps / re-plans / Browser Use don't repeat it.
                        run_notes.append(
                            f"'{step.label}' stalled with the structured click ({cause})."
                        )
                        recovered, rec_obs = await _recover(
                            db,
                            task,
                            step,
                            cause,
                            observations,
                            task_browser,
                            model=preferred_model,
                            browser_use_options=_browser_use_options(),
                            manual_assist_enabled=manual_assist_enabled,
                            record=_record_action_cb,
                            lessons=site_lessons_text,
                            notes=run_notes,
                        )
                        if recovered:
                            inter.ok = True
                            used_layer = "browser_use"
                            final_obs = rec_obs
                            run_notes.append(
                                f"'{step.label}' only worked via Browser Use, not the "
                                "structured click."
                            )

                    if final_obs:
                        observations.append(final_obs)
                    step.state = "done" if inter.ok else "failed"
                    step.layer_used = used_layer
                    step.ended_at = _now()
                    await db.commit()
                    await _publish_plan(task)
                    await _log(
                        db, task.id,
                        final_obs or f"Step {step.ordinal} complete",
                        level="milestone" if inter.ok else "warn",
                        step_id=step.id, layer=used_layer,
                    )
                    continue

                if result.observation:
                    observations.append(result.observation)
                step.state = "done" if result.ok else "failed"
                step.layer_used = result.layer
                step.ended_at = _now()
                await db.commit()
                await _publish_plan(task)
                await _log(
                    db,
                    task.id,
                    result.observation or f"Step {step.ordinal} complete",
                    level="milestone" if result.ok else "warn",
                    step_id=step.id,
                    layer=result.layer,
                    detail=result.detail,
                    data=result.data or None,
                )

            # Synthesise a direct answer from everything gathered, and decide
            # honestly whether the goal was actually met.
            synth = await _synthesize_answer(task.goal, observations, model=preferred_model)
            answer = str(synth.get("answer") or "").strip()
            answered = bool(synth.get("answered")) and bool(answer)

            done = sum(1 for s in task.steps if s.state == "done")
            did_action = any(
                s.state == "done"
                and s.layer_used in ("agent_browser", "browser_use", "vision")
                for s in task.steps
            )
            summary = f"Completed {done}/{len(task.steps)} steps"
            if deferred:
                summary += f" · {deferred} interaction step(s) deferred to the acting layer"
            task.result = {
                "summary": summary,
                "answer": answer or None,
                "observations": observations,
                "deferred": deferred,
                "intent": task.intent,
                "cart": cart_items,
            }

            # Never report a hollow success: a pure read/research task that
            # gathered nothing usable is a failure, not a completion.
            read_only = not did_action and deferred == 0
            if done == 0 or (read_only and not answered):
                task.error = "Could not gather enough information to answer the goal."
                await db.commit()
                await _set_state(db, task, "failed")
                await _log(
                    db, task.id,
                    answer
                    or "Couldn't find enough information to answer this. The site may be "
                       "blocking automated reads, or the task needs sign-in.",
                    level="warn",
                )
            else:
                await _set_state(db, task, "completed")
                await _log(db, task.id, answer or summary, level="milestone")
                # Learn durable preferences from a successful task for next time.
                if auto_learn_enabled:
                    try:
                        learned = await learning_service.learn_from_task(
                            db, task.user_id, task.goal, observations,
                            model=preferred_model,
                        )
                        if learned:
                            await _log(
                                db, task.id,
                                f"Learned {learned} new preference(s) for next time",
                                level="info", layer="memory",
                            )
                    except Exception:  # noqa: BLE001
                        pass

            # Reflexion: distil reusable lessons about this SITE from the run
            # (success OR failure) so future runs here are smarter and shorter.
            if auto_learn_enabled and session_domain:
                try:
                    n = await lessons_service.reflect_and_store(
                        db, task.user_id, session_domain, task.goal,
                        _build_run_summary(task, run_notes, answered, task.error),
                        model=preferred_model,
                    )
                    if n:
                        await _log(
                            db, task.id,
                            f"Learned {n} lesson(s) about {session_domain} for next time",
                            level="info", layer="memory",
                        )
                except Exception:  # noqa: BLE001
                    pass

        except Exception as exc:  # noqa: BLE001
            log.exception("runtime crashed for task %s", task_id)
            try:
                task.error = str(exc)[:1000]
                await _set_state(db, task, "failed")
                await _log(db, task.id, "Runtime error", level="error", detail=str(exc)[:400])
            except Exception:  # noqa: BLE001
                pass
        finally:
            # Drop the in-memory credentials and any pending prompt for this task.
            _task_credentials.pop(task.id, None)
            _pending_prompt.pop(task.id, None)
            if browser_use_adapter is not None:
                try:
                    storage = await browser_use_adapter.storage_state()
                    current_url = await browser_use_adapter.current_url()
                    row = await db.execute(
                        select(BrowserSession)
                        .where(
                            BrowserSession.task_id == task.id,
                            BrowserSession.layer == "browser_use",
                        )
                        .order_by(BrowserSession.created_at.desc())
                    )
                    session = row.scalars().first()
                    if session is not None:
                        session.storage_state = storage or None
                        session.current_url = current_url or None
                        session.last_screenshot_url = browser_use_adapter.last_screenshot_url
                        session.closed_at = _now()
                        await db.commit()
                    save_domain = _session_domain(task.intent)
                    if save_domain and storage and storage.get("cookies"):
                        await connected_sites_service.save_session(
                            db, task.user_id, save_domain, storage
                        )
                except Exception:  # noqa: BLE001
                    pass
                await browser_use_adapter.close()
            # Persist browser session state and release chromium.
            if task_browser.started:
                try:
                    storage = await task_browser.storage_state()
                    current_url = await task_browser.current_url()
                    last_shot = await task_browser.screenshot()
                    row = await db.execute(
                        select(BrowserSession)
                        .where(BrowserSession.task_id == task.id)
                        .order_by(BrowserSession.created_at.desc())
                    )
                    session = row.scalars().first()
                    if session is not None:
                        session.storage_state = storage or None
                        session.current_url = current_url or None
                        session.last_screenshot_url = last_shot
                        session.closed_at = _now()
                        await db.commit()
                    # Save the login session against the connected account so the
                    # next task on this site starts already signed in. Only when
                    # there are real cookies, so we never clobber a good session
                    # with an anonymous one.
                    save_domain = _session_domain(task.intent)
                    if save_domain and storage and storage.get("cookies"):
                        await connected_sites_service.save_session(
                            db, task.user_id, save_domain, storage
                        )
                except Exception:  # noqa: BLE001
                    pass
                await task_browser.close()


# ---------------------- approvals ----------------------

_pending_approvals: dict[uuid.UUID, asyncio.Event] = {}
_approval_results: dict[uuid.UUID, str] = {}


async def _request_approval(
    db: AsyncSession, task: Task, step: TaskStep, reason: str, summary: dict[str, Any]
) -> None:
    summary = dict(summary)
    summary.setdefault("step_label", step.label)
    summary.setdefault("step_ordinal", step.ordinal)
    summary.setdefault("intent", task.intent)
    approval = Approval(
        task_id=task.id, step_id=step.id, reason=reason, summary=summary, state="pending"
    )
    db.add(approval)
    await db.flush()
    await db.commit()
    _pending_approvals[approval.id] = asyncio.Event()
    _approval_task[approval.id] = task.id

    task.state = "waiting_for_approval"
    await db.commit()
    await _publish(
        task.id,
        "approval",
        {
            "id": str(approval.id),
            "step_id": str(step.id),
            "reason": reason,
            "summary": summary,
            "state": "pending",
        },
    )
    await _publish(task.id, "state", {"state": "waiting_for_approval"})
    await _log(
        db,
        task.id,
        f"Approval required: {reason}",
        level="milestone",
        layer="approval",
        step_id=step.id,
        data={"approval_id": str(approval.id)},
    )


async def _wait_for_approval(task_id: uuid.UUID) -> str:
    # Find the most recent pending approval for this task.
    async with SessionLocal() as db:
        result = await db.execute(
            select(Approval)
            .where(Approval.task_id == task_id, Approval.state == "pending")
            .order_by(Approval.created_at.desc())
        )
        approval = result.scalars().first()
        if approval is None:
            return "approved"

    event = _pending_approvals.setdefault(approval.id, asyncio.Event())
    await event.wait()
    return _approval_results.pop(approval.id, "approved")


def resolve_approval(approval_id: uuid.UUID, decision: str) -> None:
    """Called from the HTTP layer when the user approves or rejects."""
    _approval_results[approval_id] = decision
    event = _pending_approvals.get(approval_id)
    if event:
        event.set()


# ---------------------- human assist (L4) ----------------------

_pending_user_inputs: dict[uuid.UUID, asyncio.Event] = {}
_user_input_results: dict[uuid.UUID, str] = {}

# Tracks approval -> task and tasks the user has asked to cancel, so a cancel
# can unblock a runtime that is parked waiting for approval or human input.
_approval_task: dict[uuid.UUID, uuid.UUID] = {}
_cancelled: set[uuid.UUID] = set()
_paused: set[uuid.UUID] = set()
_pause_events: dict[uuid.UUID, asyncio.Event] = {}
# Pending "re-plan from here" requests submitted while a task is paused.
_replan_requests: dict[uuid.UUID, dict[str, Any]] = {}
# The human prompt a task is currently waiting on (otp/credentials/captcha/info/
# assist), so the UI can re-open it after an accidental dismissal OR a page
# reload — the prompt event itself is ephemeral, this survives.
_pending_prompt: dict[uuid.UUID, dict[str, Any]] = {}


def pending_prompt(task_id: uuid.UUID) -> dict[str, Any] | None:
    return _pending_prompt.get(task_id)

CANCEL_SENTINEL = "__cancelled__"


def submit_user_input(task_id: uuid.UUID, text: str) -> None:
    """Called from the HTTP layer when the user answers a human-assist question."""
    _user_input_results[task_id] = text
    _pending_prompt.pop(task_id, None)
    event = _pending_user_inputs.get(task_id)
    if event:
        event.set()


async def wait_for_user_input(task_id: uuid.UUID) -> str:
    event = _pending_user_inputs.setdefault(task_id, asyncio.Event())
    await event.wait()
    _pending_user_inputs.pop(task_id, None)
    if task_id in _cancelled:
        return CANCEL_SENTINEL
    return _user_input_results.pop(task_id, "")


# ---------------------- credentials (kept in memory only, never logged) ------

_pending_credentials: dict[uuid.UUID, asyncio.Event] = {}
_credential_results: dict[uuid.UUID, dict[str, str]] = {}

# Credentials provided during this task, kept in memory so that a re-login (e.g.
# after a wrong CAPTCHA reloads the form) refills automatically instead of asking
# the user again. Cleared when the task ends.
_task_credentials: dict[uuid.UUID, dict[str, str]] = {}


def submit_credentials(task_id: uuid.UUID, email: str, password: str) -> None:
    _credential_results[task_id] = {"email": email, "password": password}
    _pending_prompt.pop(task_id, None)
    event = _pending_credentials.get(task_id)
    if event:
        event.set()


async def wait_for_credentials(task_id: uuid.UUID) -> dict[str, str] | None:
    event = _pending_credentials.setdefault(task_id, asyncio.Event())
    await event.wait()
    _pending_credentials.pop(task_id, None)
    if task_id in _cancelled:
        return None
    return _credential_results.pop(task_id, None)


# ---------------------- one-time passcodes (in memory only, never logged) ----

_pending_otp: dict[uuid.UUID, asyncio.Event] = {}
_otp_results: dict[uuid.UUID, str] = {}


def submit_otp(task_id: uuid.UUID, code: str) -> None:
    _otp_results[task_id] = code
    _pending_prompt.pop(task_id, None)
    event = _pending_otp.get(task_id)
    if event:
        event.set()


async def wait_for_otp(task_id: uuid.UUID) -> str | None:
    event = _pending_otp.setdefault(task_id, asyncio.Event())
    await event.wait()
    _pending_otp.pop(task_id, None)
    if task_id in _cancelled:
        return None
    return _otp_results.pop(task_id, None)


# ---------------------- personal details (in memory only, never logged) -------
# Sensitive form values (name, email, phone, address, card, …) the user types
# when Argus refuses to auto-fill. Keyed by task; mapped element-ref -> value.

_pending_info: dict[uuid.UUID, asyncio.Event] = {}
_info_results: dict[uuid.UUID, dict[str, str]] = {}


def submit_info(task_id: uuid.UUID, values: dict[str, str]) -> None:
    _info_results[task_id] = values
    _pending_prompt.pop(task_id, None)
    event = _pending_info.get(task_id)
    if event:
        event.set()


async def wait_for_info(task_id: uuid.UUID) -> dict[str, str] | None:
    event = _pending_info.setdefault(task_id, asyncio.Event())
    await event.wait()
    _pending_info.pop(task_id, None)
    if task_id in _cancelled:
        return None
    return _info_results.pop(task_id, None)


# ---------------------- CAPTCHA answers (in memory only, never logged) --------

_pending_captcha: dict[uuid.UUID, asyncio.Event] = {}
_captcha_results: dict[uuid.UUID, str] = {}


def submit_captcha(task_id: uuid.UUID, text: str) -> None:
    _captcha_results[task_id] = text
    _pending_prompt.pop(task_id, None)
    event = _pending_captcha.get(task_id)
    if event:
        event.set()


async def wait_for_captcha(task_id: uuid.UUID) -> str | None:
    event = _pending_captcha.setdefault(task_id, asyncio.Event())
    await event.wait()
    _pending_captcha.pop(task_id, None)
    if task_id in _cancelled:
        return None
    return _captcha_results.pop(task_id, None)


def is_cancelled(task_id: uuid.UUID) -> bool:
    return task_id in _cancelled


def is_paused(task_id: uuid.UUID) -> bool:
    return task_id in _paused


def pause_task(task_id: uuid.UUID) -> None:
    if task_id in _cancelled:
        return
    _paused.add(task_id)
    event = _pause_events.setdefault(task_id, asyncio.Event())
    event.clear()


def resume_task(task_id: uuid.UUID) -> None:
    _paused.discard(task_id)
    event = _pause_events.get(task_id)
    if event:
        event.set()


def submit_replan(
    task_id: uuid.UUID, instruction: str, screenshot_url: str | None = None
) -> None:
    """Queue a new plan from the user and wake the task so it applies it at the
    next step boundary. Works whether the task is paused or still running."""
    _replan_requests[task_id] = {
        "instruction": instruction,
        "screenshot_url": screenshot_url,
    }
    resume_task(task_id)


def cancel_task(task_id: uuid.UUID) -> None:
    """Mark a task cancelled and wake any wait it is parked on."""
    _cancelled.add(task_id)
    resume_task(task_id)
    _replan_requests.pop(task_id, None)
    _pending_prompt.pop(task_id, None)
    _task_credentials.pop(task_id, None)
    # Wake a pending human-assist wait.
    ev = _pending_user_inputs.get(task_id)
    if ev:
        ev.set()
    # Wake a pending credentials wait.
    cev = _pending_credentials.get(task_id)
    if cev:
        cev.set()
    # Wake a pending OTP wait.
    oev = _pending_otp.get(task_id)
    if oev:
        oev.set()
    # Wake a pending personal-details wait.
    iev = _pending_info.get(task_id)
    if iev:
        iev.set()
    # Wake a pending CAPTCHA wait.
    capev = _pending_captcha.get(task_id)
    if capev:
        capev.set()
    # Wake any pending approval waits belonging to this task.
    for approval_id, owner in list(_approval_task.items()):
        if owner == task_id:
            _approval_results[approval_id] = "rejected"
            wev = _pending_approvals.get(approval_id)
            if wev:
                wev.set()


# ---------------------- public entry ----------------------

def start_task(task_id: uuid.UUID) -> None:
    """Fire-and-forget. The runtime owns its own DB sessions."""
    _cancelled.discard(task_id)
    resume_task(task_id)
    asyncio.create_task(_run(task_id))
