from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Approval, Task, User
from app.services import runtime


async def list_for_user(db: AsyncSession, user: User) -> list[dict]:
    result = await db.execute(
        select(Approval, Task)
        .join(Task, Approval.task_id == Task.id)
        .where(Task.user_id == user.id, Approval.state == "pending")
        .order_by(Approval.created_at.desc())
    )
    out: list[dict] = []
    for approval, task in result.all():
        out.append(
            {
                "id": str(approval.id),
                "task_id": str(task.id),
                "task_title": task.title,
                "reason": approval.reason,
                "summary": approval.summary,
                "state": approval.state,
                "created_at": approval.created_at.isoformat(),
            }
        )
    return out


async def respond(
    db: AsyncSession,
    user: User,
    task_id_str: str,
    decision: str,
) -> dict:
    if decision not in {"approved", "rejected"}:
        raise HTTPException(status_code=400, detail="decision must be approved|rejected")

    try:
        task_id = uuid.UUID(task_id_str)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc

    task = await db.get(Task, task_id)
    if task is None or task.user_id != user.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="task not found")

    result = await db.execute(
        select(Approval)
        .where(Approval.task_id == task_id, Approval.state == "pending")
        .order_by(Approval.created_at.desc())
    )
    approval = result.scalars().first()
    if approval is None:
        raise HTTPException(status_code=400, detail="no pending approval")

    approval.state = decision
    approval.responded_at = datetime.now(timezone.utc)
    if decision == "approved":
        task.state = "executing"
    await db.commit()

    runtime.resolve_approval(approval.id, decision)
    return {
        "id": str(approval.id),
        "task_id": str(task.id),
        "state": approval.state,
    }
