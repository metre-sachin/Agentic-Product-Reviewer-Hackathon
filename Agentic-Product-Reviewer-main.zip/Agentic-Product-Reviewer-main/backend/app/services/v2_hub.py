"""Argus v2 hub — registry of connected real browsers (extension or bookmarklet).

Each user may have one live v2 connection (the most recent wins). The runtime
drives the user's real browser through it in two modes:

- primitive `action` frames (navigate/snapshot/click/type/…): the Python brain
  keeps full step-by-step control — same contract the AgentBrowserAdapter has.
- goal `execute` frames: the in-browser Argus agent (page-agent engine) runs a
  bounded micro-loop for one step goal and reports the outcome.

The connection multiplexes many in-flight requests over one socket: every frame
gets a UUID and the matching `result` / `task_result` resolves the awaiting
future.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections.abc import Callable
from typing import Any, Protocol

log = logging.getLogger(__name__)

# One primitive action (a click, a navigation) should never hang the runtime.
ACTION_TIMEOUT_S = 60.0
# A goal step runs a whole micro-loop (many LLM calls) in the browser.
EXECUTE_TIMEOUT_S = 600.0


class _Sender(Protocol):
    async def send_json(self, data: dict[str, Any]) -> None: ...


class V2Connection:
    """One live browser socket for one user."""

    def __init__(self, ws: _Sender, user_id: str, session_id: str, info: dict[str, Any]) -> None:
        self._ws = ws
        self.user_id = user_id
        self.session_id = session_id
        self.info = dict(info or {})
        self._pending: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self._closed = False
        # Optional listener for pushed events (activity, screenshots) so the
        # runtime can stream them to the UI while a goal step runs.
        self.on_event: Callable[[str, dict[str, Any]], None] | None = None

    @property
    def kind(self) -> str:
        return str(self.info.get("kind") or "extension")

    async def _request(
        self, frame: dict[str, Any], *, timeout: float
    ) -> dict[str, Any]:
        if self._closed:
            raise ConnectionError("browser disconnected")
        frame_id = str(uuid.uuid4())
        fut: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[frame_id] = fut
        try:
            await self._ws.send_json({**frame, "id": frame_id})
            return await asyncio.wait_for(fut, timeout)
        finally:
            self._pending.pop(frame_id, None)

    async def send_action(
        self, action: dict[str, Any], *, timeout: float = ACTION_TIMEOUT_S
    ) -> dict[str, Any]:
        """Send one primitive action and await its result."""
        return await self._request({"type": "action", "action": action}, timeout=timeout)

    async def execute_goal(
        self,
        task: str,
        config: dict[str, Any] | None = None,
        *,
        timeout: float = EXECUTE_TIMEOUT_S,
    ) -> dict[str, Any]:
        """Delegate one step goal to the in-browser agent; await {success, data}."""
        return await self._request(
            {"type": "execute", "task": task, "config": config or {}}, timeout=timeout
        )

    async def stop(self) -> None:
        """Ask the in-browser agent to abort its current task (fire and forget)."""
        if self._closed:
            return
        try:
            await self._ws.send_json({"type": "stop"})
        except Exception:  # noqa: BLE001
            pass

    def resolve(self, frame_id: str, result: dict[str, Any]) -> None:
        fut = self._pending.get(frame_id)
        if fut is not None and not fut.done():
            fut.set_result(result)

    def push_event(self, event: str, data: dict[str, Any]) -> None:
        if self.on_event is not None:
            try:
                self.on_event(event, data)
            except Exception:  # noqa: BLE001
                log.debug("v2 event listener raised", exc_info=True)

    def fail_all(self, reason: str) -> None:
        self._closed = True
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(ConnectionError(reason))
        self._pending.clear()

    @property
    def closed(self) -> bool:
        return self._closed


class V2Hub:
    """User -> latest live connection."""

    def __init__(self) -> None:
        self._by_user: dict[str, V2Connection] = {}

    def register(self, conn: V2Connection) -> None:
        prev = self._by_user.get(conn.user_id)
        if prev is not None and prev is not conn:
            prev.fail_all("replaced by a newer connection")
        self._by_user[conn.user_id] = conn
        log.info(
            "v2 browser connected: user=%s session=%s kind=%s",
            conn.user_id,
            conn.session_id,
            conn.kind,
        )

    def unregister(self, conn: V2Connection) -> None:
        if self._by_user.get(conn.user_id) is conn:
            self._by_user.pop(conn.user_id, None)
            log.info("v2 browser disconnected: user=%s", conn.user_id)

    def get(self, user_id: str) -> V2Connection | None:
        conn = self._by_user.get(user_id)
        return conn if conn is not None and not conn.closed else None

    def has(self, user_id: str) -> bool:
        return self.get(user_id) is not None


# Process-wide singleton. The runtime and the WS endpoint share this instance.
hub = V2Hub()
