"""Auto-memory — distil durable user preferences from finished tasks and feedback.

A successful task (and any feedback the user leaves) is summarised by the LLM into
stable, reusable facts — diet, budget ceilings, addresses, favourite brands, etc.
— and saved to `memories`, which the planner already consults. Strictly best
effort: it never raises into the caller, and it returns [] when nothing durable is
found. Gated by the user's auto_learn_enabled setting at the call sites.
"""

from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Memory
from app.services.embeddings import embed_text, serialize

log = logging.getLogger(__name__)

_LEARN_SYSTEM = """You extract DURABLE personal preferences from a finished web task so
an assistant can apply them to FUTURE tasks. Return ONLY stable, reusable facts about
the user — diet, budget ceilings, sizes, favourite brands/stores, home/work address,
preferred airlines/seats, language, accessibility needs, and the like.

Do NOT return one-off task details (a specific search, a single item, a date, a price
you saw), transient state, secrets, or anything you are not confident is lasting. If
there is nothing durable, return an empty list.

Output strict JSON:
{"memories": [{"tag": "UPPER_SNAKE category e.g. DIET|BUDGET|ADDRESS|BRAND|TRAVEL|SIZE|LANGUAGE",
               "text": "concise preference, max 16 words"}]}
Return at most 3.
"""

_MAX_NEW = 3


async def _existing_texts(db: AsyncSession, user_id: uuid.UUID) -> set[str]:
    result = await db.execute(select(Memory.text).where(Memory.user_id == user_id))
    return {str(t).strip().lower() for (t,) in result.all()}


def _is_duplicate(text: str, existing: set[str]) -> bool:
    low = text.strip().lower()
    if not low:
        return True
    return any(low == e or low in e or e in low for e in existing)


async def learn_from_task(
    db: AsyncSession,
    user_id: uuid.UUID,
    goal: str,
    observations: list[str],
    *,
    feedback: str | None = None,
    model: str | None = None,
) -> int:
    """Distil durable preferences and persist new ones. Returns how many were added.
    Best effort — swallows all errors so it can never break task completion."""
    from app.services.llm import complete_json

    notes = "\n".join(f"- {o}" for o in observations if o)[:5000]
    parts = [f"User goal:\n{goal.strip()}"]
    if notes.strip():
        parts.append(f"What happened:\n{notes}")
    if feedback and feedback.strip():
        parts.append(f"User feedback:\n{feedback.strip()[:1000]}")
    parts.append("Extract durable preferences as JSON, or an empty list.")

    try:
        payload = await complete_json(
            system=_LEARN_SYSTEM,
            user="\n\n".join(parts),
            model=model,
            temperature=0.1,
            max_tokens=300,
        )
    except Exception:  # noqa: BLE001
        return 0

    candidates = payload.get("memories")
    if not isinstance(candidates, list) or not candidates:
        return 0

    existing = await _existing_texts(db, user_id)
    added = 0
    for item in candidates[:_MAX_NEW]:
        if not isinstance(item, dict):
            continue
        tag = str(item.get("tag") or "PREFERENCE").upper().strip()[:40]
        text = str(item.get("text") or "").strip()[:280]
        if not text or _is_duplicate(text, existing):
            continue
        try:
            vec = await embed_text(f"{tag}: {text}")
            db.add(
                Memory(
                    user_id=user_id,
                    tag=tag,
                    text=text,
                    embedding=serialize(vec) if vec else None,
                )
            )
            existing.add(text.lower())
            added += 1
        except Exception:  # noqa: BLE001
            continue

    if added:
        try:
            await db.commit()
        except Exception:  # noqa: BLE001
            await db.rollback()
            return 0
    return added
