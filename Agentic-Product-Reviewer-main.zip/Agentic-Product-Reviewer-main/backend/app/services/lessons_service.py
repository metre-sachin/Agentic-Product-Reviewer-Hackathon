"""Experiential site lessons — Reflexion-style operational memory.

After a run, distil short, reusable lessons about how a SITE behaves (what to
AVOID, what to PREFER, stable FACTs about its flow) and replay them into planning
and execution next time, so the agent stops repeating the same site-specific
mistakes. Best effort: it never raises into the caller and returns [] when there
is nothing reusable. Distinct from `memories` (the user's personal preferences).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import SiteLesson

log = logging.getLogger(__name__)

_KINDS = ("avoid", "prefer", "fact")
_MAX_PER_KIND = 3
_MAX_TOTAL_PER_DOMAIN = 24  # keep each site's memory focused, not a junk drawer

# Domain labels too generic to identify a site in free-text goals.
_COMMON_LABELS = {
    "www", "student", "students", "portal", "app", "apps", "my", "login", "erp",
    "secure", "account", "accounts", "mail", "web", "online", "home", "co", "com",
    "in", "edu", "org", "net", "gov", "ac", "io", "us", "uk", "info",
}

_REFLECT_SYSTEM = """You improve a web-automation agent by turning ONE finished run on a
specific website into short, reusable operational lessons for NEXT time on the SAME
site. Focus only on site MECHANICS — how to interact with this site — never the
user's data or preferences.

- "avoid": approaches that failed, looped, or wasted steps (e.g. a button a plain
  click cannot trigger; a field that needs a different control).
- "prefer": what actually worked, especially what succeeded AFTER a failure
  (e.g. "use Browser Use for the ratings form"; "open the Continue link directly").
- "fact": stable truths about the site's flow (e.g. "login needs an OTP after the
  password"; "feedback is star-rating, not free text").

Each lesson must be specific, actionable, and <= 16 words. Return at most 3 per
list. If the run reveals nothing reusable, return empty lists.
Output strict JSON: {"avoid": [...], "prefer": [...], "fact": [...]}.
"""


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _norm(s: str) -> str:
    return (s or "").strip().lower()


def _is_duplicate(text: str, existing: set[str]) -> bool:
    low = _norm(text)
    if not low:
        return True
    return any(low == e or low in e or e in low for e in existing)


def _distinctive_labels(domain: str) -> list[str]:
    """Identifying labels of a domain (e.g. 'alliance' from student.alliance.edu.in),
    dropping generic subdomain/suffix parts — used to spot a site named in a goal."""
    return [p for p in _norm(domain).split(".") if len(p) >= 4 and p not in _COMMON_LABELS]


async def reflect_and_store(
    db: AsyncSession,
    user_id: uuid.UUID,
    domain: str,
    goal: str,
    run_summary: str,
    *,
    model: str | None = None,
) -> int:
    """Distil and persist new site lessons from one run. Returns how many were added."""
    domain = _norm(domain)
    if not domain or not run_summary.strip():
        return 0
    from app.services.llm import complete_json

    try:
        payload = await complete_json(
            system=_REFLECT_SYSTEM,
            user=(
                f"Site: {domain}\nUser goal: {goal.strip()}\n\n"
                f"What happened this run:\n{run_summary.strip()[:5000]}\n\n"
                "Return the lessons JSON."
            ),
            model=model,
            temperature=0.1,
            max_tokens=400,
        )
    except Exception:  # noqa: BLE001
        return 0

    result = await db.execute(
        select(SiteLesson.lesson).where(
            SiteLesson.user_id == user_id, SiteLesson.domain == domain
        )
    )
    existing = {_norm(t) for (t,) in result.all()}
    if len(existing) >= _MAX_TOTAL_PER_DOMAIN:
        return 0

    added = 0
    for kind in _KINDS:
        items = payload.get(kind)
        if not isinstance(items, list):
            continue
        for item in items[:_MAX_PER_KIND]:
            text = str(item or "").strip()[:200]
            if not text or _is_duplicate(text, existing):
                continue
            db.add(SiteLesson(user_id=user_id, domain=domain, kind=kind, lesson=text))
            existing.add(_norm(text))
            added += 1
    if added:
        try:
            await db.commit()
        except Exception:  # noqa: BLE001
            await db.rollback()
            return 0
    return added


async def lessons_for_domain(
    db: AsyncSession, user_id: uuid.UUID, domain: str, limit: int = 10
) -> list[SiteLesson]:
    """Lessons for a site, most-reused first; bumps their hit counters."""
    domain = _norm(domain)
    if not domain:
        return []
    result = await db.execute(
        select(SiteLesson)
        .where(SiteLesson.user_id == user_id, SiteLesson.domain == domain)
        .order_by(SiteLesson.hits.desc(), SiteLesson.created_at.desc())
        .limit(limit)
    )
    rows = list(result.scalars().all())
    if rows:
        now = _now()
        for r in rows:
            r.hits += 1
            r.last_used_at = now
        try:
            await db.commit()
        except Exception:  # noqa: BLE001
            await db.rollback()
    return rows


async def lessons_for_goal(
    db: AsyncSession, user_id: uuid.UUID, goal: str, limit: int = 10
) -> list[SiteLesson]:
    """Pre-planning lookup: lessons for any stored domain the goal names explicitly
    (full domain or a distinctive label like 'alliance' / 'blinkit')."""
    low = _norm(goal)
    if not low:
        return []
    result = await db.execute(
        select(SiteLesson.domain).where(SiteLesson.user_id == user_id).distinct()
    )
    domains = [d for (d,) in result.all() if d]
    for d in domains:
        if d in low or any(label in low for label in _distinctive_labels(d)):
            return await lessons_for_domain(db, user_id, d, limit)
    return []


def format_lessons(lessons: list[SiteLesson]) -> str:
    """Compact bullet list for prompt injection, grouped avoid → prefer → fact."""
    if not lessons:
        return ""
    label = {"avoid": "AVOID", "prefer": "PREFER", "fact": "NOTE"}
    order = {"avoid": 0, "prefer": 1, "fact": 2}
    rows = sorted(lessons, key=lambda x: order.get(x.kind, 9))
    return "\n".join(f"- {label.get(l.kind, 'NOTE')}: {l.lesson}" for l in rows)
