from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import SessionLocal, engine
from app.models import RecurringTask, Task, TaskLog, User
from app.schemas.tasks import TaskRepeatRequest

log = logging.getLogger(__name__)

POLL_SECONDS = 60


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _add_months(dt: datetime, months: int) -> datetime:
    month = dt.month - 1 + months
    year = dt.year + month // 12
    month = month % 12 + 1
    days = [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    day = min(dt.day, days[month - 1])
    return dt.replace(year=year, month=month, day=day)


def next_run_after(dt: datetime, frequency: str, interval: int) -> datetime:
    interval = max(1, interval)
    if frequency == "daily":
        return dt + timedelta(days=interval)
    if frequency == "weekly":
        return dt + timedelta(weeks=interval)
    if frequency == "monthly":
        return _add_months(dt, interval)
    raise ValueError(f"unsupported repeat frequency: {frequency}")


async def ensure_schema() -> None:
    """Keep local dev databases usable even when migrations were not re-applied."""
    statements = [
        "ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_state_check",
        """
        ALTER TABLE tasks
          ADD CONSTRAINT tasks_state_check
          CHECK (state IN (
            'created',
            'planning',
            'executing',
            'recovering',
            'paused',
            'waiting_for_user',
            'waiting_for_approval',
            'completed',
            'failed',
            'cancelled'
          ))
        """,
        """
        CREATE TABLE IF NOT EXISTS recurring_tasks (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          goal TEXT NOT NULL,
          frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly')),
          interval INT NOT NULL DEFAULT 1,
          state TEXT NOT NULL DEFAULT 'active'
            CHECK (state IN ('active','paused','completed','cancelled')),
          next_run_at TIMESTAMPTZ,
          end_at TIMESTAMPTZ,
          remaining_runs INT,
          last_task_id UUID REFERENCES tasks(id) ON DELETE SET NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_recurring_due
          ON recurring_tasks(state, next_run_at)
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_recurring_user
          ON recurring_tasks(user_id, created_at DESC)
        """,
        """
        CREATE TABLE IF NOT EXISTS task_actions (
          id BIGSERIAL PRIMARY KEY,
          task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
          step_id UUID REFERENCES task_steps(id) ON DELETE SET NULL,
          ordinal INT NOT NULL,
          kind TEXT NOT NULL,
          target TEXT,
          value TEXT,
          url TEXT,
          screenshot_url TEXT,
          ok BOOLEAN NOT NULL DEFAULT TRUE,
          at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_task_actions_task
          ON task_actions(task_id, ordinal)
        """,
        """
        CREATE TABLE IF NOT EXISTS playbooks (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          goal_template TEXT NOT NULL,
          intent JSONB NOT NULL DEFAULT '{}'::jsonb,
          source_task_id UUID REFERENCES tasks(id) ON DELETE SET NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_playbooks_user ON playbooks(user_id, created_at DESC)",
        """
        CREATE TABLE IF NOT EXISTS playbook_steps (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          playbook_id UUID NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
          ordinal INT NOT NULL,
          label TEXT NOT NULL,
          kind TEXT,
          target TEXT,
          value_template TEXT,
          sensitive_kind TEXT,
          enabled BOOLEAN NOT NULL DEFAULT TRUE
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_playbook_steps_pb ON playbook_steps(playbook_id, ordinal)",
        """
        CREATE TABLE IF NOT EXISTS task_feedback (
          id BIGSERIAL PRIMARY KEY,
          task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          rating SMALLINT,
          text TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_task_feedback_task ON task_feedback(task_id, created_at DESC)",
        """
        CREATE TABLE IF NOT EXISTS site_lessons (
          id BIGSERIAL PRIMARY KEY,
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          domain TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'fact',
          lesson TEXT NOT NULL,
          hits INT NOT NULL DEFAULT 0,
          last_used_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_site_lessons_user_domain ON site_lessons(user_id, domain)",
        "ALTER TABLE user_settings ALTER COLUMN browser_mode SET DEFAULT 'browser'",
        "ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS browser_cdp_url TEXT",
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS browser_use_system_chrome BOOLEAN NOT NULL DEFAULT FALSE
        """,
        "ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS browser_chrome_profile TEXT",
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS browser_use_model TEXT NOT NULL DEFAULT 'gpt-4o'
        """,
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS browser_use_captcha_solver BOOLEAN NOT NULL DEFAULT TRUE
        """,
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS captcha_autosolve BOOLEAN NOT NULL DEFAULT TRUE
        """,
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS manual_assist_enabled BOOLEAN NOT NULL DEFAULT TRUE
        """,
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS autofill_enabled BOOLEAN NOT NULL DEFAULT TRUE
        """,
        """
        ALTER TABLE user_settings
          ADD COLUMN IF NOT EXISTS auto_learn_enabled BOOLEAN NOT NULL DEFAULT TRUE
        """,
        """
        UPDATE user_settings
        SET browser_mode = 'browser',
            preferred_model = 'gpt-4o',
            browser_use_model = COALESCE(NULLIF(browser_use_model, ''), 'gpt-4o')
        WHERE browser_mode IN ('structured', 'vision')
           OR preferred_model = 'gpt-4o-mini'
        """,
    ]
    async with engine.begin() as conn:
        for statement in statements:
            await conn.execute(text(statement))


async def create_schedule_for_task(
    db: AsyncSession,
    user: User,
    task: Task,
    repeat: TaskRepeatRequest | None,
) -> RecurringTask | None:
    if repeat is None or repeat.frequency == "none":
        return None

    first_next = next_run_after(_now(), repeat.frequency, repeat.interval)
    if repeat.end_at and first_next > repeat.end_at:
        return None

    schedule = RecurringTask(
        user_id=user.id,
        title=task.title,
        goal=task.goal,
        frequency=repeat.frequency,
        interval=repeat.interval,
        next_run_at=first_next,
        end_at=repeat.end_at,
        remaining_runs=repeat.occurrences,
        last_task_id=task.id,
    )
    db.add(schedule)
    db.add(
        TaskLog(
            task_id=task.id,
            level="milestone",
            layer="scheduler",
            text=f"Repeat scheduled: every {repeat.interval} {repeat.frequency}",
            detail=first_next.isoformat(),
        )
    )
    return schedule


async def run_due_once() -> list[uuid.UUID]:
    due_ids: list[uuid.UUID] = []
    now = _now()
    async with SessionLocal() as db:
        result = await db.execute(
            select(RecurringTask)
            .where(
                RecurringTask.state == "active",
                RecurringTask.next_run_at.is_not(None),
                RecurringTask.next_run_at <= now,
            )
            .order_by(RecurringTask.next_run_at.asc())
            .limit(10)
        )
        schedules = result.scalars().all()
        for schedule in schedules:
            if schedule.end_at and now > schedule.end_at:
                schedule.state = "completed"
                schedule.next_run_at = None
                continue

            task = Task(
                user_id=schedule.user_id,
                title=schedule.title,
                goal=schedule.goal,
                state="created",
                intent={},
            )
            db.add(task)
            await db.flush()
            db.add(
                TaskLog(
                    task_id=task.id,
                    level="milestone",
                    layer="scheduler",
                    text="Task created from repeat schedule",
                    detail=schedule.frequency,
                )
            )
            schedule.last_task_id = task.id
            due_ids.append(task.id)

            if schedule.remaining_runs is not None:
                schedule.remaining_runs -= 1
                if schedule.remaining_runs <= 0:
                    schedule.state = "completed"
                    schedule.next_run_at = None

            if schedule.state == "active":
                base = schedule.next_run_at or now
                next_at = next_run_after(base, schedule.frequency, schedule.interval)
                if schedule.end_at and next_at > schedule.end_at:
                    schedule.state = "completed"
                    schedule.next_run_at = None
                else:
                    schedule.next_run_at = next_at

        await db.commit()

    if due_ids:
        from app.services.runtime import start_task

        for task_id in due_ids:
            start_task(task_id)
    return due_ids


async def scheduler(stop: asyncio.Event) -> None:
    await ensure_schema()
    while not stop.is_set():
        try:
            await run_due_once()
        except Exception:  # noqa: BLE001
            log.exception("recurring task scheduler failed")
        try:
            await asyncio.wait_for(stop.wait(), timeout=POLL_SECONDS)
        except asyncio.TimeoutError:
            pass
