"""Playbooks — save a finished task as a reusable, editable recipe and re-run it.

A playbook captures a completed task's ordered, human-readable steps (the plan),
each toggleable. Re-running creates a fresh task seeded with the *enabled* steps so
the runtime skips the planner and follows the proven sequence; credentials and
personal details come from the vault, so only the variables change between runs.
"""

from __future__ import annotations

import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import Playbook, PlaybookStep, Task, TaskLog, User
from app.schemas.playbooks import (
    PlaybookDetailOut,
    PlaybookOut,
    PlaybookStepOut,
    PlaybookStepUpdate,
)


def _replayable_steps(steps: list) -> list:
    """The steps worth saving into a playbook: ones that actually ran (done/failed/
    skipped/active), in order. Falls back to all steps if none ran. Pure — unit
    tested without a DB."""
    ordered = sorted(steps, key=lambda x: x.ordinal)
    ran = [s for s in ordered if s.state in ("done", "failed", "skipped", "active")]
    return ran or ordered


def _step_out(s: PlaybookStep) -> PlaybookStepOut:
    return PlaybookStepOut(
        id=str(s.id), ordinal=s.ordinal, label=s.label, kind=s.kind, enabled=s.enabled
    )


def _to_out(pb: Playbook) -> PlaybookOut:
    return PlaybookOut(
        id=str(pb.id),
        title=pb.title,
        goal_template=pb.goal_template,
        intent=pb.intent or {},
        source_task_id=str(pb.source_task_id) if pb.source_task_id else None,
        step_count=len(pb.steps),
        created_at=pb.created_at,
    )


def _detail_out(pb: Playbook) -> PlaybookDetailOut:
    return PlaybookDetailOut(
        **_to_out(pb).model_dump(),
        steps=[_step_out(s) for s in sorted(pb.steps, key=lambda x: x.ordinal)],
    )


async def _get_owned(db: AsyncSession, user: User, playbook_id: str) -> Playbook:
    try:
        pid = uuid.UUID(playbook_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid playbook id") from exc
    result = await db.execute(
        select(Playbook)
        .where(Playbook.id == pid, Playbook.user_id == user.id)
        .options(selectinload(Playbook.steps))
    )
    pb = result.scalar_one_or_none()
    if pb is None:
        raise HTTPException(status_code=404, detail="playbook not found")
    return pb


async def create_from_task(
    db: AsyncSession, user: User, task_id: str, title: str | None = None
) -> PlaybookDetailOut:
    try:
        tid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid task id") from exc
    result = await db.execute(
        select(Task)
        .where(Task.id == tid, Task.user_id == user.id)
        .options(selectinload(Task.steps))
    )
    task = result.scalar_one_or_none()
    if task is None:
        raise HTTPException(status_code=404, detail="task not found")

    # Only steps that actually ran are worth replaying; skip ones never reached.
    source_steps = _replayable_steps(task.steps)
    if not source_steps:
        raise HTTPException(status_code=400, detail="task has no steps to save")

    pb = Playbook(
        user_id=user.id,
        title=(title or task.title)[:120],
        goal_template=task.goal,
        intent=task.intent or {},
        source_task_id=task.id,
    )
    db.add(pb)
    await db.flush()
    for i, s in enumerate(source_steps, start=1):
        db.add(
            PlaybookStep(
                playbook_id=pb.id,
                ordinal=i,
                label=s.label,
                kind=s.meta,
                enabled=True,
            )
        )
    await db.commit()
    await db.refresh(pb, attribute_names=["steps"])
    return _detail_out(pb)


async def list_for_user(db: AsyncSession, user: User) -> list[PlaybookOut]:
    result = await db.execute(
        select(Playbook)
        .where(Playbook.user_id == user.id)
        .options(selectinload(Playbook.steps))
        .order_by(Playbook.created_at.desc())
    )
    return [_to_out(pb) for pb in result.scalars().all()]


async def get_detail(db: AsyncSession, user: User, playbook_id: str) -> PlaybookDetailOut:
    return _detail_out(await _get_owned(db, user, playbook_id))


async def update_step(
    db: AsyncSession,
    user: User,
    playbook_id: str,
    step_id: str,
    payload: PlaybookStepUpdate,
) -> PlaybookDetailOut:
    pb = await _get_owned(db, user, playbook_id)
    try:
        sid = uuid.UUID(step_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid step id") from exc
    step = next((s for s in pb.steps if s.id == sid), None)
    if step is None:
        raise HTTPException(status_code=404, detail="step not found")
    if payload.enabled is not None:
        step.enabled = payload.enabled
    if payload.label is not None:
        step.label = payload.label.strip()[:200]
    await db.commit()
    await db.refresh(pb, attribute_names=["steps"])
    return _detail_out(pb)


async def delete_step(
    db: AsyncSession, user: User, playbook_id: str, step_id: str
) -> PlaybookDetailOut:
    pb = await _get_owned(db, user, playbook_id)
    try:
        sid = uuid.UUID(step_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid step id") from exc
    step = next((s for s in pb.steps if s.id == sid), None)
    if step is None:
        raise HTTPException(status_code=404, detail="step not found")
    await db.delete(step)
    await db.flush()
    # Re-number remaining steps so ordinals stay contiguous.
    remaining = sorted([s for s in pb.steps if s.id != sid], key=lambda x: x.ordinal)
    for i, s in enumerate(remaining, start=1):
        s.ordinal = i
    await db.commit()
    await db.refresh(pb, attribute_names=["steps"])
    return _detail_out(pb)


async def delete(db: AsyncSession, user: User, playbook_id: str) -> None:
    pb = await _get_owned(db, user, playbook_id)
    await db.delete(pb)
    await db.commit()


async def create_run_task(
    db: AsyncSession, user: User, playbook_id: str, goal: str | None = None
) -> Task:
    """Create a new task that runs this playbook. The intent carries playbook_id so
    the runtime seeds the enabled steps and skips the planner. Caller starts it."""
    pb = await _get_owned(db, user, playbook_id)
    enabled = [s for s in pb.steps if s.enabled]
    if not enabled:
        raise HTTPException(status_code=400, detail="playbook has no enabled steps")
    intent = dict(pb.intent or {})
    intent["playbook_id"] = str(pb.id)
    task = Task(
        user_id=user.id,
        title=pb.title,
        goal=(goal or pb.goal_template).strip(),
        state="created",
        intent=intent,
    )
    db.add(task)
    await db.flush()
    db.add(
        TaskLog(
            task_id=task.id,
            level="milestone",
            layer="playbook",
            text=f"Task created from playbook: {pb.title}",
            detail=f"{len(enabled)} step(s)",
        )
    )
    await db.commit()
    await db.refresh(task)
    return task


async def get_for_run(
    db: AsyncSession, playbook_id: uuid.UUID
) -> tuple[Playbook, list[PlaybookStep]] | None:
    """Used by the runtime: the playbook plus its enabled steps in order."""
    result = await db.execute(
        select(Playbook)
        .where(Playbook.id == playbook_id)
        .options(selectinload(Playbook.steps))
    )
    pb = result.scalar_one_or_none()
    if pb is None:
        return None
    enabled = sorted([s for s in pb.steps if s.enabled], key=lambda x: x.ordinal)
    return pb, enabled
