"""Argus backend package.

The orchestrator imports the agent and integration packages which live at the
repository root (`agents/`, `integrations/`), while `app` lives under `backend/`.
Ensure the repo root is importable regardless of the working directory uvicorn
is launched from.
"""

import pathlib
import sys

_REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
