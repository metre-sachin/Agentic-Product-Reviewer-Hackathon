import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.api import (
    approvals,
    auth,
    connected_sites,
    health,
    memories,
    playbooks,
    settings as settings_api,
    stats,
    tasks,
    v2,
    v2_ws,
    vault,
)
from app.services import recurring_service, quality_service
from app.api import quality


@asynccontextmanager
async def lifespan(app: FastAPI):
    await quality_service.initialize()
    operations_task = asyncio.create_task(quality_service.operations_loop())
    followup_task = asyncio.create_task(quality_service.followup_loop())
    stop_recurring = asyncio.Event()
    recurring_task = asyncio.create_task(recurring_service.scheduler(stop_recurring))
    try:
        yield
    finally:
        operations_task.cancel()
        await asyncio.gather(operations_task, return_exceptions=True)
        followup_task.cancel()
        await asyncio.gather(followup_task, return_exceptions=True)
        await quality_service.shutdown()
        stop_recurring.set()
        recurring_task.cancel()
        try:
            await recurring_task
        except asyncio.CancelledError:
            pass


app = FastAPI(
    title="Argus",
    description="Personal autonomous web task agent.",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(quality.router)
app.include_router(health.router)
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(tasks.router, prefix="/tasks", tags=["tasks"])
app.include_router(approvals.router, prefix="/approvals", tags=["approvals"])
app.include_router(settings_api.router, prefix="/settings", tags=["settings"])
app.include_router(memories.router, prefix="/memories", tags=["memories"])
app.include_router(playbooks.router, prefix="/playbooks", tags=["playbooks"])
app.include_router(connected_sites.router, prefix="/connected-sites", tags=["sites"])
app.include_router(vault.router, prefix="/vault", tags=["vault"])
app.include_router(stats.router, prefix="/stats", tags=["stats"])
app.include_router(v2.router, tags=["v2"])
app.include_router(v2_ws.router, tags=["v2"])


# The v2 in-page agent runs on ARBITRARY page origins (bookmarklet) and inside
# the extension, so /v2 endpoints answer any origin. Safe: auth is a bearer JWT
# header, never cookies, so cross-origin requests carry no ambient credentials.
_V2_CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Authorization, Content-Type",
    "Access-Control-Max-Age": "86400",
}


@app.middleware("http")
async def v2_cors(request: Request, call_next):
    if not request.url.path.startswith("/v2"):
        return await call_next(request)
    if request.method == "OPTIONS":
        return Response(status_code=204, headers=_V2_CORS_HEADERS)
    response = await call_next(request)
    for key, value in _V2_CORS_HEADERS.items():
        response.headers[key] = value
    return response

# Live browser screenshots. Filenames are UUID-scoped and unguessable.
app.mount("/media", StaticFiles(directory=str(settings.media_path)), name="media")
