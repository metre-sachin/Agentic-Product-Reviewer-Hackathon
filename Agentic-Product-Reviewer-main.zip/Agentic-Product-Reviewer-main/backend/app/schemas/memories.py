from datetime import datetime

from pydantic import BaseModel, Field


class MemoryCreate(BaseModel):
    tag: str = Field(min_length=1, max_length=40)
    text: str = Field(min_length=1, max_length=2000)


class MemoryOut(BaseModel):
    id: str
    tag: str
    text: str
    created_at: datetime
    updated_at: datetime
