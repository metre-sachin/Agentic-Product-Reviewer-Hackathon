from typing import Any

from pydantic import BaseModel, Field


class SettingsOut(BaseModel):
    approval_rules: dict[str, Any]
    browser_mode: str
    browser_headless: bool
    preferred_model: str
    browser_cdp_url: str | None = None
    browser_use_system_chrome: bool = False
    browser_chrome_profile: str | None = None
    browser_use_model: str = "gpt-4o"
    browser_use_captcha_solver: bool = True
    captcha_autosolve: bool = True
    manual_assist_enabled: bool = True
    autofill_enabled: bool = True
    auto_learn_enabled: bool = True


class SettingsUpdate(BaseModel):
    approval_rules: dict[str, Any] | None = None
    browser_mode: str | None = Field(default=None, pattern="^(structured|browser|vision|v2)$")
    browser_headless: bool | None = None
    preferred_model: str | None = None
    browser_cdp_url: str | None = None
    browser_use_system_chrome: bool | None = None
    browser_chrome_profile: str | None = None
    browser_use_model: str | None = None
    browser_use_captcha_solver: bool | None = None
    captcha_autosolve: bool | None = None
    manual_assist_enabled: bool | None = None
    autofill_enabled: bool | None = None
    auto_learn_enabled: bool | None = None
