from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class VaultEntryOut(BaseModel):
    """Vault entry metadata. The encrypted values are NEVER returned — only which
    fields are stored (e.g. ['email', 'password']) so the UI can describe it."""

    id: str
    kind: str            # 'login' | 'identity' | 'card' | ...
    label: str           # domain for logins, '__identity__' for the profile
    fields: list[str]    # which keys are stored, values omitted
    ask_every_time: bool
    last_used_at: datetime | None
    created_at: datetime


class VaultEntryUpdate(BaseModel):
    ask_every_time: bool | None = None
