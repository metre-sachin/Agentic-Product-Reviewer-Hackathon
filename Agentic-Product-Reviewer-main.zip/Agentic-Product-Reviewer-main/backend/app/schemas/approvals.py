from datetime import datetime
from typing import Any

from pydantic import BaseModel


class PendingApprovalOut(BaseModel):
    id: str
    task_id: str
    task_title: str
    reason: str
    summary: dict[str, Any]
    state: str
    created_at: datetime
