from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class TaskRepeatRequest(BaseModel):
    frequency: str = Field(default="none", pattern="^(none|daily|weekly|monthly)$")
    interval: int = Field(default=1, ge=1, le=365)
    end_at: datetime | None = None
    occurrences: int | None = Field(default=None, ge=1, le=365)


class TaskCreateRequest(BaseModel):
    goal: str = Field(min_length=3, max_length=2000)
    title: str | None = None
    repeat: TaskRepeatRequest | None = None


class TaskStepOut(BaseModel):
    id: str
    ordinal: int
    label: str
    meta: str | None
    state: str
    layer_used: str | None
    attempts: int


class TaskLogOut(BaseModel):
    id: int
    level: str
    layer: str | None
    text: str
    detail: str | None
    at: datetime


class TaskActionOut(BaseModel):
    id: int
    ordinal: int
    kind: str
    target: str | None
    value: str | None
    url: str | None
    screenshot_url: str | None
    ok: bool
    at: datetime


class TaskOut(BaseModel):
    id: str
    title: str
    goal: str
    state: str
    intent: dict[str, Any]
    result: dict[str, Any] | None
    error: str | None
    started_at: datetime | None
    completed_at: datetime | None
    created_at: datetime
    updated_at: datetime


class TaskDetailOut(TaskOut):
    steps: list[TaskStepOut]
    logs: list[TaskLogOut]
    actions: list[TaskActionOut] = []
    screenshots: list[str] = []
    last_screenshot_url: str | None = None
    # The human prompt this task is currently waiting on (otp/credentials/captcha/
    # info/assist), so the UI can rebuild it after a reload. None when not waiting.
    pending_input: dict[str, Any] | None = None


class UserInputRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class ReplanRequest(BaseModel):
    instruction: str = Field(min_length=1, max_length=4000)
    screenshot_url: str | None = Field(default=None, max_length=2000)


class FeedbackRequest(BaseModel):
    rating: int | None = Field(default=None, ge=1, le=5)
    text: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def _at_least_one(self) -> "FeedbackRequest":
        if self.rating is None and not (self.text and self.text.strip()):
            raise ValueError("provide a rating or text")
        return self


class CredentialsRequest(BaseModel):
    email: str = Field(min_length=1, max_length=320)
    password: str = Field(min_length=1, max_length=512)


class OtpRequest(BaseModel):
    code: str = Field(min_length=1, max_length=32)


class CaptchaRequest(BaseModel):
    text: str = Field(min_length=1, max_length=32)


class InfoRequest(BaseModel):
    """Personal/sensitive form values keyed by element ref (e.g. {"e5": "..."})."""

    values: dict[str, str]

    @field_validator("values")
    @classmethod
    def _bounded(cls, v: dict[str, str]) -> dict[str, str]:
        if not v or len(v) > 30:
            raise ValueError("values must contain between 1 and 30 entries")
        for key, val in v.items():
            if not key or len(key) > 64:
                raise ValueError("invalid field id")
            if len(val) > 1024:
                raise ValueError("value too long")
        return v
