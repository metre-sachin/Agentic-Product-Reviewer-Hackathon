from datetime import datetime

from pydantic import BaseModel, Field


class ConnectedSiteCreate(BaseModel):
    domain: str = Field(min_length=3, max_length=180)
    display_name: str | None = None
    scopes: list[str] = Field(default_factory=list)


class ConnectedSiteUpdate(BaseModel):
    status: str | None = Field(default=None, pattern="^(live|ok|paused|error)$")
    display_name: str | None = None
    scopes: list[str] | None = None


class ConnectedSiteOut(BaseModel):
    id: str
    domain: str
    display_name: str | None
    status: str
    scopes: list[str]
    has_session: bool = False
    last_used_at: datetime | None
    created_at: datetime
