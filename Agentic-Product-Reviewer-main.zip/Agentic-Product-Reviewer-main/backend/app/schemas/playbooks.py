from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PlaybookStepOut(BaseModel):
    id: str
    ordinal: int
    label: str
    kind: str | None
    enabled: bool


class PlaybookOut(BaseModel):
    id: str
    title: str
    goal_template: str
    intent: dict[str, Any]
    source_task_id: str | None
    step_count: int
    created_at: datetime


class PlaybookDetailOut(PlaybookOut):
    steps: list[PlaybookStepOut]


class PlaybookCreateRequest(BaseModel):
    task_id: str
    title: str | None = Field(default=None, max_length=120)


class PlaybookStepUpdate(BaseModel):
    enabled: bool | None = None
    label: str | None = Field(default=None, min_length=1, max_length=200)


class PlaybookRunRequest(BaseModel):
    goal: str | None = Field(default=None, min_length=3, max_length=2000)
