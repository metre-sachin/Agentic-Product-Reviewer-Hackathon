from pydantic import BaseModel


class StatsOut(BaseModel):
    tasks_week: int
    success_rate: float           # 0.0-1.0
    recoveries: int
    avg_time_seconds: float
    delta_tasks_week: int
    delta_success_rate: float
    delta_recoveries: int
    delta_avg_time_seconds: float
