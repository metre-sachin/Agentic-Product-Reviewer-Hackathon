# Argus v2

Argus v2 keeps the FastAPI backend as the **brain** and moves the **hands** into
your real, logged-in browser using the [page-agent](https://github.com/alibaba/page-agent)
engine (browser-use-derived DOM extraction, spec-faithful clicks, native-setter
form fills). This is what fixes v1's missed buttons and broken form-filling.

It ships two ways to put Argus on a page — **same backend, same `.env`, same
auth** as the rest of Argus:

| | Bookmarklet | Extension |
|---|---|---|
| Install | zero — drag one button | load the WXT build |
| Scope | the current tab | all tabs, survives navigation, multi-tab tasks |
| Screenshots for vision recovery | no | yes (`captureVisibleTab`) |
| Best for | instant demo / one-off | the real product |

## Auto-fill from memory (the headline behaviour)

Argus fills everything it already knows and **only asks for what it can't know**:

- **Auto-filled** from the encrypted vault ("memory"): name, username, email,
  phone, address, date of birth, payment card, and saved per-site logins — via
  the `autofill_field` / `autofill_login` tools. The LLM sees only the field
  *kind*, never the value; the value goes straight into the DOM.
- **Always asked** (never guessed): OTP / 2FA / verification codes and CAPTCHA
  text — through the Argus panel modal (or the extension side panel).
- **Approval-gated**: pay, checkout, place order, submit, send, book, publish —
  a one-click confirm before the click, enforced in-browser against the same
  `HARD_TRIGGERS` list the Python approval agent uses.

## Packages

```
v2/packages/
├── panel/        Argus-branded shadow-DOM UI (activity feed, ask/approve modals)
├── agent/        the engine wrapper — backend client, autofill+safety tools,
│                 Argus prompt, PrimitiveHost (primitive actions), V2Socket
├── bookmarklet/  IIFE bundle → served by the backend at /v2/argus.js
└── extension/    WXT MV3 extension (background WS + relay + MAIN-world host + side panel)
```

## Backend surface (in the existing `backend/`)

- `WS /ws/v2` — authenticated (Argus JWT) transport; the runtime drives the
  connected browser through it. (`backend/app/api/v2_ws.py`, `services/v2_hub.py`)
- `GET /v2/config` — model + limits for the in-browser agent.
- `GET /v2/profile?domain=…` — the autofill values from memory (owner-only).
- `POST /v2/llm/chat/completions` — OpenAI-compatible proxy; injects the real
  key server-side so it never reaches the page.
- `GET /v2/argus.js`, `GET /v2/bookmarklet` — the bundle and its install page.
- `integrations/page_agent/adapter.py` — `V2BrowserAdapter`: the same method
  surface as `AgentBrowserAdapter`, so the executor/recovery/approval loop drives
  the real browser unchanged. `browser_mode="v2"` selects it.
- `integrations/agent_reach/adapter.py` — platform-aware L1 reads.

## Build

```bash
cd v2
pnpm install
pnpm build            # → packages/bookmarklet/dist/argus.js  + extension .output/
```

The backend serves the freshly built `argus.js` automatically.

## Run it

1. `pnpm build` in `v2/`.
2. Start Argus (`./scripts/start.sh`) with `OPENAI_API_KEY` set.
3. **Bookmarklet:** open `http://localhost:8000/v2/bookmarklet`, paste your Argus
   token, drag the button to your bookmarks bar, click it on any page.
   **Extension:** `chrome://extensions` → Load unpacked →
   `v2/packages/extension/.output/chrome-mv3`, open the side panel, paste backend
   URL + token.
4. In the Argus web app set **Settings → browser mode → v2**. Tasks now run in
   your connected browser; if none is connected Argus falls back to server-side
   Playwright so tasks never dead-end.

## Why this shape

- **Adapters are interchangeable** — v2 honours the `StepInput → StepResult`
  contract, so recovery/approval/action-trace all work without changes.
- **Safety lives outside the engine** — approval + never-autofill-secrets are
  Argus tool wrappers *and* a server-side backstop, so a page can't bypass them.
- **The key never leaves the server** — the page authenticates with the Argus
  JWT and the backend proxies to OpenAI.

Both upstreams are MIT (page-agent itself credits browser-use).
