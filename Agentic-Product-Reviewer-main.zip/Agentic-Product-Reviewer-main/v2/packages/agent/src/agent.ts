/**
 * createArgusAgent — the Argus v2 in-browser agent.
 *
 * page-agent engine (DOM extraction + spec-faithful clicks + native input) with
 * the Argus brain around it: LLM calls proxied through the Argus backend,
 * auto-fill from vault memory, OTP/CAPTCHA asks, irreversible-click approvals,
 * and the Argus panel UI.
 */
import { PageAgentCore, type ExecutionResult } from '@page-agent/core'
import { PageController } from '@page-agent/page-controller'
import { ArgusPanel } from '@argus/panel'

import { ArgusBackend } from './backend'
import { installArgusCursorTheme } from './cursor-theme'
import { buildInstructions } from './prompt'
import { createArgusTools } from './safety'
import type { ArgusAgentOptions, ArgusProfile } from './types'

const EMPTY_PROFILE: ArgusProfile = {
  identity: {},
  identity_fields: [],
  login: null,
  login_available: false,
}

function askKind(question: string): 'text' | 'password' | 'otp' {
  const low = question.toLowerCase()
  if (/(otp|one[- ]time|2fa|verification code|code sent)/.test(low)) return 'otp'
  if (/password/.test(low)) return 'password'
  return 'text'
}

export interface ArgusAgent {
  core: PageAgentCore
  panel: ArgusPanel | null
  backend: ArgusBackend
  profile: ArgusProfile
  runTask: (task: string) => Promise<ExecutionResult>
  stop: () => Promise<void>
  dispose: () => void
}

export async function createArgusAgent(opts: ArgusAgentOptions): Promise<ArgusAgent> {
  installArgusCursorTheme()
  const backend = new ArgusBackend(opts.backendUrl, opts.token)

  const [config, profile] = await Promise.all([
    backend.config().catch(() => null),
    backend.profile(location.hostname).catch(() => EMPTY_PROFILE),
  ])

  let core!: PageAgentCore
  let panel: ArgusPanel | null = null

  const showPanel = opts.showPanel ?? true
  if (showPanel) {
    panel = new ArgusPanel({
      title: 'Argus',
      collapsed: false,
      onSubmitTask:
        (opts.showComposer ?? true)
          ? (task) => {
              void runTask(task)
            }
          : undefined,
      onStop: () => void core.stop(),
    })
  }

  const onAsk =
    opts.onAsk ??
    (async (question: string, o?: { kind?: 'text' | 'password' | 'otp' }) => {
      if (!panel) throw new Error('no ask channel available')
      return panel.ask(question, { kind: o?.kind ?? askKind(question) })
    })

  const onApprove =
    opts.onApprove ??
    (async (summary: string) => {
      if (!panel) return false // no UI to approve with — always block
      panel.log(`approval needed: ${summary}`, 'err')
      return panel.confirmAction(summary)
    })

  const pageController = new PageController({ enableMask: true })

  core = new PageAgentCore({
    pageController,
    model: config?.model ?? 'gpt-4o',
    baseURL: backend.llmBaseURL,
    apiKey: backend.token, // the Argus JWT — the proxy swaps in the real key
    language: opts.language ?? 'en-US',
    maxSteps: opts.maxSteps ?? config?.max_steps ?? 40,
    customTools: createArgusTools({ backend, profile, onApprove }),
    instructions: {
      system: buildInstructions({
        identityFields: Object.keys(profile.identity),
        loginAvailable: profile.login_available,
      }),
    },
  })

  core.onAskUser = (question) => onAsk(question, { kind: askKind(question) })

  if (panel) {
    core.addEventListener('activity', (e) => {
      const a = (e as CustomEvent).detail as {
        type: string
        tool?: string
        input?: unknown
        output?: string
        message?: string
      }
      if (a.type === 'thinking') panel.setStatus('thinking…', 'info')
      else if (a.type === 'executing') {
        panel.setStatus(`${a.tool}…`, 'info')
        panel.log(`▸ ${a.tool} ${a.input ? JSON.stringify(a.input).slice(0, 100) : ''}`, 'act')
      } else if (a.type === 'executed') {
        panel.log((a.output || '').slice(0, 160), 'info')
      } else if (a.type === 'error') {
        panel.log(a.message || 'error', 'err')
      } else if (a.type === 'retrying') {
        panel.log('retrying LLM call…', 'err')
      }
    })
    core.addEventListener('statuschange', () => {
      const s = core.status
      panel.setRunning(s === 'running')
      if (s === 'completed') panel.setStatus('done', 'ok')
      else if (s === 'error') panel.setStatus('failed', 'err')
      else if (s === 'stopped') panel.setStatus('stopped', 'err')
      else if (s === 'idle') panel.setStatus('ready')
    })
  }

  async function runTask(task: string): Promise<ExecutionResult> {
    panel?.log(`task: ${task}`, 'act')
    const result = await core.execute(task)
    panel?.log(result.success ? `✓ ${result.data}` : `✗ ${result.data}`, result.success ? 'ok' : 'err')
    return result
  }

  return {
    core,
    panel,
    backend,
    profile,
    runTask,
    stop: () => core.stop(),
    dispose: () => {
      core.dispose()
      panel?.dispose()
    },
  }
}
