/**
 * V2Socket — page-context client for the Argus backend's /ws/v2 hub.
 *
 * Used by the bookmarklet: the page itself becomes the user's connected
 * browser. Services primitive `action` frames with the PrimitiveHost and goal
 * `execute` frames with the full Argus agent. The extension has its own socket
 * in the background service worker instead (it must survive tab navigation).
 */
import type { ArgusAgent } from './agent'
import type { ActionFrame, PrimitiveHost } from './host'

interface V2SocketOptions {
  wsUrl: string
  token: string
  info?: Record<string, unknown>
  host: PrimitiveHost
  /** Lazily provide the goal-mode agent (created on first execute frame). */
  getAgent: () => Promise<ArgusAgent>
  onState?: (state: 'connecting' | 'connected' | 'disconnected') => void
}

const RECONNECT_BASE_MS = 2000
const RECONNECT_MAX_MS = 30_000

export class V2Socket {
  #ws: WebSocket | null = null
  #opts: V2SocketOptions
  #closed = false
  #retry = 0

  constructor(opts: V2SocketOptions) {
    this.#opts = opts
  }

  connect(): void {
    if (this.#closed || this.#ws) return
    this.#opts.onState?.('connecting')
    const ws = new WebSocket(this.#opts.wsUrl)
    this.#ws = ws

    ws.addEventListener('open', () => {
      this.#retry = 0
      ws.send(
        JSON.stringify({
          type: 'hello',
          token: this.#opts.token,
          info: { kind: 'page', url: location.href, ...this.#opts.info },
        })
      )
    })

    ws.addEventListener('message', (event) => {
      void this.#handle(String(event.data))
    })

    ws.addEventListener('close', () => {
      this.#ws = null
      this.#opts.onState?.('disconnected')
      if (this.#closed) return
      const delay = Math.min(RECONNECT_BASE_MS * 2 ** this.#retry++, RECONNECT_MAX_MS)
      setTimeout(() => this.connect(), delay)
    })
  }

  #send(data: Record<string, unknown>): void {
    if (this.#ws?.readyState === WebSocket.OPEN) {
      this.#ws.send(JSON.stringify(data))
    }
  }

  async #handle(raw: string): Promise<void> {
    let msg: {
      type?: string
      id?: string
      action?: ActionFrame
      task?: string
      config?: Record<string, unknown>
    }
    try {
      msg = JSON.parse(raw)
    } catch {
      return
    }

    switch (msg.type) {
      case 'welcome':
        this.#opts.onState?.('connected')
        return
      case 'ping':
        this.#send({ type: 'pong' })
        return
      case 'action': {
        const result = await this.#opts.host.execute(msg.action as ActionFrame)
        this.#send({ type: 'result', id: msg.id, result })
        return
      }
      case 'execute': {
        try {
          const agent = await this.#opts.getAgent()
          const cfgUrl = (msg.config as { url?: string } | undefined)?.url
          if (cfgUrl && cfgUrl !== location.href) {
            // Goal steps may carry a starting URL; navigating tears the page
            // down, so surface that instead of silently ignoring it.
            this.#send({
              type: 'result',
              id: msg.id,
              result: {
                success: false,
                data: `page is on ${location.href}, step wants ${cfgUrl} — navigate first via action frames`,
              },
            })
            return
          }
          const result = await agent.runTask(String(msg.task ?? ''))
          this.#send({
            type: 'result',
            id: msg.id,
            result: { success: result.success, data: result.data },
          })
        } catch (err) {
          this.#send({
            type: 'result',
            id: msg.id,
            result: { success: false, data: err instanceof Error ? err.message : String(err) },
          })
        }
        return
      }
      case 'stop': {
        const agent = await this.#opts.getAgent().catch(() => null)
        void agent?.stop()
        return
      }
    }
  }

  dispose(): void {
    this.#closed = true
    this.#ws?.close()
    this.#ws = null
  }
}
