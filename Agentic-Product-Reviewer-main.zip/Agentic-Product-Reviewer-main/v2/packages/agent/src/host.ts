/**
 * PrimitiveHost — services Argus's primitive action frames on this page using
 * the page-agent PageController engine.
 *
 * This is what lets the EXISTING Argus runtime (browser_loop.py + recovery +
 * approvals + action trace) drive the user's real browser unchanged: the same
 * `{kind: "click", ref: "e12"}` contract, but executed with page-agent's DOM
 * extraction and spec-faithful event synthesis instead of the old snapshot JS.
 *
 * Snapshot shape mirrors integrations/agent_browser/adapter.py::Snapshot.
 */
import { PageController } from '@page-agent/page-controller'
import { installArgusCursorTheme } from './cursor-theme'

export interface SnapshotElement {
  ref: string
  tag: string
  type: string
  role: string
  name: string
  placeholder: string
  href: string
  editable: boolean
  filled: boolean
  disabled: boolean
  text: string
  rect: { x: number; y: number; w: number; h: number; cx: number; cy: number }
}

export interface ActionFrame {
  kind: string
  ref?: string
  url?: string
  text?: string
  value?: string
  key?: string
  direction?: string
  amount?: number
  ms?: number
  limit?: number
}

export type ActionResult = Record<string, unknown> & { ok: boolean }

const MAX_ELEMENTS = 260

function refToIndex(ref: string | undefined): number {
  const n = Number.parseInt(String(ref ?? '').replace(/^e/, ''), 10)
  if (Number.isNaN(n) || n < 0) throw new Error(`invalid element ref: ${ref}`)
  return n
}

export class PrimitiveHost {
  #pc: PageController | null = null

  /** Lazy so merely loading the script never touches the page. */
  get pageController(): PageController {
    if (!this.#pc) {
      installArgusCursorTheme()
      this.#pc = new PageController({ enableMask: true })
    }
    return this.#pc
  }

  /**
   * Interactive-element listing in the v1 Snapshot shape, built from
   * page-agent's selector map (pinned @page-agent 1.12.1 internals).
   */
  async snapshot(): Promise<{ url: string; title: string; elements: SnapshotElement[] }> {
    const pc = this.pageController
    await pc.updateTree()
    const selectorMap = (
      pc as unknown as { selectorMap: Map<number, { ref?: Element | null }> }
    ).selectorMap

    const elements: SnapshotElement[] = []
    for (const [index, node] of selectorMap) {
      if (elements.length >= MAX_ELEMENTS) break
      const el = node.ref
      if (!(el instanceof HTMLElement)) continue
      const rect = el.getBoundingClientRect()
      const tag = el.tagName.toLowerCase()
      const type = el.getAttribute('type') || ''
      const isPassword = type === 'password'
      const value = isPassword ? '' : ((el as HTMLInputElement).value ?? '')
      const aria = el.getAttribute('aria-label') || ''
      const text = (el.innerText || '').trim().replace(/\s+/g, ' ')
      elements.push({
        ref: `e${index}`,
        tag,
        type,
        role: el.getAttribute('role') || '',
        name: (aria || el.getAttribute('placeholder') || el.getAttribute('title') ||
          el.getAttribute('name') || text || value || '').slice(0, 120),
        placeholder: el.getAttribute('placeholder') || '',
        href: el.getAttribute('href') || '',
        editable:
          ['input', 'textarea'].includes(tag) || el.isContentEditable,
        filled: Boolean(value && String(value).trim().length),
        disabled:
          Boolean((el as HTMLButtonElement).disabled) ||
          el.getAttribute('aria-disabled') === 'true',
        text: text.slice(0, 160),
        rect: {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          w: Math.round(rect.width),
          h: Math.round(rect.height),
          cx: Math.round(rect.x + rect.width / 2),
          cy: Math.round(rect.y + rect.height / 2),
        },
      })
    }
    await pc.cleanUpHighlights()
    return { url: location.href, title: document.title, elements }
  }

  async execute(action: ActionFrame): Promise<ActionResult> {
    try {
      switch (action.kind) {
        case 'snapshot':
          return { ok: true, snapshot: await this.snapshot() }
        case 'page_text': {
          const text = (document.body?.innerText || '').trim()
          return { ok: true, text: text.slice(0, action.limit ?? 5000) }
        }
        case 'page_info':
          return { ok: true, url: location.href, title: document.title }
        case 'click': {
          const r = await this.pageController.clickElement(refToIndex(action.ref))
          return { ok: !r.message.includes('❌'), message: r.message }
        }
        case 'type': {
          const r = await this.pageController.inputText(
            refToIndex(action.ref),
            action.text ?? ''
          )
          return { ok: !r.message.includes('❌'), message: r.message }
        }
        case 'select': {
          const r = await this.pageController.selectOption(
            refToIndex(action.ref),
            action.value ?? ''
          )
          return { ok: !r.message.includes('❌'), message: r.message }
        }
        case 'press':
          return { ok: this.#press(action.key ?? 'Enter') }
        case 'scroll': {
          const amount = Math.abs(action.amount ?? 650)
          const down = (action.direction ?? 'down') !== 'up'
          const r = await this.pageController.scroll({ down, numPages: 0, pixels: amount })
          return { ok: true, message: r.message }
        }
        case 'wait': {
          const ms = Math.max(100, Math.min(action.ms ?? 1000, 5000))
          await new Promise((r) => setTimeout(r, ms))
          return { ok: true }
        }
        case 'navigate': {
          // Same-tab navigation tears this page down; ack first, then go.
          setTimeout(() => location.assign(action.url ?? location.href), 50)
          return { ok: true, url: action.url }
        }
        case 'screenshot':
          return { ok: false, error: 'screenshot requires the Argus extension' }
        default:
          return { ok: false, error: `unknown action kind: ${action.kind}` }
      }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  }

  #press(key: string): boolean {
    const target = (document.activeElement as HTMLElement | null) ?? document.body
    if (!target) return false
    const init: KeyboardEventInit = { key, bubbles: true, cancelable: true }
    target.dispatchEvent(new KeyboardEvent('keydown', init))
    target.dispatchEvent(new KeyboardEvent('keypress', init))
    target.dispatchEvent(new KeyboardEvent('keyup', init))
    if (key === 'Enter') {
      const form = (target as HTMLInputElement).form
      if (form) {
        try {
          form.requestSubmit()
        } catch {
          /* some forms only submit via their own JS — the key events above did their part */
        }
      }
    }
    return true
  }

  dispose(): void {
    this.#pc?.dispose()
    this.#pc = null
  }
}
