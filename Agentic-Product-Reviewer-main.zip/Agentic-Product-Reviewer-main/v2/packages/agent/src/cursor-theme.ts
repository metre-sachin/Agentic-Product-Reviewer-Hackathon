/**
 * Re-skins Page Agent's simulator cursor without forking the controller.
 *
 * Page Agent injects CSS-module class names for an arrow cursor. Matching the
 * stable semantic fragments keeps this override compatible with patch updates,
 * while the data attribute makes mounting idempotent across agent instances.
 */
export function installArgusCursorTheme(): void {
  if (document.querySelector('style[data-argus-cursor-theme]')) return

  const style = document.createElement('style')
  style.setAttribute('data-argus-cursor-theme', '')
  style.textContent = `
    [class*="_cursor_"]:has(> [class*="_cursorFilling_"]) {
      width: 30px !important;
      height: 30px !important;
      transform: translate(-50%, -50%) !important;
      filter: drop-shadow(0 5px 10px rgba(8, 8, 10, 0.32));
    }

    [class*="_cursorFilling_"],
    [class*="_cursorBorder_"] {
      width: 30px !important;
      height: 30px !important;
      margin: 0 !important;
      transform: none !important;
      mask-image: none !important;
      border-radius: 999px !important;
      background-repeat: no-repeat !important;
    }

    [class*="_cursorFilling_"] {
      border: 1px solid rgba(244, 244, 245, 0.78) !important;
      background:
        radial-gradient(circle at 50% 50%, #08080a 0 18%, transparent 20%),
        radial-gradient(circle at 39% 34%, #f4f4f5 0 9%, #c4f0c8 31%, #667b6a 58%, #15151a 72%) !important;
      box-shadow:
        inset 0 0 0 3px rgba(8, 8, 10, 0.46),
        inset 0 1px 0 rgba(255, 255, 255, 0.48) !important;
    }

    [class*="_cursorBorder_"] {
      border: 1px solid rgba(196, 240, 200, 0.68) !important;
      background: transparent !important;
    }

    [class*="_cursorRipple_"] {
      width: 30px !important;
      height: 30px !important;
      margin: 0 !important;
    }

    [class*="_cursorRipple_"]::after {
      border: 2px solid rgba(196, 240, 200, 0.82) !important;
    }
  `
  ;(document.head || document.documentElement).appendChild(style)
}
