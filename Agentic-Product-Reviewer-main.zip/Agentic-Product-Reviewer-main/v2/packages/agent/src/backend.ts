/**
 * ArgusBackend — the in-browser agent's line to the Argus brain.
 *
 * Auth is the user's Argus JWT. The same token is what the page-agent LLM
 * client sends as its "api key" to the /v2/llm proxy, so the real
 * OPENAI_API_KEY never exists in the page.
 */
import type { ArgusConfig, ArgusProfile } from './types'

export class ArgusBackend {
  readonly baseUrl: string
  readonly token: string

  constructor(baseUrl: string, token: string) {
    this.baseUrl = baseUrl.replace(/\/+$/, '')
    this.token = token
  }

  get llmBaseURL(): string {
    return `${this.baseUrl}/v2/llm`
  }

  get wsUrl(): string {
    return `${this.baseUrl.replace(/^http/, 'ws')}/ws/v2`
  }

  async #get<T>(path: string): Promise<T> {
    const res = await fetch(`${this.baseUrl}${path}`, {
      headers: { Authorization: `Bearer ${this.token}` },
    })
    if (!res.ok) {
      throw new Error(`Argus backend ${path} → ${res.status} ${await res.text()}`)
    }
    return (await res.json()) as T
  }

  config(): Promise<ArgusConfig> {
    return this.#get<ArgusConfig>('/v2/config')
  }

  /** Autofill profile ("memory") for the given page domain. */
  profile(domain: string): Promise<ArgusProfile> {
    return this.#get<ArgusProfile>(`/v2/profile?domain=${encodeURIComponent(domain)}`)
  }
}
