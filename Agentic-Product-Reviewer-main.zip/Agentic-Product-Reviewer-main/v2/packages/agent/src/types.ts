export interface ArgusProfile {
  /** Saved identity values keyed by field kind (name/email/phone/address/dob/card). */
  identity: Record<string, string>
  identity_fields: string[]
  /** Saved login for the requested domain, when autofill is allowed. */
  login: { email: string; password: string } | null
  login_available: boolean
}

export interface ArgusConfig {
  model: string
  max_steps: number
  llm_mocked: boolean
  backend_public_url: string
}

export interface ArgusAgentOptions {
  /** Argus backend origin, e.g. http://localhost:8000 */
  backendUrl: string
  /** The user's Argus JWT — doubles as the LLM-proxy api key. */
  token: string
  language?: 'en-US' | 'zh-CN'
  maxSteps?: number
  /**
   * Ask the user a question (OTP, missing info). Defaults to the Argus panel
   * modal; the extension can route this to its side panel instead.
   */
  onAsk?: (question: string, opts?: { kind?: 'text' | 'password' | 'otp' }) => Promise<string>
  /**
   * Confirm an irreversible action (pay / checkout / send / submit). Defaults
   * to the Argus panel approval modal. Return false to block the click.
   */
  onApprove?: (summary: string) => Promise<boolean>
  /** Show the Argus panel UI. Default true. */
  showPanel?: boolean
  /** Show the task composer inside the panel. Default true. */
  showComposer?: boolean
}
