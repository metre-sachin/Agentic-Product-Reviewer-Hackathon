/**
 * Argus safety + autofill tools for the page-agent core.
 *
 * - `click_element_by_index` is REPLACED with a gated version: clicks whose
 *   target text matches an irreversible-action trigger raise an approval
 *   prompt first (mirrors agents/approval/approval.py HARD_TRIGGERS).
 * - `autofill_field` types a saved identity value (vault "memory") into an
 *   element. The value goes straight from the profile into the DOM — the LLM
 *   only ever sees the field KIND, not the value.
 * - `autofill_login` fetches the saved login for the current domain at call
 *   time and fills email/password fields the same way.
 */
import type { PageAgentCore, PageAgentTool } from '@page-agent/core'
import { tool } from '@page-agent/core'
import * as z from 'zod'

import type { ArgusBackend } from './backend'
import type { ArgusProfile } from './types'

// Mirror of agents/approval/approval.py HARD_TRIGGERS — keep in sync.
export const HARD_TRIGGERS = [
  'pay',
  'payment',
  'checkout',
  'place order',
  'buy now',
  'purchase',
  'submit application',
  'submit form',
  'send email',
  'send message',
  'confirm booking',
  'book ticket',
  'book flight',
  'book hotel',
  'post review',
  'post comment',
  'publish',
] as const

export function matchedTrigger(label: string): string | null {
  const low = (label || '').toLowerCase()
  for (const phrase of HARD_TRIGGERS) {
    if (low.includes(phrase)) return phrase
  }
  return null
}

/**
 * Best-effort text of an indexed element.
 * Reaches into PageController internals (pinned @page-agent 1.12.1): the
 * elementTextMap holds each interactive element's visible text.
 */
function elementLabel(agent: PageAgentCore, index: number): string {
  try {
    const pc = agent.pageController as unknown as {
      elementTextMap?: Map<number, string>
      selectorMap?: Map<number, { ref?: Element | null }>
    }
    const text = pc.elementTextMap?.get(index)
    if (text) return text
    const el = pc.selectorMap?.get(index)?.ref
    if (el instanceof HTMLElement) {
      return (
        el.innerText ||
        el.getAttribute('aria-label') ||
        (el as HTMLInputElement).value ||
        ''
      ).trim()
    }
  } catch {
    /* label is advisory — never break the click over it */
  }
  return ''
}

export interface SafetyDeps {
  backend: ArgusBackend
  profile: ArgusProfile
  onApprove: (summary: string) => Promise<boolean>
}

export function createArgusTools(deps: SafetyDeps): Record<string, PageAgentTool> {
  const { backend, profile, onApprove } = deps

  const gatedClick = tool({
    description: 'Click element by index',
    inputSchema: z.object({ index: z.int().min(0) }),
    execute: async function (this: PageAgentCore, input: { index: number }) {
      const label = elementLabel(this, input.index)
      const trigger = matchedTrigger(label)
      if (trigger) {
        const approved = await onApprove(
          `Click "${label.slice(0, 120) || trigger}" — matches irreversible trigger "${trigger}" on ${location.hostname}`
        )
        if (!approved) {
          return `⛔ User DENIED clicking "${label.slice(0, 80)}". Do not retry this click; adapt or finish with done.`
        }
      }
      const result = await this.pageController.clickElement(input.index)
      return result.message
    },
  })

  const autofillField = tool({
    description:
      'Auto-fill a personal field from the user\'s saved profile ("memory"). ' +
      'kind must be one of the saved identity fields listed in your instructions. ' +
      'The saved value is typed into the element directly — use this INSTEAD of ' +
      'asking the user or typing personal data yourself.',
    inputSchema: z.object({
      index: z.int().min(0),
      kind: z.string(),
    }),
    execute: async function (this: PageAgentCore, input: { index: number; kind: string }) {
      const kind = input.kind.trim().toLowerCase()
      const value = profile.identity[kind]
      if (!value) {
        const available = Object.keys(profile.identity).join(', ') || 'none'
        return (
          `❌ No saved value for "${kind}". Saved kinds: ${available}. ` +
          `Ask the user for this value with ask_user instead.`
        )
      }
      const result = await this.pageController.inputText(input.index, value)
      return result.message.includes('❌')
        ? result.message
        : `✅ Auto-filled ${kind} from saved profile into element ${input.index}.`
    },
  })

  const autofillLogin = tool({
    description:
      'Auto-fill the saved login for THIS site into a sign-in form. Provide the ' +
      'index of the email/username field and (optionally) the password field. ' +
      'Values come from the encrypted vault and are never shown to you.',
    inputSchema: z.object({
      email_index: z.int().min(0).optional(),
      password_index: z.int().min(0).optional(),
    }),
    execute: async function (
      this: PageAgentCore,
      input: { email_index?: number; password_index?: number }
    ) {
      // Fetch at call time so the password lives in memory only for this fill.
      const fresh = await backend.profile(location.hostname)
      if (!fresh.login) {
        return '❌ No saved login for this site. Ask the user for credentials with ask_user.'
      }
      const filled: string[] = []
      if (input.email_index !== undefined) {
        const r = await this.pageController.inputText(input.email_index, fresh.login.email)
        if (!r.message.includes('❌')) filled.push('email/username')
      }
      if (input.password_index !== undefined) {
        const r = await this.pageController.inputText(input.password_index, fresh.login.password)
        if (!r.message.includes('❌')) filled.push('password')
      }
      if (!filled.length) {
        return '❌ Nothing was filled — pass email_index and/or password_index of the sign-in fields.'
      }
      return `✅ Auto-filled ${filled.join(' and ')} from the vault. Now click the sign-in button.`
    },
  })

  return {
    click_element_by_index: gatedClick,
    autofill_field: autofillField,
    autofill_login: autofillLogin,
  }
}
