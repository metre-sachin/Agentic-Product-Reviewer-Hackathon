/**
 * Frame types shared by background <-> relay <-> main-world <-> sidepanel.
 * The backend wire protocol lives in backend/app/api/v2_ws.py; frames forwarded
 * to pages keep the backend's `id` so correlation is end-to-end.
 */

export interface ActionFrame {
  type: 'action'
  id: string
  action: Record<string, unknown> & { kind: string }
}

export interface ExecuteFrame {
  type: 'execute'
  id: string
  task: string
  config?: Record<string, unknown>
  /** Attached by the background so the main world can reach the backend. */
  auth?: { backendUrl: string; token: string }
}

export interface StopFrame {
  type: 'stop'
}

export interface ResultFrame {
  type: 'result'
  id: string
  result: Record<string, unknown>
}

export interface EventFrame {
  type: 'event'
  event: string
  data: Record<string, unknown>
}

export type PageBoundFrame = ActionFrame | ExecuteFrame | StopFrame
export type PageOriginFrame = ResultFrame | EventFrame

/** window.postMessage envelopes between relay (isolated) and main world. */
export const TO_MAIN = 'argus-v2-to-main'
export const FROM_MAIN = 'argus-v2-from-main'

/** chrome.runtime messages between sidepanel and background. */
export type SidepanelCommand =
  | { cmd: 'status' }
  | { cmd: 'connect' }
  | { cmd: 'run'; task: string }
  | { cmd: 'stop' }

export interface SidepanelPush {
  type: 'sp'
  kind: 'state' | 'result' | 'activity' | 'log'
  data: Record<string, unknown>
}

export interface StoredConfig {
  argusBackendUrl?: string
  argusToken?: string
}
