import { defineConfig } from 'wxt'

// Argus v2 extension — the user's real browser as Argus's hands.
//
// `manifest.key` pins the extension's ID (gijcoaaofgeakofpgblonfaininkiifh)
// across rebuilds/reinstalls — same trick page-agent's extension uses. It is
// NOT a secret (Chrome extension keys are public by design, embedded in every
// install); it only lets the Argus frontend address this exact extension for
// the zero-paste pairing handshake in `externally_connectable` below.
const MANIFEST_KEY =
  'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDJXBAXwiQdItmemazh1K/q76yQpu4BKGnEAngcCTTl+HppmeIAmQs+b6GN4L4l8+tm1NayQ//xHur9L0bHhSkkNjMyX9z5sWoieuRwvYznY49f2kSPk1stbWhUhhb8S6KuO9hFo2z1E9xUcf0j7alIc4Sun0vk6gH9l0xZ6hHtfAo5s2BcukUBb8G2Pui/vwq448HWCmh+QnPcsWriEdHBLxo3Ol+J3k3Rdrz0s4h+AbaITbVYsacG3oI0x0wnm1iPw1aqPonLsV+KEdFJPkMIxaS61bi9oOMlhBR5cIKD3B27CL5dCAQGBzwcpCNAYY8BpkC0RGJf24cYY0VNmILlAgMBAAECggEBAInNgonv6G00M4CSJTmsJ/R9sDiStWF/edqV4gM13cjg402v7XaBRqulFAgX3an1o42NbZ00Yk1u3l0FZMgY/o30tdbsujr7yunr9ridUHfur+lmY/NqYkTVkkf+OG7TiHL7K8iEzoVu4SO9mwNim66kuBIVnIf+Cfy19Z+3TCuct4ezzXHSpKc5eqkLA0yGIU5BkSbIJqvEFgpsNF4svC/qdqOgq8lDaTqsghbx9aJCaEPRVUhtf6FnTZ9tf/H9Z5g8zCF+efkYw4mLg7yasBxjjML9mZhsrlNhCOtbgWmvMRv6ME5TRkF6dt1zr3hqLEROxkqcSLEOrBeKPqdw1YECgYEA8+PMl/3NTOTKsLY7OPYt2vbJ+loxyxowLrW4srtoZJ/QVAhikMe7xxInno/V1Rqn0HCzTelNb1hD8OPKLMjuWRtdWAk7G7Q/kKNsdlxqL5azt4cZtSKITX/JuSHLP1qdbfk3WqmuwDgzIT3tjybgGdd9RdwKtzKtCh1CWCuPg0UCgYEA01ukQfFwOQb+kK+dyg6oT02N2blPxJwOA2JantoY0rg0ykrE+azySXq7QoQZR/GFQI2721gztOlWWRcplvwygtgjyD5VbOsP80Tr0PM3/g7daf/yEy0yW01RZnncf3fwvf8/yDwQY+UFWBYjbS16sh2LrmRvDUeuR23mHiucKyECgYBHYGfEI7ctxde8F9kFNqb86jT6W+MuuZ9YTD6dsFNA/7SMo1eVX58JB7sooJfIImDyk8kmCB1tdLuNiFzm9ncrBOMwnKL73Kitv+ZCTZGWE9jM4XEYnd6eL8PttoIxLGfeg407r2VBRDFSjTk1J/92EKbNBzTroJ0b1KxR+Y2qsQKBgQCiA+SUu/u3azomNMhyg+vW5m8vD5Mq9ijzxSgMDsjqdlPZIZl+fmk3lEIJSfOLJ4NqqXrwN9ti+V68ajnySB58GCzNqaKYHFQcuZ8+i8JHGKP3RkANHR81x733HMC+YXWEXy5IUmqJ+JuxGz9KyIr+EBHru4c5GdJpZL/6LpnGoQKBgGzh6TjmfUs5wT3pTFbfZrgip37Fn6qzD1USM4IOSOCzQ3SQvfcNKI8HpSbBqb/sooqnVPzEoSmNZNF/2wELnD2WHOt8pH8HDnHoajWty46bH+AiHXI/vfDYjeafWM8K7s+cmaKnWup+IBCBUZaXvnZM8kCyxmrokrnggIfiSCCw'

// Frontend origins allowed to pair with this extension via chrome.runtime
// sendMessage (see entrypoints/background.ts onMessageExternal). Add your
// deployed frontend origin here when you ship beyond local dev.
const PAIRING_ORIGINS = ['http://localhost:3000/*', 'https://localhost:3000/*']

export default defineConfig({
  vite: () => ({
    build: {
      rollupOptions: {
        onwarn(message, handler) {
          if (message.code === 'EVAL') return // page-agent's script tool uses eval
          handler(message)
        },
      },
    },
  }),
  manifest: {
    key: MANIFEST_KEY,
    name: 'Argus',
    description:
      "Argus v2 — your personal web agent, acting in your own browser with your own logged-in sessions.",
    permissions: ['storage', 'tabs', 'alarms', 'sidePanel', 'activeTab'],
    host_permissions: ['<all_urls>'],
    externally_connectable: {
      matches: PAIRING_ORIGINS,
    },
    action: {
      default_title: 'Argus',
    },
    side_panel: {
      default_path: 'sidepanel.html',
    },
  },
})
