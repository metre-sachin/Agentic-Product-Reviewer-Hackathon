/**
 * Argus side panel — pairing (backend URL + token), connection status, and a
 * composer that runs tasks in the active tab through the MAIN-world host.
 */
import type { SidepanelPush, StoredConfig } from '@/lib/protocol'

const $ = <T extends HTMLElement>(id: string): T => document.getElementById(id) as T

const dot = $('dot')
const status = $('status')
const pair = $('pair')
const backendUrlInput = $<HTMLInputElement>('backendUrl')
const tokenInput = $<HTMLInputElement>('token')
const saveBtn = $<HTMLButtonElement>('save')
const taskInput = $<HTMLTextAreaElement>('task')
const goBtn = $<HTMLButtonElement>('go')
const stopBtn = $<HTMLButtonElement>('stop')
const feed = $('feed')

function log(text: string, tone: '' | 'ok' | 'err' | 'act' = ''): void {
  const line = document.createElement('div')
  line.className = `line ${tone}`.trim()
  line.textContent = text
  feed.appendChild(line)
  while (feed.childElementCount > 150) feed.firstElementChild?.remove()
  feed.scrollTop = feed.scrollHeight
}

function setState(state: string): void {
  dot.className = `dot ${state === 'connected' ? 'connected' : state === 'connecting' ? 'connecting' : ''}`
  status.textContent =
    state === 'connected'
      ? 'connected to Argus'
      : state === 'connecting'
        ? 'connecting…'
        : 'not connected'
}

async function init(): Promise<void> {
  const stored = (await chrome.storage.local.get([
    'argusBackendUrl',
    'argusToken',
  ])) as StoredConfig
  backendUrlInput.value = stored.argusBackendUrl ?? 'http://localhost:8000'
  if (stored.argusToken) tokenInput.value = stored.argusToken

  const resp = (await chrome.runtime.sendMessage({ cmd: 'status' }).catch(() => null)) as {
    state?: string
    configured?: boolean
  } | null
  setState(resp?.state ?? 'disconnected')
  pair.classList.toggle('hidden', Boolean(resp?.configured && resp?.state === 'connected'))
}

saveBtn.addEventListener('click', async () => {
  await chrome.storage.local.set({
    argusBackendUrl: backendUrlInput.value.trim(),
    argusToken: tokenInput.value.trim(),
  })
  await chrome.runtime.sendMessage({ cmd: 'connect' }).catch(() => null)
  log('saved — connecting…')
})

goBtn.addEventListener('click', async () => {
  const task = taskInput.value.trim()
  if (!task) return
  taskInput.value = ''
  log(`task: ${task}`, 'act')
  const resp = (await chrome.runtime.sendMessage({ cmd: 'run', task }).catch((e) => ({
    ok: false,
    error: String(e),
  }))) as { ok: boolean; error?: string }
  if (!resp.ok) log(resp.error ?? 'failed to start', 'err')
})

stopBtn.addEventListener('click', () => {
  void chrome.runtime.sendMessage({ cmd: 'stop' }).catch(() => null)
})

chrome.runtime.onMessage.addListener((msg: SidepanelPush) => {
  if (msg?.type !== 'sp') return
  if (msg.kind === 'state') {
    setState(String(msg.data.state))
    if (msg.data.state === 'connected') pair.classList.add('hidden')
  } else if (msg.kind === 'result') {
    const success = Boolean(msg.data.success)
    log(`${success ? '✓' : '✗'} ${String(msg.data.data ?? '')}`, success ? 'ok' : 'err')
  } else if (msg.kind === 'activity') {
    const a = msg.data as { type?: string; tool?: string; output?: string; message?: string }
    if (a.type === 'executing') log(`▸ ${a.tool}`, 'act')
    else if (a.type === 'executed') log(String(a.output ?? '').slice(0, 140))
    else if (a.type === 'error') log(String(a.message ?? 'error'), 'err')
  }
})

void init()
