/**
 * Argus host content script (MAIN world) — the page-agent engine living in the
 * page. Services primitive `action` frames with the PrimitiveHost and goal
 * `execute` frames with the full Argus agent (panel, autofill from memory,
 * OTP asks, approval gates).
 */
import {
  createArgusAgent,
  PrimitiveHost,
  type ActionFrame,
  type ArgusAgent,
} from '@argus/agent'

import { FROM_MAIN, TO_MAIN } from '@/lib/protocol'

interface InboundFrame {
  type: 'action' | 'execute' | 'stop'
  id?: string
  action?: ActionFrame
  task?: string
  config?: Record<string, unknown>
  auth?: { backendUrl: string; token: string }
}

export default defineContentScript({
  matches: ['<all_urls>'],
  runAt: 'document_idle',
  world: 'MAIN',
  main() {
    const host = new PrimitiveHost()
    let agent: ArgusAgent | null = null
    let agentAuthKey = ''

    function post(frame: Record<string, unknown>): void {
      window.postMessage({ source: FROM_MAIN, frame }, '*')
    }

    function postActivity(data: Record<string, unknown>): void {
      post({ type: 'event', event: 'activity', data })
    }

    async function getAgent(auth: { backendUrl: string; token: string }): Promise<ArgusAgent> {
      const key = `${auth.backendUrl}::${auth.token.slice(0, 24)}`
      if (agent && agentAuthKey === key) return agent
      agent?.dispose()
      agent = await createArgusAgent({
        backendUrl: auth.backendUrl,
        token: auth.token,
        showComposer: true,
      })
      agentAuthKey = key
      agent.core.addEventListener('activity', (e) => {
        const detail = (e as CustomEvent).detail as Record<string, unknown>
        postActivity(detail)
      })
      return agent
    }

    window.addEventListener('message', (event) => {
      if (event.source !== window) return
      const data = event.data as { source?: string; frame?: InboundFrame }
      if (data?.source !== TO_MAIN || !data.frame) return
      void handle(data.frame)
    })

    async function handle(frame: InboundFrame): Promise<void> {
      switch (frame.type) {
        case 'action': {
          const result = await host.execute(frame.action as ActionFrame)
          post({ type: 'result', id: frame.id, result })
          return
        }
        case 'execute': {
          if (!frame.auth) {
            post({
              type: 'result',
              id: frame.id,
              result: { success: false, data: 'missing auth on execute frame' },
            })
            return
          }
          try {
            const a = await getAgent(frame.auth)
            const result = await a.runTask(String(frame.task ?? ''))
            post({
              type: 'result',
              id: frame.id,
              result: { success: result.success, data: result.data },
            })
          } catch (err) {
            post({
              type: 'result',
              id: frame.id,
              result: {
                success: false,
                data: err instanceof Error ? err.message : String(err),
              },
            })
          }
          return
        }
        case 'stop':
          void agent?.stop()
          return
      }
    }
  },
})
