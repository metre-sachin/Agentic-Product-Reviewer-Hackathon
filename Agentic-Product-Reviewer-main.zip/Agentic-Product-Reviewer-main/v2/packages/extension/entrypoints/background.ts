/**
 * Argus v2 background — owns the WebSocket to the Argus backend and routes
 * frames between the backend and the page (via the relay content script).
 *
 * Tab-level actions (navigate, screenshot) run here; everything DOM-level is
 * executed in the page by the page-agent engine. A chrome.alarms heartbeat
 * revives the MV3 service worker and reconnects the socket after eviction.
 */
import type {
  PageBoundFrame,
  SidepanelCommand,
  SidepanelPush,
  StoredConfig,
} from '@/lib/protocol'

const RECONNECT_BASE_MS = 2000
const RECONNECT_MAX_MS = 30_000
const NAVIGATE_TIMEOUT_MS = 20_000

let ws: WebSocket | null = null
let wsState: 'connecting' | 'connected' | 'disconnected' = 'disconnected'
let retry = 0
/** Tab a task is currently working in (set by navigate / run). */
let targetTabId: number | null = null
/** Pending sidepanel-initiated executes, by frame id. */
const sidepanelPending = new Set<string>()

export default defineBackground(() => {
  void chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true })

  // Chrome allows a 30-second minimum for unpacked/modern MV3 extensions.
  // The alarm revives an evicted service worker and restores the persisted
  // WebSocket without the user reopening Argus.
  chrome.alarms.create('argus-keepalive', { periodInMinutes: 0.5 })
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'argus-keepalive') void ensureConnected()
  })

  chrome.runtime.onStartup.addListener(() => void ensureConnected())
  chrome.runtime.onInstalled.addListener(() => void ensureConnected())

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.argusToken || changes.argusBackendUrl)) {
      ws?.close()
      ws = null
      void ensureConnected()
    }
  })

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Frames coming back from pages (via relay).
    if (msg?.type === 'result' || msg?.type === 'event') {
      handlePageFrame(msg)
      return
    }
    // Sidepanel commands.
    if (msg?.cmd) {
      void handleSidepanel(msg as SidepanelCommand, sendResponse)
      return true // async sendResponse
    }
  })

  // Zero-paste pairing: the Argus web app (an origin listed in
  // manifest.externally_connectable) sends the token directly — no copying a
  // JWT by hand, no risk of a truncated paste. Any origin not in that list is
  // never delivered here at all; the browser enforces it before we see it.
  chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
    if (msg?.type !== 'argus-pair' || !msg.backendUrl || !msg.token) {
      sendResponse({ ok: false, error: 'malformed pairing message' })
      return
    }
    void chrome.storage.local
      .set({ argusBackendUrl: msg.backendUrl, argusToken: msg.token })
      .then(async () => {
        ws?.close()
        ws = null
        await ensureConnected()
        sendResponse({ ok: true })
      })
    return true // async sendResponse
  })

  void ensureConnected()
})

async function getConfig(): Promise<{ backendUrl: string; token: string } | null> {
  const stored = (await chrome.storage.local.get([
    'argusBackendUrl',
    'argusToken',
  ])) as StoredConfig
  if (!stored.argusBackendUrl || !stored.argusToken) return null
  return { backendUrl: stored.argusBackendUrl.replace(/\/+$/, ''), token: stored.argusToken }
}

async function ensureConnected(): Promise<void> {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return
  const config = await getConfig()
  if (!config) {
    setState('disconnected')
    return
  }

  setState('connecting')
  const socket = new WebSocket(`${config.backendUrl.replace(/^http/, 'ws')}/ws/v2`)
  ws = socket

  socket.addEventListener('open', () => {
    retry = 0
    socket.send(
      JSON.stringify({
        type: 'hello',
        token: config.token,
        info: { kind: 'extension', version: chrome.runtime.getManifest().version },
      })
    )
  })

  socket.addEventListener('message', (event) => {
    void handleBackendFrame(String(event.data), config)
  })

  socket.addEventListener('close', () => {
    if (ws === socket) ws = null
    setState('disconnected')
    const delay = Math.min(RECONNECT_BASE_MS * 2 ** retry++, RECONNECT_MAX_MS)
    setTimeout(() => void ensureConnected(), delay)
  })
}

function setState(state: typeof wsState): void {
  wsState = state
  pushToSidepanel({ type: 'sp', kind: 'state', data: { state } })
  void chrome.action.setBadgeText({ text: state === 'connected' ? '●' : '' })
  void chrome.action.setBadgeTextColor?.({ color: '#C4F0C8' })
  void chrome.action.setBadgeBackgroundColor({ color: '#0B0B0E' })
}

function wsSend(data: Record<string, unknown>): void {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data))
}

async function handleBackendFrame(
  raw: string,
  config: { backendUrl: string; token: string }
): Promise<void> {
  let msg: {
    type?: string
    id?: string
    action?: { kind: string; url?: string }
    task?: string
    config?: Record<string, unknown>
  }
  try {
    msg = JSON.parse(raw)
  } catch {
    return
  }

  switch (msg.type) {
    case 'welcome':
      setState('connected')
      return
    case 'ping':
      wsSend({ type: 'pong' })
      return
    case 'action': {
      const kind = msg.action?.kind
      if (kind === 'navigate') {
        const result = await navigate(msg.action?.url ?? '')
        wsSend({ type: 'result', id: msg.id, result })
      } else if (kind === 'screenshot') {
        const result = await screenshot()
        wsSend({ type: 'result', id: msg.id, result })
      } else {
        await forwardToPage({ type: 'action', id: msg.id!, action: msg.action! }, msg.id!)
      }
      return
    }
    case 'execute':
      await forwardToPage(
        {
          type: 'execute',
          id: msg.id!,
          task: msg.task ?? '',
          config: msg.config,
          auth: config,
        },
        msg.id!
      )
      return
    case 'stop':
      await forwardToPage({ type: 'stop' }, null)
      return
  }
}

/** Frames posted back by pages (relay → runtime message). */
function handlePageFrame(msg: {
  type: string
  id?: string
  result?: Record<string, unknown>
  event?: string
  data?: Record<string, unknown>
}): void {
  if (msg.type === 'result' && msg.id) {
    if (sidepanelPending.delete(msg.id)) {
      pushToSidepanel({ type: 'sp', kind: 'result', data: msg.result ?? {} })
    } else {
      wsSend({ type: 'result', id: msg.id, result: msg.result ?? {} })
    }
    return
  }
  if (msg.type === 'event') {
    wsSend({ type: 'event', event: msg.event, data: msg.data ?? {} })
    if (msg.event === 'activity') {
      pushToSidepanel({ type: 'sp', kind: 'activity', data: msg.data ?? {} })
    }
  }
}

async function resolveTargetTab(): Promise<chrome.tabs.Tab | null> {
  if (targetTabId !== null) {
    try {
      const tab = await chrome.tabs.get(targetTabId)
      if (tab?.id) return tab
    } catch {
      targetTabId = null
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true })
  return active ?? null
}

async function forwardToPage(frame: PageBoundFrame, replyId: string | null): Promise<void> {
  const tab = await resolveTargetTab()
  if (!tab?.id) {
    if (replyId) wsSend({ type: 'result', id: replyId, result: { ok: false, success: false, error: 'no active tab' } })
    return
  }
  targetTabId = tab.id
  try {
    await sendToTabWithRetry(tab.id, frame)
  } catch (err) {
    if (replyId) {
      wsSend({
        type: 'result',
        id: replyId,
        result: {
          ok: false,
          success: false,
          error: `page not reachable (${err instanceof Error ? err.message : err}) — is this a chrome:// page?`,
        },
      })
    }
  }
}

/** Content scripts need a beat to come up after navigation. */
async function sendToTabWithRetry(tabId: number, frame: PageBoundFrame): Promise<void> {
  let lastErr: unknown
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      await chrome.tabs.sendMessage(tabId, frame)
      return
    } catch (err) {
      lastErr = err
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)))
    }
  }
  throw lastErr
}

async function navigate(url: string): Promise<Record<string, unknown>> {
  const tab = await resolveTargetTab()
  if (!tab?.id) return { ok: false, error: 'no active tab' }
  targetTabId = tab.id
  try {
    await chrome.tabs.update(tab.id, { url })
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
  const finalUrl = await new Promise<string>((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener)
      resolve(url)
    }, NAVIGATE_TIMEOUT_MS)
    const listener = (updatedTabId: number, info: chrome.tabs.TabChangeInfo, t: chrome.tabs.Tab) => {
      if (updatedTabId === tab.id && info.status === 'complete') {
        clearTimeout(timer)
        chrome.tabs.onUpdated.removeListener(listener)
        resolve(t.url ?? url)
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
  })
  return { ok: true, url: finalUrl }
}

async function screenshot(): Promise<Record<string, unknown>> {
  const tab = await resolveTargetTab()
  if (!tab?.windowId) return { ok: false, error: 'no active tab' }
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' })
    return { ok: true, dataUrl }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}

async function handleSidepanel(
  msg: SidepanelCommand,
  sendResponse: (response: unknown) => void
): Promise<void> {
  switch (msg.cmd) {
    case 'status': {
      const config = await getConfig()
      sendResponse({ state: wsState, configured: Boolean(config) })
      return
    }
    case 'connect':
      ws?.close()
      ws = null
      await ensureConnected()
      sendResponse({ ok: true })
      return
    case 'run': {
      const config = await getConfig()
      if (!config) {
        sendResponse({ ok: false, error: 'set backend URL and token first' })
        return
      }
      const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true })
      if (!active?.id) {
        sendResponse({ ok: false, error: 'no active tab' })
        return
      }
      targetTabId = active.id
      const id = `sp-${crypto.randomUUID()}`
      sidepanelPending.add(id)
      try {
        await sendToTabWithRetry(active.id, {
          type: 'execute',
          id,
          task: msg.task,
          auth: config,
        })
        sendResponse({ ok: true, id })
      } catch (err) {
        sidepanelPending.delete(id)
        sendResponse({
          ok: false,
          error: `page not reachable (${err instanceof Error ? err.message : err})`,
        })
      }
      return
    }
    case 'stop':
      await forwardToPage({ type: 'stop' }, null)
      sendResponse({ ok: true })
      return
  }
}

function pushToSidepanel(push: SidepanelPush): void {
  void chrome.runtime.sendMessage(push).catch(() => {
    /* sidepanel closed — fine */
  })
}
