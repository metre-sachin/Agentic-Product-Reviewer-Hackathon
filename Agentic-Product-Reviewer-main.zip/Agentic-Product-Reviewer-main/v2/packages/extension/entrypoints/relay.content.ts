/**
 * Relay content script (isolated world) — bridges the background service
 * worker and the MAIN-world Argus host over window.postMessage. The MAIN world
 * has the page's real DOM + JS realm (needed by the page-agent engine) but no
 * chrome.* APIs; this relay is its messenger.
 */
import { FROM_MAIN, TO_MAIN } from '@/lib/protocol'

export default defineContentScript({
  matches: ['<all_urls>'],
  runAt: 'document_idle',
  main() {
    // background → main world
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === 'action' || msg?.type === 'execute' || msg?.type === 'stop') {
        window.postMessage({ source: TO_MAIN, frame: msg }, '*')
      }
    })

    // main world → background
    window.addEventListener('message', (event) => {
      if (event.source !== window) return
      const data = event.data as { source?: string; frame?: Record<string, unknown> }
      if (data?.source !== FROM_MAIN || !data.frame) return
      void chrome.runtime.sendMessage(data.frame).catch(() => {
        /* background asleep — the keepalive alarm revives it */
      })
    })
  },
})
