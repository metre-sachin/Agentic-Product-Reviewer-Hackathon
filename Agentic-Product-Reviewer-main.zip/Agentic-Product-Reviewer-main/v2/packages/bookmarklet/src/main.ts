/**
 * Argus v2 bookmarklet entry — summons the Argus agent on ANY page.
 *
 * The bookmarklet (from {backend}/v2/bookmarklet) sets window.__ARGUS_CFG__ and
 * injects this script. The page then:
 *  1. shows the Argus panel with a task composer,
 *  2. connects to the backend hub (/ws/v2) so web-app tasks can drive this tab,
 *  3. auto-fills from vault memory and asks only for OTP/CAPTCHA/unsaved values.
 */
import {
  createArgusAgent,
  PrimitiveHost,
  V2Socket,
  type ArgusAgent,
} from '@argus/agent'

interface ArgusCfg {
  backendUrl: string
  token: string
}

declare global {
  interface Window {
    __ARGUS_CFG__?: ArgusCfg
    __ARGUS_V2__?: { toggle: () => void; dispose: () => void }
  }
}

const cfg = window.__ARGUS_CFG__
if (!cfg?.backendUrl || !cfg?.token) {
  console.error('[Argus] missing config — launch via the bookmarklet from /v2/bookmarklet')
} else if (window.__ARGUS_V2__) {
  window.__ARGUS_V2__.toggle()
} else {
  void boot(cfg)
}

async function boot(config: ArgusCfg): Promise<void> {
  let agentPromise: Promise<ArgusAgent> | null = null

  const getAgent = (): Promise<ArgusAgent> => {
    agentPromise ??= createArgusAgent({
      backendUrl: config.backendUrl,
      token: config.token,
    })
    return agentPromise
  }

  const agent = await getAgent()
  agent.panel?.log('Argus is on this page. Give it a task, or run one from the app.', 'info')

  const host = new PrimitiveHost()
  const socket = new V2Socket({
    wsUrl: `${config.backendUrl.replace(/^http/, 'ws')}/ws/v2`,
    token: config.token,
    host,
    getAgent,
    onState: (state) => {
      if (state === 'connected') agent.panel?.setStatus('connected to Argus', 'ok')
      else if (state === 'disconnected') agent.panel?.setStatus('offline (panel still works)')
    },
  })
  socket.connect()

  window.__ARGUS_V2__ = {
    toggle: () => agent.panel?.toggle(),
    dispose: () => {
      socket.dispose()
      host.dispose()
      agent.dispose()
      delete window.__ARGUS_V2__
    },
  }
}
