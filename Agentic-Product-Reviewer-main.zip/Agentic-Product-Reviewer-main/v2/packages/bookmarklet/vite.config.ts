import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vite'
import cssInjectedByJsPlugin from 'vite-plugin-css-injected-by-js'

const here = fileURLToPath(new URL('.', import.meta.url))

// Single-file IIFE bundle served by the backend at /v2/argus.js.
export default defineConfig({
  plugins: [cssInjectedByJsPlugin()],
  publicDir: false,
  build: {
    lib: {
      entry: resolve(here, 'src/main.ts'),
      name: 'ArgusV2',
      fileName: () => 'argus.js',
      formats: ['iife'],
    },
    outDir: resolve(here, 'dist'),
    cssCodeSplit: false,
    rollupOptions: {
      onwarn(message, handler) {
        if (message.code === 'EVAL') return // page-agent's script tool uses eval
        handler(message)
      },
    },
  },
})
