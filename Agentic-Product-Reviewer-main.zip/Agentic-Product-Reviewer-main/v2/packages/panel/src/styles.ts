/**
 * Compact Page-Agent-inspired control bar in the Argus visual language.
 * Kept inside a shadow root so host-page CSS cannot leak in or out.
 */
export const PANEL_CSS = /* css */ `
:host { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; }

.root {
  position: fixed;
  right: 20px;
  bottom: 20px;
  z-index: 2147483646;
  width: min(372px, calc(100vw - 32px));
  color: #F4F4F5;
  font-family: Geist, "Geist Sans", system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.5;
}

/* ---- collapsed Argus eye ---- */
.orb {
  position: absolute;
  right: 0;
  bottom: 0;
  width: 46px;
  height: 46px;
  border: 1px solid rgba(244,244,245,0.16);
  border-radius: 50%;
  background: #111115;
  display: grid;
  place-items: center;
  cursor: pointer;
  box-shadow: 0 10px 30px rgba(8,8,10,0.38), inset 0 1px 0 rgba(255,255,255,0.06);
  transition: transform 180ms cubic-bezier(.2,.8,.2,1), border-color 180ms ease;
}
.orb:hover { transform: translateY(-2px); border-color: rgba(196,240,200,0.42); }
.orb:active { transform: scale(.96); }
.orb .iris,
.head .dot {
  position: relative;
  border-radius: 50%;
  background: radial-gradient(circle at 38% 32%, #F4F4F5 0 10%, #C4F0C8 33%, #647868 59%, #15151A 74%);
  box-shadow: inset 0 0 0 2px rgba(8,8,10,.48), inset 0 1px 0 rgba(255,255,255,.48);
}
.orb .iris { width: 24px; height: 24px; }
.orb .iris span,
.head .dot span {
  position: absolute;
  inset: 38%;
  border-radius: 50%;
  background: #08080A;
}
.orb.running .iris { animation: argus-breathe 1.4s ease-in-out infinite; }

/* ---- compact command card ---- */
.card {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid rgba(244,244,245,0.13);
  border-radius: 15px;
  background: rgba(11,11,14,0.96);
  box-shadow: 0 18px 55px rgba(8,8,10,0.46), inset 0 1px 0 rgba(255,255,255,0.05);
  backdrop-filter: blur(18px) saturate(120%);
}

.head {
  min-height: 43px;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 9px 8px 12px;
  background: #111115;
  user-select: none;
}
.head .dot { width: 16px; height: 16px; flex: none; }
.head .dot.running { animation: argus-breathe 1.4s ease-in-out infinite; }
.head .dot.ok { box-shadow: inset 0 0 0 2px rgba(8,8,10,.42), 0 0 0 1px rgba(196,240,200,.26); }
.head .dot.err { background: radial-gradient(circle at 38% 32%, #F4F4F5 0 9%, #E8B4B4 35%, #765858 65%, #15151A 76%); }
.head .title { font-size: 12.5px; font-weight: 650; letter-spacing: -.01em; }
.head .status {
  min-width: 0;
  flex: 1;
  color: #929299;
  font-size: 11.5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.icon-btn {
  all: unset;
  position: relative;
  width: 27px;
  height: 27px;
  flex: none;
  display: grid;
  place-items: center;
  border-radius: 8px;
  color: #929299;
  cursor: pointer;
  transition: color 150ms ease, background-color 150ms ease, transform 150ms ease;
}
.icon-btn:hover { color: #F4F4F5; background: rgba(255,255,255,.06); }
.icon-btn:active { transform: scale(.94); }
.feed-toggle > span {
  width: 7px;
  height: 7px;
  border-right: 1.5px solid currentColor;
  border-bottom: 1.5px solid currentColor;
  transform: translateY(-2px) rotate(45deg);
  transition: transform 160ms ease;
}
.feed-toggle.open > span { transform: translateY(2px) rotate(225deg); }
.feed-toggle.has-activity::after {
  content: '';
  position: absolute;
  right: 4px;
  top: 4px;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: #C4F0C8;
}
.collapse-btn > span,
.collapse-btn > span::after {
  position: absolute;
  width: 10px;
  height: 1.5px;
  border-radius: 2px;
  background: currentColor;
}
.collapse-btn > span { transform: rotate(45deg); }
.collapse-btn > span::after { content: ''; transform: rotate(90deg); }

.feed {
  max-height: 226px;
  overflow-y: auto;
  padding: 10px 13px;
  border-top: 1px solid rgba(255,255,255,.055);
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: rgba(8,8,10,.38);
  scrollbar-width: thin;
  scrollbar-color: #2A2A2E transparent;
}
.line { color: #A1A1A6; font-size: 12px; word-break: break-word; }
.line.ok { color: #C4F0C8; }
.line.err { color: #E8B4B4; }
.line.act { color: #F4F4F5; font-weight: 520; }
.line .t {
  margin-right: 6px;
  color: #595960;
  font-family: "Geist Mono", ui-monospace, monospace;
  font-size: 10.5px;
}

/* ---- input row ---- */
.composer {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  padding: 9px;
  border-top: 1px solid rgba(255,255,255,.07);
  background: #0D0D10;
}
.composer textarea {
  min-height: 38px;
  max-height: 106px;
  flex: 1;
  resize: none;
  outline: none;
  border: 1px solid rgba(244,244,245,.11);
  border-radius: 10px;
  background: #17171C;
  color: #F4F4F5;
  font: inherit;
  padding: 8px 10px;
  transition: border-color 150ms ease, background-color 150ms ease;
}
.composer textarea:hover { border-color: rgba(244,244,245,.17); }
.composer textarea:focus { border-color: rgba(196,240,200,.42); background: #19191E; }
.composer textarea::placeholder { color: #717178; }
.btn {
  all: unset;
  min-width: 34px;
  cursor: pointer;
  align-self: stretch;
  display: grid;
  place-items: center;
  border-radius: 10px;
  background: #C4F0C8;
  color: #0B0B0E;
  font-size: 12px;
  font-weight: 680;
  padding: 0 12px;
  transition: background-color 150ms ease, transform 150ms ease;
}
.btn:hover { background: #D2F4D5; }
.btn:active { transform: scale(.96); }
.btn.stop { border: 1px solid rgba(232,180,180,.2); background: #1B1619; color: #E8B4B4; }
.btn:disabled { opacity: .4; cursor: default; }

/* ---- ask / approve ---- */
.modal {
  padding: 13px;
  border-top: 1px solid rgba(255,255,255,.06);
  background: #111115;
  display: flex;
  flex-direction: column;
  gap: 9px;
}
.modal .q { color: #F4F4F5; font-size: 13px; font-weight: 560; }
.modal .hint { color: #717178; font-size: 11px; }
.modal input {
  width: 100%;
  outline: none;
  border: 1px solid rgba(255,255,255,.11);
  border-radius: 9px;
  background: #17171C;
  color: #F4F4F5;
  font: inherit;
  padding: 8px 10px;
}
.modal input:focus { border-color: rgba(196,240,200,.42); }
.modal .row { display: flex; gap: 8px; justify-content: flex-end; }
.modal .row .btn { min-height: 35px; align-self: auto; }
.modal .approve { background: #C4F0C8; color: #08080A; }
.modal .deny { border: 1px solid rgba(255,255,255,.1); background: #17171C; color: #E8B4B4; }

@keyframes argus-breathe {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(.86); opacity: .68; }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
}

.hidden { display: none !important; }
`
