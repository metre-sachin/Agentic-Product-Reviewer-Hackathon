/**
 * ArgusPanel — the Argus-branded in-page UI for the v2 agent.
 *
 * A shadow-DOM card that shows live agent activity, takes task input, asks the
 * user questions (OTP, missing info) and confirms irreversible actions. Framework
 * free so it can mount on any page (bookmarklet) and inside extension documents.
 */
import { PANEL_CSS } from './styles'

export type PanelTone = 'info' | 'ok' | 'err' | 'act'

export interface AskOptions {
  /** 'password' masks the input; 'otp' shows a one-time-code hint. */
  kind?: 'text' | 'password' | 'otp'
}

export interface ArgusPanelOptions {
  title?: string
  /** Called when the user submits a task from the composer. */
  onSubmitTask?: (task: string) => void
  /** Called when the user presses stop while a task runs. */
  onStop?: () => void
  /** Start collapsed to the orb. */
  collapsed?: boolean
}

interface PendingModal {
  resolve: (value: string) => void
  reject: (reason: Error) => void
}

export class ArgusPanel {
  #host: HTMLDivElement
  #root: ShadowRoot
  #card!: HTMLDivElement
  #orb!: HTMLDivElement
  #dot!: HTMLSpanElement
  #status!: HTMLSpanElement
  #feed!: HTMLDivElement
  #feedToggle!: HTMLButtonElement
  #composer!: HTMLDivElement
  #input!: HTMLTextAreaElement
  #runBtn!: HTMLButtonElement
  #modal!: HTMLDivElement
  #opts: ArgusPanelOptions
  #pending: PendingModal | null = null
  #running = false
  #disposed = false

  constructor(opts: ArgusPanelOptions = {}) {
    this.#opts = opts
    this.#host = document.createElement('div')
    this.#host.setAttribute('data-argus-panel', '')
    this.#root = this.#host.attachShadow({ mode: 'closed' })

    const style = document.createElement('style')
    style.textContent = PANEL_CSS
    this.#root.appendChild(style)

    this.#build()
    ;(document.body || document.documentElement).appendChild(this.#host)
    if (opts.collapsed) this.collapse()
  }

  #build(): void {
    const root = document.createElement('div')
    root.className = 'root'

    // Collapsed orb
    this.#orb = document.createElement('div')
    this.#orb.className = 'orb hidden'
    this.#orb.title = 'Argus'
    this.#orb.innerHTML = '<div class="iris"><span></span></div>'
    this.#orb.addEventListener('click', () => this.expand())

    // Card
    this.#card = document.createElement('div')
    this.#card.className = 'card'

    const head = document.createElement('div')
    head.className = 'head'
    this.#dot = document.createElement('span')
    this.#dot.className = 'dot'
    this.#dot.innerHTML = '<span></span>'
    const title = document.createElement('span')
    title.className = 'title'
    title.textContent = this.#opts.title ?? 'Argus'
    this.#status = document.createElement('span')
    this.#status.className = 'status'
    this.#status.textContent = 'ready'
    this.#feedToggle = document.createElement('button')
    this.#feedToggle.className = 'icon-btn feed-toggle'
    this.#feedToggle.setAttribute('aria-label', 'Show activity')
    this.#feedToggle.setAttribute('aria-expanded', 'false')
    this.#feedToggle.innerHTML = '<span></span>'
    this.#feedToggle.addEventListener('click', () => {
      const isHidden = this.#feed.classList.toggle('hidden')
      this.#feedToggle.classList.toggle('open', !isHidden)
      this.#feedToggle.setAttribute('aria-expanded', String(!isHidden))
      this.#feedToggle.setAttribute('aria-label', isHidden ? 'Show activity' : 'Hide activity')
      if (!isHidden) this.#feed.scrollTop = this.#feed.scrollHeight
    })
    const collapseBtn = document.createElement('button')
    collapseBtn.className = 'icon-btn collapse-btn'
    collapseBtn.setAttribute('aria-label', 'Minimise Argus')
    collapseBtn.innerHTML = '<span></span>'
    collapseBtn.title = 'Collapse'
    collapseBtn.addEventListener('click', () => this.collapse())
    head.append(this.#dot, title, this.#status, this.#feedToggle, collapseBtn)

    this.#feed = document.createElement('div')
    this.#feed.className = 'feed hidden'

    this.#modal = document.createElement('div')
    this.#modal.className = 'modal hidden'

    this.#composer = document.createElement('div')
    this.#composer.className = 'composer'
    this.#input = document.createElement('textarea')
    this.#input.placeholder = 'Ask Argus to do something on this page'
    this.#input.rows = 1
    this.#input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        this.#submit()
      }
    })
    this.#runBtn = document.createElement('button')
    this.#runBtn.className = 'btn'
    this.#runBtn.textContent = 'Run'
    this.#runBtn.addEventListener('click', () => {
      if (this.#running) this.#opts.onStop?.()
      else this.#submit()
    })
    this.#composer.append(this.#input, this.#runBtn)
    if (!this.#opts.onSubmitTask) this.#composer.classList.add('hidden')

    this.#card.append(head, this.#feed, this.#modal, this.#composer)
    root.append(this.#card, this.#orb)
    this.#root.appendChild(root)
  }

  #submit(): void {
    const task = this.#input.value.trim()
    if (!task || this.#running) return
    this.#input.value = ''
    this.#opts.onSubmitTask?.(task)
  }

  // ---- public surface ----

  expand(): void {
    this.#card.classList.remove('hidden')
    this.#orb.classList.add('hidden')
  }

  collapse(): void {
    this.#card.classList.add('hidden')
    this.#orb.classList.remove('hidden')
  }

  toggle(): void {
    if (this.#card.classList.contains('hidden')) this.expand()
    else this.collapse()
  }

  setStatus(text: string, tone: PanelTone = 'info'): void {
    this.#status.textContent = text
    this.#dot.className = 'dot' + (tone === 'info' ? '' : ` ${tone}`)
  }

  setRunning(running: boolean): void {
    this.#running = running
    this.#runBtn.textContent = running ? 'Stop' : 'Run'
    this.#runBtn.classList.toggle('stop', running)
    this.#orb.classList.toggle('running', running)
    this.#dot.className = 'dot' + (running ? ' running' : '')
    if (!running) this.#input.focus()
  }

  log(text: string, tone: PanelTone = 'info'): void {
    const line = document.createElement('div')
    line.className = `line ${tone === 'info' ? '' : tone}`.trim()
    const t = document.createElement('span')
    t.className = 't'
    t.textContent = new Date().toLocaleTimeString([], { hour12: false })
    line.append(t, document.createTextNode(text))
    this.#feed.appendChild(line)
    this.#feedToggle.classList.add('has-activity')
    this.#feedToggle.title = `${this.#feed.childElementCount} activity item${this.#feed.childElementCount === 1 ? '' : 's'}`
    while (this.#feed.childElementCount > 120) this.#feed.firstElementChild?.remove()
    this.#feed.scrollTop = this.#feed.scrollHeight
  }

  /** Ask the user a question; resolves with their answer. OTP flows land here. */
  ask(question: string, opts: AskOptions = {}): Promise<string> {
    this.expand()
    this.#closeModal(new Error('superseded by a new question'))
    return new Promise<string>((resolve, reject) => {
      this.#pending = { resolve, reject }
      this.#modal.innerHTML = ''
      const q = document.createElement('div')
      q.className = 'q'
      q.textContent = question
      const input = document.createElement('input')
      input.type = opts.kind === 'password' ? 'password' : 'text'
      input.autocomplete = 'off'
      if (opts.kind === 'otp') {
        input.inputMode = 'numeric'
        input.placeholder = 'one-time code'
      }
      const hint = document.createElement('div')
      hint.className = 'hint'
      hint.textContent =
        opts.kind === 'otp'
          ? 'Argus never guesses codes — this value is used once and not stored.'
          : 'Sent directly to the page. Not stored unless you save it in the vault.'
      const row = document.createElement('div')
      row.className = 'row'
      const okBtn = document.createElement('button')
      okBtn.className = 'btn approve'
      okBtn.textContent = 'Send'
      const cancelBtn = document.createElement('button')
      cancelBtn.className = 'btn deny'
      cancelBtn.textContent = 'Cancel'
      const finish = (ok: boolean) => {
        const value = input.value
        this.#modal.classList.add('hidden')
        const pending = this.#pending
        this.#pending = null
        if (!pending) return
        if (ok) pending.resolve(value)
        else pending.reject(new Error('user cancelled'))
      }
      okBtn.addEventListener('click', () => finish(true))
      cancelBtn.addEventListener('click', () => finish(false))
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true)
        if (e.key === 'Escape') finish(false)
      })
      row.append(cancelBtn, okBtn)
      this.#modal.append(q, input, hint, row)
      this.#modal.classList.remove('hidden')
      input.focus()
    })
  }

  /** Confirm an irreversible action; resolves true when approved. */
  confirmAction(summary: string): Promise<boolean> {
    this.expand()
    this.#closeModal(new Error('superseded by an approval request'))
    return new Promise<boolean>((resolve) => {
      this.#pending = {
        resolve: () => resolve(true),
        reject: () => resolve(false),
      }
      this.#modal.innerHTML = ''
      const q = document.createElement('div')
      q.className = 'q'
      q.textContent = `Approve irreversible action?`
      const hint = document.createElement('div')
      hint.className = 'hint'
      hint.textContent = summary
      const row = document.createElement('div')
      row.className = 'row'
      const denyBtn = document.createElement('button')
      denyBtn.className = 'btn deny'
      denyBtn.textContent = 'Deny'
      const approveBtn = document.createElement('button')
      approveBtn.className = 'btn approve'
      approveBtn.textContent = 'Approve'
      const finish = (ok: boolean) => {
        this.#modal.classList.add('hidden')
        const pending = this.#pending
        this.#pending = null
        if (!pending) return
        if (ok) pending.resolve('')
        else pending.reject(new Error('denied'))
      }
      approveBtn.addEventListener('click', () => finish(true))
      denyBtn.addEventListener('click', () => finish(false))
      row.append(denyBtn, approveBtn)
      this.#modal.append(q, hint, row)
      this.#modal.classList.remove('hidden')
    })
  }

  #closeModal(reason: Error): void {
    if (this.#pending) {
      this.#pending.reject(reason)
      this.#pending = null
    }
    this.#modal.classList.add('hidden')
  }

  dispose(): void {
    if (this.#disposed) return
    this.#disposed = true
    this.#closeModal(new Error('panel disposed'))
    this.#host.remove()
  }
}
