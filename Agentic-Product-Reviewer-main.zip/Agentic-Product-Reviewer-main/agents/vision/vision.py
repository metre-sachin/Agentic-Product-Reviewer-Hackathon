"""Vision Agent — thin wrapper around the vision adapter for screenshot reasoning.

Kept separate from the adapter so the orchestrator can swap models without
touching the integration. Delegates the model call to VisionAdapter.decide.
"""

from __future__ import annotations

from integrations.vision.adapter import VisionAdapter


async def reason_about_screenshot(
    image_bytes: bytes,
    *,
    goal: str,
    step_label: str,
    elements_digest: str,
    model: str = "gpt-4o-mini",
    api_key: str = "",
    history: list[str] | None = None,
) -> dict:
    adapter = VisionAdapter(model=model, api_key=api_key)
    return await adapter.decide(
        image_bytes,
        goal=goal,
        step_label=step_label,
        elements_digest=elements_digest,
        history=history,
    )
