"""Planner Agent — turns a user goal into a structured plan.

Uses the OpenAI client via `backend.app.services.llm`. JSON mode guarantees a
parseable response shape: {title, intent, steps[]}.
"""

from __future__ import annotations

from typing import Any

from agents.state import AgentState, PlanStep

# Imported lazily inside plan() to avoid a hard import cycle for tests.

PLANNER_SYSTEM = """You are Argus, a careful autonomous web operator that plans how
to accomplish a user's goal on the open web using browser automation.

Output strict JSON with this shape:
{
  "title": "short imperative title (max 60 chars)",
  "intent": {
    "domain": "best-guess target site or category (e.g. 'blinkit.com', 'gmail.com', 'multiple')",
    "budget": null | number,
    "currency": null | "INR" | "USD" | ...,
    "constraints": ["short bullet constraints inferred from the goal"]
  },
  "steps": [
    {
      "label": "imperative action, no more than 12 words",
      "meta": one of "AUTO" | "STRUCTURED" | "EXECUTING" | "APPROVAL" | "PENDING"
    }
  ]
}

Rules:
- Use the FEWEST steps that actually accomplish the goal — typically 3 to 6, and
  at most 9. Each step must be a distinct, concrete action. Do NOT pad: merge
  trivial adjacent actions (e.g. "open site" + "log in" can be one step), and do
  not add a separate "review"/"verify" step unless verification genuinely needs
  its own action. Prefer the shortest path; if you know a direct route, take it.
- If "What Argus already learned about this site" is provided below, USE it: take
  the shortcuts that worked and avoid the approaches that failed — plan around
  them rather than rediscovering them.
- Use 'STRUCTURED' for navigation/auth/search/form-fill steps.
- Use 'EXECUTING' for the main action (adding to cart, drafting email, etc.).
- Use 'APPROVAL' for any step that pays money, submits a form/application,
  sends an email/message, books a ticket, places an order, posts publicly.
- Use 'AUTO' for inference, summary, or research-only steps.
- For research / "find, compare, summarize, check" goals: name the concrete
  source sites in the relevant steps (e.g. 'en.wikipedia.org', 'arxiv.org',
  'news.ycombinator.com'), use one step per source when several are involved,
  and ALWAYS finish with a single 'AUTO' step that synthesises the final answer
  for the user.
- Never include a step that auto-completes payment, submission, or booking
  without a preceding APPROVAL gate.
- Constraints should reflect what the user *said* (budget, dietary, dates,
  location, etc.). Do not invent constraints.
"""


REPLAN_SYSTEM = """You are Argus, RE-PLANNING a web task that is already in progress.
The user paused and gave a new instruction, and may have attached a screenshot of
exactly where the browser is right now. Produce the REMAINING steps to finish the
task from the CURRENT state — do NOT repeat work already completed.

Output strict JSON with this shape:
{
  "steps": [
    { "label": "imperative action, no more than 12 words",
      "meta": one of "AUTO" | "STRUCTURED" | "EXECUTING" | "APPROVAL" | "PENDING" }
  ]
}

Rules:
- Between 1 and 9 steps, ordered and concrete. Continue from where things stand.
- Prioritise the user's NEW instruction; treat the screenshot (if any) as the
  ground truth for the current page.
- Use 'STRUCTURED' for navigation/auth/search/form-fill, 'EXECUTING' for the main
  action, 'APPROVAL' before anything that pays/submits/sends/books/posts, and
  'AUTO' for inference/summary/research steps. Never auto-complete an irreversible
  action without a preceding APPROVAL gate.
"""


def _coerce_steps(raw_steps: list[dict[str, Any]]) -> list[PlanStep]:
    steps: list[PlanStep] = []
    for i, step in enumerate(raw_steps[:12], start=1):
        label = str(step.get("label") or "").strip()
        if not label:
            continue
        meta = str(step.get("meta") or "AUTO").upper()
        if meta not in {"AUTO", "STRUCTURED", "EXECUTING", "APPROVAL", "PENDING"}:
            meta = "AUTO"
        steps.append(PlanStep(ordinal=i, label=label[:160], meta=meta, state="pending"))
    return steps


async def plan(state: AgentState, *, model: str | None = None) -> AgentState:
    from app.services.llm import complete_json

    parts = [f"Goal: {state.goal.strip()}"]
    if state.memories:
        prefs = "\n".join(f"- [{m.get('tag')}] {m.get('text')}" for m in state.memories)
        parts.append(
            "Known user preferences (apply any that are relevant; ignore the rest):\n" + prefs
        )
    if state.lessons:
        parts.append("What Argus already learned about this site:\n" + state.lessons)
    parts.append("Return the JSON plan.")
    user_prompt = "\n\n".join(parts)
    payload = await complete_json(
        system=PLANNER_SYSTEM,
        user=user_prompt,
        model=model,
        temperature=0.2,
    )

    title = str(payload.get("title") or state.goal[:60])
    intent = payload.get("intent") or {}
    if not isinstance(intent, dict):
        intent = {}

    raw_steps = payload.get("steps") or []
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ValueError("planner returned no steps")

    state.plan = _coerce_steps(raw_steps)
    state.intent = {
        "title": title,
        "domain": intent.get("domain"),
        "budget": intent.get("budget"),
        "currency": intent.get("currency"),
        "constraints": intent.get("constraints") or [],
    }
    return state


async def replan(
    state: AgentState,
    *,
    done_steps: list[dict[str, Any]],
    observations: list[str],
    current_url: str | None,
    user_instruction: str,
    screenshot_b64: str | None = None,
    notes: list[str] | None = None,
    model: str | None = None,
) -> AgentState:
    """Rebuild the REMAINING plan for an in-progress task from the user's new
    instruction (and an optional screenshot of the current page). Returns the
    state with `state.plan` set to the new remaining steps only."""
    from app.services.llm import complete_json, complete_json_vision

    parts = [f"Original goal: {state.goal.strip()}"]
    if state.intent.get("constraints"):
        parts.append("Constraints: " + ", ".join(map(str, state.intent["constraints"])))
    if done_steps:
        done = "\n".join(
            f"- [{s.get('state', 'done')}] {s.get('label')}" for s in done_steps
        )
        parts.append("Already attempted (do not repeat):\n" + done)
    if notes:
        parts.append(
            "What already failed this run — do NOT repeat these approaches:\n"
            + "\n".join(f"- {n}" for n in notes[-6:])
        )
    if state.lessons:
        parts.append("What Argus learned about this site:\n" + state.lessons)
    if observations:
        parts.append("Findings so far: " + " | ".join(observations[-5:]))
    if current_url:
        parts.append(f"Current page: {current_url}")
    parts.append(f"\nThe user's NEW instruction:\n{user_instruction.strip()}")
    parts.append(
        "\nReturn the JSON with the remaining steps — the FEWEST that finish the "
        "task from here. No filler."
    )
    user_prompt = "\n\n".join(parts)

    if screenshot_b64:
        payload = await complete_json_vision(
            system=REPLAN_SYSTEM,
            user=user_prompt,
            image_b64=screenshot_b64,
            model=model,
            temperature=0.2,
            max_tokens=600,
        )
    else:
        payload = await complete_json(
            system=REPLAN_SYSTEM,
            user=user_prompt,
            model=model,
            temperature=0.2,
            max_tokens=600,
        )

    raw_steps = payload.get("steps") or []
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ValueError("replanner returned no steps")
    state.plan = _coerce_steps(raw_steps)
    return state
