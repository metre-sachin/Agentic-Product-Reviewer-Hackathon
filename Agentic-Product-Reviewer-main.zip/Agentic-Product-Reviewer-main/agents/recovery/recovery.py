"""Recovery Agent.

Decides escalation when a step fails or confidence drops below threshold.
Order: Scrapling -> Agent Browser -> Browser Use -> Vision -> Human.
"""

from __future__ import annotations

from integrations.base import Layer, StepResult

CONFIDENCE_THRESHOLD = 0.55

ESCALATION: dict[Layer, Layer | None] = {
    Layer.SCRAPLING: Layer.AGENT_BROWSER,
    Layer.AGENT_BROWSER: Layer.BROWSER_USE,
    Layer.BROWSER_USE: Layer.VISION,
    Layer.VISION: Layer.HUMAN,
    Layer.HUMAN: None,
}


def should_escalate(result: StepResult) -> bool:
    return (not result.ok) or result.confidence < CONFIDENCE_THRESHOLD


def next_layer(current: Layer) -> Layer | None:
    return ESCALATION.get(current)
