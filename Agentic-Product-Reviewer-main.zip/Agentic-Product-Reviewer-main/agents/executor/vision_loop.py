"""Vision interaction loop — L4 fallback.

A bounded screenshot -> reason -> act cycle. The vision model looks at a real
screenshot and the labelled element list, then chooses an action that we execute
through the Agent Browser adapter (click by ref) or the Playwright controller
(click by pixel coordinates).

Reuses the InteractionResult shape so the runtime treats L4 like L2/L3.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from agents.executor.browser_loop import (
    _ACTION_KIND,
    InteractionResult,
    Record,
    _best_add_to_cart,
    _el_label,
    _element_center,
    _is_generic_click_target,
    _looks_like_add_to_cart,
    _record_value,
    _step_wants_add_to_cart,
)
from agents.vision.vision import reason_about_screenshot

MAX_ACTIONS = 5
MAX_REPEAT_ACTION = 2

Emit = Callable[[str, str | None], Awaitable[None]]


def _decision_key(decision: dict) -> str:
    return "|".join(
        [
            str(decision.get("action") or "").lower(),
            str(decision.get("ref") or ""),
            str(decision.get("text") or "")[:80],
            str(decision.get("direction") or ""),
            str(decision.get("x") or ""),
            str(decision.get("y") or ""),
        ]
    )


def _intish(value, default: int) -> int:  # noqa: ANN001
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


async def run_vision(
    *,
    adapter,                 # AgentBrowserAdapter
    controller,              # PlaywrightController (for screenshot bytes + click_xy)
    goal: str,
    step_label: str,
    intent: dict,
    emit: Emit,
    model: str,
    api_key: str,
    record: Record | None = None,
) -> InteractionResult:
    if controller is None:
        return InteractionResult(ok=False, observation="no browser for vision")

    history: list[str] = []
    repeats: dict[str, int] = {}
    for i in range(MAX_ACTIONS):
        image = await controller.screenshot_bytes()
        if image is None:
            return InteractionResult(ok=False, observation="could not capture screenshot")

        snap = await adapter.snapshot()
        decision = await reason_about_screenshot(
            image,
            goal=goal,
            step_label=step_label,
            elements_digest=snap.digest(),
            model=model,
            api_key=api_key,
            history=history,
        )
        action = str(decision.get("action") or "give_up").lower()
        thought = str(decision.get("thought") or "")
        key = _decision_key(decision)
        if repeats.get(key, 0) >= MAX_REPEAT_ACTION:
            return InteractionResult(
                ok=False,
                observation="Vision repeated the same no-progress action",
                actions_taken=i,
                data={"cause": "vision_repeated_action", "history": history[-6:]},
            )

        if action == "done":
            return InteractionResult(
                ok=True,
                observation=str(decision.get("observation") or f"Completed: {step_label}"),
                actions_taken=i,
            )
        if action == "give_up":
            return InteractionResult(ok=False, observation="", actions_taken=i)

        ref = str(decision.get("ref") or "")
        target = next((e for e in snap.elements if e.get("ref") == ref), None)
        target_label = _el_label(target) or str(decision.get("target") or "")
        if action == "click" and _step_wants_add_to_cart(step_label):
            should_pick_cta = (
                not ref
                or _is_generic_click_target(target_label, target)
                or not _looks_like_add_to_cart(target_label)
                or any("main content" in h.lower() for h in history[-4:])
            )
            cta = _best_add_to_cart(snap) if should_pick_cta else None
            if cta is not None:
                ref = str(cta.get("ref") or ref)
                target = cta
                target_label = _el_label(cta)
        ok = False
        desc = ""
        if action == "click":
            if ref:
                ok = await adapter.click(ref)
                desc = f"Vision clicked {target_label or ref}"
                if not ok:
                    point = _element_center(target)
                    if point is not None:
                        ok = await controller.click_xy(*point)
                        if ok:
                            desc = f"Vision clicked {target_label or ref} at screen position"
            if not ok and decision.get("x") is not None and decision.get("y") is not None:
                ok = await controller.click_xy(float(decision["x"]), float(decision["y"]))
                desc = f"Vision clicked ({decision.get('x')}, {decision.get('y')})"
        elif action == "type":
            text = str(decision.get("text") or "")
            if ref:
                ok = await adapter.type_text(ref, text)
                desc = f"Vision typed into {ref}"
        elif action == "scroll":
            direction = str(decision.get("direction") or "down")
            ok = await adapter.scroll(direction, _intish(decision.get("amount"), 650))
            desc = f"Vision scrolled {direction}"
        elif action == "wait":
            ms = _intish(decision.get("amount"), 1000)
            ok = await adapter.wait(ms)
            desc = f"Vision waited {ms}ms"

        await emit(desc or f"Vision action: {action}", thought or None)
        if record is not None and action in _ACTION_KIND:
            await record(
                {
                    "kind": _ACTION_KIND[action],
                    "target": target_label or None,
                    "value": _record_value(action, decision, target),
                    "url": str(getattr(snap, "url", "") or "") or None,
                    "ok": bool(ok),
                }
            )
        if ok:
            repeats[key] = 0
            history.append(desc or action)
        else:
            repeats[key] = repeats.get(key, 0) + 1
            history.append(f"{desc or action} -> failed")

    return InteractionResult(
        ok=False,
        observation=f"Vision reached limit on: {step_label}",
        data={"cause": "vision_action_limit", "history": history[-6:]},
    )
