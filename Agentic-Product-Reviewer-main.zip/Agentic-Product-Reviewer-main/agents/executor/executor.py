"""Executor Agent.

For each plan step the executor:
  1. Asks the LLM what to do (search the web, fetch a URL, reason from context,
     or flag that the step needs page interaction).
  2. Runs the Scrapling reading layer for search/fetch actions.
  3. Asks the LLM to distil a concise, relevant observation from what it read.

Reading (L1) is fully real here. Acting layers (Agent Browser / Browser Use /
Vision) arrive in later phases — until then, interaction steps return
`needs_interaction` so the runtime logs an honest note and moves on.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from urllib.parse import parse_qs, unquote, urlparse

from integrations.base import Layer
from integrations.scrapling.adapter import ScraplingAdapter

log = logging.getLogger(__name__)

# A page reader: url -> {"url","title","text","links"} or None. A searcher:
# query -> the same shape for the results page. Callers (the runtime) inject
# browser-backed implementations; the executor falls back to plain HTTP.
PageReader = Callable[[str], Awaitable[dict | None]]
Searcher = Callable[[str], Awaitable[dict | None]]

_scrapling = ScraplingAdapter()

# How many real result pages to open and read per research step, and how much
# text to keep from each so the combined read stays within the model budget.
MAX_FOLLOW = 3
PER_PAGE_CHARS = 2800
TOTAL_CHARS = 8000


@dataclass
class ExecResult:
    ok: bool
    layer: str
    observation: str
    detail: str | None = None
    needs_interaction: bool = False
    url: str | None = None
    data: dict = field(default_factory=dict)


DECIDE_SYSTEM = """You are Argus's executor. Decide the single best next action to
make progress on ONE step of a web task. Output strict JSON:

{
  "action": "search" | "fetch" | "reason" | "interact",
  "query": "search query (when action=search)",
  "url": "absolute url (when action=fetch)",
  "rationale": "one short sentence"
}

Guidance:
- "search": you need to find pages/sites/options on the open web. When the step
  targets a specific site, include that site/domain in the query (e.g.
  "climate change site:bbc.com").
- "fetch": you already know the exact URL to read.
- "reason": the step is pure inference/summary/decision over what you already know.
- "interact": the step requires clicking, typing, logging in, adding to cart,
  submitting a form, or completing a purchase (cannot be done by reading alone).
Pick "interact" honestly when the step is an action, not a read.
"""

EXTRACT_SYSTEM = """You are Argus's executor, reading REAL web page(s) to advance ONE
step of a task. The content may contain several pages separated by
'--- SOURCE: <url> ---' markers — synthesise across all of them.

Write a concise, FACTUAL observation (max 5 sentences) capturing only what is
relevant to the step: concrete facts, names, prices, dates, headlines, figures,
options. Quote specifics rather than vague summaries, and note which source a key
fact came from when helpful.

Set "useful": false ONLY when the content genuinely has nothing relevant — a
block/login page, an empty search, or unrelated text. Never set useful=true for a
page that simply lacks the requested information.

Output strict JSON: {"observation": "...", "useful": true|false}.
"""

REASON_SYSTEM = """You are Argus's executor. Complete one reasoning/summary step of
a task using the accumulated context. Be concrete and brief (max 3 sentences).
Output strict JSON: {"observation": "..."}.
"""


def _context_blurb(goal: str, intent: dict, prior: list[str]) -> str:
    lines = [f"Task goal: {goal}"]
    if intent.get("domain"):
        lines.append(f"Likely site/domain: {intent['domain']}")
    if intent.get("constraints"):
        lines.append(f"Constraints: {', '.join(map(str, intent['constraints']))}")
    if prior:
        lines.append("What Argus has learned so far:")
        lines.extend(f"- {p}" for p in prior[-6:])
    return "\n".join(lines)


async def execute_step(
    *,
    goal: str,
    step_label: str,
    step_meta: str,
    intent: dict,
    prior_observations: list[str],
    scrapling_enabled: bool = True,
    searcher: Searcher | None = None,
    reader: PageReader | None = None,
    model: str | None = None,
) -> ExecResult:
    from app.services.llm import complete_json

    # Prefer the injected (browser-backed) search/read, falling back to plain
    # HTTP when it returns nothing or isn't provided. Real Chrome passes the
    # bot-checks that block HTTP search engines, so this is what lets Argus
    # actually reach and read live sites.
    async def _do_search(q: str) -> dict | None:
        if searcher is not None:
            try:
                r = await searcher(q)
                if r:
                    return r
            except Exception as exc:  # noqa: BLE001
                log.info("browser search failed, falling back to HTTP: %s", exc)
        return await _scrapling_search(q)

    async def _do_read(u: str) -> dict | None:
        if reader is not None:
            try:
                r = await reader(u)
                if r:
                    return r
            except Exception as exc:  # noqa: BLE001
                log.info("browser read failed, falling back to HTTP: %s", exc)
        return await _scrapling_read(u)

    context = _context_blurb(goal, intent, prior_observations)
    decision = await complete_json(
        system=DECIDE_SYSTEM,
        user=f"{context}\n\nStep to perform now: {step_label}\nReturn the action JSON.",
        model=model,
        temperature=0.1,
        max_tokens=300,
    )
    action = str(decision.get("action") or "reason").lower()

    # --- interaction step: not readable, defer to acting layers (later phases) ---
    if action == "interact":
        return ExecResult(
            ok=False,
            layer=Layer.AGENT_BROWSER.value,
            observation="",
            detail="step needs page interaction (acting layer pending)",
            needs_interaction=True,
        )

    # --- reading (L1): real multi-hop browsing ---
    if action in ("search", "fetch") and scrapling_enabled:
        url = str(decision.get("url") or "")
        if action == "fetch" and url:
            result = await _read_pages([url], step_label, query=goal, read=_do_read, model=model)
        else:
            query = str(decision.get("query") or goal)
            result = await _research(
                query,
                step_label,
                intent,
                search=_do_search,
                read=_do_read,
                model=model,
            )
        if result is not None:
            return result
        # Read produced nothing usable — fall through to reasoning so the task
        # still progresses, but it will be marked unsuccessful honestly.

    # --- reasoning fallback (no web needed, or read unavailable/failed) ---
    reasoned = await complete_json(
        system=REASON_SYSTEM,
        user=f"{context}\n\nStep to complete by reasoning: {step_label}\nReturn JSON.",
        model=model,
        temperature=0.2,
        max_tokens=300,
    )
    obs = str(reasoned.get("observation") or "").strip()
    layer = Layer.SCRAPLING.value if action in ("search", "fetch") else Layer.HUMAN.value
    return ExecResult(
        ok=bool(obs),
        layer=layer if action in ("search", "fetch") else "reasoning",
        observation=obs or f"Completed: {step_label}",
        detail=None if scrapling_enabled else "scrapling disabled",
    )


def _real_url(href: str) -> str:
    """Resolve a SERP href to its true target, decoding DuckDuckGo's /l/?uddg=
    redirector. Returns '' for non-http or search-engine-internal links."""
    if not href:
        return ""
    try:
        p = urlparse(href)
        if "duckduckgo.com" in p.netloc and p.path.startswith("/l/"):
            uddg = parse_qs(p.query).get("uddg", [None])[0]
            return unquote(uddg) if uddg else ""
        if p.scheme in ("http", "https"):
            return href
    except Exception:  # noqa: BLE001
        return ""
    return ""


def _rank_links(links: list[dict], domain_hint: str) -> list[str]:
    """Clean, dedupe, and order candidate result URLs. Real result pages only —
    no search-engine chrome — with the intended domain floated to the top."""
    out: list[str] = []
    seen: set[str] = set()
    for link in links:
        url = _real_url(str(link.get("href") or ""))
        if not url:
            continue
        host = urlparse(url).netloc.lower()
        if not host or "duckduckgo.com" in host:
            continue
        if url in seen:
            continue
        seen.add(url)
        out.append(url)
    hint = (domain_hint or "").strip().lower()
    if hint and hint not in ("multiple", "various", "n/a"):
        out.sort(key=lambda u: 0 if hint in urlparse(u).netloc.lower() else 1)
    return out


async def _scrapling_search(query: str) -> dict | None:
    """Default searcher: plain HTTP search (fallback when no browser)."""
    r = await _scrapling.search(query)
    if not getattr(r, "ok", False):
        return None
    return {
        "url": r.observed.get("url"),
        "title": r.observed.get("title") or "",
        "text": str(r.observed.get("text") or ""),
        "links": r.observed.get("links") or [],
    }


async def _scrapling_read(url: str) -> dict | None:
    """Default page reader: plain HTTP fetch (fallback when no browser)."""
    r = await _scrapling.fetch(url)
    if not getattr(r, "ok", False):
        return None
    text = str(r.observed.get("text") or "")
    if not text.strip():
        return None
    return {
        "url": r.observed.get("url") or url,
        "title": r.observed.get("title") or "",
        "text": text,
        "links": r.observed.get("links") or [],
    }


async def _read_each(urls: list[str], read: PageReader) -> list[tuple[str, str, str]]:
    """Read each URL in turn; keep (url, title, text) for the ones with content."""
    pages: list[tuple[str, str, str]] = []
    for u in urls[:MAX_FOLLOW]:
        try:
            pg = await read(u)
        except Exception as exc:  # noqa: BLE001
            log.info("read failed for %s: %s", u, exc)
            continue
        if pg and str(pg.get("text") or "").strip():
            pages.append((str(pg.get("url") or u), str(pg.get("title") or ""), str(pg["text"])))
    return pages


def _combine(pages: list[tuple[str, str, str]]) -> tuple[str, list[str]]:
    chunks: list[str] = []
    sources: list[str] = []
    total = 0
    for url, title, text in pages:
        snippet = text[:PER_PAGE_CHARS]
        chunks.append(f"--- SOURCE: {url} ({title}) ---\n{snippet}")
        sources.append(url)
        total += len(snippet)
        if total >= TOTAL_CHARS:
            break
    return "\n\n".join(chunks), sources


async def _extract_from(
    text: str,
    sources: list[str],
    step_label: str,
    query: str,
    *,
    model: str | None = None,
) -> ExecResult:
    from app.services.llm import complete_json

    extracted = await complete_json(
        system=EXTRACT_SYSTEM,
        user=(
            f"Step goal: {step_label}\nSearch query: {query}\n\n"
            f"Page content (may contain multiple SOURCE-delimited pages):\n"
            f"{text[:TOTAL_CHARS]}\n\nReturn JSON."
        ),
        model=model,
        temperature=0.1,
        max_tokens=450,
    )
    obs = str(extracted.get("observation") or "").strip()
    useful = bool(extracted.get("useful"))
    clean = [s for s in sources if s]
    return ExecResult(
        ok=useful and bool(obs),
        layer=Layer.SCRAPLING.value,
        observation=obs or "Read the page(s) but found nothing relevant to this step.",
        detail=" · ".join(clean[:3]) or None,
        url=clean[0] if clean else None,
        data={"sources": clean[:5]},
    )


async def _read_pages(
    urls: list[str],
    step_label: str,
    *,
    query: str,
    read: PageReader,
    model: str | None = None,
) -> ExecResult | None:
    """Open the given URLs, read their real content, and extract an observation."""
    pages = await _read_each(urls, read)
    if not pages:
        return None
    combined, sources = _combine(pages)
    if not combined.strip():
        return None
    return await _extract_from(combined, sources, step_label, query, model=model)


async def _research(
    query: str,
    step_label: str,
    intent: dict,
    *,
    search: Searcher,
    read: PageReader,
    model: str | None = None,
) -> ExecResult | None:
    """Search, then actually visit the top results and read them — instead of
    extracting from the search-results page itself."""
    serp = await search(query)
    if not serp:
        return None
    domain_hint = str((intent or {}).get("domain") or "")
    urls = _rank_links(serp.get("links") or [], domain_hint)
    if urls:
        result = await _read_pages(urls, step_label, query=query, read=read, model=model)
        if result is not None and result.ok:
            return result
    # No followable results (or none useful) — fall back to the SERP text so the
    # step still has a chance, but usefulness is judged honestly downstream.
    return await _extract_from(
        str(serp.get("text") or ""),
        [str(serp.get("url") or "")],
        step_label,
        query,
        model=model,
    )


def pick_layer(step_meta: str) -> Layer:
    """Initial layer choice based on step intent. Recovery may escalate later."""
    meta = (step_meta or "").upper()
    if meta in {"AUTO", "READ", "RESEARCH", "PENDING"}:
        return Layer.SCRAPLING
    return Layer.AGENT_BROWSER
