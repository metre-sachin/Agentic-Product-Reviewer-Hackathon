"""Unit tests for the cart ledger in the browser interaction loop.

These guard the "add each item only once, stay under budget" rule: Argus tracks
what it has already added so add-to-cart steps never duplicate a product or cross
the spend cap. Pure logic, no browser or network — runnable with stdlib unittest:

    PYTHONPATH=. backend/.venv/bin/python -m unittest \
        agents.executor.tests.test_cart_ledger
"""

from __future__ import annotations

import asyncio
import unittest
from dataclasses import dataclass, field
from typing import Any

from agents.executor import browser_loop
from agents.executor.browser_loop import (
    _cart_item_for_cta,
    _cart_state_block,
    _clean_item_name,
    _ledger_total,
    _name_in_ledger,
    _normalize_name,
    _parse_prices,
    run_interaction,
)


def _el(ref: str, *, text: str = "", name: str = "", rect: dict | None = None) -> dict[str, Any]:
    return {"ref": ref, "text": text, "name": name, "rect": rect or {}}


def _rect(x: int, y: int, w: int, h: int) -> dict[str, Any]:
    return {"x": x, "y": y, "w": w, "h": h, "cx": x + w // 2, "cy": y + h // 2}


@dataclass
class _Snap:
    elements: list[dict[str, Any]] = field(default_factory=list)


class PriceParsingTests(unittest.TestCase):
    def test_extracts_rupee_prices(self) -> None:
        self.assertEqual(_parse_prices("₹65 ₹75"), [65.0, 75.0])

    def test_handles_thousands_separator(self) -> None:
        self.assertEqual(_parse_prices("Total ₹1,250.50"), [1250.5])

    def test_no_price(self) -> None:
        self.assertEqual(_parse_prices("Add to cart"), [])


class NameCleaningTests(unittest.TestCase):
    def test_strips_offer_price_and_add(self) -> None:
        cleaned = _clean_item_name("13% OFF MTR Puliogare Powder 100 g ₹65 ₹75 ADD")
        self.assertEqual(cleaned, "MTR Puliogare Powder 100 g")

    def test_normalize_ignores_size_and_case(self) -> None:
        self.assertEqual(
            _normalize_name("MTR Puliogare Powder 200 g"),
            _normalize_name("mtr puliogare powder 100 g"),
        )


class LedgerMatchTests(unittest.TestCase):
    def setUp(self) -> None:
        self.ledger = [
            {"name": "MTR Puliogare Powder 200 g", "price": 120.0},
            {"name": "Catch Puliogare Powder", "price": 48.0},
        ]

    def test_same_product_different_size_is_a_duplicate(self) -> None:
        self.assertTrue(_name_in_ledger("MTR Puliogare Powder 100 g", self.ledger))

    def test_distinct_product_is_not_a_duplicate(self) -> None:
        self.assertFalse(_name_in_ledger("Aachi Garam Masala", self.ledger))

    def test_empty_name_never_matches(self) -> None:
        self.assertFalse(_name_in_ledger("", self.ledger))

    def test_total_tolerates_missing_price(self) -> None:
        self.assertEqual(_ledger_total(self.ledger + [{"name": "x", "price": None}]), 168.0)


class CtaProductExtractionTests(unittest.TestCase):
    def test_finds_enclosing_card_name_and_discounted_price(self) -> None:
        cta = _el("e1", text="ADD", rect=_rect(180, 290, 60, 30))
        card = _el(
            "e2",
            text="13% OFF MTR Puliogare Powder 100 g ₹65 ₹75 ADD",
            rect=_rect(120, 250, 160, 140),  # encloses the CTA centre
        )
        far = _el("e3", text="Other product ₹999", rect=_rect(800, 250, 160, 140))
        snap = _Snap([cta, card, far])

        name, price = _cart_item_for_cta(snap, cta)
        self.assertEqual(name, "MTR Puliogare Powder 100 g")
        self.assertEqual(price, 65.0)  # pays the lower (discounted) price

    def test_returns_blank_when_no_priced_card_encloses_cta(self) -> None:
        cta = _el("e1", text="ADD", rect=_rect(180, 290, 60, 30))
        snap = _Snap([cta, _el("e2", text="Banner", rect=_rect(0, 0, 1200, 80))])
        self.assertEqual(_cart_item_for_cta(snap, cta), ("", None))


class CartStateBlockTests(unittest.TestCase):
    def test_lists_items_subtotal_and_remaining(self) -> None:
        ledger = [
            {"name": "MTR Puliogare Powder", "price": 65.0},
            {"name": "Catch Puliogare Powder", "price": 48.0},
        ]
        block = _cart_state_block(ledger, budget=1000.0, currency="INR")
        self.assertIn("MTR Puliogare Powder", block)
        self.assertIn("Cart subtotal: ₹113 of ₹1000", block)
        self.assertIn("Remaining: ₹887", block)
        self.assertIn("ONE new DISTINCT item", block)

    def test_empty_cart_message(self) -> None:
        block = _cart_state_block([], budget=500.0, currency="INR")
        self.assertIn("cart is currently empty", block)
        self.assertIn("Remaining: ₹500", block)


@dataclass
class _FullSnap:
    url: str = "https://blinkit.com/s/?q=rice"
    title: str = "Blinkit"
    elements: list[dict[str, Any]] = field(default_factory=list)

    def digest(self, limit: int = 60) -> str:
        return "interactive elements"


class _FakeAdapter:
    """Minimal stand-in for AgentBrowserAdapter: a static rice-results page whose
    clicks always 'succeed'."""

    def __init__(self, snap: _FullSnap) -> None:
        self._snap = snap
        self.clicks: list[str] = []

    async def goto(self, url: str) -> str:
        return url

    async def snapshot(self) -> _FullSnap:
        return self._snap

    async def page_text(self, limit: int = 5000) -> str:
        return ""

    async def click(self, ref: str) -> bool:
        self.clicks.append(ref)
        return True

    async def type_text(self, ref: str, text: str) -> bool:
        return True

    async def select(self, ref: str, value: str) -> bool:
        return True

    async def press(self, key: str) -> bool:
        return True

    async def scroll(self, direction: str, amount: int) -> bool:
        return True

    async def wait(self, ms: int) -> bool:
        return True


class OneItemPerStepTests(unittest.TestCase):
    """The core "only once per item" guarantee: an add-to-cart step adds exactly
    ONE product and finishes, even when the model would happily keep clicking ADD
    on every other rice on the page."""

    def setUp(self) -> None:
        add_btn = {
            "ref": "e_add", "tag": "div", "type": "", "role": "button",
            "name": "ADD", "text": "ADD", "href": "",
            "editable": False, "filled": False, "disabled": False,
            "rect": _rect(180, 290, 60, 30),
        }
        card = _el(
            "e_card",
            text="India Gate Raw Sonamasuri Rice 1 kg ₹88 ₹99 ADD",
            rect=_rect(120, 250, 160, 170),  # encloses the ADD button
        )
        self.adapter = _FakeAdapter(_FullSnap(elements=[card, add_btn]))
        self._orig_decide = browser_loop._decide
        self._calls = {"n": 0}

        async def _fake_decide(**_kw: Any) -> dict[str, Any]:
            # The model would keep choosing ADD; the loop must cut it off after one.
            self._calls["n"] += 1
            if self._calls["n"] > 4:  # safety so a regression can't hang the test
                return {"action": "done", "observation": "stop"}
            return {"action": "click", "ref": "e_add", "target": "ADD"}

        browser_loop._decide = _fake_decide  # type: ignore[assignment]

    def tearDown(self) -> None:
        browser_loop._decide = self._orig_decide  # type: ignore[assignment]

    async def _emit(self, text: str, detail: str | None = None) -> None:
        return None

    def test_step_stops_after_one_product(self) -> None:
        result = asyncio.run(
            run_interaction(
                adapter=self.adapter,
                goal="make pulliodare under 1000, only once per item",
                step_label="Select the first ingredient and add to cart",
                intent={},
                prior_observations=[],
                emit=self._emit,
                cart_ledger=[],
                budget=1000.0,
                currency="INR",
            )
        )
        self.assertTrue(result.ok)
        # Exactly one ADD click, one ledger entry, and the model was only asked once.
        self.assertEqual(self.adapter.clicks, ["e_add"])
        self.assertEqual(self._calls["n"], 1)
        added = result.data.get("added_items") or []
        self.assertEqual(len(added), 1)
        self.assertIn("India Gate", added[0]["name"])
        self.assertEqual(added[0]["price"], 88.0)


if __name__ == "__main__":
    unittest.main()
