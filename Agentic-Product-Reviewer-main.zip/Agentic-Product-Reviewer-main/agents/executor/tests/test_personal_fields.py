"""Unit tests for sensitive-field detection in the browser interaction loop.

These guard the privacy rule: Argus must recognise personal/sensitive form
fields so it asks the user instead of auto-filling them. Pure logic, no browser
or network — runnable with stdlib unittest:

    PYTHONPATH=. backend/.venv/bin/python -m unittest \
        agents.executor.tests.test_personal_fields
"""

from __future__ import annotations

import unittest
from dataclasses import dataclass, field
from typing import Any

from agents.executor.browser_loop import (
    _best_message_box,
    _collect_personal_fields,
    _looks_like_message_box,
    _looks_like_search_box,
    _personal_kind,
    _step_wants_message_compose,
)


def _el(ref: str, **kw: Any) -> dict[str, Any]:
    base = {
        "ref": ref, "tag": "input", "type": "text", "role": "", "name": "",
        "placeholder": "", "text": "", "href": "", "editable": True,
        "filled": False, "disabled": False,
    }
    base.update(kw)
    return base


@dataclass
class _Snap:
    elements: list[dict[str, Any]] = field(default_factory=list)


class PersonalKindTests(unittest.TestCase):
    def test_classifies_common_sensitive_fields(self) -> None:
        cases = {
            "email": _el("e1", type="email"),
            "phone": _el("e2", type="tel"),
            "phone-by-name": _el("e3", name="Mobile number"),
            "name": _el("e4", placeholder="Full name"),
            "username": _el("e5", name="username"),
            "address": _el("e6", placeholder="Street address"),
            "dob": _el("e7", name="Date of birth"),
            "card": _el("e8", placeholder="Card number"),
        }
        self.assertEqual(_personal_kind(cases["email"]), "email")
        self.assertEqual(_personal_kind(cases["phone"]), "phone")
        self.assertEqual(_personal_kind(cases["phone-by-name"]), "phone")
        self.assertEqual(_personal_kind(cases["name"]), "name")
        self.assertEqual(_personal_kind(cases["username"]), "username")
        self.assertEqual(_personal_kind(cases["address"]), "address")
        self.assertEqual(_personal_kind(cases["dob"]), "dob")
        self.assertEqual(_personal_kind(cases["card"]), "card")

    def test_excludes_other_gates_and_non_personal(self) -> None:
        # password, OTP and CAPTCHA have their own dedicated flows
        self.assertIsNone(_personal_kind(_el("e1", type="password", name="Password")))
        self.assertIsNone(_personal_kind(_el("e2", name="One-time passcode")))
        self.assertIsNone(_personal_kind(_el("e3", placeholder="Type the text above")))
        # plain non-personal fields
        self.assertIsNone(_personal_kind(_el("e4", placeholder="Search products")))
        self.assertIsNone(_personal_kind(_el("e5", name="Quantity")))
        self.assertIsNone(_personal_kind(_el("e6", placeholder="Coupon code")))

    def test_ignores_filled_and_non_editable(self) -> None:
        self.assertIsNone(_personal_kind(_el("e1", type="email", filled=True)))
        self.assertIsNone(_personal_kind(_el("e2", name="Full name", editable=False)))
        self.assertIsNone(_personal_kind(None))


class CollectPersonalFieldsTests(unittest.TestCase):
    def test_scans_snapshot_when_no_request(self) -> None:
        snap = _Snap([
            _el("e0", type="submit", editable=False, name="Continue"),
            _el("e1", placeholder="Full name"),
            _el("e2", type="email"),
            _el("e3", type="tel", name="Phone"),
            _el("e4", placeholder="Search"),  # excluded
        ])
        fields = _collect_personal_fields(snap, None)
        refs = {f["ref"] for f in fields}
        self.assertEqual(refs, {"e1", "e2", "e3"})
        kinds = {f["ref"]: f["kind"] for f in fields}
        self.assertEqual(kinds["e2"], "email")
        self.assertEqual(kinds["e3"], "phone")

    def test_honours_requested_fields(self) -> None:
        snap = _Snap([
            _el("e1", placeholder="Full name"),
            _el("e2", type="email"),
        ])
        fields = _collect_personal_fields(
            snap, [{"ref": "e2", "label": "Work email", "kind": "email"}]
        )
        self.assertEqual(len(fields), 1)
        self.assertEqual(fields[0]["ref"], "e2")
        self.assertEqual(fields[0]["label"], "Work email")

    def test_tolerates_malformed_request(self) -> None:
        snap = _Snap([_el("e1", placeholder="Full name")])
        # non-dict items and unknown refs must not crash; falls back to scan
        fields = _collect_personal_fields(snap, ["nonsense", {"ref": "zzz"}])
        self.assertEqual([f["ref"] for f in fields], ["e1"])

    def test_skips_filled_fields(self) -> None:
        snap = _Snap([
            _el("e1", type="email", filled=True),
            _el("e2", type="tel", name="Phone"),
        ])
        fields = _collect_personal_fields(snap, None)
        self.assertEqual([f["ref"] for f in fields], ["e2"])


class MessageComposerTests(unittest.TestCase):
    def test_search_vs_compose_labels(self) -> None:
        self.assertTrue(_looks_like_search_box("Search name or number"))
        self.assertTrue(_looks_like_search_box("Search or start a new chat"))
        self.assertTrue(_looks_like_search_box("New chat"))
        self.assertFalse(_looks_like_search_box("Type a message"))

    def test_message_box_detection(self) -> None:
        composer = _el("e1", tag="div", type="", name="Type a message")
        search = _el("e2", name="Search name or number")
        self.assertTrue(_looks_like_message_box(composer))
        self.assertFalse(_looks_like_message_box(search))
        # non-editable element with a composer-ish label is not a composer
        self.assertFalse(_looks_like_message_box(_el("e3", name="Type a message", editable=False)))

    def test_step_intent(self) -> None:
        self.assertTrue(_step_wants_message_compose("Type a lovely message in the chat box"))
        self.assertTrue(_step_wants_message_compose("Send the lovely message"))
        self.assertFalse(_step_wants_message_compose("Locate pinned contact 'Walkie Talkie'"))
        self.assertFalse(_step_wants_message_compose("Click on 'Walkie Talkie' chat"))

    def test_best_message_box_prefers_bottom_composer(self) -> None:
        snap = _Snap([
            _el("e1", name="Search name or number", rect={"cy": 80}),
            _el("e2", tag="div", type="", name="Type a message", rect={"cy": 760}),
        ])
        box = _best_message_box(snap)
        self.assertIsNotNone(box)
        self.assertEqual(box["ref"], "e2")

    def test_best_message_box_none_when_only_search(self) -> None:
        snap = _Snap([_el("e1", name="Search name or number", rect={"cy": 80})])
        self.assertIsNone(_best_message_box(snap))


if __name__ == "__main__":
    unittest.main()
