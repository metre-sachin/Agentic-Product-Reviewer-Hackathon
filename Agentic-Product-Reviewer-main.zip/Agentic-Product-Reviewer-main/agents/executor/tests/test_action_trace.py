"""Unit tests for the structured action-trace recorder helpers.

These guard the privacy invariant: a password, OTP, or personal-field value must
never reach the persisted action trace — it is redacted to '•••' before record.
Pure logic, no browser or network — runnable with stdlib unittest:

    PYTHONPATH=. backend/.venv/bin/python -m unittest \
        agents.executor.tests.test_action_trace
"""

from __future__ import annotations

import unittest
from typing import Any

from agents.executor.browser_loop import REDACTED, _ACTION_KIND, _record_value


def _el(ref: str, **kw: Any) -> dict[str, Any]:
    base = {
        "ref": ref, "tag": "input", "type": "text", "role": "", "name": "",
        "placeholder": "", "text": "", "href": "", "editable": True,
        "filled": False, "disabled": False,
    }
    base.update(kw)
    return base


class ActionKindMapTests(unittest.TestCase):
    def test_internal_verbs_map_to_trace_kinds(self) -> None:
        self.assertEqual(_ACTION_KIND["goto"], "navigate")
        self.assertEqual(_ACTION_KIND["click"], "click")
        self.assertEqual(_ACTION_KIND["type"], "type")
        self.assertEqual(_ACTION_KIND["select"], "select")
        self.assertEqual(_ACTION_KIND["press"], "press")
        self.assertEqual(_ACTION_KIND["scroll"], "scroll")
        self.assertEqual(_ACTION_KIND["wait"], "wait")
        # non-action verbs (done/need_*) are intentionally absent so they are
        # never recorded as browser actions.
        self.assertNotIn("done", _ACTION_KIND)
        self.assertNotIn("need_credentials", _ACTION_KIND)


class RecordValueRedactionTests(unittest.TestCase):
    def test_password_field_is_redacted(self) -> None:
        target = _el("e1", type="password", name="Password")
        value = _record_value("type", {"text": "hunter2"}, target)
        self.assertEqual(value, REDACTED)
        self.assertNotIn("hunter2", value or "")

    def test_personal_fields_are_redacted(self) -> None:
        for target in (
            _el("e1", type="email"),
            _el("e2", type="tel", name="Phone"),
            _el("e3", placeholder="Full name"),
            _el("e4", placeholder="Card number"),
        ):
            value = _record_value("type", {"text": "secret-pii"}, target)
            self.assertEqual(value, REDACTED, f"not redacted: {target}")

    def test_non_sensitive_text_is_kept(self) -> None:
        target = _el("e1", placeholder="Search products")
        self.assertEqual(_record_value("type", {"text": "running shoes"}, target), "running shoes")

    def test_type_without_target_keeps_text(self) -> None:
        # No element resolved (typed by coordinates) — not classifiable as
        # sensitive, so the literal text is recorded.
        self.assertEqual(_record_value("type", {"text": "hello"}, None), "hello")

    def test_other_actions_capture_their_salient_value(self) -> None:
        self.assertEqual(_record_value("goto", {"url": "https://x.com"}, None), "https://x.com")
        self.assertEqual(_record_value("select", {"value": "Large"}, None), "Large")
        self.assertEqual(_record_value("press", {"key": "Enter"}, None), "Enter")
        self.assertEqual(_record_value("scroll", {"direction": "down"}, None), "down")
        self.assertIsNone(_record_value("click", {"text": "ignored"}, None))


if __name__ == "__main__":
    unittest.main()
