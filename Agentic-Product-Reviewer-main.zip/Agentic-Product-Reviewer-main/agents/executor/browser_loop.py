"""Browser interaction loop — drives the Agent Browser adapter to complete one
interaction step via a bounded LLM act/observe cycle.

Safety: the loop is forbidden from clicking anything that pays, checks out,
places an order, submits an application/form, or sends a message. If the next
needed action is one of those, it stops and returns `needs_approval` so the
runtime raises a human approval before anything irreversible happens.
"""

from __future__ import annotations

import base64
import hashlib
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from agents.approval.approval import HARD_TRIGGERS

MAX_ACTIONS = 16
MAX_NO_PROGRESS = 3
MAX_REPEAT_ACTION = 2

Emit = Callable[[str, str | None], Awaitable[None]]
# Structured action recorder: receives one payload per executed action
# ({kind, target, value, url, ok}) for the persisted action trace. Optional.
Record = Callable[[dict[str, Any]], Awaitable[None]]

# Maps the loop's internal action verbs to the stable trace `kind` taxonomy.
_ACTION_KIND: dict[str, str] = {
    "goto": "navigate",
    "click": "click",
    "type": "type",
    "select": "select",
    "press": "press",
    "scroll": "scroll",
    "wait": "wait",
}

# Redaction sentinel for sensitive values — the secret itself is never recorded.
REDACTED = "•••"

SYSTEM = """You operate a web browser to accomplish ONE step of a task. You are given
a structured snapshot of the current page's interactive elements (each with a
ref like e3). Choose the single next action. Output strict JSON:

{
  "action": "goto" | "click" | "type" | "select" | "press" | "scroll" |
            "wait" | "done" | "need_approval" | "need_credentials" |
            "need_info" | "need_otp" | "need_captcha" | "give_up",
  "ref": "element ref for click/type/select",
  "url": "absolute url for goto",
  "x": number, "y": number,
  "text": "text for type",
  "value": "option for select",
  "key": "key name for press (e.g. Enter)",
  "direction": "up | down for scroll",
  "amount": "scroll pixels",
  "target": "visible label/description of the click target",
  "fields": [{"ref": "element ref", "label": "short human label e.g. Phone number",
              "kind": "name|username|email|phone|address|dob|card|other"}],
  "confidence": 0.0-1.0,
  "thought": "one short sentence on why",
  "observation": "for done: what was accomplished",
  "added_item": {"name": "exact product name", "price": number},
  "approval_reason": "for need_approval: what irreversible action is next"
}

Rules:
- Prefer the structured refs. Use x/y only when you can see a target that has no
  matching ref. Use goto only to reach a starting page.
- For shopping/product pages, click the exact visible button such as "Add to cart",
  "Add to basket", or "Add to bag". Do not click product images, result cards,
  "Main content", or other broad page containers when the step is to add an item.
  If the user asked for the first/selected item, use the first visible matching
  add-to-cart button in the main results.
- CART STATE: when the context lists "Items ALREADY in the cart", NEVER add any of
  those products again — pick a different, distinct product, or return "done" if no
  new matching product is needed. Respect the remaining budget shown: do not add an
  item whose price exceeds it. When you add a product, return "done" with
  "added_item" naming the product and its price (the price you actually pay, i.e.
  the discounted price when one is shown); set added_item to null if you added
  nothing.
- Messaging apps (WhatsApp, Messenger, Instagram, Telegram, etc.): the message
  composer is the editable box at the BOTTOM of an OPEN conversation, usually
  labelled "Type a message" or "Message". To write a message, type into THAT box
  only — NEVER the search field ("Search", "Search or start a new chat", "Search
  name or number", "New chat", "New contact"), which just finds contacts. If the
  target chat isn't open yet, open it first (search for the contact, click the
  chat), then type in the composer. After typing, VERIFY the message text now
  appears in the composer (check the Visible page text); if the composer is still
  empty, click it and type again — do NOT report done until the text is actually
  there. Once the text is in the composer the typing step is DONE.
- Sending a message (only when this step is approved): the message text must
  already be in the composer; click the composer to focus it, then press Enter
  (action "press", key "Enter") OR click the send / paper-plane button directly to
  the RIGHT of the composer. Do NOT click the emoji/sticker, attach/clip, camera,
  voice/microphone icons, the search box, "New chat", or a contact in the list —
  none of those send the message.
- Do not repeat a failed or no-progress action. If history says a click did not
  move the page forward, choose a different action, scroll, wait once, or give up.
- Use scroll when the likely next control is below or above the viewport.
- For delivery/location pickers: if the page shows "Detect my location" plus a
  manual list of location results, choose the first/highest matching location
  result. Do not click "Detect my location" again after permission is denied or
  unavailable.
- STAR RATINGS / SURVEYS (any site): a row of star icons (or 1-5 radio buttons /
  faces / a numeric scale) is a rating question. To give a rating of N, click the
  N-th star/option in that question's row (the 5th star = 5/5). Rate EVERY such
  question — forms reject submission until all are rated. Use the rating the user
  asked for in the task goal; if none was specified, pick a realistic value
  (generally 3-5 of 5, varied rather than identical). After rating the visible
  questions, click Next/Continue to reach the remaining questions or pages and
  rate those too.
- If the page is a sign-in / login form with EMPTY email/username and password
  fields, return action "need_credentials" — NEVER guess or invent credentials.
  But if those fields are already filled (marked [filled] in the snapshot), do NOT
  return need_credentials again. Instead: if a CAPTCHA / "type the text above"
  field is present and empty, return need_captcha; otherwise click the sign-in
  button to submit.
- PERSONAL / SENSITIVE DATA — NEVER type a value into a personal or sensitive
  field from the task text, prior context, memory, or your own guess. This covers
  full name, username/handle, email address, phone/mobile number, postal or
  billing address, date of birth, and payment card details. When the page shows
  one or more EMPTY such fields, return action "need_info" and list every empty
  sensitive field in "fields" (give each a short human "label" and a "kind"). The
  user supplies the values and Argus types them. Once a field is already [filled],
  do NOT ask for it again — move on. (Use need_credentials for a sign-in
  email+password pair, and need_otp for one-time codes — not need_info.)
- If the page asks for a one-time passcode, a 2FA / verification code, or an OTP
  (a short numeric or alphanumeric code sent to the user by SMS, email, or an
  authenticator app), return action "need_otp" with "ref" set to the code input —
  NEVER guess or invent the code.
- If the page shows a CAPTCHA image challenge — a distorted-text image with a
  field like "Type the text above", "Enter the characters", or "Enter the code
  shown" — return action "need_captcha" with "ref" set to that text input. The
  characters live in an image you cannot see, so do NOT guess them.
- NEVER click anything that pays, checks out, places an order, confirms a
  booking, submits an application/form, or sends a message/email. If that is the
  next required action, return action "need_approval".
- A "Visible page text" section is included after the element list. READ it to
  find and verify the information this step needs (tables, marks, totals, status,
  dates, values) — the element list only holds clickable controls, not page
  content, so the answer usually lives in the visible text.
- If the page already shows the information the step is looking for, return action
  "done" with the SPECIFIC facts in "observation": quote the actual values and
  their labels (e.g. each component's marks and the subject/term), not a vague
  "completed" or "navigated". Never leave a page that contains the answer without
  extracting it first.
- If the answer needs a selection first (e.g. choose a term/exam in a dropdown,
  then Submit), do that, wait for the result, then READ the resulting page before
  returning "done".
- Otherwise return "done" only when the current page clearly shows the step's
  goal is satisfied.
"""

VISION_SYSTEM = (
    SYSTEM
    + "\nYou also see a live screenshot of the browser viewport. Use both the pixels "
      "and the element list. The element refs include approximate center points."
)

SYSTEM_ALLOW = SYSTEM.replace(
    "- NEVER click anything that pays, checks out, places an order, confirms a\n"
    "  booking, submits an application/form, or sends a message/email. If that is the\n"
    "  next required action, return action \"need_approval\".",
    "- The user has explicitly APPROVED the irreversible action for this step. You\n"
    "  may now click the pay/checkout/submit/confirm button to complete it.",
)


@dataclass
class InteractionResult:
    ok: bool
    observation: str
    needs_approval: bool = False
    approval_reason: str | None = None
    needs_credentials: bool = False
    email_ref: str | None = None
    password_ref: str | None = None
    needs_otp: bool = False
    otp_ref: str | None = None
    needs_captcha: bool = False
    captcha_ref: str | None = None
    needs_info: bool = False
    info_fields: list[dict[str, str]] = field(default_factory=list)
    actions_taken: int = 0
    data: dict[str, Any] = field(default_factory=dict)


def _is_irreversible(label: str) -> bool:
    low = (label or "").lower()
    return any(t in low for t in HARD_TRIGGERS)


# Personal / sensitive field kinds Argus must never auto-fill — the user is asked
# for each and Argus types in what they provide. OTP, CAPTCHA and login
# email+password have their own dedicated gates and are excluded here.
_PERSONAL_KEYWORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("dob", ("date of birth", "birth date", "birthday", "dob", "d.o.b")),
    ("card", ("card number", "credit card", "debit card", "cardholder", "cvv",
              "cvc", "expiry", "expiration", "card no", "card")),
    ("phone", ("phone", "mobile", "telephone", "contact number", "cell", "tel")),
    ("email", ("email", "e-mail")),
    ("address", ("address", "street", "city", "postcode", "postal code",
                 "zip code", "zip", "state", "province", "pincode", "pin code")),
    ("username", ("username", "user name", "user id", "userid", "login id",
                  "handle")),
    ("name", ("full name", "first name", "last name", "given name", "surname",
              "your name", "name")),
)

# Field hints that are handled by other gates — never treat as generic personal.
_PERSONAL_EXCLUDE = (
    "search", "otp", "one-time", "one time", "passcode", "verification", "2fa",
    "captcha", "type the text", "text above", "characters", "code shown",
    "password", "coupon", "promo", "quantity", "comment", "message",
)


def _personal_kind(el: dict[str, Any] | None) -> str | None:
    """Classify an editable field as a sensitive personal kind, or None.

    Used both to honour the model's need_info request and as a safety net so the
    loop can never type into a sensitive field on its own."""
    if not el or not el.get("editable") or el.get("filled"):
        return None
    typ = str(el.get("type") or "").lower()
    if typ == "password":  # belongs to the credentials gate
        return None
    hay = " ".join(
        str(el.get(k) or "")
        for k in ("name", "placeholder", "text")
    ).lower()
    if any(x in hay for x in _PERSONAL_EXCLUDE):
        return None
    if typ == "email":
        return "email"
    if typ == "tel":
        return "phone"
    for kind, words in _PERSONAL_KEYWORDS:
        if any(w in hay for w in words):
            return kind
    return None


def _field_label(el: dict[str, Any] | None, kind: str) -> str:
    label = _el_label(el).strip()
    if label and len(label) <= 60:
        return label
    return {
        "name": "Full name", "username": "Username", "email": "Email address",
        "phone": "Phone number", "address": "Address", "dob": "Date of birth",
        "card": "Card details",
    }.get(kind, "Personal detail")


def _collect_personal_fields(snap, requested: list[dict] | None) -> list[dict[str, str]]:
    """Build the sensitive-field list to ask the user about. Trust the model's
    requested fields when they map to real empty editable inputs; otherwise scan
    the snapshot for empty personal fields."""
    by_ref = {str(e.get("ref")): e for e in snap.elements}
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def _add(el: dict[str, Any], kind: str | None, label: str | None) -> None:
        ref = str(el.get("ref") or "")
        if not ref or ref in seen or not el.get("editable") or el.get("filled"):
            return
        k = kind or _personal_kind(el) or "other"
        seen.add(ref)
        out.append({"ref": ref, "label": label or _field_label(el, k), "kind": k})

    for item in requested or []:
        if not isinstance(item, dict):
            continue
        el = by_ref.get(str(item.get("ref")))
        if el is not None:
            _add(el, str(item.get("kind") or "") or None, str(item.get("label") or "") or None)

    if not out:
        for el in snap.elements:
            kind = _personal_kind(el)
            if kind:
                _add(el, kind, None)
    return out


def _el_label(el: dict[str, Any] | None) -> str:
    if not el:
        return ""
    return str(el.get("name") or el.get("placeholder") or el.get("text") or el.get("href") or "")


def _element_center(el: dict[str, Any] | None) -> tuple[float, float] | None:
    rect = (el or {}).get("rect") or {}
    x = rect.get("cx")
    y = rect.get("cy")
    if x is None or y is None:
        return None
    try:
        return float(x), float(y)
    except (TypeError, ValueError):
        return None


def _snapshot_key(snap) -> str:
    """Stable-enough fingerprint for detecting no visible DOM progress."""
    parts = [str(snap.url), str(snap.title)]
    for el in snap.elements[:80]:
        rect = el.get("rect") or {}
        parts.append(
            "|".join(
                [
                    str(el.get("tag") or ""),
                    str(el.get("type") or ""),
                    str(el.get("role") or ""),
                    _el_label(el)[:80],
                    "filled" if el.get("filled") else "empty",
                    "disabled" if el.get("disabled") else "enabled",
                    str(rect.get("cx") or ""),
                    str(rect.get("cy") or ""),
                ]
            )
        )
    return hashlib.sha1("\n".join(parts).encode("utf-8")).hexdigest()


def _decision_key(decision: dict[str, Any]) -> str:
    x = decision.get("x")
    y = decision.get("y")
    coords = ""
    if x is not None and y is not None:
        try:
            coords = f"{round(float(x) / 10) * 10},{round(float(y) / 10) * 10}"
        except (TypeError, ValueError):
            coords = ""
    return "|".join(
        [
            str(decision.get("action") or "").lower(),
            str(decision.get("ref") or ""),
            str(decision.get("url") or ""),
            str(decision.get("text") or "")[:80],
            str(decision.get("value") or ""),
            str(decision.get("key") or ""),
            str(decision.get("direction") or ""),
            coords,
        ]
    )


def _intish(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _first_location_suggestion(snap) -> dict[str, Any] | None:
    excludes = (
        "detect my location",
        "search",
        "login",
        "cart",
        "please provide",
        "permission",
        "welcome",
    )
    hints = (
        "bangalore",
        "bengaluru",
        "karnataka",
        "division",
        "village",
        "road",
        "phase",
        "near",
        "locality",
        "location",
        "address",
    )
    matches: list[dict[str, Any]] = []
    for el in snap.elements:
        label = _el_label(el).strip()
        low = label.lower()
        if not label or len(label) > 220:
            continue
        if any(x in low for x in excludes):
            continue
        if not any(h in low for h in hints):
            continue
        rect = el.get("rect") or {}
        if not rect.get("cy"):
            continue
        matches.append(el)
    matches.sort(key=lambda e: ((e.get("rect") or {}).get("cy") or 99999))
    return matches[0] if matches else None


def _should_redirect_to_location_result(target_label: str, history: list[str]) -> bool:
    low = target_label.lower()
    if "detect my location" in low:
        return True
    if "select-locality" in low or "locality" in low:
        return any(
            "detect my location" in h.lower() or "select-locality" in h.lower()
            for h in history
        )
    return False


# ---- Cart ledger: track what was added so steps never duplicate or overspend ----

_PRICE_RE = re.compile(r"₹\s*(\d[\d,]*(?:\.\d+)?)")
# Pack/size tokens stripped before comparing names so "100 g" variations still match.
_SIZE_RE = re.compile(r"\b\d+(?:\.\d+)?\s*(?:g|kg|ml|l|ltr|x|pack|pcs?|pieces?|units?)\b")


def _parse_prices(text: str) -> list[float]:
    out: list[float] = []
    for m in _PRICE_RE.finditer(text or ""):
        try:
            out.append(float(m.group(1).replace(",", "")))
        except ValueError:
            continue
    return out


def _clean_item_name(text: str) -> str:
    """Strip prices, discount badges and the ADD verb from a product-card blob to
    leave a human product name."""
    t = re.sub(r"\d+%\s*off", " ", text or "", flags=re.IGNORECASE)
    t = _PRICE_RE.sub(" ", t)
    t = re.sub(r"\b(add to cart|add to basket|add to bag|add)\b", " ", t, flags=re.IGNORECASE)
    t = re.sub(r"\s+", " ", t).strip(" -·•|\t")
    return t[:80]


def _normalize_name(name: str) -> str:
    """Loose key for matching the same product across snapshots (case/size/punct
    insensitive)."""
    n = re.sub(r"[^a-z0-9 ]", " ", (name or "").lower())
    n = _SIZE_RE.sub(" ", n)
    n = re.sub(r"\s+", " ", n).strip()
    return n


def _ledger_total(ledger: list[dict[str, Any]] | None) -> float:
    total = 0.0
    for item in ledger or []:
        try:
            total += float(item.get("price") or 0)
        except (TypeError, ValueError):
            continue
    return total


def _name_in_ledger(name: str, ledger: list[dict[str, Any]] | None) -> bool:
    target = _normalize_name(name)
    if not target:
        return False
    for item in ledger or []:
        known = _normalize_name(str(item.get("name") or ""))
        if not known:
            continue
        if known == target or known in target or target in known:
            return True
    return False


def _cart_item_for_cta(snap, cta: dict[str, Any] | None) -> tuple[str, float | None]:
    """Best-effort (name, price) for the product card that owns an add-to-cart CTA.

    Finds the tightest element whose rect encloses the button's centre and whose
    text carries a price — the product card. Returns ("", None) when nothing
    confident is found, so callers fall back to the model/runtime guards."""
    rect = (cta or {}).get("rect") or {}
    try:
        cx = float(rect.get("cx"))
        cy = float(rect.get("cy"))
        cta_area = float(rect.get("w") or 0) * float(rect.get("h") or 0)
    except (TypeError, ValueError):
        return "", None
    best: dict[str, Any] | None = None
    best_area: float | None = None
    for el in snap.elements:
        if el is cta:
            continue
        r = el.get("rect") or {}
        try:
            x = float(r.get("x"))
            y = float(r.get("y"))
            w = float(r.get("w") or 0)
            h = float(r.get("h") or 0)
        except (TypeError, ValueError):
            continue
        if w <= 0 or h <= 0:
            continue
        if not (x - 4 <= cx <= x + w + 4 and y - 4 <= cy <= y + h + 4):
            continue
        area = w * h
        if area <= cta_area or area > 500_000:  # bigger than the button, smaller than the page
            continue
        text = str(el.get("text") or el.get("name") or "")
        if not _parse_prices(text):
            continue
        if best_area is None or area < best_area:
            best, best_area = el, area
    if best is None:
        return "", None
    text = str(best.get("text") or best.get("name") or "")
    prices = _parse_prices(text)
    price = min(prices) if prices else None  # pay the discounted (lower) price
    return _clean_item_name(text), price


def _cart_state_block(
    ledger: list[dict[str, Any]] | None,
    budget: float | None,
    currency: str | None,
) -> str:
    """The cart-awareness context injected into add-to-cart steps so the model
    knows what is already in the cart and how much budget remains."""
    sym = "₹" if str(currency or "").upper() == "INR" else ""
    lines: list[str] = []
    if ledger:
        lines.append("Items ALREADY in the cart — do NOT add any of these again:")
        for item in ledger:
            nm = str(item.get("name") or "item")
            pr = item.get("price")
            if isinstance(pr, (int, float)):
                lines.append(f"  - {nm} — {sym}{float(pr):.0f}")
            else:
                lines.append(f"  - {nm}")
    else:
        lines.append("The cart is currently empty.")
    if budget is not None:
        spent = _ledger_total(ledger)
        lines.append(
            f"Cart subtotal: {sym}{spent:.0f} of {sym}{float(budget):.0f} budget. "
            f"Remaining: {sym}{max(0.0, float(budget) - spent):.0f}."
        )
    lines.append(
        "Add at most ONE new DISTINCT item this step. If every matching product is "
        "already in the cart, or the cheapest new option would exceed the remaining "
        'budget, return action "done" without adding anything.'
    )
    return "\n".join(lines)


def _step_wants_add_to_cart(step_label: str) -> bool:
    low = step_label.lower()
    return (
        ("add" in low and any(word in low for word in ("cart", "basket", "bag")))
        or "add selected" in low
    )


def _looks_like_add_to_cart(label: str) -> bool:
    low = label.lower()
    return (
        "add to cart" in low
        or "add to basket" in low
        or "add to bag" in low
        or ("add" in low and any(word in low for word in ("cart", "basket", "bag")))
    )


def _is_generic_click_target(label: str, el: dict[str, Any] | None) -> bool:
    low = label.strip().lower()
    if low in {
        "",
        "main",
        "main content",
        "content",
        "results",
        "search results",
        "page",
        "body",
    }:
        return True
    rect = (el or {}).get("rect") or {}
    try:
        w = float(rect.get("w") or 0)
        h = float(rect.get("h") or 0)
    except (TypeError, ValueError):
        return False
    return w > 500 and h > 250 and any(word in low for word in ("content", "results", "main"))


def _best_add_to_cart(snap) -> dict[str, Any] | None:
    matches: list[dict[str, Any]] = []
    for el in snap.elements:
        if el.get("disabled"):
            continue
        label = _el_label(el)
        if not _looks_like_add_to_cart(label):
            continue
        rect = el.get("rect") or {}
        try:
            w = float(rect.get("w") or 0)
            h = float(rect.get("h") or 0)
            cx = float(rect.get("cx") or 0)
            cy = float(rect.get("cy") or 0)
        except (TypeError, ValueError):
            continue
        if w < 20 or h < 12 or w > 360 or h > 90 or cy < 90:
            continue
        item = dict(el)
        item["_score"] = (
            1 if cx > 1120 else 0,  # right-rail recommendations are weaker than main results
            1 if cx < 120 else 0,
            cy,
            cx,
        )
        matches.append(item)
    matches.sort(key=lambda e: e.get("_score", (9, 9, 99999, 99999)))
    return matches[0] if matches else None


# Search fields that messaging apps put at the top — typing a message into one of
# these is the classic mistake we guard against.
_SEARCH_BOX_HINTS = (
    "search", "search or start", "search name or number", "find a chat",
    "new chat", "new contact", "new group", "search input",
)
# The actual message composer at the bottom of an open conversation.
_COMPOSE_BOX_HINTS = (
    "type a message", "type message", "write a message", "send a message",
    "message...", "compose", "type your message",
)


def _looks_like_search_box(label: str) -> bool:
    low = (label or "").strip().lower()
    return any(h in low for h in _SEARCH_BOX_HINTS)


def _looks_like_message_box(el: dict[str, Any] | None) -> bool:
    if not el or not el.get("editable") or el.get("disabled"):
        return False
    low = _el_label(el).strip().lower()
    if not low or _looks_like_search_box(low):
        return False
    if any(h in low for h in _COMPOSE_BOX_HINTS):
        return True
    # A bare "message" label on an editable box is the composer too.
    return low == "message"


def _step_wants_message_compose(step_label: str) -> bool:
    low = step_label.lower()
    verb = any(v in low for v in ("type", "write", "compose", "enter", "draft", "send"))
    target = any(
        t in low for t in ("message", "chat box", "chatbox", "compose", "text box")
    )
    return verb and target


def _best_message_box(snap) -> dict[str, Any] | None:
    """The conversation's message composer — the editable box that reads like a
    composer and sits lowest on the page (composers live at the bottom)."""
    matches: list[tuple[float, dict[str, Any]]] = []
    for el in snap.elements:
        if not _looks_like_message_box(el):
            continue
        rect = el.get("rect") or {}
        try:
            cy = float(rect.get("cy") or 0)
        except (TypeError, ValueError):
            cy = 0.0
        matches.append((cy, el))
    if not matches:
        return None
    matches.sort(key=lambda t: -t[0])  # bottom-most first
    return matches[0][1]


async def _decide(
    *,
    system: str,
    context: str,
    image: bytes | None,
    model: str | None,
) -> dict[str, Any]:
    from app.services.llm import complete_json, complete_json_vision

    if image:
        return await complete_json_vision(
            system=VISION_SYSTEM if system == SYSTEM else VISION_SYSTEM.replace(SYSTEM, system),
            user=context + "\n\nReturn the next action JSON.",
            image_b64=base64.b64encode(image).decode(),
            model=model,
            temperature=0.1,
            max_tokens=500,
        )
    return await complete_json(
        system=system,
        user=context + "\n\nReturn the next action JSON.",
        model=model,
        temperature=0.1,
        max_tokens=450,
    )


def _click_hint(el: dict[str, Any] | None) -> str:
    """A short ' (→ url)' / ' (form action)' suffix for click logs, so the trace
    shows whether a button is a real link or a JS/postback control — the 'what is
    this button' visibility a human would get from right-click → inspect."""
    href = str((el or {}).get("href") or "").strip()
    if not href:
        return ""
    low = href.lower()
    if low.startswith("javascript:") or "__dopostback" in low:
        return " (form action)"
    if low == "#" or low.startswith("#"):
        return ""
    return f" (→ {href[:80]})"


def _record_value(action: str, decision: dict[str, Any], target: dict[str, Any] | None) -> str | None:
    """The value to record for an executed action, redacting anything sensitive.

    Sensitive `type` actions are intercepted earlier in the loop (the safety net
    returns need_info / need_credentials before execution), so this is defence in
    depth: a password or personal field can never leak into the trace."""
    if action == "goto":
        return str(decision.get("url") or "") or None
    if action == "type":
        is_password = bool(target) and str((target or {}).get("type") or "").lower() == "password"
        if is_password or _personal_kind(target):
            return REDACTED
        return str(decision.get("text") or "") or None
    if action == "select":
        return str(decision.get("value") or "") or None
    if action == "press":
        return str(decision.get("key") or "") or None
    if action == "scroll":
        return str(decision.get("direction") or "") or None
    return None


async def run_interaction(
    *,
    adapter,                 # AgentBrowserAdapter
    goal: str,
    step_label: str,
    intent: dict,
    prior_observations: list[str],
    emit: Emit,
    start_url: str | None = None,
    allow_irreversible: bool = False,
    controller=None,          # PlaywrightController, optional for screenshot/x-y actions
    use_vision: bool = False,
    model: str | None = None,
    record: Record | None = None,
    cart_ledger: list[dict[str, Any]] | None = None,
    budget: float | None = None,
    currency: str | None = None,
) -> InteractionResult:
    system = SYSTEM_ALLOW if allow_irreversible else SYSTEM
    # Items this step puts in the cart, returned so the runtime extends the ledger.
    added_items: list[dict[str, Any]] = []

    if start_url:
        await adapter.goto(start_url)
        await emit(f"Opened {start_url}", None)

    history: list[str] = []
    failed_actions: dict[str, int] = {}
    no_progress = 0
    for step_i in range(MAX_ACTIONS):
        snap = await adapter.snapshot()
        before_key = _snapshot_key(snap)
        context = [
            f"Task goal: {goal}",
            f"Current step: {step_label}",
        ]
        if intent.get("constraints"):
            context.append(f"Constraints: {', '.join(map(str, intent['constraints']))}")
        if prior_observations:
            context.append("Known so far: " + " | ".join(prior_observations[-4:]))
        if _step_wants_add_to_cart(step_label):
            context.append(
                "This is an add-to-cart step: click the exact visible Add to cart/"
                "basket/bag button for the selected or first matching product, not a broad "
                "page area or product image. Add exactly ONE product for this step — the "
                "moment it is in the cart the step is DONE; do NOT keep adding more "
                "products of the same kind."
            )
            if cart_ledger is not None or budget is not None:
                context.append(_cart_state_block(cart_ledger, budget, currency))
        if history:
            context.append("Recent browser history:")
            context.extend(f"- {h}" for h in history[-8:])
        context.append("")
        context.append(snap.digest())

        page_text = await adapter.page_text()
        if page_text:
            context.append("")
            context.append(
                "Visible page text (read this to find/verify the step's answer):"
            )
            context.append(page_text)

        image = None
        if use_vision and controller is not None:
            try:
                image = await controller.screenshot_bytes()
            except Exception:  # noqa: BLE001
                image = None

        decision = await _decide(
            system=system,
            context="\n".join(context),
            image=image,
            model=model,
        )
        action = str(decision.get("action") or "done").lower()
        thought = str(decision.get("thought") or "")
        action_key = _decision_key(decision)
        # Product to record in the ledger if this iteration's click succeeds.
        pending_add: dict[str, Any] | None = None

        if failed_actions.get(action_key, 0) >= MAX_REPEAT_ACTION:
            return InteractionResult(
                ok=False,
                observation=f"Repeated the same failed action on: {step_label}",
                actions_taken=step_i,
                data={
                    "cause": "repeated_action",
                    "history": history[-6:],
                    "added_items": added_items,
                },
            )

        if action == "need_credentials":
            pw = next((e for e in snap.elements if e.get("type") == "password"), None)
            em = (
                next((e for e in snap.elements if e.get("type") == "email"), None)
                or next(
                    (e for e in snap.elements
                     if e.get("editable") and e.get("type") in ("text", "")),
                    None,
                )
            )
            return InteractionResult(
                ok=False,
                observation="",
                needs_credentials=True,
                email_ref=(em or {}).get("ref"),
                password_ref=(pw or {}).get("ref"),
                actions_taken=step_i,
            )

        if action == "need_info":
            fields = _collect_personal_fields(snap, decision.get("fields"))
            if fields:
                return InteractionResult(
                    ok=False,
                    observation="",
                    needs_info=True,
                    info_fields=fields,
                    actions_taken=step_i,
                )
            # Model flagged sensitive fields but none are actually empty/editable —
            # nothing to ask for, so fall through and let it pick another action.

        if action == "need_otp":
            # Trust the model's ref if it gave one, else locate the likeliest
            # one-time-code field by name/placeholder/type.
            picked = str(decision.get("ref") or "")
            otp_el = next((e for e in snap.elements if e.get("ref") == picked), None)
            if otp_el is None:
                def _looks_like_otp(e: dict) -> bool:
                    hay = f"{e.get('name','')} {e.get('placeholder','')}".lower()
                    if any(k in hay for k in ("otp", "one-time", "one time", "passcode",
                                              "verification", "2fa", "code", "token")):
                        return True
                    return e.get("type") in ("tel", "number")

                otp_el = (
                    next(
                        (e for e in snap.elements if e.get("editable") and _looks_like_otp(e)),
                        None,
                    )
                    or next((e for e in snap.elements if e.get("editable")), None)
                )
            return InteractionResult(
                ok=False,
                observation="",
                needs_otp=True,
                otp_ref=(otp_el or {}).get("ref"),
                actions_taken=step_i,
            )

        if action == "need_captcha":
            picked = str(decision.get("ref") or "")
            cap_el = next((e for e in snap.elements if e.get("ref") == picked), None)
            if cap_el is None:
                def _looks_like_captcha(e: dict) -> bool:
                    hay = f"{e.get('name','')} {e.get('placeholder','')}".lower()
                    return any(k in hay for k in (
                        "captcha", "type the text", "text above", "characters",
                        "code shown", "enter the code", "verification image",
                    ))

                cap_el = (
                    next(
                        (e for e in snap.elements if e.get("editable") and _looks_like_captcha(e)),
                        None,
                    )
                    or next((e for e in snap.elements if e.get("editable")), None)
                )
            return InteractionResult(
                ok=False,
                observation="",
                needs_captcha=True,
                captcha_ref=(cap_el or {}).get("ref"),
                actions_taken=step_i,
            )

        if action == "need_approval" and not allow_irreversible:
            return InteractionResult(
                ok=False,
                observation="",
                needs_approval=True,
                approval_reason=str(decision.get("approval_reason") or step_label),
                actions_taken=step_i,
            )

        if action == "done":
            obs = str(decision.get("observation") or f"Completed: {step_label}")
            # Trust the model's named item only if the deterministic guard didn't
            # already capture one this step (avoids double-counting).
            reported = decision.get("added_item")
            if not added_items and isinstance(reported, dict) and reported.get("name"):
                try:
                    price = (
                        float(reported.get("price"))
                        if reported.get("price") is not None
                        else None
                    )
                except (TypeError, ValueError):
                    price = None
                added_items.append({"name": str(reported["name"])[:80], "price": price})
            return InteractionResult(
                ok=True,
                observation=obs,
                actions_taken=step_i,
                data={"added_items": added_items},
            )

        if action == "give_up":
            return InteractionResult(
                ok=False,
                observation=str(decision.get("observation") or ""),
                actions_taken=step_i,
                data={
                    "cause": "model_give_up",
                    "history": history[-6:],
                    "added_items": added_items,
                },
            )

        # Resolve the target element label for the safety check.
        ref = str(decision.get("ref") or "")
        target = next((e for e in snap.elements if e.get("ref") == ref), None)
        target_label = _el_label(target) or str(decision.get("target") or "")

        if action == "click" and _should_redirect_to_location_result(target_label, history):
            suggestion = _first_location_suggestion(snap)
            if suggestion is not None:
                ref = str(suggestion.get("ref") or ref)
                target = suggestion
                target_label = _el_label(suggestion)

        if action == "click" and _step_wants_add_to_cart(step_label):
            should_pick_cta = (
                not ref
                or _is_generic_click_target(target_label, target)
                or not _looks_like_add_to_cart(target_label)
                or any("main content" in h.lower() for h in history[-4:])
            )
            cta = _best_add_to_cart(snap) if should_pick_cta else None
            if cta is not None:
                ref = str(cta.get("ref") or ref)
                target = cta
                target_label = _el_label(cta)
                decision["ref"] = ref
                decision.pop("x", None)
                decision.pop("y", None)

            # Deterministic backstop to the prompt-level cart guidance: never click
            # ADD on a product already in the cart, and never cross the budget.
            item_name, item_price = _cart_item_for_cta(snap, target)
            if item_name:
                seen = list(cart_ledger or []) + added_items
                if _name_in_ledger(item_name, seen):
                    note = f"Skipped '{item_name}' — already in cart"
                    history.append(note)
                    await emit(note, "duplicate guard")
                    no_progress += 1
                    if no_progress >= MAX_NO_PROGRESS:
                        return InteractionResult(
                            ok=True,
                            observation=f"All matching items already in cart for: {step_label}",
                            actions_taken=step_i,
                            data={"added_items": added_items, "cause": "all_in_cart"},
                        )
                    continue
                if budget is not None and item_price is not None:
                    spent = _ledger_total(seen)
                    if spent + item_price > budget + 1e-6:
                        return InteractionResult(
                            ok=True,
                            observation=(
                                f"Stopped before exceeding budget: '{item_name}' "
                                f"(₹{item_price:.0f}) would exceed the remaining "
                                f"₹{max(0.0, budget - spent):.0f}."
                            ),
                            actions_taken=step_i,
                            data={"added_items": added_items, "cause": "budget_reached"},
                        )
                pending_add = {"name": item_name, "price": item_price}

        # Messaging composer: when the step is to write a message, never type into
        # the search/new-chat box. Redirect to the conversation's message composer
        # (the editable box at the bottom of the open chat).
        if action == "type" and _step_wants_message_compose(step_label):
            aiming_wrong = (
                not ref
                or _looks_like_search_box(target_label)
                or not _looks_like_message_box(target)
            )
            if aiming_wrong:
                box = _best_message_box(snap)
                if box is not None:
                    ref = str(box.get("ref") or ref)
                    target = box
                    target_label = _el_label(box)
                    decision["ref"] = ref
                    decision.pop("x", None)
                    decision.pop("y", None)

        if action == "click" and _is_irreversible(target_label) and not allow_irreversible:
            return InteractionResult(
                ok=False,
                observation="",
                needs_approval=True,
                approval_reason=f"about to click '{target_label}'",
                actions_taken=step_i,
            )

        # Safety net: never let the loop type into a personal/sensitive field on
        # its own. Ask the user for every empty sensitive field instead, even if
        # the model tried to fill one from context.
        if action == "type":
            sensitive_kind = _personal_kind(target)
            if sensitive_kind:
                fields = _collect_personal_fields(snap, None) or [
                    {"ref": ref, "label": _field_label(target, sensitive_kind),
                     "kind": sensitive_kind}
                ]
                return InteractionResult(
                    ok=False,
                    observation="",
                    needs_info=True,
                    info_fields=fields,
                    actions_taken=step_i,
                )

        ok = False
        desc = ""
        if action == "goto":
            url = str(decision.get("url") or "")
            if url:
                await adapter.goto(url)
                ok, desc = True, f"Navigated to {url}"
        elif action == "click":
            if ref:
                ok = await adapter.click(ref)
                desc = f"Clicked {target_label or ref}{_click_hint(target)}"
                if not ok and controller is not None:
                    point = _element_center(target)
                    if point is not None:
                        ok = await controller.click_xy(*point)
                        if ok:
                            desc = f"Clicked {target_label or ref} at screen position"
            elif (
                controller is not None
                and decision.get("x") is not None
                and decision.get("y") is not None
            ):
                try:
                    x = float(decision["x"])
                    y = float(decision["y"])
                except (TypeError, ValueError):
                    ok = False
                else:
                    ok = await controller.click_xy(x, y)
                    desc = f"Clicked {target_label or f'({x:.0f}, {y:.0f})'}"
            else:
                desc = "Click target missing"
        elif action == "type":
            text = str(decision.get("text") or "")
            ok = await adapter.type_text(ref, text)
            desc = f"Typed into {target_label or ref}"
        elif action == "select":
            value = str(decision.get("value") or "")
            ok = await adapter.select(ref, value)
            desc = f"Selected {value} in {target_label or ref}"
        elif action == "press":
            key = str(decision.get("key") or "Enter")
            ok = await adapter.press(key)
            desc = f"Pressed {key}"
        elif action == "scroll":
            direction = str(decision.get("direction") or "down")
            amount = _intish(decision.get("amount"), 650)
            ok = await adapter.scroll(direction, amount)
            desc = f"Scrolled {direction}"
        elif action == "wait":
            ms = _intish(decision.get("amount"), 1000)
            ok = await adapter.wait(ms)
            desc = f"Waited {ms}ms"
        else:
            desc = f"Unsupported action: {action}"

        await emit(desc or f"Action: {action}", thought or None)

        if record is not None and action in _ACTION_KIND:
            await record(
                {
                    "kind": _ACTION_KIND[action],
                    "target": target_label or None,
                    "value": _record_value(action, decision, target),
                    "url": str(getattr(snap, "url", "") or "") or None,
                    "ok": bool(ok),
                }
            )

        if not ok:
            failed_actions[action_key] = failed_actions.get(action_key, 0) + 1
            note = f"{desc or action} -> failed"
            history.append(note)
            await emit(f"Action did not take effect: {desc}", None)
            if failed_actions[action_key] >= MAX_REPEAT_ACTION:
                return InteractionResult(
                    ok=False,
                    observation=f"Action failed repeatedly on: {step_label}",
                    actions_taken=step_i + 1,
                    data={
                        "cause": "action_failed",
                        "history": history[-6:],
                        "added_items": added_items,
                    },
                )
            continue

        # One product per add-to-cart step: the moment a product lands in the cart,
        # finish the step. This honours the user's "only once per item" and the
        # one-ingredient-per-step plan, instead of sweeping every matching product
        # (e.g. ten different rice brands) into the cart in a single step.
        added_now = action == "click" and _step_wants_add_to_cart(step_label) and (
            pending_add is not None
            or (target_label or "").strip().lower().startswith("add")
        )
        if added_now:
            if pending_add is not None:
                added_items.append(pending_add)
            name = (pending_add or {}).get("name") or target_label or "item"
            await emit(f"Added to cart: {name}", None)
            return InteractionResult(
                ok=True,
                observation=f"Added {name} to the cart (one item for this step).",
                actions_taken=step_i + 1,
                data={"added_items": added_items},
            )

        try:
            after = await adapter.snapshot()
            after_key = _snapshot_key(after)
        except Exception:  # noqa: BLE001
            after_key = ""

        progressed = bool(after_key and after_key != before_key)
        if progressed or action in {"goto", "type", "select"}:
            no_progress = 0
            history.append(desc or action)
        else:
            no_progress += 1
            history.append(f"{desc or action} -> no visible change")
            if no_progress >= MAX_NO_PROGRESS:
                return InteractionResult(
                    ok=False,
                    observation=f"No visible progress on: {step_label}",
                    actions_taken=step_i + 1,
                    data={
                        "cause": "no_progress",
                        "history": history[-6:],
                        "added_items": added_items,
                    },
                )

    return InteractionResult(
        ok=False,
        observation=f"Reached action limit on: {step_label}",
        actions_taken=MAX_ACTIONS,
        data={"cause": "action_limit", "history": history[-6:], "added_items": added_items},
    )
