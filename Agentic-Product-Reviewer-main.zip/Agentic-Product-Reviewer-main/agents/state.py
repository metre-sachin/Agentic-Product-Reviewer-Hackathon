"""Shared state passed between agents in the LangGraph runtime.

Phase 3 turns this into a real LangGraph StateGraph. For now it is the contract
the agents agree on.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class PlanStep:
    ordinal: int
    label: str
    meta: str = "AUTO"
    state: str = "pending"           # pending | active | done | failed | skipped
    layer: str | None = None         # which adapter handled it
    attempts: int = 0
    notes: str | None = None


@dataclass
class AgentState:
    task_id: str
    user_id: str
    goal: str
    intent: dict[str, Any] = field(default_factory=dict)
    memories: list[dict[str, Any]] = field(default_factory=list)
    # Preformatted "what Argus learned about this site" lessons, injected so the
    # planner reuses what worked and avoids what failed (Reflexion-style memory).
    lessons: str = ""
    plan: list[PlanStep] = field(default_factory=list)
    current_step: int = 0
    waiting_for: str | None = None   # 'approval' | 'user_input' | None
    last_error: str | None = None
    result: dict[str, Any] = field(default_factory=dict)
