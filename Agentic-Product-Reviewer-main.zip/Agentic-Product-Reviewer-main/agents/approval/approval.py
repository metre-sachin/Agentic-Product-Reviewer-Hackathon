"""Approval Agent.

Inspects a proposed action and decides whether a human must approve before it
happens. Hard-coded triggers always fire regardless of user settings.
"""

from __future__ import annotations

from dataclasses import dataclass

# Phrases on buttons / step intents that ALWAYS require approval.
HARD_TRIGGERS = (
    "pay", "payment", "checkout", "place order", "buy now", "purchase",
    "submit application", "submit form", "send email", "send message",
    "confirm booking", "book ticket", "book flight", "book hotel",
    "post review", "post comment", "publish",
)


@dataclass
class ApprovalRequest:
    reason: str
    summary: dict


def needs_approval(action_label: str, intent_meta: str, user_rules: dict) -> ApprovalRequest | None:
    label = (action_label or "").lower()
    meta = (intent_meta or "").lower()

    for phrase in HARD_TRIGGERS:
        if phrase in label or phrase in meta:
            return ApprovalRequest(reason="irreversible", summary={"phrase": phrase})

    if user_rules.get("new_site") and intent_meta == "new_site":
        return ApprovalRequest(reason="new_site", summary={})

    return None
