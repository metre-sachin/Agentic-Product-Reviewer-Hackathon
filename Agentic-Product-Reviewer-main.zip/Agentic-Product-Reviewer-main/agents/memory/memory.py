"""Memory Agent.

Retrieves the user preferences most relevant to a goal so the planner can shape
its plan around them (diet, budget, addresses, travel prefs, etc.).

Ranking uses cosine similarity over stored embeddings when available; otherwise
it falls back to the most recent memories. Either way the planner gets a small,
relevant set rather than the whole store.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Memory
from app.services.embeddings import cosine, deserialize, embed_text


async def relevant_memories(
    db: AsyncSession, user_id, goal: str, limit: int = 5
) -> list[dict]:
    result = await db.execute(
        select(Memory).where(Memory.user_id == user_id).order_by(Memory.created_at.desc())
    )
    memories = list(result.scalars().all())
    if not memories:
        return []

    goal_vec = await embed_text(goal)
    if goal_vec:
        scored: list[tuple[float, Memory]] = []
        for m in memories:
            vec = deserialize(m.embedding)
            score = cosine(goal_vec, vec) if vec else 0.0
            scored.append((score, m))
        scored.sort(key=lambda t: t[0], reverse=True)
        # Keep only memories with some signal; if none scored, fall back to recent.
        top = [m for s, m in scored if s > 0.15][:limit]
        chosen = top or [m for _, m in scored[:limit]]
    else:
        chosen = memories[:limit]

    return [{"tag": m.tag, "text": m.text} for m in chosen]
