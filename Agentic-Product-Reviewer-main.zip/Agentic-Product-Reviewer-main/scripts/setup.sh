#!/usr/bin/env bash
# One-command bootstrap for Argus local dev.
#   ./scripts/setup.sh
# Idempotent: safe to re-run.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "[setup] 1/6 — .env"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "        created .env from .env.example"
  echo "[setup]        generating secrets..."
  if command -v python3 >/dev/null; then
    # gen_keys needs cryptography; try, but don't fail the whole setup if absent.
    python3 - <<'PY' >> .env 2>/dev/null || echo "        (run scripts/gen_keys.py after installing deps to fill secrets)"
import secrets
print(f"JWT_SECRET={secrets.token_urlsafe(48)}")
print(f"NEXTAUTH_SECRET={secrets.token_urlsafe(48)}")
PY
  fi
  echo "        >>> edit .env and add OPENAI_API_KEY to enable planning/vision <<<"
else
  echo "        .env already exists — leaving it alone"
fi

echo "[setup] 2/6 — Postgres + Redis (docker compose)"
docker compose up -d

echo "[setup] 3/6 — backend venv + deps"
cd backend
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -q --upgrade pip
pip install -q -e .
echo "[setup] 4/6 — chromium for the browser layers"
python -m playwright install chromium || echo "        (playwright browser install skipped/failed — browser layers will degrade)"
deactivate
cd "$ROOT"

echo "[setup] 5/6 — frontend deps + env"
cd frontend
if command -v pnpm >/dev/null; then pnpm install; else npm install; fi
# Next.js reads frontend/.env.local, NOT the repo-root .env. Mirror the auth
# vars across so NextAuth has its secret (otherwise every protected page shows
# "Server error — problem with the server configuration").
if [ ! -f .env.local ]; then
  SECRET=$(grep '^NEXTAUTH_SECRET=' ../.env | head -1 | cut -d= -f2-)
  [ -z "$SECRET" ] && SECRET="dev-secret-$(openssl rand -hex 16 2>/dev/null || echo changeme0000000000000000000000)"
  {
    echo "NEXTAUTH_URL=http://localhost:3000"
    echo "NEXTAUTH_SECRET=$SECRET"
    echo "NEXT_PUBLIC_BACKEND_URL=http://localhost:8000"
    echo "GOOGLE_CLIENT_ID=$(grep '^GOOGLE_CLIENT_ID=' ../.env | head -1 | cut -d= -f2-)"
    echo "GOOGLE_CLIENT_SECRET=$(grep '^GOOGLE_CLIENT_SECRET=' ../.env | head -1 | cut -d= -f2-)"
  } > .env.local
  echo "        wrote frontend/.env.local"
fi
cd "$ROOT"

echo "[setup] 6/6 — done"
cat <<'EOF'

Next:
  1. Put OPENAI_API_KEY into .env (planning, execution, vision, memory).
  2. (optional) Seed a demo account with preferences:
       cd backend && source .venv/bin/activate && python ../scripts/seed.py
  3. Start everything:
       ./scripts/dev.sh
  Frontend → http://localhost:3000   Backend → http://localhost:8000/docs
EOF
