#!/usr/bin/env bash
# Argus — one command to run EVERYTHING.
#
#   ./scripts/start.sh
#
# Boots Postgres + Redis (Docker if available, else native Homebrew), the
# FastAPI backend, and the Next.js frontend, then prints the URL. Ctrl+C stops
# everything this script started. Idempotent and safe to re-run.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PGPORT=5433
PGDATA="$ROOT/.localdb"
PGSOCK=/tmp
DB_URL="postgresql+asyncpg://argus:argus_dev@127.0.0.1:${PGPORT}/argus"
REDIS_URL="redis://localhost:6379/0"
STARTED_PG=0
STARTED_REDIS=0
BACK_PID=""
FRONT_PID=""

say() { printf "\033[1;36m[argus]\033[0m %s\n" "$*"; }

# Free a TCP port by killing whatever holds it (prevents two dev servers from
# sharing one .next build dir, which corrupts it and yields 404s).
free_port() {
  local pids
  pids=$(lsof -ti:"$1" 2>/dev/null || true)
  if [ -n "$pids" ]; then
    say "freeing port $1 (stopping a previous instance)"
    echo "$pids" | xargs kill -9 2>/dev/null || true
    sleep 1
  fi
}

# ---------------------------------------------------------------------------
# 0. stop any previous Argus servers so we never run two at once
# ---------------------------------------------------------------------------
pkill -f "uvicorn app.main" 2>/dev/null || true
free_port 8000
free_port 3000

# ---------------------------------------------------------------------------
# 0b. env files
# ---------------------------------------------------------------------------
if [ ! -f .env ]; then
  cp .env.example .env
  python3 - >> .env <<'PY' 2>/dev/null || true
import secrets
print(f"JWT_SECRET={secrets.token_urlsafe(48)}")
print(f"NEXTAUTH_SECRET={secrets.token_urlsafe(48)}")
PY
  say "created .env (add OPENAI_API_KEY to enable planning/execution)"
fi

if [ ! -f frontend/.env.local ]; then
  SECRET=$(grep '^NEXTAUTH_SECRET=' .env | head -1 | cut -d= -f2-)
  [ -z "$SECRET" ] && SECRET="dev-secret-please-change-0000000000000000"
  cat > frontend/.env.local <<EOF
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=$SECRET
NEXT_PUBLIC_BACKEND_URL=http://localhost:8000
GOOGLE_CLIENT_ID=$(grep '^GOOGLE_CLIENT_ID=' .env | head -1 | cut -d= -f2-)
GOOGLE_CLIENT_SECRET=$(grep '^GOOGLE_CLIENT_SECRET=' .env | head -1 | cut -d= -f2-)
EOF
  say "created frontend/.env.local"
fi

# ---------------------------------------------------------------------------
# 1. Postgres + Redis
# ---------------------------------------------------------------------------
USE_DOCKER=0
if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
  USE_DOCKER=1
fi

if [ "$USE_DOCKER" = "1" ]; then
  say "starting Postgres + Redis via Docker"
  docker compose up -d
  DB_URL="postgresql+asyncpg://argus:argus_dev@localhost:5432/argus"
  until docker compose exec -T postgres pg_isready -U argus >/dev/null 2>&1; do sleep 1; done
else
  say "Docker not found — using native Postgres + Redis"
  export LC_ALL=C LANG=C   # avoids macOS 'postmaster became multithreaded' bug

  # A shared local Argus database may already be healthy even when this
  # worktree has no matching postmaster.pid. Reuse it rather than trying to
  # launch a second Postgres instance on the same port.
  if ! pg_isready -h "$PGSOCK" -p "$PGPORT" -U argus >/dev/null 2>&1; then
    [ -d "$PGDATA" ] || { say "initializing Postgres data dir"; initdb -D "$PGDATA" -U argus --auth=trust >/dev/null; }
    pg_ctl -D "$PGDATA" -o "-p $PGPORT -k $PGSOCK" -l "$PGDATA/server.log" start >/dev/null
    STARTED_PG=1
    sleep 2
  fi
  createdb -h "$PGSOCK" -p "$PGPORT" -U argus argus >/dev/null 2>&1 || true

  # Apply migrations if the schema is empty.
  TABLES=$(psql -h "$PGSOCK" -p "$PGPORT" -U argus -d argus -tAc \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null || echo 0)
  if [ "${TABLES:-0}" -lt 5 ]; then
    say "applying database migrations"
    for f in database/migrations/*.sql; do
      psql -h "$PGSOCK" -p "$PGPORT" -U argus -d argus -q -f "$f" >/dev/null 2>&1 || true
    done
  fi

  if ! redis-cli ping >/dev/null 2>&1; then
    say "starting Redis"
    redis-server --port 6379 --daemonize yes >/dev/null
    STARTED_REDIS=1
  fi
fi

export DATABASE_URL="$DB_URL"
export REDIS_URL="$REDIS_URL"

# ---------------------------------------------------------------------------
# 2. backend
# ---------------------------------------------------------------------------
cd backend
if [ ! -d .venv ]; then
  say "creating backend venv + installing deps (first run, ~1-2 min)"
  python3 -m venv .venv
  ./.venv/bin/pip install -q --upgrade pip
  ./.venv/bin/pip install -q -e .
fi
say "starting backend on :8000"
LC_ALL=C ./.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload --reload-dir app --reload-dir ../agents --reload-dir ../integrations > /tmp/argus-backend.log 2>&1 &
BACK_PID=$!
cd "$ROOT"

# ---------------------------------------------------------------------------
# 3. frontend
# ---------------------------------------------------------------------------
cd frontend
if [ ! -d node_modules ]; then
  say "installing frontend deps (first run)"
  if command -v pnpm >/dev/null; then pnpm install; else npm install; fi
fi
say "starting frontend on :3000"
if command -v pnpm >/dev/null; then pnpm dev > /tmp/argus-frontend.log 2>&1 & else npm run dev > /tmp/argus-frontend.log 2>&1 & fi
FRONT_PID=$!
cd "$ROOT"

# ---------------------------------------------------------------------------
# 4. wait until both are answering, then print the link
# ---------------------------------------------------------------------------
cleanup() {
  echo
  say "shutting down…"
  [ -n "$FRONT_PID" ] && kill "$FRONT_PID" 2>/dev/null || true
  [ -n "$BACK_PID" ] && kill "$BACK_PID" 2>/dev/null || true
  if [ "$USE_DOCKER" = "0" ]; then
    [ "$STARTED_REDIS" = "1" ] && redis-cli shutdown nosave 2>/dev/null || true
    [ "$STARTED_PG" = "1" ] && pg_ctl -D "$PGDATA" stop -m fast >/dev/null 2>&1 || true
  fi
  exit 0
}
trap cleanup INT TERM

for _ in $(seq 1 30); do
  curl -sf localhost:8000/health >/dev/null 2>&1 && break || sleep 1
done
for _ in $(seq 1 30); do
  curl -sf localhost:3000 >/dev/null 2>&1 && break || sleep 1
done

LLM=$(curl -s localhost:8000/health/capabilities 2>/dev/null | grep -o '"llm":[a-z]*' || echo '"llm":?')

cat <<EOF

  ┌─────────────────────────────────────────────┐
  │  Argus is running                           │
  │                                             │
  │   ▶  http://localhost:3000                  │
  │      backend  http://localhost:8000/docs    │
  │                                             │
  │   demo login: demo@argus.app / argusdemo123 │
  │   ($LLM — add OPENAI_API_KEY to .env for     │
  │    real planning, then re-run)              │
  │                                             │
  │   Ctrl+C to stop everything                 │
  └─────────────────────────────────────────────┘

EOF

# Keep running until the user stops it (or a server dies).
wait
