"""Seed a demo account with preferences so the Memory + planning flow shines.

Run from the backend venv:
    cd backend && source .venv/bin/activate && python ../scripts/seed.py

Creates (idempotently):
  - user demo@argus.app / password 'argusdemo123'
  - default approval settings
  - a few memories (embedded if OPENAI_API_KEY is set)
  - a couple of connected sites
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

# Make `app` importable when run from anywhere.
BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

from sqlalchemy import select  # noqa: E402

from app.core.security import hash_password  # noqa: E402
from app.db.session import SessionLocal  # noqa: E402
from app.models import ConnectedSite, Memory, User, UserSettings  # noqa: E402
from app.services.auth_service import DEFAULT_APPROVAL_RULES  # noqa: E402
from app.services.embeddings import embed_text, serialize  # noqa: E402

DEMO_EMAIL = "demo@argus.app"
DEMO_PASSWORD = "argusdemo123"

MEMORIES = [
    ("DIET", "Vegetarian. High-protein preferred. Avoid palm oil."),
    ("BUDGET", "Default weekly grocery budget: ₹1500."),
    ("ADDRESS", "Default delivery: 14B Worli, Mumbai 400018."),
    ("TRAVEL", "Prefers morning flights, aisle seat, no layovers over 2h."),
]

SITES = [
    ("blinkit.com", "Blinkit", ["cart", "orders", "address"]),
    ("makemytrip.com", "MakeMyTrip", ["flights", "hotels"]),
]


async def main() -> None:
    async with SessionLocal() as db:
        result = await db.execute(select(User).where(User.email == DEMO_EMAIL))
        user = result.scalar_one_or_none()
        if user is None:
            user = User(
                email=DEMO_EMAIL,
                name="Demo User",
                password_hash=hash_password(DEMO_PASSWORD),
                email_verified=True,
            )
            db.add(user)
            await db.flush()
            db.add(UserSettings(user_id=user.id, approval_rules=DEFAULT_APPROVAL_RULES))
            print(f"created user {DEMO_EMAIL} / {DEMO_PASSWORD}")
        else:
            print(f"user {DEMO_EMAIL} already exists")

        existing = await db.execute(select(Memory).where(Memory.user_id == user.id))
        if existing.scalars().first() is None:
            for tag, text in MEMORIES:
                vec = await embed_text(f"{tag}: {text}")
                db.add(Memory(
                    user_id=user.id, tag=tag, text=text,
                    embedding=serialize(vec) if vec else None,
                ))
            print(f"seeded {len(MEMORIES)} memories (embedded={'yes' if vec else 'no key'})")

        for domain, name, scopes in SITES:
            dup = await db.execute(
                select(ConnectedSite).where(
                    ConnectedSite.user_id == user.id, ConnectedSite.domain == domain
                )
            )
            if dup.scalar_one_or_none() is None:
                db.add(ConnectedSite(
                    user_id=user.id, domain=domain, display_name=name,
                    scopes=scopes, status="live",
                ))
        await db.commit()
        print("seed complete.")


if __name__ == "__main__":
    asyncio.run(main())
