#!/usr/bin/env bash
# Boot Postgres+Redis (Docker), backend (uvicorn), and frontend (next dev).
# Stops everything on Ctrl+C.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [ ! -f .env ]; then
  echo "[dev] .env missing — copy .env.example to .env first."
  exit 1
fi

echo "[dev] starting Postgres + Redis..."
docker compose up -d

echo "[dev] waiting for Postgres..."
until docker compose exec -T postgres pg_isready -U "${POSTGRES_USER:-argus}" >/dev/null 2>&1; do
  sleep 1
done

cleanup() {
  echo "[dev] shutting down..."
  kill $(jobs -p) 2>/dev/null || true
}
trap cleanup EXIT INT TERM

echo "[dev] starting backend on :8000..."
(cd backend && uvicorn app.main:app --reload --host 0.0.0.0 --port "${BACKEND_PORT:-8000}") &

echo "[dev] starting frontend on :3000..."
(cd frontend && pnpm dev 2>/dev/null || npm run dev) &

wait
