-- Post-task feedback. After a task finishes (or is cancelled), the user can leave
-- a rating and/or a note. Feedback — and successful tasks — are distilled by the
-- app layer into durable preferences in `memories`, so Argus learns over time.

CREATE TABLE IF NOT EXISTS task_feedback (
  id          BIGSERIAL PRIMARY KEY,
  task_id     UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating      SMALLINT,                 -- optional 1..5 (thumbs map to 1/5)
  text        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_task_feedback_task ON task_feedback(task_id, created_at DESC);
