-- Repeating task schedules.
-- Idempotent for existing local databases.

CREATE TABLE IF NOT EXISTS recurring_tasks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  goal            TEXT NOT NULL,
  frequency       TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly')),
  interval        INT NOT NULL DEFAULT 1,
  state           TEXT NOT NULL DEFAULT 'active'
                  CHECK (state IN ('active','paused','completed','cancelled')),
  next_run_at     TIMESTAMPTZ,
  end_at          TIMESTAMPTZ,
  remaining_runs  INT,
  last_task_id    UUID REFERENCES tasks(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recurring_due ON recurring_tasks(state, next_run_at);
CREATE INDEX IF NOT EXISTS idx_recurring_user ON recurring_tasks(user_id, created_at DESC);

DO $$ BEGIN
  CREATE TRIGGER trg_recurring_tasks_touch BEFORE UPDATE ON recurring_tasks
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
