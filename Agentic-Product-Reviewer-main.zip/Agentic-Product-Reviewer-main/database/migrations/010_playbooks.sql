-- Playbooks: a finished task saved as a reusable, editable recipe. A playbook is
-- the ordered, human-readable STEPS of a completed task (not the raw action
-- trace), each toggleable. Re-running a playbook seeds a new task with the enabled
-- steps and skips the planner; credentials/personal details are filled from the
-- vault, so only the variables change between runs.

CREATE TABLE IF NOT EXISTS playbooks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  goal_template   TEXT NOT NULL,
  intent          JSONB NOT NULL DEFAULT '{}'::jsonb,
  source_task_id  UUID REFERENCES tasks(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_playbooks_user ON playbooks(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS playbook_steps (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playbook_id     UUID NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
  ordinal         INT  NOT NULL,
  label           TEXT NOT NULL,
  kind            TEXT,            -- step meta: STRUCTURED | EXECUTING | APPROVAL | AUTO
  target          TEXT,            -- dominant action target, if any (informational)
  value_template  TEXT,            -- reserved for templated fills
  sensitive_kind  TEXT,            -- reserved: which vault field supplies the value
  enabled         BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX IF NOT EXISTS idx_playbook_steps_pb ON playbook_steps(playbook_id, ordinal);
