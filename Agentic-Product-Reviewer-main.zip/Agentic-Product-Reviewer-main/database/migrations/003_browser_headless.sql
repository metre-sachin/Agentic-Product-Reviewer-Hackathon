-- Per-user headless/headed browser preference.
-- Additive and idempotent so it is safe to apply to an existing database.
ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_headless BOOLEAN NOT NULL DEFAULT TRUE;
