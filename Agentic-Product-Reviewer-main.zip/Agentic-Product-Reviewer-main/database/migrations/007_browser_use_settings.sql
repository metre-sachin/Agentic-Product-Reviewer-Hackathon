-- Browser Use parity settings: connected browser, profile, CAPTCHA/manual gates.

ALTER TABLE user_settings
  ALTER COLUMN browser_mode SET DEFAULT 'browser';

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_cdp_url TEXT;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_use_system_chrome BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_chrome_profile TEXT;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_use_model TEXT NOT NULL DEFAULT 'gpt-4o';

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS browser_use_captcha_solver BOOLEAN NOT NULL DEFAULT TRUE;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS captcha_autosolve BOOLEAN NOT NULL DEFAULT TRUE;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS manual_assist_enabled BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE user_settings
SET browser_mode = 'browser',
    preferred_model = 'gpt-4o',
    browser_use_model = COALESCE(NULLIF(browser_use_model, ''), 'gpt-4o')
WHERE browser_mode IN ('structured', 'vision')
   OR preferred_model = 'gpt-4o-mini';
