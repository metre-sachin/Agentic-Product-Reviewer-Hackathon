-- Experiential "site lessons" — Reflexion-style operational memory. After a run,
-- Argus distils short, reusable lessons about HOW a specific site behaves (what
-- approach failed, what worked, stable facts about its flow) and replays them into
-- planning + execution next time, so it stops repeating the same mistakes. Distinct
-- from `memories` (which holds the user's personal preferences, not site mechanics).

CREATE TABLE IF NOT EXISTS site_lessons (
  id           BIGSERIAL PRIMARY KEY,
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  domain       TEXT NOT NULL,                  -- registrable host the lesson is about
  kind         TEXT NOT NULL DEFAULT 'fact'    -- avoid | prefer | fact
               CHECK (kind IN ('avoid', 'prefer', 'fact')),
  lesson       TEXT NOT NULL,
  hits         INT  NOT NULL DEFAULT 0,        -- how often it has been reused
  last_used_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_site_lessons_user_domain
  ON site_lessons(user_id, domain);
