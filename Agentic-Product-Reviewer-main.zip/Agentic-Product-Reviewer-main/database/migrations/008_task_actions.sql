-- Structured action trace: every concrete browser action Argus actually took
-- (navigate / click / type / select / press / scroll / wait), as opposed to the
-- *plan* (task_steps) or the freeform narration (task_logs). This is the
-- click-by-click record that powers replay, playbooks, and "you were here" visual
-- re-grounding. Sensitive values (passwords, OTPs, personal fields) are redacted
-- to '•••' by the application layer before insert — never stored in the clear.

CREATE TABLE IF NOT EXISTS task_actions (
  id              BIGSERIAL PRIMARY KEY,
  task_id         UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  step_id         UUID REFERENCES task_steps(id) ON DELETE SET NULL,
  ordinal         INT  NOT NULL,                 -- monotonically increasing per task
  kind            TEXT NOT NULL,                 -- navigate|click|type|select|press|scroll|wait|read|extract
  target          TEXT,                          -- visible label/description of the target
  value           TEXT,                          -- redacted for sensitive fields ('•••')
  url             TEXT,                          -- page URL the action occurred on
  screenshot_url  TEXT,                          -- optional frame captured around the action
  ok              BOOLEAN NOT NULL DEFAULT TRUE, -- did the action take effect
  at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_task_actions_task ON task_actions(task_id, ordinal);
