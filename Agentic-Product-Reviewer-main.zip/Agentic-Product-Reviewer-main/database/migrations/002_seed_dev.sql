-- Optional dev seed. Runs after 001. Safe on re-run.

INSERT INTO users (id, email, name, email_verified)
VALUES ('00000000-0000-0000-0000-000000000001', 'demo@argus.app', 'Demo User', true)
ON CONFLICT (email) DO NOTHING;

INSERT INTO user_settings (user_id, approval_rules, browser_mode)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  '{"payment": true, "identity": true, "spend_over": 500, "post_on_behalf": false, "new_site": true}'::jsonb,
  'structured'
)
ON CONFLICT (user_id) DO NOTHING;
