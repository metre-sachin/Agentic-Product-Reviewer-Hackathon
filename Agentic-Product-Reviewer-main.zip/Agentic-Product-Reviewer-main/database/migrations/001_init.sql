-- Argus initial schema. Applied automatically by docker-entrypoint-initdb.d.
-- One migration per file; numbered. Idempotent guards where cheap.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- States are stored as TEXT with CHECK constraints rather than native ENUM
-- types. The application layer treats them as strings, and CHECK constraints
-- give the same validation while allowing new states without ALTER TYPE.
--
--   task_state:      created | planning | executing | recovering | paused |
--                    waiting_for_user | waiting_for_approval |
--                    completed | failed | cancelled
--   step_state:      pending | active | done | skipped | failed
--   execution_layer: scrapling | agent_browser | browser_use | vision | human
--   approval_state:  pending | approved | rejected | expired
--   log_level:       debug | info | warn | error | milestone

-- ---------- Users + auth ----------
CREATE TABLE IF NOT EXISTS users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email           CITEXT UNIQUE,
  name            TEXT,
  avatar_url      TEXT,
  password_hash   TEXT,            -- nullable for OAuth-only users
  google_id       TEXT UNIQUE,     -- nullable for password-only users
  email_verified  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- User-scoped saved details (cards, addresses, IDs). Encrypted at rest by app layer.
CREATE TABLE IF NOT EXISTS vault_entries (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind            TEXT NOT NULL,      -- 'card' | 'address' | 'identity' | 'login' | ...
  label           TEXT NOT NULL,
  ciphertext      BYTEA NOT NULL,     -- Fernet-encrypted JSON blob
  ask_every_time  BOOLEAN NOT NULL DEFAULT FALSE,
  last_used_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_vault_user ON vault_entries(user_id);

-- ---------- Tasks ----------
CREATE TABLE IF NOT EXISTS tasks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  goal            TEXT NOT NULL,         -- the raw user prompt
  state           TEXT NOT NULL DEFAULT 'created'
                  CHECK (state IN ('created','planning','executing','recovering',
                    'paused','waiting_for_user','waiting_for_approval',
                    'completed','failed','cancelled')),
  intent          JSONB NOT NULL DEFAULT '{}'::jsonb,  -- parsed goal: domain, budget, constraints
  result          JSONB,                              -- final summary on completion
  error           TEXT,
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tasks_user_created ON tasks(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tasks_state ON tasks(state);

CREATE TABLE IF NOT EXISTS recurring_tasks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  goal            TEXT NOT NULL,
  frequency       TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly')),
  interval        INT NOT NULL DEFAULT 1,
  state           TEXT NOT NULL DEFAULT 'active'
                  CHECK (state IN ('active','paused','completed','cancelled')),
  next_run_at     TIMESTAMPTZ,
  end_at          TIMESTAMPTZ,
  remaining_runs  INT,
  last_task_id    UUID REFERENCES tasks(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_recurring_due ON recurring_tasks(state, next_run_at);
CREATE INDEX IF NOT EXISTS idx_recurring_user ON recurring_tasks(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS task_steps (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id         UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  ordinal         INT  NOT NULL,
  label           TEXT NOT NULL,
  meta            TEXT,                 -- e.g. 'STRUCTURED', 'EXECUTING', 'APPROVAL'
  state           TEXT NOT NULL DEFAULT 'pending'
                  CHECK (state IN ('pending','active','done','skipped','failed')),
  layer_used      TEXT,
  attempts        INT NOT NULL DEFAULT 0,
  payload         JSONB NOT NULL DEFAULT '{}'::jsonb,
  started_at      TIMESTAMPTZ,
  ended_at        TIMESTAMPTZ,
  UNIQUE (task_id, ordinal)
);
CREATE INDEX IF NOT EXISTS idx_steps_task ON task_steps(task_id, ordinal);

CREATE TABLE IF NOT EXISTS task_logs (
  id              BIGSERIAL PRIMARY KEY,
  task_id         UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  step_id         UUID REFERENCES task_steps(id) ON DELETE SET NULL,
  level           TEXT NOT NULL DEFAULT 'info'
                  CHECK (level IN ('debug','info','warn','error','milestone')),
  layer           TEXT,
  text            TEXT NOT NULL,
  detail          TEXT,
  data            JSONB,
  at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_logs_task_at ON task_logs(task_id, at DESC);

-- ---------- Approvals ----------
CREATE TABLE IF NOT EXISTS approvals (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id         UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  step_id         UUID REFERENCES task_steps(id) ON DELETE SET NULL,
  reason          TEXT NOT NULL,         -- 'payment' | 'submit' | 'send' | 'booking' | 'new_site'
  summary         JSONB NOT NULL,        -- what's about to happen, shown to the user
  state           TEXT NOT NULL DEFAULT 'pending'
                  CHECK (state IN ('pending','approved','rejected','expired')),
  responded_at    TIMESTAMPTZ,
  expires_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_approvals_task ON approvals(task_id);
CREATE INDEX IF NOT EXISTS idx_approvals_state ON approvals(state);

-- ---------- Recovery events ----------
CREATE TABLE IF NOT EXISTS recovery_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id         UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  step_id         UUID REFERENCES task_steps(id) ON DELETE SET NULL,
  from_layer      TEXT NOT NULL,
  to_layer        TEXT NOT NULL,
  cause           TEXT NOT NULL,        -- 'low_confidence' | 'element_missing' | 'timeout' | 'blocked'
  evidence        JSONB,
  recovered       BOOLEAN,
  at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_recovery_task ON recovery_events(task_id, at DESC);

-- ---------- Browser sessions ----------
CREATE TABLE IF NOT EXISTS browser_sessions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id         UUID REFERENCES tasks(id) ON DELETE CASCADE,
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  layer           TEXT NOT NULL,
  storage_state   JSONB,                -- Playwright storageState (cookies, localStorage)
  current_url     TEXT,
  last_screenshot_url TEXT,
  closed_at       TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_browser_sessions_task ON browser_sessions(task_id);

-- ---------- Memory ----------
CREATE TABLE IF NOT EXISTS memories (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tag             TEXT NOT NULL,         -- DIET, BUDGET, ADDRESS, TRAVEL, ...
  text            TEXT NOT NULL,
  embedding       BYTEA,                 -- optional; populated when OPENAI key present
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id);

-- ---------- Connected sites ----------
CREATE TABLE IF NOT EXISTS connected_sites (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  domain          TEXT NOT NULL,
  display_name    TEXT,
  status          TEXT NOT NULL DEFAULT 'live',  -- live | ok | paused | error
  scopes          JSONB NOT NULL DEFAULT '[]'::jsonb,
  storage_state   JSONB,                          -- cached login state per site
  last_used_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, domain)
);

-- ---------- Per-user app settings ----------
CREATE TABLE IF NOT EXISTS user_settings (
  user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  approval_rules   JSONB NOT NULL DEFAULT '{}'::jsonb,
  browser_mode     TEXT NOT NULL DEFAULT 'browser',
  browser_headless BOOLEAN NOT NULL DEFAULT TRUE,  -- headed window when FALSE
  preferred_model  TEXT NOT NULL DEFAULT 'gpt-4o',
  browser_cdp_url  TEXT,
  browser_use_system_chrome BOOLEAN NOT NULL DEFAULT FALSE,
  browser_chrome_profile TEXT,
  browser_use_model TEXT NOT NULL DEFAULT 'gpt-4o',
  browser_use_captcha_solver BOOLEAN NOT NULL DEFAULT TRUE,
  captcha_autosolve BOOLEAN NOT NULL DEFAULT TRUE,
  manual_assist_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- updated_at triggers ----------
CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DO $$ BEGIN
  CREATE TRIGGER trg_users_touch BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER trg_tasks_touch BEFORE UPDATE ON tasks
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER trg_recurring_tasks_touch BEFORE UPDATE ON recurring_tasks
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER trg_memories_touch BEFORE UPDATE ON memories
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TRIGGER trg_user_settings_touch BEFORE UPDATE ON user_settings
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
