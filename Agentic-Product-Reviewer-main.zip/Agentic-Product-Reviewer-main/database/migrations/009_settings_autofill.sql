-- Per-user toggles for the credential vault and learned-memory features.
--   autofill_enabled   — autofill saved logins/details before asking (Phase 2)
--   auto_learn_enabled — distil durable preferences from finished tasks (Phase 5)

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS autofill_enabled BOOLEAN NOT NULL DEFAULT TRUE;

ALTER TABLE user_settings
  ADD COLUMN IF NOT EXISTS auto_learn_enabled BOOLEAN NOT NULL DEFAULT TRUE;
