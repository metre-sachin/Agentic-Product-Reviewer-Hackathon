-- Allow task execution to be paused and resumed.

ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_state_check;

ALTER TABLE tasks
  ADD CONSTRAINT tasks_state_check
  CHECK (state IN (
    'created',
    'planning',
    'executing',
    'recovering',
    'paused',
    'waiting_for_user',
    'waiting_for_approval',
    'completed',
    'failed',
    'cancelled'
  ));
