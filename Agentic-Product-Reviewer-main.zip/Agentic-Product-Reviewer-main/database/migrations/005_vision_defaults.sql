-- Default the agent to the more capable autonomous browser path.

ALTER TABLE user_settings
  ALTER COLUMN browser_mode SET DEFAULT 'browser';

ALTER TABLE user_settings
  ALTER COLUMN preferred_model SET DEFAULT 'gpt-4o';

UPDATE user_settings
SET browser_mode = 'browser',
    preferred_model = 'gpt-4o'
WHERE browser_mode = 'structured'
  AND preferred_model = 'gpt-4o-mini';
