# Database

Plain Postgres 16. Migrations are numbered SQL files, applied in order.

In dev they auto-apply when the Postgres container first boots via
`docker-entrypoint-initdb.d`. To re-run from scratch:

```bash
docker compose down -v   # wipes volume
docker compose up -d     # re-applies all migrations
```

## Tables

- **users** — accounts; `password_hash` for email/password, `google_id` for OAuth
- **vault_entries** — encrypted cards/addresses/identities/logins
- **tasks** — one row per user goal; tracks state machine
- **task_steps** — generated plan steps; ordered
- **task_logs** — append-only timeline shown live in the UI
- **approvals** — every irreversible action requires one
- **recovery_events** — L1→L2→L3→L4 escalations
- **browser_sessions** — Playwright storage state per task, per layer
- **memories** — user preferences with optional embeddings
- **connected_sites** — per-domain login state and scopes
- **user_settings** — approval rules, preferred browser mode, model
