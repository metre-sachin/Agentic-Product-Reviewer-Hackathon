# Architecture

```
┌──────────────────────┐
│  Frontend (Next.js)  │  Existing design. Auth via NextAuth.
└──────────┬───────────┘
           │ HTTPS + SSE
┌──────────▼───────────┐
│  Backend (FastAPI)   │  Auth, REST, SSE stream, task lifecycle.
│   ┌──────────────┐   │
│   │  Orchestrator │  │  LangGraph state machine over AgentState.
│   └──┬────────┬──┘   │
│      │        │      │
│  ┌───▼──┐  ┌──▼───┐  │  Agents:
│  │ Plan │  │Exec  │  │   planner / executor / recovery
│  └──────┘  └──┬───┘  │   approval / memory / vision
│               │      │
└───────────────┼──────┘
                │
       ┌────────▼─────────┐
       │   Adapter ladder  │  L1 Scrapling   (read)
       │                   │  L2 Agent Browser
       │                   │  L3 Browser Use
       │                   │  L4 Vision (GPT-4o)
       │                   │  L5 Human assist
       └────────┬──────────┘
                │
        Playwright controller (shared chromium)
                │
                ▼
            The open web
```

## Why this shape

- **Orchestration is ours.** Adapters are interchangeable; the brain isn't tied
  to any vendor SDK's task loop.
- **One contract** (`StepInput → StepResult`) makes Recovery dumb-simple:
  if `ok=false` or `confidence < threshold`, escalate.
- **Safety lives outside the adapters.** The Approval Agent inspects intents
  before any adapter runs irreversible steps, so swapping an adapter can't
  bypass a checkout gate.
- **State lives in Postgres, not in memory.** A crashed worker resumes; the UI
  reads the same source of truth as the executor.

## Data flow on a typical task

1. User POSTs `/tasks` with a goal.
2. Backend creates `tasks` row (state=`created`), enqueues Redis job.
3. Worker loads task, runs Planner → fills `task_steps`, state=`planning`→`executing`.
4. For each step:
   - Executor picks initial layer (Scrapling for read, Agent Browser for act).
   - Adapter runs; `task_logs` append; `BrowserPreview` URL updates.
   - On low confidence → Recovery records `recovery_events` row, escalates.
   - On irreversible intent → Approval creates `approvals` row, state=`waiting_for_approval`.
5. User approves/rejects via `/tasks/{id}/approve` or `/reject`.
6. On finish → state=`completed`, `result` populated, UI shows summary.

## Frontend integration points (Phase 4 wires these)

| UI component | Data source |
|---|---|
| `PlanList` | `GET /tasks/{id}` then SSE step updates |
| `ExecutionLog` | SSE `log` events |
| `BrowserPreview` | SSE `screenshot` events (signed URLs) |
| `ApprovalBar` / `ApprovalModal` | SSE `approval` event + POST to `/approve` |
| `RecoveryModal` | SSE `recovery` event + POST `/user-input` |
