# Runbook

## One command (recommended)

```bash
./scripts/start.sh
```

Brings up the database, Redis, backend, and frontend — Docker if available,
otherwise native Homebrew Postgres/Redis. Creates `.env`, `frontend/.env.local`,
the backend venv, and installs deps on first run. Applies migrations
automatically. Prints `http://localhost:3000` when ready; Ctrl+C stops it all.

Add `OPENAI_API_KEY` to `.env` and re-run to enable planning/execution. Browser
layers also need `python -m playwright install chromium` (see setup below).

## First-time setup

```bash
./scripts/setup.sh
```

This copies `.env`, starts Postgres + Redis, creates the backend venv and
installs deps, installs chromium for the browser layers, and installs frontend
deps.

Then:

1. Add `OPENAI_API_KEY=...` to `.env` (enables planning, execution, vision, memory).
2. (optional) Seed a demo account with preferences:
   ```bash
   cd backend && source .venv/bin/activate && python ../scripts/seed.py
   ```
   → `demo@argus.app` / `argusdemo123`, pre-loaded with diet/budget/travel memories.

## Run

```bash
./scripts/dev.sh
```

- Frontend → http://localhost:3000
- Backend docs → http://localhost:8000/docs
- Capabilities (what's live right now) → http://localhost:8000/health/capabilities

## Check what's enabled

```bash
curl -s localhost:8000/health/capabilities | jq
```

```json
{
  "llm": true,
  "layers": {
    "scrapling": true,
    "agent_browser": true,
    "browser_use": true,
    "vision": true,
    "human": true
  }
}
```

- `llm: false` → no OpenAI key; planning will fail fast. Add the key to `.env`.
- `agent_browser: false` → chromium not installed; run `python -m playwright install chromium`.
- `browser_use: false` → package missing or no key; recovery skips L3 and goes to vision/human.

## Reset the database

```bash
docker compose down -v && docker compose up -d   # re-applies migrations from scratch
```

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Tasks stay in `planning` then `failed` with "OPENAI_API_KEY not set" | no key | add `OPENAI_API_KEY` to `.env`, restart backend |
| Interaction steps "deferred" | no chromium | `python -m playwright install chromium` |
| Recovery never reaches Browser Use | `browser-use` not installed / no key | `pip install browser-use`, set key |
| SSE not updating the task screen | backend down or CORS | confirm backend on :8000, `FRONTEND_ORIGIN` matches |
| Login fails | secrets unset | `python scripts/gen_keys.py >> .env`, restart both |
| Every page except landing shows **"Server error — problem with the server configuration"** | NextAuth has no secret because Next.js reads `frontend/.env.local`, not the repo-root `.env` | create `frontend/.env.local` with `NEXTAUTH_URL`, `NEXTAUTH_SECRET`, `NEXT_PUBLIC_BACKEND_URL` (setup.sh does this), then restart `npm run dev` |
| Screenshots 404 | media dir | check `MEDIA_DIR`; `/media` is mounted from there |

## Production notes (beyond MVP)

- Move the runtime off `asyncio.create_task` onto the Redis/RQ worker (queue is
  already provisioned) so tasks survive restarts and scale across workers.
- Swap the in-process event bus for Redis pub/sub (same `publish()` API).
- Put `/media` behind signed URLs or an authenticated proxy instead of public
  UUID paths.
- Swap pure-Python cosine for pgvector once memory volume grows.
