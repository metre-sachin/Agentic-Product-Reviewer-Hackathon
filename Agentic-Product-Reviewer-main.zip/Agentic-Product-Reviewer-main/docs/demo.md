# Demo workflows

Three cross-domain tasks that show Argus is a general web operator, not a
single-site bot. Sign in (or use the seeded `demo@argus.app` / `argusdemo123`),
then type the goal on the home screen.

Watch the execution screen: the **plan** appears, the **log** streams every
action with the layer that handled it, the **browser preview** shows live
screenshots, and Argus **pauses for approval** before anything irreversible.

---

## 1. Research & compare (read-dominant — completes fully without checkout)

> "Compare noise-cancelling headphones under ₹15000 across a few sites and
> recommend one with reasons."

- L1 **Scrapling** searches and reads product/listing pages (cheap, quiet).
- The executor distils observations per step; later steps build on earlier finds.
- Ends with a recommendation in the result summary — no interaction, no approval.

Shows: planning, real web reads, accumulating context, clean completion.

---

## 2. Build a grocery cart (interaction + memory + approval gate)

> "Build a high-protein vegetarian grocery cart for 7 days under ₹1500."

- **Memory** loads the seeded DIET + BUDGET preferences and shapes the plan.
- L1 reads candidate items; L2 **Agent Browser** opens the site and adds items
  (live screenshots stream in).
- At checkout Argus **stops** — the approval bar + modal show the cart and total.
  Nothing is purchased until you click **Approve**.

Shows: memory-driven planning, structured interaction, the hard safety gate.

---

## 3. Inbox triage / form fill (interaction + recovery + human assist)

> "Open my email, summarize the latest unread messages, and draft reply
> suggestions." (or) "Fill this signup form with my saved details."

- L2 drives the page. If a layout confuses structured interaction, the
  **Recovery** ladder escalates automatically: L2 → L3 **Browser Use** → L4
  **Vision** (screenshot reasoning).
- If every automated layer is unsure, Argus asks you a clear question
  (**human assist**) and resumes with your answer.
- Sending an email / submitting the form triggers an **approval** first.

Shows: the full recovery ladder, the `⟳ RECOVERED n` indicator, and human assist.

---

## What to point at during a demo

- **Plan list** populating from the planner.
- **Execution log** tagging each line with the layer (`scrapling`,
  `agent_browser`, `browser_use`, `vision`, `human`).
- **Browser preview** updating live after every action.
- **Approval modal** on checkout — emphasise nothing irreversible happens
  without it, regardless of settings.
- **Recovery** escalation when a step stalls.
- **Memory** line in the log proving preferences were applied.
- `GET /health/capabilities` to show which layers are live.
