# Roadmap

| # | Phase | Status |
|---|---|---|
| 0 | Repo scaffold + Docker | ✅ done |
| 1 | DB schema | ✅ done |
| 2 | Auth (email/password + Google) + Tasks CRUD API | ✅ done |
| 3 | Real OpenAI planner + runtime state machine + SSE; all frontend on real data | ✅ done |
| 4 | Scrapling adapter (L1 reading) + LLM executor wired into runtime | ✅ done |
| 5 | Agent Browser adapter (L2 acting) + live screenshots | ✅ done |
| 6 | Browser Use adapter (L3 autonomous) + Recovery escalation | ✅ done |
| 7 | Vision adapter (L4) + human assist (L5) — full ladder | ✅ done |
| 8 | Memory embeddings + retrieval at plan time | ✅ done |
| 9 | Demo polish — setup script, seed, capabilities, runbook | ✅ done |

**MVP complete.** All nine phases shipped. See [demo.md](demo.md) for showcase
workflows and [runbook.md](runbook.md) for operating instructions.

## Phase 9 notes

- `scripts/setup.sh` — one-command bootstrap (.env, docker, deps, chromium).
- `scripts/seed.py` — demo account `demo@argus.app` / `argusdemo123` with
  diet/budget/travel memories + connected sites, so memory-driven planning is
  visible immediately.
- `GET /health/capabilities` reports which layers are live (llm key, scrapling,
  agent_browser, browser_use, vision) — used in the runbook and for debugging.
- `docs/runbook.md` (operate + troubleshoot) and `docs/demo.md` (three
  cross-domain showcase workflows).

## Phase 8 notes

- New memories are embedded (`text-embedding-3-small`) and stored as packed
  float32 bytes in `memories.embedding`. Embeddings are best-effort: no API key
  → memory still saves, retrieval just falls back to most-recent.
- The Memory agent retrieves the top relevant preferences for a goal via cosine
  similarity (pure-Python, no numpy/pgvector for the MVP), and the runtime feeds
  them into the planner before planning. A `memory` log line shows which
  preferences were loaded, and the plan reflects them (diet, budget, address,
  travel prefs, etc.).
- Settings → Memory (Phase 3) already does CRUD; adding a memory there now makes
  it influence future plans automatically.

## Phase 7 notes

- Vision layer (L4): `VisionAdapter.decide` sends a live screenshot + the
  labelled element list to the OpenAI vision model and returns a structured
  action. The vision loop (`agents/executor/vision_loop.py`) executes it through
  the Agent Browser adapter (click by ref) or the controller (click by pixel
  coords), bounded to a few actions. `complete_json_vision` added to the LLM
  client; `screenshot_bytes` / `click_xy` added to the controller.
- The recovery ladder is now complete: a stalled step escalates
  L2 Agent Browser → L3 Browser Use → L4 Vision → L5 human assist, each hop
  recorded in `recovery_events` and streamed.
- L5 human assist: when every automated layer fails, the task enters
  `waiting_for_user`, streams an `assist` event (question + step), and blocks on
  the user's reply via `/tasks/{id}/user-input`. The reply is fed back as
  guidance into one more structured interaction pass.
- Frontend: `useTaskStream` captures `assist`; the execution screen auto-opens
  the recovery modal with Argus's question and the user's answer resumes the run.
- Same safety rules hold at every layer — vision and the guided retry are still
  forbidden from completing payments/submissions without explicit approval.

## Phase 4 notes

- `ScraplingAdapter` is the real L1 reading layer. It tries cheap HTTP first
  (`AsyncFetcher`, TLS/header fingerprint impersonation — no browser), then
  escalates to the stealth browser (`StealthyFetcher`) only if HTTP is blocked.
  Import-safe: if Scrapling or its browser deps are missing, reads degrade and
  the executor reasons from context instead.
- The executor agent (`agents/executor/executor.py`) drives each step: an LLM
  decides search / fetch / reason / interact, Scrapling reads for the first two,
  and a second LLM call distils a concise observation. Observations accumulate
  as context across steps.
- Read-dominant tasks (compare, research, find, summarize public pages) can
  complete end-to-end now. Steps needing clicks/typing/checkout are flagged
  `needs_interaction` and honestly deferred to the acting layer (Phase 5),
  surfaced in the log and the task result.
- Scrapling's stealth-browser fallback needs browser binaries
  (`patchright`/camoufox); the cheap HTTP path does not.

## Phase 5 notes

- `PlaywrightController` owns one chromium per task; `AgentBrowserAdapter` reads
  a structured page snapshot (interactive elements tagged with stable refs) and
  clicks/types/selects by ref — no brittle CSS selectors.
- The browser interaction loop (`agents/executor/browser_loop.py`) is a bounded
  LLM act/observe cycle. It is forbidden from clicking pay/checkout/submit/send;
  if that's the next action it stops and the runtime raises a human approval,
  then resumes with `allow_irreversible=True` once approved.
- Interaction steps that were "deferred" in Phase 4 now execute for real. The
  runtime opens the browser lazily on the first interaction step, streams a live
  screenshot after every action (SSE `screenshot` event → `BrowserPreview`),
  persists `browser_sessions` (storage state, last URL, last shot), and releases
  chromium when the task ends.
- Requires a chromium binary: `python -m playwright install chromium`.
  Import-safe: if the browser layer can't start, interaction steps degrade to an
  honest "deferred" note instead of crashing.

## Phase 6 notes

- `BrowserUseAdapter` (L3) is the autonomous fallback: it runs browser-use's
  LLM-in-the-loop agent on the failing sub-task. Import-safe and
  version-defensive across browser-use's shifting API + LLM wrappers.
- The Recovery agent escalates automatically: when L2 structured interaction
  stalls (action limit / no progress) or the structured browser can't even
  start, the runtime moves the task to `recovering`, writes a `recovery_events`
  row, streams an SSE `recovery` event, runs Browser Use, then records whether
  it recovered. Falls back honestly if L3 is unavailable.
- Frontend: `useTaskStream` captures `recovery` events; the execution screen
  shows a `⟳ RECOVERED n` indicator and the escalation appears inline in the log.
- browser-use needs its own browser binary too; if absent or no API key, the
  layer reports unavailable and recovery degrades gracefully.

## Phase 3 notes

- Planner uses OpenAI (`OPENAI_MODEL_PLANNER`, default `gpt-4o-mini`) via
  `backend/app/services/llm.py`. Without a key, `POST /tasks` still creates the
  task row but the runtime fails fast in planning with a clear error — add
  `OPENAI_API_KEY` to `.env` to enable real planning.
- The executor is a placeholder that walks each planned step, logging real
  events and honouring approval gates, so the full UI pipeline (plan → log →
  approval → completion) is exercisable today. Phases 4–7 swap the placeholder
  for the adapter ladder.
- All frontend mock data is gone. `lib/mock-data.ts` deleted; static product
  config moved to `lib/ui-config.ts`. Every screen reads the backend.
