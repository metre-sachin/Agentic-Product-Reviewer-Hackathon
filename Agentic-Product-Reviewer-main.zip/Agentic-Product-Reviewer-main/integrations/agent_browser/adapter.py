"""Agent Browser adapter — L2 structured DOM/a11y interaction.

Primary acting layer: clicks, types, selects, and fills forms using semantic
refs taken from a structured page snapshot rather than brittle CSS selectors.

Operates on a Playwright Page borrowed from the PlaywrightController, so it adds
no browser process of its own. No Playwright import at module load — fully
import-safe.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from integrations.base import Layer

log = logging.getLogger(__name__)

# JS that tags every interactive element with a stable ref and returns metadata.
_SNAPSHOT_JS = r"""
() => {
  const BASE_SEL = [
    'a[href]', 'button', 'input', 'input[type=submit]', 'input[type=button]',
    'textarea', 'select', '[role=button]',
    '[role=link]', '[role=checkbox]', '[role=tab]', '[role=option]',
    '[role=listitem]', '[contenteditable=true]', '[onclick]', '[aria-label]',
    '[tabindex]:not([tabindex="-1"])', '[data-testid]', '[data-test]',
    '[data-cy]', '[data-action]', '.a-button', '.a-button-input',
    '.a-button-text', 'li',
  ].join(', ');

  const candidates = [];
  const seen = new Set();
  const out = [];

  function textOf(el) {
    return (el.innerText || el.value || el.getAttribute('aria-label') || '')
      .trim().replace(/\s+/g, ' ');
  }

  function visibleRect(el) {
    const rect = el.getBoundingClientRect();
    const visible = rect.width > 0 && rect.height > 0 &&
      getComputedStyle(el).visibility !== 'hidden' &&
      getComputedStyle(el).display !== 'none';
    return visible ? rect : null;
  }

  function looksLikeLocationOption(el, text) {
    const hay = [
      text,
      el.getAttribute('aria-label') || '',
      el.getAttribute('data-testid') || '',
      el.getAttribute('data-test') || '',
      el.getAttribute('class') || '',
      el.id || '',
    ].join(' ').toLowerCase();
    const locationPattern = new RegExp(
      [
        'location', 'locality', 'address', 'area', 'city', 'pincode',
        'pin code', 'deliver', 'select', 'nearby', 'bangalore',
        'bengaluru', 'chandapura',
      ].join('|')
    );
    return locationPattern.test(hay);
  }

  function addCandidate(el, source) {
    if (!el || seen.has(el)) return;
    const rect = visibleRect(el);
    if (!rect) return;
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role') || '';
    const text = textOf(el);
    const low = text.toLowerCase();
    const ariaLow = (el.getAttribute('aria-label') || '').toLowerCase();
    const style = getComputedStyle(el);
    const clickable =
      style.cursor === 'pointer' || !!el.onclick || role === 'option' ||
      role === 'listitem' || role === 'button' || role === 'link' ||
      tag === 'button' || tag === 'a' || tag === 'li' ||
      ['submit', 'button', 'checkbox', 'radio'].includes(el.getAttribute('type') || '') ||
      el.getAttribute('tabindex') || el.classList.contains('a-button') ||
      el.classList.contains('a-button-input') || el.classList.contains('a-button-text');
    const locationish = looksLikeLocationOption(el, text);
    const commerceCta = /add\s+to\s+(cart|basket|bag)|add\s+item|buy\s+again/i.test(
      [
        text,
        el.value || '',
        el.getAttribute('aria-label') || '',
        el.getAttribute('name') || '',
        el.getAttribute('data-action') || '',
      ].join(' ')
    );
    const compactReadable =
      text.length >= 3 && text.length <= 260 && rect.height >= 16 &&
      rect.height <= 150 && rect.width <= 900;
    const genericLandmark =
      ['main', 'banner', 'navigation', 'complementary', 'contentinfo'].includes(role) ||
      ['main content', 'skip to main content', 'results', 'search results'].includes(low) ||
      ['main content', 'skip to main content', 'results', 'search results'].includes(ariaLow);

    if (genericLandmark && rect.width > 500 && rect.height > 250) return;
    if (source === 'hint' && !clickable && !commerceCta && !(locationish && compactReadable)) {
      return;
    }
    seen.add(el);
    candidates.push({ el, rect, text });
  }

  Array.from(document.querySelectorAll(BASE_SEL)).forEach((el) => addCandidate(el, 'base'));
  Array.from(document.querySelectorAll('body *')).forEach((el) => addCandidate(el, 'hint'));

  let i = 0;
  for (const item of candidates) {
    const el = item.el;
    const rect = item.rect;
    const text = item.text;
    const ref = 'e' + i;
    el.setAttribute('data-argus-ref', ref);
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role') || '';
    const type = el.getAttribute('type') || '';
    const isPw = type === 'password';
    const aria = el.getAttribute('aria-label') || '';
    const valueLabel = isPw ? '' : (el.value || el.getAttribute('value') || '');
    const buttonish = tag === 'button' || role === 'button' ||
      ['submit', 'button'].includes(type) ||
      el.classList.contains('a-button') || el.classList.contains('a-button-input') ||
      el.classList.contains('a-button-text');
    // Never surface a password's value into the snapshot text.
    const name = (buttonish
      ? (
        aria || text || valueLabel || el.getAttribute('title') ||
        el.getAttribute('placeholder') || el.getAttribute('name') || ''
      )
      : (
        aria || el.getAttribute('placeholder') || el.getAttribute('title') ||
        el.getAttribute('name') || text || valueLabel || ''
      )
    ).slice(0, 120);
    out.push({
      ref,
      tag,
      type,
      role,
      name,
      placeholder: el.getAttribute('placeholder') || '',
      href: el.getAttribute('href') || '',
      editable: ['input', 'textarea'].includes(tag) ||
        el.getAttribute('contenteditable') === 'true',
      filled: !!(el.value && String(el.value).trim().length),
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      text: text.slice(0, 160),
      rect: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.width),
        h: Math.round(rect.height),
        cx: Math.round(rect.x + rect.width / 2),
        cy: Math.round(rect.y + rect.height / 2),
      },
    });
    i++;
    if (i >= 220) break;
  }
  return out;
}
"""


# Resolve the real navigable destination of a clicked element: the nearest <a> in
# (self / ancestor / descendant) with a genuine http(s) or relative href. Returns
# the absolute URL so the adapter can navigate straight there — far more reliable
# than clicking for plain "Continue"/"Next" links. Returns null for javascript:/#/
# mailto:/tel: (those have no destination to go to — they must be triggered).
_RESOLVE_HREF_JS = r"""
(el) => {
  let a = null;
  if (el.tagName === 'A' && el.getAttribute('href')) a = el;
  if (!a && el.closest) a = el.closest('a[href]');
  if (!a && el.querySelector) a = el.querySelector('a[href]');
  if (!a) return null;
  const raw = (a.getAttribute('href') || '').trim();
  const low = raw.toLowerCase();
  if (!raw || low === '#' || low.startsWith('#') || low.startsWith('javascript:') ||
      low.startsWith('mailto:') || low.startsWith('tel:')) return null;
  try { return a.href; } catch (e) { return null; }
}
"""

# Last-resort activation run inside the page when synthetic clicks don't trigger
# the element's real action. Resolves the nearest actionable control first (so a
# wrapper ref still works), then dispatches a full pointer/mouse event sequence,
# follows javascript:/__doPostBack hrefs, and submits the owning form — the cases
# a plain click misses on JS portals.
_ACTIVATE_JS = r"""
(el) => {
  const SEL = 'a,button,input,[role=button],[onclick],.a-button,.a-button-input';
  let t = (el.matches && el.matches(SEL)) ? el : null;
  if (!t && el.closest) t = el.closest(SEL);
  if (!t && el.querySelector) t = el.querySelector(SEL);
  if (!t) t = el;
  try { t.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
  try {
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      const Ctor = type.startsWith('pointer') ? PointerEvent : MouseEvent;
      t.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
    }
  } catch (e) {
    try { t.click(); } catch (e2) {}
  }
  const href = t.getAttribute && t.getAttribute('href');
  if (href && href.trim().toLowerCase().startsWith('javascript:')) {
    try { (0, eval)(href.trim().slice(11)); } catch (e) {}
  }
  const itype = (t.getAttribute && (t.getAttribute('type') || '')).toLowerCase();
  const tag = t.tagName ? t.tagName.toLowerCase() : '';
  if (itype === 'submit' || tag === 'button' || tag === 'input') {
    const form = t.form || (t.closest && t.closest('form'));
    if (form) {
      try { form.requestSubmit ? form.requestSubmit(itype === 'submit' ? t : undefined) : form.submit(); }
      catch (e) {}
    }
  }
}
"""


@dataclass
class Snapshot:
    url: str
    title: str
    elements: list[dict[str, Any]] = field(default_factory=list)

    def digest(self, limit: int = 60) -> str:
        """Compact, LLM-friendly listing of interactive elements."""
        lines = [f"URL: {self.url}", f"Title: {self.title}", "Interactive elements:"]
        for el in self.elements[:limit]:
            label = el.get("name") or el.get("placeholder") or el.get("text") or el.get("href") or ""
            kind = el.get("type") or el.get("role") or el.get("tag")
            edit = " [editable]" if el.get("editable") else ""
            filled = " [filled]" if el.get("filled") else ""
            disabled = " [disabled]" if el.get("disabled") else ""
            rect = el.get("rect") or {}
            where = ""
            if rect:
                where = f' @({rect.get("cx")},{rect.get("cy")}) {rect.get("w")}x{rect.get("h")}'
            lines.append(
                f'  {el["ref"]}: <{kind}> {label}{edit}{filled}{disabled}{where}'.rstrip()
            )
        return "\n".join(lines)


class AgentBrowserAdapter:
    layer = Layer.AGENT_BROWSER

    def __init__(self, controller) -> None:  # PlaywrightController
        self._c = controller

    async def goto(self, url: str) -> str:
        return await self._c.goto(url)

    async def snapshot(self) -> Snapshot:
        page = self._c.page
        try:
            elements = await page.evaluate(_SNAPSHOT_JS)
        except Exception as exc:  # noqa: BLE001
            log.warning("snapshot eval failed: %s", exc)
            elements = []
        title = ""
        try:
            title = await page.title()
        except Exception:  # noqa: BLE001
            pass
        return Snapshot(url=page.url, title=title, elements=elements or [])

    async def page_text(self, limit: int = 5000) -> str:
        """Visible text of the current page (innerText).

        The snapshot only lists interactive controls, so this is how the loop
        actually reads page CONTENT — tables, marks, totals, statuses — to find
        and verify the answer instead of clicking blindly past it."""
        page = self._c.page
        try:
            text = await page.evaluate(
                "() => (document.body && document.body.innerText) "
                "? document.body.innerText : ''"
            )
        except Exception as exc:  # noqa: BLE001
            log.info("page_text eval failed: %s", exc)
            return ""
        return (text or "").strip()[:limit]

    async def _follow_href_if_stuck(self, loc, before_url: str) -> None:
        """After a click, if we're still on the same URL but the element is a real
        link, navigate straight to its destination. This is what gets "Continue"/
        "Next" anchors that swallow clicks to actually move the page. No-ops for
        postback/button controls (they have no destination to go to)."""
        page = self._c.page
        try:
            if page.url != before_url:
                return
            href = await loc.evaluate(_RESOLVE_HREF_JS)
            if href and href != page.url:
                log.info("click had no effect; following link to %s", href)
                await self._c.goto(href)
                await self._after_action()
        except Exception as exc:  # noqa: BLE001
            log.info("href follow skipped: %s", exc)

    async def click(self, ref: str) -> bool:
        sel = f'[data-argus-ref="{ref}"]'
        page = self._c.page
        loc = page.locator(sel).first
        before_url = page.url

        # 1) Trusted Playwright click (real input events; best for most sites).
        try:
            await loc.click(timeout=8_000)
            await self._after_action()
            await self._follow_href_if_stuck(loc, before_url)
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("dom click failed on %s: %s", ref, exc)

        # 2) Forced trusted click — bypasses actionability checks when the element
        #    is briefly overlapped or deemed unstable but is the real target.
        try:
            await loc.click(timeout=4_000, force=True)
            await self._after_action()
            await self._follow_href_if_stuck(loc, before_url)
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("forced click failed on %s: %s", ref, exc)

        # 3) Mouse click at the element centre (defeats transparent overlays).
        try:
            box = await loc.bounding_box(timeout=2_000)
            if box:
                await page.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
                await self._after_action()
                await self._follow_href_if_stuck(loc, before_url)
                return True
        except Exception as exc:  # noqa: BLE001
            log.info("center click failed on %s: %s", ref, exc)

        # 4) Run the element's own activation in the page (ASP.NET __doPostBack,
        #    javascript: hrefs, form submits), then follow a real link if it's
        #    still stuck — the last-resort path for buttons a click won't fire.
        try:
            await loc.evaluate(_ACTIVATE_JS)
            await self._after_action()
            await self._follow_href_if_stuck(loc, before_url)
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("js activate failed on %s: %s", ref, exc)

        # 5) Even if every click strategy raised, a real link can still be reached.
        try:
            href = await loc.evaluate(_RESOLVE_HREF_JS)
            if href:
                await self._c.goto(href)
                await self._after_action()
                return True
        except Exception as exc:  # noqa: BLE001
            log.info("href-follow failed on %s: %s", ref, exc)
        return False

    async def type_text(self, ref: str, text: str) -> bool:
        sel = f'[data-argus-ref="{ref}"]'
        page = self._c.page
        loc = page.locator(sel).first
        # Rich composers (WhatsApp, Slack, etc.) are contenteditable editors that
        # ignore a bulk fill, and char-by-char typing mangles emoji. insert_text
        # sends the whole string in one input event — emoji-safe and it fires the
        # input handlers these editors need so the send button activates.
        try:
            is_contenteditable = await loc.evaluate("(el) => el.isContentEditable === true")
        except Exception:  # noqa: BLE001
            is_contenteditable = False
        if is_contenteditable:
            try:
                await loc.click(timeout=8_000)
            except Exception:  # noqa: BLE001
                pass
            try:
                await loc.fill("")  # clear any residual text where supported
            except Exception:  # noqa: BLE001
                pass
            try:
                await page.keyboard.insert_text(text)
                return True
            except Exception as exc:  # noqa: BLE001
                log.info("insert_text failed on %s: %s", ref, exc)
            try:
                await loc.press_sequentially(text, delay=15)
                return True
            except Exception as exc:  # noqa: BLE001
                log.info("press_sequentially failed on %s: %s", ref, exc)
        try:
            await page.fill(sel, text, timeout=10_000)
            # Frameworks (React/Angular/Vue) often only commit a value when they
            # see native input/change events — nudge them so the field "sticks".
            try:
                await loc.evaluate(
                    "(el) => { el.dispatchEvent(new Event('input', {bubbles:true}));"
                    " el.dispatchEvent(new Event('change', {bubbles:true})); }"
                )
            except Exception:  # noqa: BLE001
                pass
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("type failed on %s: %s", ref, exc)
            return False

    async def select(self, ref: str, value: str) -> bool:
        sel = f'[data-argus-ref="{ref}"]'
        page = self._c.page
        try:
            await page.select_option(sel, label=value, timeout=10_000)
            return True
        except Exception:  # noqa: BLE001
            try:
                await page.select_option(sel, value=value, timeout=10_000)
                return True
            except Exception as exc:  # noqa: BLE001
                log.info("select failed on %s: %s", ref, exc)
                return False

    async def press(self, key: str) -> bool:
        try:
            await self._c.page.keyboard.press(key)
            return True
        except Exception:  # noqa: BLE001
            return False

    async def scroll(self, direction: str = "down", amount: int = 650) -> bool:
        try:
            dy = abs(int(amount or 650))
        except (TypeError, ValueError):
            dy = 650
        if str(direction or "down").lower() == "up":
            dy = -dy
        try:
            await self._c.page.mouse.wheel(0, dy)
            await self._c.page.wait_for_timeout(300)
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("scroll failed: %s", exc)
            return False

    async def wait(self, ms: int = 1000) -> bool:
        try:
            await self._c.page.wait_for_timeout(max(100, min(int(ms or 1000), 5000)))
            return True
        except Exception:  # noqa: BLE001
            return False

    async def _after_action(self) -> None:
        page = self._c.page
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=8_000)
        except Exception:  # noqa: BLE001
            pass
        try:
            await page.wait_for_timeout(300)
        except Exception:  # noqa: BLE001
            pass

    async def _do(self, selector: str, action: str) -> bool:
        page = self._c.page
        try:
            locator = page.locator(selector).first
            await getattr(locator, action)(timeout=10_000)
            await self._after_action()
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("%s failed on %s: %s", action, selector, exc)
            return False

    async def close(self) -> None:
        return None
