"""Agent-Reach read adapter — platform-aware L1 reads with fallbacks.

Follows Agent-Reach's philosophy (github.com/Panniantong/Agent-Reach): route
each read to the most reliable upstream tool for that platform instead of
scraping everything the same way. Used as an upgrade over plain Scrapling for
read/search steps; the Recovery ladder escalates past it exactly like any L1.

Routing (first working wins):
- youtube.com / youtu.be  → yt-dlp metadata + subtitles (if installed)
- github.com              → gh CLI (if installed and authed)
- anything else           → Jina Reader (https://r.jina.ai/<url>, no key needed)

Import-safe and dependency-tolerant: missing tools simply mean the route is
skipped. Install Agent-Reach itself (`agent-reach install`) to unlock cookie-
backed platforms (Twitter/X, Reddit, …); its `doctor` output tells you what is
live.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from urllib.parse import urlparse

import httpx

from integrations.base import Layer, StepInput, StepResult

log = logging.getLogger(__name__)

JINA_READER = "https://r.jina.ai/"
READ_TIMEOUT_S = 45.0
SUBPROCESS_TIMEOUT_S = 60.0
MAX_TEXT = 20_000


def _host(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower()
    except ValueError:
        return ""


async def _run_cli(*argv: str) -> str | None:
    """Run one CLI read; None when the tool is missing or fails."""
    if shutil.which(argv[0]) is None:
        return None
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        out, _ = await asyncio.wait_for(proc.communicate(), SUBPROCESS_TIMEOUT_S)
    except (OSError, asyncio.TimeoutError):
        return None
    if proc.returncode != 0 or not out:
        return None
    return out.decode("utf-8", errors="replace")


class AgentReachAdapter:
    layer = Layer.SCRAPLING  # same rung of the ladder as the HTTP read layer

    async def _read_youtube(self, url: str) -> str | None:
        raw = await _run_cli("yt-dlp", "--dump-json", "--no-download", url)
        if raw is None:
            return None
        try:
            meta = json.loads(raw.splitlines()[0])
        except (ValueError, IndexError):
            return None
        parts = [
            f"Title: {meta.get('title', '')}",
            f"Channel: {meta.get('channel', meta.get('uploader', ''))}",
            f"Duration: {meta.get('duration_string', meta.get('duration', ''))}",
            f"Views: {meta.get('view_count', '')}",
            "",
            meta.get("description") or "",
        ]
        return "\n".join(str(p) for p in parts)

    async def _read_github(self, url: str) -> str | None:
        path = urlparse(url).path.strip("/")
        segs = path.split("/")
        if len(segs) < 2:
            return None
        repo = f"{segs[0]}/{segs[1]}"
        return await _run_cli("gh", "repo", "view", repo)

    async def _read_jina(self, url: str) -> str | None:
        try:
            async with httpx.AsyncClient(
                timeout=READ_TIMEOUT_S, follow_redirects=True
            ) as client:
                resp = await client.get(f"{JINA_READER}{url}")
        except httpx.HTTPError as exc:
            log.info("jina read failed for %s: %s", url, exc)
            return None
        if resp.status_code != 200 or not resp.text.strip():
            return None
        return resp.text

    async def run(self, step: StepInput) -> StepResult:
        url = (step.url or "").strip()
        if not url:
            return StepResult(
                ok=False,
                confidence=0.0,
                layer=self.layer,
                error="agent-reach read needs a URL",
            )

        host = _host(url)
        text: str | None = None
        route = "jina"

        if "youtube.com" in host or "youtu.be" in host:
            text = await self._read_youtube(url)
            route = "yt-dlp"
        elif host.endswith("github.com"):
            text = await self._read_github(url)
            route = "gh"

        if text is None:
            text = await self._read_jina(url)
            route = "jina" if text is not None else route

        if text is None:
            return StepResult(
                ok=False,
                confidence=0.1,
                layer=self.layer,
                error=f"all read routes failed for {url}",
            )

        return StepResult(
            ok=True,
            confidence=0.8,
            layer=self.layer,
            observed={"url": url, "route": route, "text": text[:MAX_TEXT]},
        )

    async def close(self) -> None:
        return None
