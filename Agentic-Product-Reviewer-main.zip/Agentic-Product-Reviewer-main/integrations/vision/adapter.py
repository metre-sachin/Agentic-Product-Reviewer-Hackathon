"""Vision adapter — L4 last-resort visual reasoning.

When structured interaction (L2) and the autonomous agent (L3) both stall, the
vision layer looks at an actual screenshot the way a person would and decides the
next action: click a labelled element by ref, click a pixel location, type text,
or give up. Execution is still performed through the Agent Browser adapter /
Playwright controller, so vision reasons but the structured layer acts.
"""

from __future__ import annotations

import base64
import logging

from integrations.base import Layer

log = logging.getLogger(__name__)

VISION_SYSTEM = """You are Argus's vision fallback. You see a screenshot of a web page
(viewport 1280x800) plus a list of interactive elements already tagged with refs
like e3. Decide the single next action to advance the step. Output strict JSON:

{
  "action": "click" | "type" | "scroll" | "wait" | "done" | "give_up",
  "ref": "element ref to act on, if one matches",
  "x": number, "y": number,   // pixel coords to click when no ref matches
  "text": "text to type (for type)",
  "direction": "up | down for scroll",
  "amount": "scroll pixels or wait milliseconds",
  "observation": "for done: what was accomplished",
  "confidence": 0.0-1.0,
  "thought": "one short sentence"
}

Rules:
- Prefer acting on a labelled ref. Only use x/y pixel coords when nothing in the
  list matches what you see.
- For shopping/product pages, click the exact visible "Add to cart", "Add to
  basket", or "Add to bag" button. Do not click product photos, product cards,
  page background, or "Main content". If the user asked for the first/selected
  item, use the first visible matching add-to-cart button in the main results.
- Do not repeat actions listed as failed or no-progress in the recent history.
- Use scroll if the next needed control is likely outside the viewport.
- For delivery/location pickers: if a manual list of location suggestions is
  visible, click the first/highest matching suggestion. Do not keep clicking
  "Detect my location" after permission is denied or unavailable.
- Messaging apps: write into the composer at the BOTTOM of the open chat
  ("Type a message"), never the search box at the top. To send, click ONLY the
  send / paper-plane button just to the right of the composer — never the
  emoji/sticker, attach/clip, camera, or voice/microphone icons.
- NEVER type personal or sensitive data into a field from the task text, context,
  memory, or a guess — full name, username, email, phone number, address, date of
  birth, password, or payment card details. If an empty field like that must be
  filled to proceed, return "give_up" (the user is asked to provide it).
- NEVER click anything that pays, checks out, places an order, confirms a
  booking, submits an application, or sends a message. Return "give_up" if that
  is the only way forward (a human will be asked).
- When the screenshot already shows the information the step needs (marks, a
  table, totals, a status, values), READ it and return "done" with the SPECIFIC
  facts in "observation" — quote the actual numbers and labels, not a vague
  "completed". Do not move past a page that already shows the answer.
- Return "done" the moment the step's goal is visibly satisfied.
"""


class VisionAdapter:
    layer = Layer.VISION

    def __init__(self, *, model: str = "gpt-4o-mini", api_key: str = "") -> None:
        self._model = model
        self._api_key = api_key

    @property
    def available(self) -> bool:
        return bool(self._api_key)

    async def decide(
        self,
        image_bytes: bytes,
        *,
        goal: str,
        step_label: str,
        elements_digest: str,
        history: list[str] | None = None,
    ) -> dict:
        if not self.available:
            return {"action": "give_up", "confidence": 0.0, "thought": "no API key"}
        from app.services.llm import complete_json_vision

        b64 = base64.b64encode(image_bytes).decode()
        user = (
            f"Task goal: {goal}\nCurrent step: {step_label}\n\n"
            f"Interactive elements:\n{elements_digest}\n\n"
            + (
                "Recent vision history:\n"
                + "\n".join(f"- {h}" for h in history[-6:])
                + "\n\n"
                if history
                else ""
            )
            + "Look at the screenshot and return the next action JSON."
        )
        try:
            return await complete_json_vision(
                system=VISION_SYSTEM, user=user, image_b64=b64, model=self._model,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("vision decide failed: %s", exc)
            return {"action": "give_up", "confidence": 0.0, "thought": str(exc)[:120]}
