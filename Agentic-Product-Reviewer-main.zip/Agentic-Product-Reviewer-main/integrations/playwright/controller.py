"""Shared Playwright controller.

Owns the chromium lifecycle for one task. Other adapters borrow the Page from
here so we never spawn two browsers for one task. Persists storage state so a
reopened task resumes logged-in, and writes screenshots to a media directory
the backend serves statically.

Import-safe: Playwright is imported lazily. If it (or the browser binary) is
missing, `start()` raises a clear error the caller turns into graceful
degradation.
"""

from __future__ import annotations

import logging
import pathlib
import socket
from typing import Any

log = logging.getLogger(__name__)


def _free_port() -> int:
    """Reserve a free local TCP port for the browser's CDP endpoint."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()

# Launch flags that strip the most common automation signatures. Notably we drop
# Chromium's default `--enable-automation` switch (which sets navigator.webdriver
# and shows the "controlled by automation" banner) and disable the blink feature
# that re-adds the webdriver flag.
_STEALTH_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-infobars",
]

# Runs in every page/frame before site scripts. Masks the remaining tells that a
# launch flag can't: navigator.webdriver, the missing chrome runtime, empty
# plugin/language lists, and the headless permissions quirk.
_STEALTH_JS = r"""
(() => {
  try { Object.defineProperty(navigator, 'webdriver', { get: () => undefined }); } catch (e) {}
  if (!window.chrome) { window.chrome = { runtime: {} }; }
  try { Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] }); } catch (e) {}
  try { Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] }); } catch (e) {}
  try {
    const q = window.navigator.permissions && window.navigator.permissions.query;
    if (q) {
      window.navigator.permissions.query = (p) =>
        p && p.name === 'notifications'
          ? Promise.resolve({ state: Notification.permission })
          : q(p);
    }
  } catch (e) {}
})();
"""


# Pulls the rendered page's text, title, and links for the reading layer.
_READ_JS = r"""
() => {
  const text = (document.body && document.body.innerText) ? document.body.innerText : '';
  const links = Array.from(document.querySelectorAll('a[href]')).slice(0, 200).map((a) => ({
    href: a.href,
    text: (a.innerText || '').trim().slice(0, 120),
  }));
  return { title: document.title || '', text, links };
}
"""


class PlaywrightController:
    def __init__(
        self,
        media_dir: pathlib.Path,
        *,
        headless: bool = True,
        channel: str | None = None,
        locale: str = "en-US",
        timezone: str = "UTC",
        proxy: str | None = None,
    ) -> None:
        self._media_dir = media_dir
        self._headless = headless
        self._channel = channel or None
        self._locale = locale
        self._timezone = timezone
        self._proxy = proxy or None
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None
        self._shot_seq = 0
        self._cdp_url: str | None = None

    @property
    def started(self) -> bool:
        return self._page is not None

    @property
    def cdp_url(self) -> str | None:
        """HTTP CDP endpoint of the running browser, so another tool (Browser Use)
        can attach to THIS browser/page instead of launching its own."""
        return self._cdp_url

    async def _launch(self):
        """Launch real Chrome when available (best anti-bot evasion), else fall
        back to bundled chromium. Both run with automation flags stripped and a
        remote-debugging port so Browser Use can attach to the same browser."""
        port = _free_port()
        args = [
            *_STEALTH_ARGS,
            f"--remote-debugging-port={port}",
            "--remote-debugging-address=127.0.0.1",
        ]
        kwargs: dict[str, Any] = dict(
            headless=self._headless,
            args=args,
            ignore_default_args=["--enable-automation"],
        )
        if self._proxy:
            kwargs["proxy"] = {"server": self._proxy}
        browser = None
        if self._channel:
            try:
                browser = await self._pw.chromium.launch(channel=self._channel, **kwargs)
            except Exception as exc:  # noqa: BLE001
                log.warning(
                    "browser channel %r unavailable (%s); using bundled chromium",
                    self._channel, exc,
                )
        if browser is None:
            browser = await self._pw.chromium.launch(**kwargs)
        self._cdp_url = f"http://127.0.0.1:{port}"
        return browser

    async def _clean_user_agent(self) -> str | None:
        """The browser's own UA with the headless marker removed.

        Headless Chromium reports `HeadlessChrome/<v>` — a giveaway. We strip the
        "Headless" token but keep the real version and platform, so the UA stays
        consistent with the client-hint headers the browser sends (overriding only
        the version, as the old code did, is what got flagged). Returns None when
        the UA is already clean (headed mode) so the native UA is used as-is.
        """
        try:
            tmp = await self._browser.new_context()
            try:
                page = await tmp.new_page()
                ua = await page.evaluate("navigator.userAgent")
            finally:
                await tmp.close()
            if ua and "Headless" in ua:
                return ua.replace("HeadlessChrome", "Chrome").replace("Headless", "")
        except Exception as exc:  # noqa: BLE001
            log.info("could not resolve a clean user agent: %s", exc)
        return None

    async def start(self, storage_state: dict | None = None) -> None:
        from playwright.async_api import async_playwright  # lazy

        self._pw = await async_playwright().start()
        self._browser = await self._launch()
        user_agent = await self._clean_user_agent()
        ctx_kwargs: dict[str, Any] = dict(
            storage_state=storage_state or None,
            viewport={"width": 1280, "height": 800},
            locale=self._locale,
            timezone_id=self._timezone,
            extra_http_headers={"Accept-Language": f"{self._locale},en;q=0.9"},
        )
        if user_agent:
            ctx_kwargs["user_agent"] = user_agent
        self._context = await self._browser.new_context(**ctx_kwargs)
        await self._context.add_init_script(_STEALTH_JS)
        self._page = await self._context.new_page()

    @property
    def page(self):
        if self._page is None:
            raise RuntimeError("PlaywrightController not started")
        return self._page

    async def goto(self, url: str, *, wait_until: str = "domcontentloaded") -> str:
        await self.page.goto(url, wait_until=wait_until, timeout=45_000)
        return self.page.url

    async def current_url(self) -> str:
        return self.page.url if self._page else ""

    async def read(self, url: str) -> dict | None:
        """Navigate with the real browser and return {url,title,text,links}.

        Real Chrome renders JS and passes bot-checks that block plain HTTP
        fetches (search-engine challenges, Cloudflare, etc.), so this is the
        reliable way to actually read a page. Returns None if nothing usable.
        """
        if self._page is None:
            return None
        try:
            await self.goto(url)
            try:
                await self._page.wait_for_load_state("networkidle", timeout=4000)
            except Exception:  # noqa: BLE001
                pass
            data = await self._page.evaluate(_READ_JS)
        except Exception as exc:  # noqa: BLE001
            log.info("browser read failed for %s: %s", url, exc)
            return None
        text = str(data.get("text") or "")[:9000]
        if not text.strip():
            return None
        return {
            "url": self._page.url,
            "title": str(data.get("title") or "")[:200],
            "text": text,
            "links": data.get("links") or [],
        }

    async def search_serp(self, query: str) -> dict | None:
        """Run a web search in the real browser and return the results page
        (text + result links) for the caller to rank and follow."""
        from urllib.parse import quote_plus

        return await self.read("https://html.duckduckgo.com/html/?q=" + quote_plus(query))

    async def screenshot(self, task_id: str) -> pathlib.Path | None:
        """Capture the viewport. Returns the file path, or None on failure."""
        if self._page is None:
            return None
        task_dir = self._media_dir / task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        self._shot_seq += 1
        path = task_dir / f"{self._shot_seq:04d}.png"
        try:
            await self._page.screenshot(path=str(path), full_page=False)
            return path
        except Exception as exc:  # noqa: BLE001
            log.warning("screenshot failed: %s", exc)
            return None

    async def screenshot_bytes(self) -> bytes | None:
        """Capture the viewport as PNG bytes (for vision reasoning)."""
        if self._page is None:
            return None
        try:
            return await self._page.screenshot(full_page=False)
        except Exception as exc:  # noqa: BLE001
            log.warning("screenshot_bytes failed: %s", exc)
            return None

    async def click_xy(self, x: float, y: float) -> bool:
        if self._page is None:
            return False
        try:
            await self._page.mouse.click(x, y)
            try:
                await self._page.wait_for_load_state("domcontentloaded", timeout=8_000)
            except Exception:  # noqa: BLE001
                pass
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("click_xy failed: %s", exc)
            return False

    async def storage_state(self) -> dict[str, Any]:
        if self._context is None:
            return {}
        try:
            return await self._context.storage_state()
        except Exception:  # noqa: BLE001
            return {}

    async def stop(self) -> None:
        for closer in (
            getattr(self._context, "close", None),
            getattr(self._browser, "close", None),
            getattr(self._pw, "stop", None),
        ):
            if closer is None:
                continue
            try:
                await closer()
            except Exception:  # noqa: BLE001
                pass
        self._page = self._context = self._browser = self._pw = None
        self._cdp_url = None
