"""Scrapling adapter — L1 reading layer with anti-bot evasion.

https://github.com/D4Vinci/Scrapling

Used first whenever a step only needs to *read* a page: search results,
listings, prices, schedules, availability. Cheapest and quietest layer.

Design notes:
- Scrapling (and its Playwright backend) is imported lazily so the backend
  boots even when the package or browser binaries are absent. If it can't run,
  `run()` returns ok=False so the Recovery agent escalates to the next layer.
- The adapter is version-defensive: Scrapling's extraction surface has shifted
  across releases, so text/link extraction tries several method names.
"""

from __future__ import annotations

import asyncio
import logging
from html.parser import HTMLParser
from urllib.parse import quote_plus, urljoin

from integrations.base import Layer, LayerAdapter, StepInput, StepResult

log = logging.getLogger(__name__)

# Keep extracted text cheap to feed back to the LLM.
MAX_TEXT_CHARS = 6000
MAX_LINKS = 40

# HTTP-only search fallback (used when no real browser is available). DuckDuckGo's
# HTML endpoint now serves a bot challenge to plain HTTP clients, so we use Mojeek,
# which still answers scrapers. The primary search path renders DuckDuckGo in real
# Chrome (see PlaywrightController.search_serp), which passes the challenge.
SEARCH_ENDPOINT = "https://www.mojeek.com/search?q={query}"


def _scrapling_available() -> bool:
    try:
        import scrapling  # noqa: F401

        return True
    except Exception:  # noqa: BLE001
        return False


async def _http_fetch(url: str):
    """Cheapest read: HTTP with TLS/header fingerprint impersonation.

    No browser process — fast and quiet. Good for static HTML and search-engine
    result pages. Returns an Adaptor-compatible object or raises.
    """
    from scrapling.fetchers import AsyncFetcher  # type: ignore

    # AsyncFetcher.get impersonates a real browser's TLS + headers (anti-bot).
    return await AsyncFetcher.get(url, stealthy_headers=True, timeout=30)


async def _browser_fetch(url: str, *, timeout_ms: int = 45_000):
    """Anti-bot browser read — heavier, used only when HTTP is blocked."""
    from scrapling.fetchers import StealthyFetcher  # type: ignore

    if hasattr(StealthyFetcher, "async_fetch"):
        return await StealthyFetcher.async_fetch(
            url, headless=True, network_idle=True, timeout=timeout_ms
        )
    return await asyncio.to_thread(
        StealthyFetcher.fetch, url, headless=True, network_idle=True, timeout=timeout_ms
    )


async def _async_fetch(url: str):
    """Try cheap HTTP first, escalate to the stealth browser if it fails."""
    try:
        page = await _http_fetch(url)
        # Some blockers return a 2xx page with no usable text; detect that.
        if _extract_text(page).strip():
            return page
    except Exception as exc:  # noqa: BLE001
        log.info("http fetch fell back to browser for %s: %s", url, exc)
    return await _browser_fetch(url)


# ---- plain-httpx fallback (always available; no Scrapling deps needed) ----

class _HTMLText(HTMLParser):
    """Minimal HTML -> text + title + links extractor using the stdlib."""

    _SKIP = {"script", "style", "noscript", "head", "svg"}

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.links: list[dict[str, str]] = []
        self.title = ""
        self._skip_depth = 0
        self._in_title = False
        self._href: str | None = None
        self._link_text: list[str] = []

    def handle_starttag(self, tag, attrs):  # noqa: ANN001
        if tag in self._SKIP:
            self._skip_depth += 1
        if tag == "title":
            self._in_title = True
        if tag == "a":
            self._href = dict(attrs).get("href")
            self._link_text = []

    def handle_endtag(self, tag):  # noqa: ANN001
        if tag in self._SKIP and self._skip_depth:
            self._skip_depth -= 1
        if tag == "title":
            self._in_title = False
        if tag == "a" and self._href:
            text = " ".join(self._link_text).strip()
            self.links.append({"href": self._href, "text": text[:120]})
            self._href = None

    def handle_data(self, data):  # noqa: ANN001
        if self._skip_depth:
            return
        text = data.strip()
        if not text:
            return
        if self._in_title:
            self.title += text
        else:
            self.parts.append(text)
        if self._href is not None:
            self._link_text.append(text)


async def _httpx_fetch(url: str) -> StepResult:
    import httpx

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml",
    }
    async with httpx.AsyncClient(timeout=20, follow_redirects=True, headers=headers) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        html = resp.text

    parser = _HTMLText()
    parser.feed(html)
    text = " ".join(parser.parts)[:MAX_TEXT_CHARS]
    links = [
        {"href": urljoin(url, l["href"]), "text": l["text"]}
        for l in parser.links
        if l["href"].startswith(("http", "/"))
    ][:MAX_LINKS]
    return StepResult(
        ok=bool(text),
        confidence=0.7 if text else 0.2,
        layer=Layer.SCRAPLING,
        observed={"url": str(resp.url), "title": parser.title[:200] or None, "text": text, "links": links},
        error=None if text else "no text extracted",
    )


def _extract_text(page) -> str:
    for attr in ("get_all_text", "get_text"):
        fn = getattr(page, attr, None)
        if callable(fn):
            try:
                text = fn()
                if text:
                    return str(text)[:MAX_TEXT_CHARS]
            except Exception:  # noqa: BLE001
                continue
    # Fallback: body text via CSS.
    try:
        node = page.css_first("body")
        if node is not None:
            text = getattr(node, "text", None) or str(node)
            return str(text)[:MAX_TEXT_CHARS]
    except Exception:  # noqa: BLE001
        pass
    return ""


def _extract_title(page) -> str | None:
    try:
        node = page.css_first("title::text") or page.css_first("title")
        if node is None:
            return None
        return str(getattr(node, "text", node)).strip()[:200]
    except Exception:  # noqa: BLE001
        return None


def _extract_links(page, base_url: str) -> list[dict[str, str]]:
    links: list[dict[str, str]] = []
    try:
        anchors = page.css("a")
    except Exception:  # noqa: BLE001
        return links
    for a in anchors or []:
        try:
            href = a.attrib.get("href") if hasattr(a, "attrib") else a.get("href")
            text = (getattr(a, "text", "") or "").strip()
        except Exception:  # noqa: BLE001
            continue
        if not href:
            continue
        absolute = urljoin(base_url, href)
        if absolute.startswith("http"):
            links.append({"href": absolute, "text": text[:120]})
        if len(links) >= MAX_LINKS:
            break
    return links


class ScraplingAdapter:
    layer = Layer.SCRAPLING

    def __init__(self) -> None:
        self._available: bool | None = None

    @property
    def available(self) -> bool:
        # Reading is always available: Scrapling when its deps are present,
        # otherwise a plain-httpx fallback. So L1 never silently disappears.
        return True

    async def fetch(self, url: str) -> StepResult:
        # 1. Preferred: Scrapling (stealth HTTP, then stealth browser).
        if _scrapling_available():
            try:
                page = await _async_fetch(url)
                text = _extract_text(page)
                if text:
                    return StepResult(
                        ok=True, confidence=0.85, layer=self.layer,
                        observed={
                            "url": url,
                            "title": _extract_title(page),
                            "text": text,
                            "links": _extract_links(page, url),
                        },
                    )
            except Exception as exc:  # noqa: BLE001
                log.info("scrapling fetch failed for %s, falling back to httpx: %s", url, exc)

        # 2. Fallback: plain httpx (always works, basic extraction).
        try:
            return await _httpx_fetch(url)
        except Exception as exc:  # noqa: BLE001
            log.warning("httpx fetch failed for %s: %s", url, exc)
            return StepResult(
                ok=False, confidence=0.0, layer=self.layer, error=f"fetch failed: {exc}",
            )

    async def search(self, query: str) -> StepResult:
        url = SEARCH_ENDPOINT.format(query=quote_plus(query))
        result = await self.fetch(url)
        if result.ok:
            result.observed["query"] = query
        return result

    async def run(self, step: StepInput) -> StepResult:
        if step.url:
            return await self.fetch(step.url)
        return await self.search(step.goal)

    async def close(self) -> None:
        return None


_: LayerAdapter = ScraplingAdapter()  # type-check the contract at import
