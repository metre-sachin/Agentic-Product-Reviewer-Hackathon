"""Shared contracts for execution layers.

Every layer adapter (Scrapling, Agent Browser, Browser Use, Vision) returns a
StepResult so the Recovery Agent can decide whether to escalate.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol


class Layer(str, Enum):
    SCRAPLING = "scrapling"
    AGENT_BROWSER = "agent_browser"
    BROWSER_USE = "browser_use"
    VISION = "vision"
    HUMAN = "human"


@dataclass
class StepInput:
    """One unit of work handed to an adapter."""
    goal: str                       # natural-language intent for this step
    url: str | None = None
    selector_hint: str | None = None
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class StepResult:
    ok: bool
    confidence: float               # 0.0-1.0
    layer: Layer
    observed: dict[str, Any] = field(default_factory=dict)   # extracted data, URLs, etc.
    screenshot_url: str | None = None
    error: str | None = None


class LayerAdapter(Protocol):
    layer: Layer

    async def run(self, step: StepInput) -> StepResult: ...
    async def close(self) -> None: ...
