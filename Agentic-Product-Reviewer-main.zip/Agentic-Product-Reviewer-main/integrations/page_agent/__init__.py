from integrations.page_agent.adapter import V2BrowserAdapter

__all__ = ["V2BrowserAdapter"]
