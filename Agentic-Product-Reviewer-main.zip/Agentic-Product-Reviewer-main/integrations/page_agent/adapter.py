"""Argus v2 adapter — drives the user's real browser through the page-agent
engine (Argus extension or bookmarklet) instead of a server-side Playwright
Chromium.

It exposes the SAME method surface as `AgentBrowserAdapter`
(goto/snapshot/page_text/click/type_text/select/press/scroll/wait/close) and
returns the SAME `Snapshot` shape, so the executor loop, recovery ladder, and
approval gate drive it with no changes — the architecture's "adapters are
interchangeable" promise, realised over a WebSocket.

The clicking/typing quality upgrade lives in the browser: primitives are
executed by page-agent's PageController (browser-use-derived DOM extraction,
W3C-spec event sequences, native value setters, framework patches), so buttons
and forms that defeated the old snapshot JS now work.

It also adds `run_goal()`: delegate one whole step goal to the in-browser Argus
agent (the page-agent ReAct micro-loop with backend-proxied LLM calls) and get a
StepResult back — the smarter, fewer-round-trips mode.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from integrations.agent_browser.adapter import Snapshot
from integrations.base import Layer, StepInput, StepResult

if TYPE_CHECKING:
    from app.services.v2_hub import V2Connection

log = logging.getLogger(__name__)


class V2BrowserAdapter:
    # Same layer label as the structured DOM adapter, so recovery/telemetry treat
    # a v2-driven step identically to an Agent-Browser step.
    layer = Layer.AGENT_BROWSER

    def __init__(self, conn: "V2Connection") -> None:
        self._conn = conn

    async def _act(self, kind: str, **params) -> dict:
        try:
            return await self._conn.send_action({"kind": kind, **params})
        except Exception as exc:  # noqa: BLE001 — surface as a failed action, not a crash
            log.warning("v2 action %s failed: %s", kind, exc)
            return {"ok": False, "error": str(exc)}

    # ---- AgentBrowserAdapter-compatible surface ----

    async def goto(self, url: str) -> str:
        r = await self._act("navigate", url=url)
        return r.get("url") or url

    async def snapshot(self) -> Snapshot:
        r = await self._act("snapshot")
        snap = r.get("snapshot") or {}
        return Snapshot(
            url=snap.get("url", ""),
            title=snap.get("title", ""),
            elements=snap.get("elements") or [],
        )

    async def page_text(self, limit: int = 5000) -> str:
        r = await self._act("page_text", limit=limit)
        return (r.get("text") or "").strip()[:limit]

    async def click(self, ref: str) -> bool:
        r = await self._act("click", ref=ref)
        return bool(r.get("ok"))

    async def type_text(self, ref: str, text: str) -> bool:
        r = await self._act("type", ref=ref, text=text)
        return bool(r.get("ok"))

    async def select(self, ref: str, value: str) -> bool:
        r = await self._act("select", ref=ref, value=value)
        return bool(r.get("ok"))

    async def press(self, key: str) -> bool:
        r = await self._act("press", key=key)
        return bool(r.get("ok"))

    async def scroll(self, direction: str = "down", amount: int = 650) -> bool:
        r = await self._act("scroll", direction=direction, amount=amount)
        return bool(r.get("ok"))

    async def wait(self, ms: int = 1000) -> bool:
        r = await self._act("wait", ms=ms)
        return bool(r.get("ok"))

    async def screenshot_bytes(self) -> bytes | None:
        """Viewport PNG from the real browser (for vision recovery / preview)."""
        import base64

        r = await self._act("screenshot")
        data_url = r.get("dataUrl") or ""
        if not data_url.startswith("data:image"):
            return None
        try:
            return base64.b64decode(data_url.split(",", 1)[1])
        except Exception:  # noqa: BLE001
            return None

    async def current_url(self) -> str:
        r = await self._act("page_info")
        return r.get("url") or ""

    # ---- goal mode ----

    async def run_goal(self, step: StepInput) -> StepResult:
        """Delegate one step goal to the in-browser Argus agent."""
        try:
            result = await self._conn.execute_goal(step.goal, {"url": step.url})
        except Exception as exc:  # noqa: BLE001
            return StepResult(
                ok=False, confidence=0.0, layer=self.layer, error=str(exc)
            )
        ok = bool(result.get("success"))
        return StepResult(
            ok=ok,
            confidence=0.9 if ok else 0.2,
            layer=self.layer,
            observed={"summary": result.get("data") or ""},
            error=None if ok else (result.get("data") or "in-browser agent failed"),
        )

    async def run(self, step: StepInput) -> StepResult:
        """LayerAdapter protocol entry — goal mode."""
        return await self.run_goal(step)

    async def close(self) -> None:
        return None
