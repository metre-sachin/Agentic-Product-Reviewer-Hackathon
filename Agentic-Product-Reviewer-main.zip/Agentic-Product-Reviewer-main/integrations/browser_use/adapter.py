"""Browser Use adapter — autonomous browser agent.

https://github.com/browser-use/browser-use

This layer mirrors the browser-use examples: an LLM-driven Agent, a Browser
session that can be managed, CDP-connected, or backed by a system Chrome
profile, vision enabled, loop detection enabled, and screenshots streamed back
to Argus.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Awaitable, Callable
from typing import Any

from integrations.base import Layer, LayerAdapter, StepInput, StepResult

log = logging.getLogger(__name__)

DEFAULT_MAX_STEPS = 40

ScreenshotCallback = Callable[[str], Awaitable[None]]
EmitCallback = Callable[[str, str | None], Awaitable[None]]
StopCallback = Callable[[], Awaitable[bool]]


def _browser_use_available() -> bool:
    try:
        import browser_use  # noqa: F401

        return True
    except Exception:  # noqa: BLE001
        return False


def _has_api_key(model: str, openai_api_key: str, browser_use_api_key: str) -> bool:
    if model.startswith("bu-"):
        return bool(browser_use_api_key or os.getenv("BROWSER_USE_API_KEY"))
    return bool(openai_api_key or os.getenv("OPENAI_API_KEY"))


def _build_llm(model: str, openai_api_key: str, browser_use_api_key: str):
    """Return a browser-use chat model, preferring ChatBrowserUse for bu-* models."""
    try:
        if model.startswith("bu-"):
            from browser_use import ChatBrowserUse  # type: ignore

            return ChatBrowserUse(
                model=model,
                api_key=browser_use_api_key or os.getenv("BROWSER_USE_API_KEY") or None,
            )
    except Exception as exc:  # noqa: BLE001
        log.info("ChatBrowserUse unavailable, falling back to OpenAI: %s", exc)

    try:
        from browser_use import ChatOpenAI  # type: ignore

        return ChatOpenAI(
            model=model if not model.startswith("bu-") else "gpt-4o",
            api_key=openai_api_key or os.getenv("OPENAI_API_KEY") or None,
        )
    except Exception:  # noqa: BLE001
        return None


def _result_text(result: Any) -> str:
    """Extract a human-readable final answer from a browser-use result."""
    structured = getattr(result, "structured_output", None)
    if structured:
        return str(structured)[:4000]
    for attr in ("final_result", "extracted_content"):
        fn = getattr(result, attr, None)
        if callable(fn):
            try:
                value = fn()
                if value:
                    return str(value)[:4000]
            except Exception:  # noqa: BLE001
                continue
    if result is not None:
        return str(result)[:4000]
    return ""


def _looks_blocked(text: str) -> str | None:
    low = text.lower()
    if "approval_needed" in low or "approval needed" in low:
        return "approval_needed"
    if "human_needed" in low or "human needed" in low:
        return "human_needed"
    return None


class BrowserUseAdapter:
    layer = Layer.BROWSER_USE

    def __init__(
        self,
        *,
        model: str = "gpt-4o",
        api_key: str = "",
        browser_use_api_key: str = "",
        headless: bool = True,
        cdp_url: str | None = None,
        use_system_chrome: bool = False,
        chrome_profile: str | None = None,
        storage_state: dict | None = None,
        channel: str | None = None,
        proxy: str | None = None,
        captcha_solver: bool = True,
        max_steps: int = DEFAULT_MAX_STEPS,
        task_id: str | None = None,
        emit: EmitCallback | None = None,
        on_screenshot: ScreenshotCallback | None = None,
        should_stop: StopCallback | None = None,
    ) -> None:
        self._model = model or "gpt-4o"
        self._api_key = api_key
        self._browser_use_api_key = browser_use_api_key
        self._headless = headless
        self._cdp_url = (cdp_url or "").strip() or None
        self._use_system_chrome = use_system_chrome
        self._chrome_profile = (chrome_profile or "").strip() or None
        self._storage_state = storage_state
        self._channel = channel or None
        self._proxy = (proxy or "").strip() or None
        self._captcha_solver = captcha_solver
        self._max_steps = max(8, min(int(max_steps or DEFAULT_MAX_STEPS), 120))
        self._task_id = task_id
        self._emit = emit
        self._on_screenshot = on_screenshot
        self._should_stop = should_stop
        self._browser = None
        self._available: bool | None = None
        self._shot_seq = 0
        self.last_screenshot_url: str | None = None

    @property
    def available(self) -> bool:
        if self._available is None:
            self._available = _browser_use_available() and _has_api_key(
                self._model, self._api_key, self._browser_use_api_key
            )
        return self._available

    async def run(self, step: StepInput) -> StepResult:
        if not self.available:
            return StepResult(
                ok=False,
                confidence=0.0,
                layer=self.layer,
                error="browser_use unavailable or no compatible API key",
            )

        llm = _build_llm(self._model, self._api_key, self._browser_use_api_key)
        if llm is None:
            return StepResult(
                ok=False,
                confidence=0.0,
                layer=self.layer,
                error="no compatible LLM wrapper for browser_use",
            )

        try:
            from browser_use import Agent  # type: ignore
        except Exception as exc:  # noqa: BLE001
            return StepResult(ok=False, confidence=0.0, layer=self.layer, error=str(exc))

        browser = await self._ensure_browser()
        prompt = self._task_prompt(step)

        async def _on_step_end(agent) -> None:  # noqa: ANN001
            await self._capture_screenshot()
            if self._emit is not None:
                await self._emit("Browser Use took a step", None)

        try:
            agent = Agent(
                task=prompt,
                llm=llm,
                browser=browser,
                use_vision=True,
                max_failures=4,
                max_actions_per_step=6,
                enable_planning=True,
                planning_replan_on_stall=2,
                loop_detection_enabled=True,
                final_response_after_failure=True,
                register_should_stop_callback=self._should_stop,
                extend_system_message=self._system_extension(step),
                source="argus",
            )
            result = await agent.run(max_steps=self._max_steps, on_step_end=_on_step_end)
        except TypeError:
            try:
                agent = Agent(task=prompt, llm=llm, browser=browser, use_vision=True)
                result = await agent.run()
            except Exception as exc:  # noqa: BLE001
                log.warning("browser_use run failed: %s", exc)
                return StepResult(ok=False, confidence=0.0, layer=self.layer, error=str(exc))
        except Exception as exc:  # noqa: BLE001
            log.warning("browser_use run failed: %s", exc)
            return StepResult(ok=False, confidence=0.0, layer=self.layer, error=str(exc))

        await self._capture_screenshot()
        text = _result_text(result)
        blocked = _looks_blocked(text)
        if blocked:
            return StepResult(
                ok=False,
                confidence=0.2,
                layer=self.layer,
                observed={"result": text},
                screenshot_url=self.last_screenshot_url,
                error=blocked,
            )
        return StepResult(
            ok=bool(text),
            confidence=0.85 if text else 0.25,
            layer=self.layer,
            observed={"result": text},
            screenshot_url=self.last_screenshot_url,
            error=None if text else "no result",
        )

    async def storage_state(self) -> dict:
        if self._browser is None:
            return {}
        try:
            return await self._browser.export_storage_state()
        except Exception:  # noqa: BLE001
            return {}

    async def current_url(self) -> str:
        if self._browser is None:
            return ""
        try:
            return await self._browser.get_current_page_url()
        except Exception:  # noqa: BLE001
            return ""

    async def close(self) -> None:
        if self._browser is None:
            return
        if self._cdp_url:
            self._browser = None
            return
        try:
            await self._browser.stop()
        except Exception:  # noqa: BLE001
            try:
                await self._browser.close()
            except Exception:  # noqa: BLE001
                pass
        self._browser = None

    async def _ensure_browser(self):
        if self._browser is not None:
            return self._browser

        from browser_use import Browser  # type: ignore

        common: dict[str, Any] = {
            "headless": self._headless,
            "keep_alive": True,
            "cross_origin_iframes": True,
            "captcha_solver": self._captcha_solver,
            "viewport": {"width": 1280, "height": 800},
            "window_size": {"width": 1280, "height": 900},
        }
        if self._proxy:
            common["proxy"] = {"server": self._proxy}

        if self._cdp_url:
            self._browser = Browser(
                cdp_url=self._cdp_url,
                keep_alive=True,
                cross_origin_iframes=True,
                captcha_solver=self._captcha_solver,
            )
        elif self._use_system_chrome:
            self._browser = Browser.from_system_chrome(
                profile_directory=self._chrome_profile,
                **common,
            )
        else:
            if self._channel:
                common["channel"] = self._channel
            if self._storage_state:
                common["storage_state"] = self._storage_state
            self._browser = Browser(**common)
        return self._browser

    def _task_prompt(self, step: StepInput) -> str:
        parts = [step.goal.strip()]
        if step.url:
            parts.append(f"Start at: {step.url}")
        observations = step.data.get("observations") if step.data else None
        if observations:
            parts.append("Known context:\n" + "\n".join(f"- {o}" for o in observations[-5:]))
        parts.append(
            "Act autonomously like a careful browser-use agent. Complete this sub-task in the "
            "browser, using the page pixels and the DOM. For shopping tasks, add requested "
            "items to cart but do not checkout or pay unless explicitly approved. For forms, "
            "fill only NON-sensitive fields (e.g. search boxes, quantities, filters). NEVER "
            "type personal or sensitive data — full name, username, email, phone number, "
            "address, date of birth, password, one-time code, or payment card details — from "
            "the task, context, or a guess. When such a field must be filled, stop and finish "
            "with 'HUMAN_NEEDED: <field>' so the user can provide it. Always stop before an "
            "irreversible submit unless approved."
        )
        if step.data.get("allow_irreversible"):
            parts.append("This step has human approval for the irreversible final click.")
        return "\n\n".join(parts)

    def _system_extension(self, step: StepInput) -> str:
        approved = bool(step.data.get("allow_irreversible")) if step.data else False
        safety = [
            "Argus safety rules:",
            "- Never buy, pay, checkout, place an order, book, submit an application/form, "
            "or send a message unless this run says it has human approval.",
            "- If such an action is required and approval is not present, finish with exactly "
            "'APPROVAL_NEEDED: <what you are about to do>'.",
            "- NEVER fill personal/sensitive fields (name, username, email, phone number, "
            "address, date of birth, password, OTP, payment card) from the task, context, or "
            "a guess — these must come from the user.",
            "- If credentials, OTP, a CAPTCHA, or any personal/sensitive field is required, "
            "finish with exactly 'HUMAN_NEEDED: <what is needed>'.",
            "- Prefer direct clicking of visible buttons/controls over broad containers.",
        ]
        if approved:
            safety.append("- Human approval is present for this step.")
        return "\n".join(safety)

    async def _capture_screenshot(self) -> None:
        if self._browser is None or not self._task_id:
            return
        from app.core.config import settings

        task_dir = settings.media_path / self._task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        self._shot_seq += 1
        path = task_dir / f"bu_{self._shot_seq:04d}.png"
        try:
            await self._browser.take_screenshot(path=str(path), full_page=False)
        except Exception as exc:  # noqa: BLE001
            log.info("browser_use screenshot failed: %s", exc)
            return
        self.last_screenshot_url = settings.screenshot_url(self._task_id, path.name)
        if self._on_screenshot is not None:
            await self._on_screenshot(self.last_screenshot_url)


_: LayerAdapter = BrowserUseAdapter()
